#!/bin/bash -x
#Copyright (C) 2009  GroundWork Open Source Solutions info@groundworkopensource.com
#

date

Box=$(uname -n | sed 's/.groundwork.groundworkopensource.com//')

# Check distro
if [ -f /etc/redhat-release ] ; then
  RHEL_NO=$(fgrep "release" /etc/redhat-release | awk '{ print $7; }' | sed 's/\./ /g' | awk '{ print $1; }')
  distro=rhel5
  builddir=redhat
  qadir=RH
  machinearch=i386
elif [ -f /etc/SuSE-release ] ; then
  RHEL_NO=$(fgrep "VERSION" /etc/SuSE-release | awk '{ print $3; }' | sed 's/\./ /g' | awk '{ print $1; }')
  distro=rhel5
  builddir=packages
  qadir=SUSE
  machinearch=i586
elif [ -f /etc/mandrake-release ] ; then
  distro='Mandrake'
  builddir=
  echo "Plese set build directory in buildRPM.sh file..."
  exit 1
fi

qasubdir=32bit
bitrock_os=32
arch=$(arch)
if [ "$arch" == "x86_64" ] ; then
  export ARCH='_64'
  libdir=lib64
  qasubdir=64bit
  machinearch=x86_64
  bitrock_os=64
else
  libdir=lib
fi

PATH=$PATH:$HOME/bin
export BR_HOME=/root/build/BitRock/groundwork
export GW_HOME=/usr/local/groundwork
export ANT_HOME=$(which ant|sed 's/\/bin\/ant//')
export MAVEN_HOME=$(which maven|sed 's/\/bin\/maven//')
export RELEASE=$distro$ARCH
export DATE=$(date +%Y-%m-%d)

export PATH=$JAVA_HOME/bin:$GW_HOME/bin:$PATH:$MAVEN_HOME/bin:$ANT_HOME/bin

HOME=/home/nagios
BASE=$HOME/groundwork-monitor
BASE_OS=$BASE/monitor-os
BASE_CORE=$BASE/monitor-core
BUILD_DIR=$BASE/build
RUN_DIR=/root/build
MoratDir=/var/www/html/tools/DEVELOPMENT

# Clean up previous builds
rm -rf $GW_HOME
rm -rf $BASE
cp -rp /usr/local/groundwork-common.ent /usr/local/groundwork

# Build monitor-pro
rm -rf $HOME/groundwork-monitor
rm -rf $HOME/groundwork-professional

# Checkout function
svn_co () {
    for i in 1 0; do
	svn co $1 $2 $3 $4 $5 $6 $7
	SVN_EXIT_CODE=$?
	if [ $SVN_EXIT_CODE -eq 0 ]; then
	    break;
	elif [ $i -eq 0 ]; then
	    echo "BUILD FAILED: There has been a problem trying to checkout groundwork files." | mail -s "6.4 Ent Build FAILED in  `hostname` - $DATE" build-info@gwos.com
	    exit 1
	fi
	sleep 30
    done
	
}
# Checkout function
svn_commit () {
    for i in 1 0; do
        svn commit $1 $2 $3 $4 $5 $6 $7
        SVN_EXIT_CODE=$?
        if [ $SVN_EXIT_CODE -eq 0 ]; then
            break;
        elif [ $i -eq 0 ]; then
            echo "BUILD FAILED: There has been a problem trying to checkout groundwork files." | mail -s "6.4 Ent Build FAILED in  `hostname` - $DATE" build-info@gwos.com
            exit 1
        fi
        sleep 30
    done

}


# Check out from subversion
cd $HOME
svn_co -N --username build --password bgwrk http://geneva/groundwork-professional/trunk groundwork-professional
cd $HOME/groundwork-professional

rm -rf $HOME/groundwork-professional/monitor-portal

svn_co --username build --password bgwrk http://geneva/groundwork-professional/trunk/build 
svn_co --username build --password bgwrk http://geneva/groundwork-professional/trunk/enterprise 
svn_co --username build --password bgwrk http://geneva/groundwork-professional/trunk/foundation 
svn_co --username build --password bgwrk http://geneva/groundwork-professional/trunk/guava-packages 
svn_co --username build --password bgwrk http://geneva/groundwork-professional/trunk/images 
svn_co --username build --password bgwrk http://geneva/groundwork-professional/trunk/load-test-tools 
svn_co --username build --password bgwrk http://geneva/groundwork-professional/trunk/patch-scripts 
#svn_co --username build --password bgwrk http://geneva/groundwork-professional/trunk/plugins 
svn_co --username build --password bgwrk http://geneva/groundwork-professional/trunk/monitor-portal 
#svn_co --username build --password bgwrk http://geneva/groundwork-professional/trunk/monitor-starter 

mkdir monitor-agent
mkdir monitor-agent/gdma
cd monitor-agent/gdma
svn_co --username build --password bgwrk http://geneva/groundwork-professional/trunk/monitor-agent/gdma/java-agent

mkdir GDMA2.1
cd GDMA2.1
svn_co --username build --password bgwrk http://geneva/groundwork-professional/trunk/monitor-agent/gdma/GDMA2.1/profiles
svn_co --username build --password bgwrk http://geneva/groundwork-professional/trunk/monitor-agent/gdma/GDMA2.1/linux/gdma/GDMA

svn_co --username build --password bgwrk http://geneva/groundwork-professional/trunk/monitor-agent/gdma/GDMA2.1/linux/gdma/gdma-core

cd $HOME/groundwork-professional
mkdir monitor-spool
cd monitor-spool
svn_co --username build --password bgwrk http://geneva/groundwork-professional/trunk/monitor-spool/scripts/services/spooler-gdma
svn_co --username build --password bgwrk http://geneva/groundwork-professional/trunk/monitor-spool/config


cd $HOME/groundwork-professional
svn_co -N --username build --password bgwrk http://geneva/groundwork-professional/trunk/monitor-professional monitor-professional
cd $HOME/groundwork-professional/monitor-professional
svn_co --username build --password bgwrk http://geneva/groundwork-professional/trunk/monitor-professional/apache 
svn_co --username build --password bgwrk http://geneva/groundwork-professional/trunk/monitor-professional/bronx 
svn_co --username build --password bgwrk http://geneva/groundwork-professional/trunk/monitor-professional/database 
#svn_co --username build --password bgwrk http://geneva/groundwork-professional/trunk/monitor-professional/guava 
svn_co --username build --password bgwrk http://geneva/groundwork-professional/trunk/monitor-professional/log-reporting 
svn_co --username build --password bgwrk http://geneva/groundwork-professional/trunk/monitor-professional/migration 
svn_co --username build --password bgwrk http://geneva/groundwork-professional/trunk/monitor-professional/monarch 
#svn_co --username build --password bgwrk http://geneva/groundwork-professional/trunk/monitor-professional/monarch-patch60 
svn_co --username build --password bgwrk http://geneva/groundwork-professional/trunk/monitor-professional/nagios 
svn_co --username build --password bgwrk http://geneva/groundwork-professional/trunk/monitor-professional/performance 
svn_co --username build --password bgwrk http://geneva/groundwork-professional/trunk/monitor-professional/performance-core 
svn_co --username build --password bgwrk http://geneva/groundwork-professional/trunk/monitor-professional/profiles 
svn_co --username build --password bgwrk http://geneva/groundwork-professional/trunk/monitor-professional/resources 
svn_co --username build --password bgwrk http://geneva/groundwork-professional/trunk/monitor-professional/snmp 
svn_co --username build --password bgwrk http://geneva/groundwork-professional/trunk/monitor-professional/sqldata 
svn_co --username build --password bgwrk http://geneva/groundwork-professional/trunk/monitor-professional/syslib 
svn_co --username build --password bgwrk http://geneva/groundwork-professional/trunk/monitor-professional/tools 
svn_co --username build --password bgwrk http://geneva/groundwork-professional/trunk/monitor-professional/fping

$HOME/groundwork-professional/build/prepare-pro.sh


cd $BASE
# Increment core-build number 
release=$(fgrep "org.groundwork.rpm.release.number" $HOME/groundwork-monitor/monitor-professional/project.properties |awk '{ print $3; }')
if [ "$bitrock_os" == "64" ] ; then
  new_release=`expr $release + 1`
else
  new_release=$release
fi

# Set new core-build release number 
sed -e 's/org.groundwork.rpm.release.number = '$release'/org.groundwork.rpm.release.number = '$new_release'/' $HOME/groundwork-monitor/monitor-professional/project.properties >  $HOME/groundwork-monitor/monitor-professional/project.properties.tmp
mv $HOME/groundwork-monitor/monitor-professional/project.properties.tmp  $HOME/groundwork-monitor/monitor-professional/project.properties

# Commit core project.properties back to subversion 
echo "Increment build(release) number" > svnmessage
if [ "$bitrock_os" == "64" ] ; then
  svn_commit --username build --password bgwrk08 $HOME/groundwork-monitor/monitor-professional/project.properties -F svnmessage
fi
rm -rf svnmessage

# Update build properties
grep -v pro $BR_HOME/build.properties > $BR_HOME/build.properties.tmp
echo pro=6.4-$new_release >> $BR_HOME/build.properties.tmp
mv -f $BR_HOME/build.properties.tmp $BR_HOME/build.properties

# Update monitor's pro version
cat $BR_HOME/groundwork-pro.xml | sed 's/name="pro_build" value="/name="pro_build" value="6.4-'$new_release'/' > $BR_HOME/groundwork-pro.xml.tmp
mv -f $BR_HOME/groundwork-pro.xml.tmp $BR_HOME/groundwork-pro.xml

# Run dos2unix for all the files under profiles directory
chmod +x $BUILD_DIR/d2unix.pl
$BUILD_DIR/d2unix.pl /home/nagios/groundwork-monitor/monitor-professional/profiles

# Start master build script
cd $BASE/monitor-professional
maven allBuild allDeploy

# Build monitor portal
cd $BASE/monitor-portal
maven clean
maven prepare 
maven deploy

# Build Java Agents
echo " Build Java agents for Websphere, Jboss and Tomcat"

cd $BASE/monitor-agent/gdma/java-agent
maven build

find /usr/local/groundwork -name .svn -exec rm -rf {} \;
find /usr/local/groundwork -name .project -exec rm -rf {} \;
find /usr/local/groundwork -name maven.xml -exec rm -rf {} \;
find /usr/local/groundwork -name project.xml -exec rm -rf {} \;

# Set permissions
cd $BASE/build
. set-permissions-pro.sh

date
cp -rp $GW_HOME/apache2/cgi-bin/profiles $BR_HOME/profiles/cgi-bin

cp -rp $GW_HOME/bin/* $BR_HOME/common/bin

cp -rp $GW_HOME/config/* $BR_HOME/core-config
cp -p $BR_HOME/core-config/db.properties $BR_HOME/core-config/db.properties.pro

#GWMON-9523
cp -rp $HOME/groundwork-monitor/foundation/resources/ws_client.properties $BR_HOME/core-config

cp -rp $GW_HOME/databases/* $BR_HOME/databases
cp -rp $BASE/monitor-professional/database/create-monitor-professional-db.sql $BR_HOME/databases

cp -rp $GW_HOME/foundation/feeder/* $BR_HOME/foundation/feeder
cp -p $GW_HOME/log-reporting/lib/LogFile.pm $BR_HOME/foundation/feeder
cp -rp $GW_HOME/foundation/scripts $BR_HOME/foundation

cp -rp $GW_HOME/gwreports/* $BR_HOME/gwreports

cp -rp $GW_HOME/log-reporting/* $BR_HOME/log-reporting

cp -p $GW_HOME/apache2/cgi-bin/snmp/mibtool/index.cgi $BR_HOME/snmp/cgi-bin/snmp/mibtool
cp -rp $GW_HOME/apache2/htdocs/snmp/mibtool/* $BR_HOME/snmp/htdocs/snmp/mibtool

cp -rp $GW_HOME/migration/* $BR_HOME/migration

#Copy JBoss admin script into migration folder
echo "include JBoss admin role script"
cp -rp $HOME/groundwork-professional/monitor-professional/migration/migrate_admin* $BR_HOME/migration

cp -rp $GW_HOME/monarch/automation/conf/* $BR_HOME/monarch/automation/conf

cp -rp $BASE_CORE/nagios/etc/nagios.cfg $BR_HOME/nagios/etc
cp -rp $GW_HOME/nagios/etc/nagios.initd.pro $BR_HOME/nagios/etc
cp -rp $GW_HOME/nagios/eventhandlers/* $BR_HOME/nagios/eventhandlers

cp -rp $GW_HOME/profiles/* $BR_HOME/profiles

cp -rp $GW_HOME/sbin/* $BR_HOME/common/sbin

cp -rp $GW_HOME/tools $BR_HOME

cp -p $BASE/monitor-framework/core/src/resources/portal-core-war/images/gwconnect.gif $BR_HOME/foundation/container/webapps/jboss/jboss-portal.sar/portal-core.war/images

cp -rp $GW_HOME/foundation/container/webapps/jboss/jboss-portal.sar/*.war $BR_HOME/foundation/container/webapps/jboss/jboss-portal.sar
cp -rp $GW_HOME/foundation/container/webapps/jboss/jboss-portal.sar/lib/*.jar $BR_HOME/foundation/container/webapps/jboss/jboss-portal.sar/lib
cp -rp $BR_HOME/core-config/jboss-service.xml $BR_HOME/foundation/container/config/jboss

#JIRA GWMON-8889
echo "Copy monarch webextension into the installer environment..."
cp -p $GW_HOME/foundation/container/webapps/monarch.war $BR_HOME/foundation/container/webapps

#JIRA GWMON-8945 Include packages in the build

echo "Update tomcat configs...."
cp $HOME/groundwork-professional/monitor-portal/applications/nms/conf/context.xml $BR_HOME/foundation/container/webapps/jboss/jboss-web.deployer

cp $HOME/groundwork-professional/monitor-portal/applications/nms/conf/web.xml $BR_HOME/foundation/container/webapps/jboss/jboss-web.deployer/ROOT.war/WEB-INF/

cp $HOME/groundwork-professional/monitor-portal/applications/nms/conf/jboss-web.xml $BR_HOME/foundation/container/webapps/jboss/jboss-web.deployer/ROOT.war/WEB-INF/

echo "Copy nagvis webextension into the installer environment..."
cp -p $GW_HOME/foundation/container/webapps/nagvis.war $BR_HOME/

cd /tmp
rm -rf current-nagvis-fs*
wget http://morat/webextension-source/nagvis/current-nagvis-fs

#JIRA GWMON-9344
echo "Cleanup of any existing nagvis files before expanding the latest package"
rm -rf $BR_HOME/nagvis

tar xfz current-nagvis-fs -C $BR_HOME/

#Fix for GWMON-9365
mkdir $BR_HOME/nagvis/migration
cp $HOME/groundwork-professional/monitor-portal/applications/nagvis/migration/*pl $BR_HOME/nagvis/migration

echo "Media files for Audible Alarms in Event Console"
cp -f $HOME/groundwork-professional/monitor-portal/applications/console/WebContent/resources/*.mp3 $BR_HOME/core-config/media

echo "Copy modified httpd.conf for enterprise version"
cp -rp $HOME/groundwork-professional/monitor-professional/apache/httpd.conf $BR_HOME/apache2/conf
cp -rp $HOME/groundwork-professional/monitor-professional/apache/server.xml $BR_HOME/foundation/container/webapps/jboss/jboss-web.deployer

echo "Update default JBoss web.xml with GroundWork specific one that includes the settings for the default admin user"
cp -fp $HOME/groundwork-professional/monitor-professional/apache/web.xml $BR_HOME/foundation/container/webapps/jboss/jboss-web.deployer/conf

#Network service portlet no longer in standalone package
#cp -p $GW_HOME/foundation/container/webapps/jboss/jboss-portal.sar/network-service-portlet.war $BR_HOME/foundation/container/webapps/jboss/jboss-portal.sar/network-service-portlet.war
#cp -p $GW_HOME/foundation/container/webapps/jboss/jboss-portal.sar/network-service-portlet.war $BR_HOME/network-service/libs/java

#
# Nedi configuration
#
echo "Nedi post build updates"
tar xfz $HOME/groundwork-professional/monitor-portal/applications/nms/conf/patches/nedi_patched.tgz -C $BR_HOME/
chown nagios.nagios $BR_HOME/nedi/*.pl
chown nagios.nagios $BR_HOME/nedi/*.conf

chmod 755 $BR_HOME/nedi/*.pl

#
# Cacti configuration
#
echo "Cacti post build updates"

tar xfz $HOME/groundwork-professional/monitor-portal/applications/nms/conf/patches/cacti_patched.tgz -C $BR_HOME/

echo "Copy default splash screens for plugins"
cp -f $HOME/groundwork-professional/monitor-portal/applications/nms/src/main/webapp/plugins/nedi/* $BR_HOME/cacti/htdocs/splash/nedi
cp -f $HOME/groundwork-professional/monitor-portal/applications/nms/src/main/webapp/plugins/ntop/* $BR_HOME/cacti/htdocs/splash/ntop
cp -f $HOME/groundwork-professional/monitor-portal/applications/nms/src/main/webapp/plugins/weathermap/* $BR_HOME/cacti/htdocs/splash/weathermap

chown -R nagios.nagios $BR_HOME/cacti

# cacti includes ntop plugins directory by default that includes a set of dummy files
# GWMON-9250

rm -rf $BR_HOME/cacti/htdocs/plugins/ntop

echo "Default database for cacti and migration scripts ..."
cp -f $HOME/groundwork-professional/monitor-portal/applications/nms/conf/database/*.sql   $BR_HOME/cacti/scripts

cp $HOME/groundwork-professional/monitor-portal/applications/nms/conf/cacti_updates/cacti_cron.sh $BR_HOME/common/bin/cacti_cron.sh
chmod +x $BR_HOME/common/bin/cacti_cron.sh

cp $HOME/groundwork-professional/monitor-portal/applications/nms/conf/cacti_updates/find_cacti_graphs $BR_HOME/foundation/feeder/find_cacti_graphs
chmod 755 $BR_HOME/foundation/feeder/find_cacti_graphs

cp $HOME/groundwork-professional/monitor-portal/applications/nms/conf/cacti_updates/check_cacti.conf $BR_HOME/cacti
cp $HOME/groundwork-professional/monitor-portal/applications/nms/conf/cacti_updates/check_cacti.pl $BR_HOME/nagios/libexec
chmod +x $BR_HOME/nagios/libexec/check_cacti.pl

cp $HOME/groundwork-professional/monitor-portal/applications/nms/conf/cacti_updates/cacti.properties $BR_HOME/cacti

cp $HOME/groundwork-professional/monitor-portal/applications/nms/conf/cacti_updates/*.xml $BR_HOME/monarch/automation/templates

cp $HOME/groundwork-professional/monitor-portal/applications/nms/conf/cacti_updates/php.ini $BR_HOME/php/etc/

echo "Spine configuration"
cp $BR_HOME/common/etc/spine.conf.dist $BR_HOME/common/etc/spine.conf

# GWMON-9578 Cleanup of files
find $BR_HOME/cacti/htdocs -name *.rej -exec rm -f  '{}' \;

# Create a plugin_downlaod directory
mkdir $BR_HOME/apache2/htdocs/agents/plugin_download

# Include Java Agents in deployment
mkdir $BR_HOME/apache2/htdocs/java-agents

echo "Copy Java agents and property files to Bitrock package"
cp -p $BASE/monitor-agent/gdma/java-agent/appserver/jboss/target/gwos-jboss-monitoringAgent.war  $BR_HOME/apache2/htdocs/java-agents
cp -p $BASE/monitor-agent/gdma/java-agent/appserver/websphere/target/gwos-was-monitoringAgent.war  $BR_HOME/apache2/htdocs/java-agents
cp -p $BASE/monitor-agent/gdma/java-agent/appserver/tomcat/target/gwos-tomcat-monitoringAgent.war  $BR_HOME/apache2/htdocs/java-agents
cp -p $BASE/monitor-agent/gdma/java-agent/appserver/weblogic/target/gwos-wls-monitoringAgent.war  $BR_HOME/apache2/htdocs/java-agents

cp -p $BASE/monitor-agent/gdma/java-agent/appserver/jboss/resources/gwos_jboss.properties  $BR_HOME/apache2/htdocs/java-agents
cp -p $BASE/monitor-agent/gdma/java-agent/appserver/websphere/resources/gwos_websphere.properties  $BR_HOME/apache2/htdocs/java-agents
cp -p $BASE/monitor-agent/gdma/java-agent/appserver/tomcat/resources/gwos_tomcat.properties  $BR_HOME/apache2/htdocs/java-agents
cp -p $BASE/monitor-agent/gdma/java-agent/appserver/weblogic/resources/gwos_weblogic.properties  $BR_HOME/apache2/htdocs/java-agents

echo "Copy gdma profiles"
cp -rp $BASE/monitor-agent/gdma/GDMA2.1/profiles/*.pl $BR_HOME/gdmadist/automationscripts
echo "Copy GDMA library"
cp -rp $BASE/monitor-agent/gdma/GDMA2.1/GDMA $BR_HOME/perl/lib/site_perl/5.8.8
echo "Copy config file for the extended Foundation API"
cp -p $HOME/groundwork-monitor/foundation/resources/gdma_plugin_update.dtd $BR_HOME/core-config

# Include Webmetrics landing page for the lead generation
mkdir $BR_HOME/apache2/htdocs/webmetrics
echo "Adding Webmetrics landing page to package"

cp -rp $HOME/groundwork-professional/monitor-professional/apache/htdocs/webmetrics/* $BR_HOME/apache2/htdocs/webmetrics

# Make sure that user is forwarded to portal login
cp -f $HOME/groundwork-professional/monitor-professional/apache/htdocs/index.html $BR_HOME/apache2

mkdir $BR_HOME/foundation/jboss/native
mkdir $BR_HOME/foundation/jboss/native/lib
mkdir $BR_HOME/foundation/jboss/native/bin

cp $BR_HOME/php-java-bridge/libphp5*.so  $BR_HOME/foundation/jboss/native/lib
cp $BR_HOME/php-java-bridge/libphp5*.so  $BR_HOME/foundation/jboss/native/bin

# Update revision number on morat
svn info /home/nagios/groundwork-monitor/monitor-professional/project.properties | grep Revision: | awk '{ print $2; }' > $RUN_DIR/logs/EE_Revision 

/usr/bin/perl -p -i -e "s:/usr/local/groundwork/nagios:\@\@BITROCK_NAGIOS_ROOTDIR\@\@:g" $BR_HOME/nagios/etc/nagios.cfg

cp -rp $BASE/monitor-portal/applications/statusviewer/src/main/resources/*.properties $BR_HOME/core-config
cp -rp $BASE/monitor-portal/applications/reportserver/src/main/resources/*.properties $BR_HOME/core-config
mv $BR_HOME/core-config/*ViewerResources_??.properties $BR_HOME/core-config/resources

mkdir $HOME/monitor-framework
mkdir $HOME/monitor-framework/josso
cd $HOME/monitor-framework/josso
svn_co --username build --password bgwrk http://geneva/groundwork-professional/trunk/monitor-framework/josso/src/resources

cp -rp $HOME/monitor-framework/josso/resources/josso-auth.properties $BR_HOME/core-config/resources
cp -rp $HOME/monitor-framework/josso/resources/josso-gateway-selfservices.xml $BR_HOME/core-config/resources
cp -rp $HOME/monitor-framework/josso/resources/josso-gateway-web.xml $BR_HOME/core-config/resources
cp -rp $HOME/monitor-framework/josso/resources/josso-gateway-db-stores.xml $BR_HOME/core-config/resources
cp -rp $HOME/monitor-framework/josso/resources/josso-gateway-jmx.xml $BR_HOME/core-config/resources
cp -rp $HOME/monitor-framework/josso/resources/josso-gateway-config.xml $BR_HOME/core-config/resources
cp -rp $HOME/monitor-framework/josso/resources/josso-gateway-auth.xml $BR_HOME/core-config/resources
cp -rp $HOME/monitor-framework/josso/resources/josso-agent-config.xml $BR_HOME/core-config/resources
cp -rp $HOME/monitor-framework/josso/resources/josso-gateway-ldap-stores.xml $BR_HOME/core-config/resources

cp -rp $HOME/groundwork-professional/monitor-portal/applications/nagios/conf/MANIFEST.MF $BR_HOME/nagios/META-INF
cp -rp $HOME/groundwork-professional/monitor-portal/applications/nagios/conf/context.xml $BR_HOME/nagios/WEB-INF
cp -rp $HOME/groundwork-professional/monitor-portal/applications/nagios/conf/web.xml $BR_HOME/nagios/WEB-INF
cp -rp $HOME/groundwork-professional/monitor-portal/applications/nagios/conf/jboss-web.xml $BR_HOME/nagios/WEB-INF
cp -rp $HOME/groundwork-professional/monitor-portal/applications/nagios/conf/login-redirect.jsp $BR_HOME/nagios


# Jira's fixes

# GWMON-6912
cp -rp $BR_HOME/core-config/jboss-service.xml $BR_HOME/foundation/container/config/jboss
##rm -rf $BR_HOME/foundation/container/config
##rm -rf $BR_HOME/core-config/jboss

$BUILD_DIR/d2unix.pl $BASE/enterprise/syslog-ng.conf 
$BUILD_DIR/d2unix.pl $BASE/enterprise/*.pl
cp -p $BASE/enterprise/syslog-ng.conf $BR_HOME/common/etc
cp -p $BASE/enterprise/syslog2nagios.5.3.pl $BR_HOME/common/bin/syslog2nagios.pl
chmod +x $BR_HOME/common/bin/*.pl

# Support script added to distribution
cp -p $BASE/monitor-professional/tools/gwdiags.pl $BR_HOME/common/bin
chmod +x $BR_HOME/common/bin/gwdiags.pl
chown nagios:nagios $BR_HOME/common/bin/gwdiags.pl

cd $HOME
rm -rf css-html%20deliverables
svn_co http://geneva/svn/engineering/projects/GWMON-6.0/css-html%20deliverables

# GWMON-5830
cp -rp $BASE_OS/performance/perfchart.cgi $BR_HOME/performance/cgi-bin/performance

#GWMON-9589
#cp -rp $BASE_OS/performance/perfchart.cgi $BR_HOME/performance/htdocs/performance
rm -f $BR_HOME/performance/htdocs/performance/PerfChartsForms.pm

# GWMON-5834
mkdir $GW_HOME/apache2/conf/groundwork

# GWMON-5841
cp -rp $BASE/monitor-professional/profiles/plugins/*.pl $BR_HOME/nagios/libexec
cp -rp $BASE/monitor-professional/profiles/plugins/*.sh $BR_HOME/nagios/libexec
cp -rp $BASE/monitor-professional/profiles/plugins/com $BR_HOME/nagios/libexec
cp -rp $BASE/monitor-professional/profiles/plugins/nagtomcat.jar $BR_HOME/nagios/libexec

# GWMON-6029
# GWMON-7102
# GWMON-7664
cp -rp $BASE/monitor-professional/profiles/plugins/data $BR_HOME/nagios/libexec
cp -rp /home/nagios/groundwork-professional/monitor-professional/profiles/plugins/lib $BR_HOME/nagios/libexec
cp -rp $BASE/monitor-professional/profiles/plugins/sql $BR_HOME/nagios/libexec
cp -rp $BASE/monitor-professional/profiles/plugins/check_oracle* $BR_HOME/nagios/libexec
cp -rp $BASE/monitor-professional/profiles/plugins/DbCheck.class $BR_HOME/nagios/libexec
cp -rp $BASE/monitor-professional/profiles/*-jdbc-oracle.xml $BR_HOME/profiles

# GWMON-5765
rm -rf $BR_HOME/profiles/service-profile-vmware_esx3_services_profile.xml

# GWMON-5861
if [ -f $BR_HOME/performance/htdocs/performance/images/logos ] ; then
  rm -f $BR_HOME/performance/htdocs/performance/images/logos
fi
mkdir -p $BR_HOME/performance/htdocs/performance/images/logos
cp -rp $BASE/foundation/misc/web-application/console/WebContent/assets/icons/services.gif $BR_HOME/performance/htdocs/performance/images/logos

# GWMON-5369
rm -rf $BR_HOME/reports/utils/utils

# GWMON-7849
mkdir /tmp/reports
svn_co http://archive.groundworkopensource.com/groundwork-opensource/trunk/reports/utils /tmp/reports
mv /tmp/reports/dashboard_avail_load.pl $BR_HOME/reports/utils
chmod 755 $BR_HOME/reports/utils/dashboard_avail_load.pl
chown nagios:nagios $BR_HOME/reports/utils/dashboard_avail_load.pl
rm -rf /tmp/reports

# GWMON-5976
chmod +x $BASE/monitor-professional/monarch/bin/*
cp -rp $BASE/monitor-professional/monarch/lib/* $BR_HOME/monarch/lib
cp -rp $BASE/monitor-professional/monarch/bin/* $BR_HOME/monarch/bin
######chmod +x $BR_HOME/monarch/bin/nagios-foundation-sync.pl

# GWMON-5905
cp -rp $BASE/monitor-professional/migration/migrate-monarch.sql $BR_HOME/migration

# GWMON-5985
rm -rf $BR_HOME/foundation/feeder/nagios2master.pl

# GWMON-2600
cp -rp $BASE/monitor-professional/nagios/etc/nagios.cfg $BR_HOME/nagios/etc

# GWMON-5984
chmod 755 $BR_HOME/profiles
chmod 444 $BR_HOME/profiles/*.xml
chmod 444 $BR_HOME/profiles/*.gz
chmod 755 $BR_HOME/nagios/libexec
chmod +x $BR_HOME/nagios/libexec/*.sh
chmod +x $BR_HOME/nagios/libexec/*.pl

# GWMON-6066
chmod 640 $BR_HOME/core-config/*properties*

# GWMON-6842
rm -f $BR_HOME/nagios/libexec/*.c

# GWMON-6503
rm -f $BR_HOME/profiles/perfconfig-vmware_esx3_services_profile.xml

# GWMON-7144
cp -p $BASE_OS/performance-core/admin/import_perfconfig.pl $BR_HOME/tools/profile_scripts
chmod +x $BR_HOME/tools/profile_scripts/*.pl

# GWMON-7428
cp -p $BASE_OS/syslib/gwservices.ent $BR_HOME/services/gwservices
chmod +x $BR_HOME/services/gwservices

# GWMON-7440
cp -p $BASE/monitor-framework/core/src/resources/portal-core-war/images/gwconnect.gif $BR_HOME/foundation/container/webapps/jboss/jboss-portal.sar/portal-core.war/images

# GWMON-7739
rm -f $BR_HOME/nagios/eventhandlers/process_service_perf.pl
rm -f $BR_HOME/nagios/eventhandlers/process_service_perf_db.pl

#GWMON-8544
cp -p $BASE_OS/performance-core/eventhandler/perfdata.properties.ee $BR_HOME/core-config/perfdata.properties

# GWMON-6937
rm -f $BR_HOME/core-config/migration.properties

# GWMON-6060
cp -p $BASE/monitor-portal/applications/console/src/java/console-admin-config.xml $BR_HOME/core-config

cp -p $BASE/monitor-professional/bronx/conf/bronx.cfg $BR_HOME/core-config
cp -p $BR_HOME/network-service/config/network-service.properties $BR_HOME/core-config

# GWMON-7771
cp -p $BASE/monitor-portal/applications/console/src/java/console.properties $BR_HOME/core-config

# GWMON-7803
cp -p $BASE/foundation/misc/web-application/reportserver/reports/StatusReports/* $BR_HOME/gwreports/StatusReports

# Force process_foundation_db_update is on
Process_Foundation_Db_Update=$(grep process_foundation_db_update $BR_HOME/nagios/eventhandlers/process_service_perf_db_file.pl | awk '{ print $4; }' | sed 's/;//')
sed -i 's/process_foundation_db_updates = '$Process_Foundation_Db_Update'/process_foundation_db_updates = 1/' $BR_HOME/nagios/eventhandlers/process_service_perf_db_file.pl

Process_Foundation_Db_Update=$(grep process_foundation_db_update $BR_HOME/nagios/eventhandlers/process_service_perfdata_file | awk '{ print $4; }' | sed 's/;//')
sed -i 's/process_foundation_db_updates = '$Process_Foundation_Db_Update'/process_foundation_db_updates = 1/' $BR_HOME/nagios/eventhandlers/process_service_perfdata_file

sed -i 's/send_events_for_pending_to_ok = 0/send_events_for_pending_to_ok = 1/' $BR_HOME/foundation/feeder/nagios2collage_socket.pl

#GWMON-9398
cd $BR_HOME/core-config
rm -f status-feeder.properties
wget http://archive.groundworkopensource.com/groundwork-opensource/trunk/foundation/collagefeeder/scripts/status-feeder.properties
chown nagios:nagios status-feeder.properties

#GWMON-9386 -- fping feeder script update
echo "Make sure latest fping feeder script is included...."
cp -fp $HOME/groundwork-professional/monitor-professional/fping/usr/local/groundwork/foundation/feeder/fping_process.pl $BR_HOME/fping-feeder/usr/local/groundwork/foundation/feeder/
cp -fp $HOME/groundwork-professional/monitor-professional/fping/usr/local/groundwork/foundation/feeder/fping_process.pl $BR_HOME/fping-feeder/usr/local/groundwork/nagios/libexec/

#Spooler-gdma
cp -rp $HOME/groundwork-professional/monitor-agent/gdma/GDMA2.1/gdma-core/bin/gdma_spool_processor.pl $BR_HOME/groundwork-spooler/gdma/bin

cp -rp $HOME/groundwork-professional/monitor-spool/config/gdma_auto.conf $BR_HOME/groundwork-spooler/gdma/config
cp -rp $HOME/groundwork-professional/monitor-spool/config/gwmon_localhost.cfg $BR_HOME/groundwork-spooler/gdma/config
rm -rf  $BR_HOME/groundwork-spooler/spooler-gdma
cp -rp $HOME/groundwork-professional/monitor-spool/spooler-gdma $BR_HOME/groundwork-spooler


# Setting up the righ ownership 
find $BR_HOME -name perfchart.cgi -exec chmod +x {} \;

# Cleanup and set ownership
find $BR_HOME -name .svn -exec rm -rf {} \;
chown -R nagios:nagios $BR_HOME

date
echo "Monitor-pro build is done at `date`"
##########################################

echo "EntBuild.sh is done..."
