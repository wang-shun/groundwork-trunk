#include <signal.h>
#include <sys/param.h>
#include <pwd.h>
static char *nmap_pl = "/usr/local/groundwork/monarch/bin/nmap_scan_one.pl";
static char *trusted_env[]={"PATH=/usr/local/groundwork/bin:/usr/bin:/usr/sbin:/sbin:/bin",0};
int main(int argc, char *argv[])
{
    char *ip_address = argv[1];
    struct passwd *pwd;
            int i;
            uid_t uid;
        for (i=0;i < NSIG;i++)  { 
            if(i!= SIGKILL && i!=SIGCHLD)
                    {(void) signal(i,SIG_IGN);
            }
                                                }
        uid=getuid();

        if ( (pwd = getpwuid(uid))== (struct passwd *)0 )
                    exit(1);
        setuid((uid_t)0);

        execle(nmap_pl,nmap_pl,ip_address,(char *)0,trusted_env);
        setuid(uid);
        exit(1);
}

