#!/usr/bin/perl --
#
# Copyright 2007 GroundWork Open Source, Inc. (<93>GroundWork<94>) # All rights reserved. This program is free software; you can redistribute it and/or # modify it under the terms of the GNU General Public License version 2 as published # by the Free Software Foundation.
#
# This program is distributed in the hope that it will be useful, but WITHOUT ANY # WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A # PARTICULAR PURPOSE.  See the GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License along with this # program; if not, write to the Free Software Foundation, Inc., 51 Franklin Street, # Fifth Floor, Boston, MA 02110-1301, USA.
#
use strict;
my $debug = 0;

my $statprogram = "/usr/local/groundwork/nagios/bin/nagiostats";

my ($min,$max,$avg);
my @lines = `$statprogram`;
foreach my $line (@lines) {
        chomp $line;
        if ($line =~ /Active Service Latency:\s+([\d\.]+)\s\/\s([\d\.]+)\s\/\s([\d\.]+)/) {
                $min=$1;
                $max=$2;
                $avg=$3;
        }
}

print "Nagios latency: Min=$min, Max=$max, Avg=$avg | Min=$min;;;; Max=$max;;;; Avg=$avg;;;;"; exit 0;



