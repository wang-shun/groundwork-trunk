#!/bin/sh -ax

mkdir -p /usr/local/groundwork/gdma
groupadd gdma
useradd -g gdma -d /usr/local/groundwork/gdma gdma

cd ~gdma
tar -xzf /root/gdma/*agent*.tar.gz

cd /root/gdma

tar -xzf Compress-Raw-Zlib-2.015.tar.gz
tar -xzf Compress-Zlib-2.015.tar.gz
tar -xzf Crypt-SSLeay-0.57.tar.gz
tar -xzf HTML-Parser-3.58.tar.gz
tar -xzf HTML-Tagset-3.20.tar.gz
tar -xzf IO-Compress-Base-2.015.tar.gz
tar -xzf IO-Compress-Zlib-2.015.tar.gz
tar -xzf libwww-perl-5.820.tar.gz
tar -xzf openssl-0.9.7l.tar.gz

cd IO-Compress-Base-2.015
make clean
perl Makefile.PL
make
make install
make clean
perl Makefile.PL PREFIX=/usr/local/groundwork/gdma
make
make install
cd ../Compress-Raw-Zlib-2.015/
make clean
perl Makefile.PL
make
make install
make clean
perl Makefile.PL PREFIX=/usr/local/groundwork/gdma
make
make install
cd ../IO-Compress-Zlib-2.015/
make clean
perl Makefile.PL
make
make install
make clean
perl Makefile.PL PREFIX=/usr/local/groundwork/gdma
make
make install
cd ../Compress-Zlib-2.015/
make clean
perl Makefile.PL
make
make install
make clean
perl Makefile.PL PREFIX=/usr/local/groundwork/gdma
make
make install
cd ../IO-Compress-Zlib-2.015/
make clean
perl Makefile.PL
make
make install
make clean
perl Makefile.PL PREFIX=/usr/local/groundwork/gdma
make
make install
cd ../HTML-Tagset-3.20/
make clean
perl Makefile.PL
make
make install
make clean
perl Makefile.PL PREFIX=/usr/local/groundwork/gdma
make
make install
cd ../HTML-Parser-3.58/
make clean
perl Makefile.PL
make
make install
make clean
perl Makefile.PL PREFIX=/usr/local/groundwork/gdma
make
make install
cd ../openssl-0.9.7l/
./config --prefix=/usr/local/groundwork/gdma --openssldir=/usr/local/groundwork/gdma/openssl
# edit Makefile to add -fPIC at the end of the CFLAGS variable
exit
make
make install
cd ../Crypt-SSLeay-0.57
perl Makefile.PL
make
make install
make clean
perl Makefile.PL PREFIX=/usr/local/groundwork/gdma --lib=/usr/local/groundwork/gdma
make
make install
cd ../libwww-perl-5.820
perl Makefile.PL PREFIX=/usr/local/groundwork/gdma 
make
make install
# update gdma_check.pl to remove the Data::Dumper reference, and add the use lib qw(/usr/local/groundwork/gdma/lib64 /usr/local/groundwork/gdma/lib); line

cd /usr/local/groundwork
chown -R gdma.gdma gdma
cd gdma/libexec
chown root check_dhcp check_icmp
chmod u+s check_dhcp check_icmp

