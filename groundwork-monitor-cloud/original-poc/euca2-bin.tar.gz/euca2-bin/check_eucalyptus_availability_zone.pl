#!/usr/local/groundwork/perl/bin/perl

# Copyright 2010 GroundWork Open Source, Inc. (GroundWork)
# All rights reserved.
#
# check_eucalyptus_availability_zone.pl
#
# Nagios plugins for determining if an availability zone is present, and if so
# if there are any problems with capacity.
#
# Change log:
#
# 2010-03-16    v0.1   Initial version.

use strict;

use lib qq(/usr/local/groundwork/nagios/libexec);

use utils qw(%ERRORS);

my $version     = "0.1";
my $PROGNAME    = "check_eucalyptus_availability_zone.pl";

use Getopt::Long;
use vars qw ($opt_v $opt_h $opt_z);

my $status = GetOptions
	("z=s"	=> \$opt_z, "zone=s"	=> \$opt_z,
	"v"	=> \$opt_v, "version"	=> \$opt_v,
	"h"	=> \$opt_h, "help"	=> \$opt_h);

if ($opt_h || ! $opt_z) {
  print "Usage: $PROGNAME -z|--zone=<s> [-v|--version] [-h|--help]

  where <s> is the name of an availability zone.\n";
  exit $ERRORS{'OK'};
}

if ($opt_v) {
  print "Version: $PROGNAME $version\n";
  exit $ERRORS{'OK'};
}

#################################################################
# Read availability zone data from cloud
#################################################################

my $azout_command = "ec2-describe-availability-zones verbose";
my @azout = `source ~nagios/setenv-euca2.sh ; \$EC2_HOME/bin/$azout_command`;
my $azcurr = "";
my $state = $ERRORS{'OK'};
my $output = "";
my $perfoutput = "";

foreach my $azline (@azout) {
  chomp $azline;
  my @azparams = split (/\t/, $azline);
  if ($azparams[1] !~ /\|\-/) { 
    $azcurr = $azparams[1];
    next;
  }
  if ($azcurr =~ /$opt_z/) {
    if ($azparams[1] =~ /vm types/) { next; }
    $azparams[1] =~ s/\|\- //;
    my ($free,$max) = $azparams[2] =~ /0+(\d+) \/ 0+(\d+)/;
    $perfoutput.=" $azparams[1]=$free;0;;0;$max";
    if (! $free) { 
      $state = $ERRORS{'WARNING'};
    }
    $output.=" $azparams[1] ($free free)";
  } else { next; }
}

if (! $output) {
  print "Availability zone $opt_z not found.\n";
  exit $ERRORS{'CRITICAL'};
} else {
  print "VM Types: $output | $perfoutput\n"; 
  exit $state;
}

exit $ERRORS{'UNKNOWN'};
