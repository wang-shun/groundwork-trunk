#!/usr/local/groundwork/perl/bin/perl

# Copyright 2010 GroundWork Open Source, Inc. (GroundWork)
# All rights reserved.
#
# euca2-config.pl
#
# Script that should be run regularly via cron as user nagios to update GroundWork
# Monitor 6.1 Enterprise with Eucalyptus cloud instances and availability zones.  It
# relies on the EC2 API tools and Eucalyptus environment variables to be set before
# running.
#
# Change log:
#
# 2010-03-16    v0.1   Initial version.
# 2010-03-17    v0.2   Tracking of inactive hosts.

BEGIN {
        unshift @INC, "/usr/local/groundwork/core/monarch/lib";
};

use strict;

my $version     = "0.2";
my $PROGNAME    = "euca2-config.pl";
my $debug       = 0;
my $test	= 0;

my $inactive		= "Cloud Inactive Hosts";
my $defaultprofile	= "cloud-machine-default";
my $azprofile		= "cloud-availability-zone";

use Getopt::Long;
use vars qw ($opt_d $opt_t $opt_v $opt_h);

my $status = GetOptions
	("d=s"	=> \$opt_d, "debug=s"	=> \$opt_d,
	"v"	=> \$opt_v, "version"	=> \$opt_v,
	"t"	=> \$opt_t, "test"	=> \$opt_t,
	"h"	=> \$opt_h, "help"	=> \$opt_h);

if ($opt_h) {
  print "Usage: $PROGNAME [-d|--debug <#>] [-v|--version] [-t|--test] [-h|--help]

  where <#> is 0 or higher.  Set <#> to 1 or higher for debug messages.
  test mode is a dry run.  No configuration changes will be made in this mode.\n";
  exit 0;
}

if ($opt_v) {
  print "Version: $PROGNAME $version\n";
  exit 0;
}

if ($opt_d) { $debug = $opt_d; }

if ($opt_t) {
  $test = 1;
  if ($debug) { print "debug: test mode is set. No configuration changes will be made in this mode even if debug output says otherwise.\n"; }
}

#################################################################
# Read data from cloud
#################################################################

# Get list of availability zones

my $azout_command = $ENV{"EC2_HOME"}."/bin/ec2-describe-availability-zones";
my @azout = `$azout_command`;
my %az = ();

foreach my $azline (@azout) {
  chomp $azline;
  if ($azline =~ /^AVAILABILITYZONE/) {
    my @azparams = split (/\t/, $azline);
    $az{"$azparams[1]"}->{ADDRESS}=$azparams[2];
    $az{"$azparams[1]"}->{PROFILE}=$azprofile;
  } else { next; }
}

if ($debug) {
  print "debug: $azout_command:\n@azout\n";
  foreach my $key (keys %az) {
    print "Availability zone = $key\n\tADDRESS = " . $az{"$key"}->{ADDRESS} . "\n";
    print "\tPROFILE = " . $az{"$key"}->{PROFILE} . "\n";
  }
}

# Get list of images

my $imout_command = $ENV{"EC2_HOME"}."/bin/ec2-describe-images";
my @imout = `$imout_command`;
my %im = ();

foreach my $imline (@imout) {
  chomp $imline;
  if ($imline =~ /^IMAGE/) {
    my @imparams = split (/\t/, $imline);
    $im{"$imparams[1]"}->{MANIFEST}=$imparams[2];
  } else { next; }
}

if ($debug) {
  print "debug: $imout_command:\n@imout\n";
  foreach my $key (keys %im) {
    print "Image = $key\n\tMANIFEST = " . $im{"$key"}->{MANIFEST} . "\n";
  }
}

# Get list of instances

my $inout_command = $ENV{"EC2_HOME"}."/bin/ec2-describe-instances";
my @inout = `$inout_command`;
my %in = ();
my @profiles = ();

foreach my $inline (@inout) {
  chomp $inline;
  if ($inline =~ /^INSTANCE/) {
    my @inparams = split (/\t/, $inline);
    $in{"$inparams[1]"}->{AMI}=$inparams[2];
    $in{"$inparams[1]"}->{PUBDNS}=$inparams[3];
    $in{"$inparams[1]"}->{PRIVDNS}=$inparams[4];
    $in{"$inparams[1]"}->{STATE}=$inparams[5];
    $in{"$inparams[1]"}->{TYPE}=$inparams[9];
    $in{"$inparams[1]"}->{AZ}=$inparams[11];
    $in{"$inparams[1]"}->{PROFILE}="cloud-machine-$inparams[2]";
    push @profiles, "cloud-machine-$inparams[2]";
  } else { next; }
}

if ($debug) {
  print "debug: $inout_command:\n@inout\n";
  foreach my $key (keys %in) {
    print "Instance = $key\n\tAMI = " . $in{"$key"}->{AMI} . "\n";
    print "\tPUBDNS = " . $in{"$key"}->{PUBDNS} . "\n";
    print "\tPRIVDNS = " . $in{"$key"}->{PRIVDNS} . "\n";
    print "\tSTATE = " . $in{"$key"}->{STATE} . "\n";
    print "\tTYPE = " . $in{"$key"}->{TYPE} . "\n";
    print "\tAZ = " . $in{"$key"}->{AZ} . "\n";
    print "\tPROFILE = " . $in{"$key"}->{PROFILE} . "\n";
  }
}

#################################################################
# Read data from Monarch and make updates as necessary
#################################################################

use dassmonarch;
use monarchWrapper;
my $monarchapi = dassmonarch->new();

if ($debug) {
  print "debug: reading and updating Monarch...\n";
  $monarchapi->set_debuglevel('verbose');
} else {
  $monarchapi->set_debuglevel('none');
}

my @inactivehosts = ();

# create inactive hostgroup if necessary
if (! $monarchapi->hostgroup_exists($inactive) ) {
  if ($debug) { print "debug: inactive hostgroup = $inactive does not exist.\n"; }
  if (! $opt_t) {
    my $result = $monarchapi->create_hostgroup($inactive,$inactive);
  }
} else {
  if ($debug) { print "debug: inactive hostgroup = $inactive already exists.\n"; }
  # get members of inactive hostgroup for adding back if they are NOT returned in
  # the list of instances
  @inactivehosts = $monarchapi->get_hosts_in_hostgroup($inactive);
  if (! $opt_t) {
    my $result = $monarchapi->delete_hostgroup($inactive);
    my $result = $monarchapi->create_hostgroup($inactive,$inactive);
  }
}

# add nonexistent instances back to inactive hostgroup if they were defined as hosts
# already

if (@inactivehosts) {
  if ($debug) { print "debug: processing inactive hosts from Monarch\n"; }
} else {
  if ($debug) { print "debug: no inactive hosts in Monarch.\n"; }
}

foreach my $instance (@inactivehosts) {
  if (! $opt_t && ! $in{"$instance"} ) { my $result = $monarchapi->assign_hostgroup($instance,$inactive); }
}

# Go through list of availability zones and see if they exist as
# either host groups or virtual hosts.  If not, then create them

if ($debug) { print "debug: checking for availability zones in Monarch.\n"; }

foreach my $azitem (keys %az) {
  # create host group if necesary
  if (! $monarchapi->hostgroup_exists($azitem) ) {
    if ($debug) { print "debug: availability zone = $azitem does not exist as host group.\n"; }
    if (! $opt_t) { my $result = $monarchapi->create_hostgroup($azitem,$azitem); }
  } else {
    if ($debug) { print "debug: availability zone = $azitem already exists as host group.\n"; }
    if (! $opt_t) {
      my $result = $monarchapi->delete_hostgroup($azitem);
      my $result = $monarchapi->create_hostgroup($azitem,$azitem);
    }
  }
  # create virtual host - call import_host_api with update flag set
  if (! $monarchapi->host_exists($azitem) ) {
    if ($debug) { print "debug: availability zone = $azitem does not exist as a host.\n"; }
  } else {
    if ($debug) { print "debug: availability zone = $azitem already exists as a host.\n"; }
  }
  if (! $opt_t) { my $result = $monarchapi->import_host_api($azitem,$azitem,$az{"$azitem"}->{ADDRESS},$az{"$azitem"}->{PROFILE},1); }

  # assign virtual host to host group
  my $result = $monarchapi->assign_hostgroup($azitem,$azitem);
}

# Go through list of assumed host profiles for instances,
# verify they exist, if they do then get the host profile
# description and use it as the name of a host group.  We
# need to do this before looping through defined instances
# because we want to flush out the host group by deleting and
# recreating it.  KNOWN ISSUE:  We are getting the list of
# assumed host profiles from instance image data that comes
# from the EC2 API.  If an instance doesn't appear in that
# list or it changes it's image then we may end up leaving
# stale host groups in Monarch.

if ($debug) { print "debug: processing host profiles to check for host groups.\n"; }

foreach my $profile (@profiles) {
  my %where = ( 'name' => $profile );
  my %results = monarchWrapper->fetch_one_where( 'profiles_host', \%where );
  my $profiledesc = $results{'description'};
  if ($debug) { print "debug: processing host profile = $profile.\n"; }
  if ($monarchapi->hostgroup_exists($profiledesc) ) {
    if (! $opt_t) { my $result = $monarchapi->delete_hostgroup($profiledesc); }
  }
  if (! $opt_t) { my $result = $monarchapi->create_hostgroup($profiledesc,$profiledesc); }
}

# Go through list of instances and see if they exist.  If not,
# then create them and assign them to the relevant host groups.
# Also set Nagios parent to the availability zone virtual host.

foreach my $initem (keys %in) {
  if ($debug) { print "debug: processing instance = $initem.\n"; }
  if (! $monarchapi->host_exists($initem) ) {
    if ($debug) { print "debug: instance = $initem does not exist as a host.\n"; }
    if ($in{"$initem"}->{STATE} !~ /running/ ) {
      if ($debug) { print "debug: instance = $initem is NOT running.\n"; }
      next;
    }
  }
  if ($in{"$initem"}->{STATE} =~ /running/ ) {
    if ($debug) {print "debug: instance = $initem is running.\n"; }
    if (! $opt_t) {
      if (! $monarchapi->get_hostprofileid($in{"$initem"}->{PROFILE}) ) {
        if ($debug) { print "debug: host profile = " . $in{"$initem"}->{PROFILE} . " doesn't exist.  Using default.\n"; }
        $in{"$initem"}->{PROFILE}=$defaultprofile;
      }
      my $result = $monarchapi->import_host_api($initem,$initem,$in{"$initem"}->{PUBDNS},$in{"$initem"}->{PROFILE},1);
      my $result = $monarchapi->assign_hostgroup($initem,$in{"$initem"}->{AZ});
      # add in here the assignment to the relevant host profile host group
      # will need to look up for the existence of a host group again based on profile name
      my %where = ( 'name' =>  $in{"$initem"}->{PROFILE} );
      my %results = monarchWrapper->fetch_one_where( 'profiles_host', \%where );
      my $profiledesc = $results{'description'};
      if ($monarchapi->hostgroup_exists($profiledesc) && ! $opt_t ) { my $result = $monarchapi->assign_hostgroup($initem,$profiledesc); }
      my @parents;
      push @parents, $in{"$initem"}->{AZ};
      my $result = $monarchapi->set_parents($initem,\@parents);
    }
  } else {
    if ($debug) {print "debug: instance = $initem is NOT running.\n"; }
    if (! $opt_t) { my $result = $monarchapi->assign_hostgroup($initem,$inactive); }
  }
}

# Perform a commit operation

if ($debug) { print "debug: performing commit.\n"; }

if (! $opt_t) { my $result = $monarchapi->generateAndCommit(); }

exit 0;
