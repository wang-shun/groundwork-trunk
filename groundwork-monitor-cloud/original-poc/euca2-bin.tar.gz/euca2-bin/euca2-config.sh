#!/bin/bash -x
source /usr/local/groundwork/users/nagios/setenv-euca2.sh

/usr/local/groundwork/perl/bin/perl /usr/local/groundwork/users/nagios/euca2-bin/euca2-config.pl
