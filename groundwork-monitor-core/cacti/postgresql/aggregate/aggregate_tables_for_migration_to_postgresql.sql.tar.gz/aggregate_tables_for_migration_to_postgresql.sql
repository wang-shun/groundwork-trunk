--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'LATIN1';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

SET search_path = public, pg_catalog;

ALTER TABLE ONLY public.plugin_aggregate_color_templates DROP CONSTRAINT plugin_aggregate_color_templates_pkey;
ALTER TABLE ONLY public.plugin_aggregate_color_template_items DROP CONSTRAINT plugin_aggregate_color_template_items_pkey;
ALTER TABLE public.plugin_aggregate_color_templates ALTER COLUMN color_template_id DROP DEFAULT;
ALTER TABLE public.plugin_aggregate_color_template_items ALTER COLUMN color_template_item_id DROP DEFAULT;
DROP SEQUENCE public.plugin_aggregate_color_templates_color_template_id_seq;
DROP TABLE public.plugin_aggregate_color_templates;
DROP SEQUENCE public.plugin_aggregate_color_template_item_color_template_item_id_seq;
DROP TABLE public.plugin_aggregate_color_template_items;
SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: plugin_aggregate_color_template_items; Type: TABLE; Schema: public; Owner: cactiuser; Tablespace: 
--

CREATE TABLE plugin_aggregate_color_template_items (
    color_template_item_id integer NOT NULL,
    color_template_id integer DEFAULT 0 NOT NULL,
    color_id integer DEFAULT 0 NOT NULL,
    sequence integer DEFAULT 0 NOT NULL
);


ALTER TABLE plugin_aggregate_color_template_items OWNER TO cactiuser;

--
-- Name: plugin_aggregate_color_template_item_color_template_item_id_seq; Type: SEQUENCE; Schema: public; Owner: cactiuser
--

CREATE SEQUENCE plugin_aggregate_color_template_item_color_template_item_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE plugin_aggregate_color_template_item_color_template_item_id_seq OWNER TO cactiuser;

--
-- Name: plugin_aggregate_color_template_item_color_template_item_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: cactiuser
--

ALTER SEQUENCE plugin_aggregate_color_template_item_color_template_item_id_seq OWNED BY plugin_aggregate_color_template_items.color_template_item_id;


--
-- Name: plugin_aggregate_color_templates; Type: TABLE; Schema: public; Owner: cactiuser; Tablespace: 
--

CREATE TABLE plugin_aggregate_color_templates (
    color_template_id integer NOT NULL,
    name character varying(255) DEFAULT ''::character varying NOT NULL
);


ALTER TABLE plugin_aggregate_color_templates OWNER TO cactiuser;

--
-- Name: plugin_aggregate_color_templates_color_template_id_seq; Type: SEQUENCE; Schema: public; Owner: cactiuser
--

CREATE SEQUENCE plugin_aggregate_color_templates_color_template_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE plugin_aggregate_color_templates_color_template_id_seq OWNER TO cactiuser;

--
-- Name: plugin_aggregate_color_templates_color_template_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: cactiuser
--

ALTER SEQUENCE plugin_aggregate_color_templates_color_template_id_seq OWNED BY plugin_aggregate_color_templates.color_template_id;


--
-- Name: color_template_item_id; Type: DEFAULT; Schema: public; Owner: cactiuser
--

ALTER TABLE ONLY plugin_aggregate_color_template_items ALTER COLUMN color_template_item_id SET DEFAULT nextval('plugin_aggregate_color_template_item_color_template_item_id_seq'::regclass);


--
-- Name: color_template_id; Type: DEFAULT; Schema: public; Owner: cactiuser
--

ALTER TABLE ONLY plugin_aggregate_color_templates ALTER COLUMN color_template_id SET DEFAULT nextval('plugin_aggregate_color_templates_color_template_id_seq'::regclass);


--
-- Name: plugin_aggregate_color_template_items_pkey; Type: CONSTRAINT; Schema: public; Owner: cactiuser; Tablespace: 
--

ALTER TABLE ONLY plugin_aggregate_color_template_items
    ADD CONSTRAINT plugin_aggregate_color_template_items_pkey PRIMARY KEY (color_template_item_id);


--
-- Name: plugin_aggregate_color_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: cactiuser; Tablespace: 
--

ALTER TABLE ONLY plugin_aggregate_color_templates
    ADD CONSTRAINT plugin_aggregate_color_templates_pkey PRIMARY KEY (color_template_id);


--
-- PostgreSQL database dump complete
--

