--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'LATIN1';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

SET search_path = public, pg_catalog;

DROP INDEX public.plugin_nectar_mailtime;
DROP INDEX public.plugin_nectar_items_report_id;
ALTER TABLE ONLY public.plugin_nectar DROP CONSTRAINT plugin_nectar_pkey;
ALTER TABLE ONLY public.plugin_nectar_items DROP CONSTRAINT plugin_nectar_items_pkey;
ALTER TABLE public.plugin_nectar_items ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.plugin_nectar ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE public.plugin_nectar_items_id_seq;
DROP TABLE public.plugin_nectar_items;
DROP SEQUENCE public.plugin_nectar_id_seq;
DROP TABLE public.plugin_nectar;
SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: plugin_nectar; Type: TABLE; Schema: public; Owner: cactiuser; Tablespace: 
--

CREATE TABLE plugin_nectar (
    id integer NOT NULL,
    user_id integer DEFAULT 0 NOT NULL,
    name character varying(100) DEFAULT ''::character varying NOT NULL,
    cformat character varying(2) DEFAULT ''::character varying NOT NULL,
    format_file character varying(255) DEFAULT ''::character varying NOT NULL,
    font_size smallint DEFAULT 0 NOT NULL,
    alignment smallint DEFAULT 0 NOT NULL,
    graph_linked character varying(2) DEFAULT ''::character varying NOT NULL,
    intrvl smallint DEFAULT 0 NOT NULL,
    count smallint DEFAULT 0 NOT NULL,
    start_offset integer DEFAULT 0 NOT NULL,
    mailtime bigint DEFAULT 0 NOT NULL,
    subject character varying(64) DEFAULT ''::character varying NOT NULL,
    from_name character varying(40) NOT NULL,
    from_email text NOT NULL,
    email text NOT NULL,
    bcc text NOT NULL,
    attachment_type smallint DEFAULT 1 NOT NULL,
    graph_height smallint DEFAULT 0 NOT NULL,
    graph_width smallint DEFAULT 0 NOT NULL,
    graph_columns smallint DEFAULT 0 NOT NULL,
    thumbnails character varying(2) DEFAULT ''::character varying NOT NULL,
    lastsent bigint DEFAULT 0 NOT NULL,
    enabled character varying(2) DEFAULT ''::character varying
);


ALTER TABLE plugin_nectar OWNER TO cactiuser;

--
-- Name: plugin_nectar_id_seq; Type: SEQUENCE; Schema: public; Owner: cactiuser
--

CREATE SEQUENCE plugin_nectar_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE plugin_nectar_id_seq OWNER TO cactiuser;

--
-- Name: plugin_nectar_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: cactiuser
--

ALTER SEQUENCE plugin_nectar_id_seq OWNED BY plugin_nectar.id;


--
-- Name: plugin_nectar_items; Type: TABLE; Schema: public; Owner: cactiuser; Tablespace: 
--

CREATE TABLE plugin_nectar_items (
    id integer NOT NULL,
    report_id integer DEFAULT 0 NOT NULL,
    item_type smallint DEFAULT 1 NOT NULL,
    tree_id integer DEFAULT 0 NOT NULL,
    branch_id integer DEFAULT 0 NOT NULL,
    tree_cascade character varying(2) DEFAULT ''::character varying NOT NULL,
    graph_name_regexp character varying(128) DEFAULT ''::character varying NOT NULL,
    host_template_id integer DEFAULT 0 NOT NULL,
    host_id integer DEFAULT 0 NOT NULL,
    graph_template_id integer DEFAULT 0 NOT NULL,
    local_graph_id integer DEFAULT 0 NOT NULL,
    timespan integer DEFAULT 0 NOT NULL,
    align smallint DEFAULT 1 NOT NULL,
    item_text text NOT NULL,
    font_size smallint DEFAULT 10 NOT NULL,
    sequence smallint DEFAULT 0 NOT NULL
);


ALTER TABLE plugin_nectar_items OWNER TO cactiuser;

--
-- Name: plugin_nectar_items_id_seq; Type: SEQUENCE; Schema: public; Owner: cactiuser
--

CREATE SEQUENCE plugin_nectar_items_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE plugin_nectar_items_id_seq OWNER TO cactiuser;

--
-- Name: plugin_nectar_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: cactiuser
--

ALTER SEQUENCE plugin_nectar_items_id_seq OWNED BY plugin_nectar_items.id;


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: cactiuser
--

ALTER TABLE ONLY plugin_nectar ALTER COLUMN id SET DEFAULT nextval('plugin_nectar_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: cactiuser
--

ALTER TABLE ONLY plugin_nectar_items ALTER COLUMN id SET DEFAULT nextval('plugin_nectar_items_id_seq'::regclass);


--
-- Name: plugin_nectar_items_pkey; Type: CONSTRAINT; Schema: public; Owner: cactiuser; Tablespace: 
--

ALTER TABLE ONLY plugin_nectar_items
    ADD CONSTRAINT plugin_nectar_items_pkey PRIMARY KEY (id);


--
-- Name: plugin_nectar_pkey; Type: CONSTRAINT; Schema: public; Owner: cactiuser; Tablespace: 
--

ALTER TABLE ONLY plugin_nectar
    ADD CONSTRAINT plugin_nectar_pkey PRIMARY KEY (id);


--
-- Name: plugin_nectar_items_report_id; Type: INDEX; Schema: public; Owner: cactiuser; Tablespace: 
--

CREATE INDEX plugin_nectar_items_report_id ON plugin_nectar_items USING btree (report_id);


--
-- Name: plugin_nectar_mailtime; Type: INDEX; Schema: public; Owner: cactiuser; Tablespace: 
--

CREATE INDEX plugin_nectar_mailtime ON plugin_nectar USING btree (mailtime);


--
-- PostgreSQL database dump complete
--

