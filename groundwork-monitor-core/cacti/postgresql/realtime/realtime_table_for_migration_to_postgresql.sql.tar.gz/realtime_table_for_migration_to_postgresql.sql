--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'LATIN1';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

SET search_path = public, pg_catalog;

ALTER TABLE ONLY public.poller_output_rt DROP CONSTRAINT poller_output_rt_pkey;
DROP TABLE public.poller_output_rt;
SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: poller_output_rt; Type: TABLE; Schema: public; Owner: cactiuser; Tablespace: 
--

CREATE TABLE poller_output_rt (
    local_data_id integer DEFAULT 0 NOT NULL,
    rrd_name character varying(19) DEFAULT ''::character varying NOT NULL,
    "time" timestamp without time zone DEFAULT '1970-01-01 00:00:00'::timestamp without time zone NOT NULL,
    output text NOT NULL,
    poller_id integer NOT NULL
);


ALTER TABLE poller_output_rt OWNER TO cactiuser;

--
-- Name: poller_output_rt_pkey; Type: CONSTRAINT; Schema: public; Owner: cactiuser; Tablespace: 
--

ALTER TABLE ONLY poller_output_rt
    ADD CONSTRAINT poller_output_rt_pkey PRIMARY KEY (local_data_id, rrd_name, "time");


--
-- PostgreSQL database dump complete
--

