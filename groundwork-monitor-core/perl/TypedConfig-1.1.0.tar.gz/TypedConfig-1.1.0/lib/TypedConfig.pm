package TypedConfig;

# Copyright 2007-2014 GroundWork Open Source, Inc. (GroundWork)
# All rights reserved. This program is free software; you can redistribute
# it and/or modify it under the terms of the GNU General Public License
# version 2 as published by the Free Software Foundation.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License along
# with this program; if not, write to the Free Software Foundation, Inc.,
# 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.

use strict;
use warnings;

our (@ISA, @EXPORT, @EXPORT_OK, %EXPORT_TAGS, $VERSION);
BEGIN {
    use Exporter ();
    @ISA         = qw(Exporter);
    @EXPORT      = qw();
    @EXPORT_OK   = qw(get_scalar get_boolean get_number get_integer get_hash get_array);
    %EXPORT_TAGS = ( DEBUG => [ @EXPORT, @EXPORT_OK ] );
    $VERSION     = "1.1.0";
}

use Safe;
use Config::General qw(ParseConfig);

#######################################################
#
#   Configuration File Handling
#
#######################################################

# The new() constructor must be invoked as:
#     my $config = TypedConfig->new ($config_file, $debug_config, \%options);
# because if it is invoked instead as:
#     my $config = TypedConfig::new ($config_file, $debug_config, \%options);
# no invocant is supplied as the implicit first argument.
# The same comments apply to the secure_new() constructor.
# The $debug and \%options arguments are optional.

sub new {
    my $invocant     = $_[0];	# implicit argument
    my $config_file  = $_[1];	# required argument
    my $debug_config = $_[2];	# optional argument
    my $options      = $_[3];	# optional parsing options
    my $class = ref($invocant) || $invocant;    # object or class name

    die "ERROR:  cannot access config file \"$config_file\"\n" if !-f "$config_file" || !-r "$config_file";

    # Interpolation defaults enabled, but may be disabled (or confirmed) by the caller.
    my $interpolate = (ref $options eq 'HASH' and exists $options->{interpolate}) ? ($options->{interpolate} ? 1 : 0) : 1;
    my %config = ParseConfig
	(
	-ConfigFile => $config_file,
	-InterPolateVars => $interpolate,
	-AutoTrue => 1,
	-SplitPolicy => 'equalsign'
	);

    # A debug_config value given in the new() function call overrides anything read from the config file.
    $config{"debug_config"} = $debug_config if defined $debug_config;

    bless \%config, $class;
}

# This constructor is just like new(), but it insists that the configuration file
# be readable/writable only by the owner.  This form should be used in cases where
# the configuration file is known to contain certain sensitive data, such as user
# credentials for database access.  In such cases, dying if the file is visible
# to anyone other than the owner is a simple way to force the local administrator
# to maintain proper security controls on the file.  (But beware, this is not a
# test of complete security; this doesn't check Access Control Lists (ACLs), which
# are a much more sophisticated form of access control.)
sub secure_new {
    my $invocant     = $_[0];	# implicit argument
    my $config_file  = $_[1];	# required argument
    my $debug_config = 0;	# suppress inadvertent copies of secure parameters
    my $options      = $_[3];	# optional parsing options

    my ($dev, $ino, $mode) = stat $config_file;
    die "ERROR:  cannot access config file \"$config_file\"\n" if not defined $mode;
    die "ERROR:  config file \"$config_file\" has permissions beyond r/w to owner\n" if $mode & 0177;

    return new($invocant, $config_file, $debug_config, $options);
}

# We explicitly disallow undefined config values here.
# This is a conscious choice, so we can perform uniform controlled error checking.
sub get_scalar {
    my $config = $_[0];	# implicit argument
    my $name   = $_[1];	# required argument
    my $value  = $config->{$name};

    die "ERROR:  cannot find a config-file value for '$name'\n" if not defined $value;
    ## We need to take a reference to a scalar value so ref() will return its type.
    die "ERROR:  '$name' is not a scalar value; check for multiple definitions\n" if ref(\$value) ne "SCALAR";

    print "name = $name, value = $value\n" if $config->{"debug_config"};
    return $value;
}

# We explicitly disallow undefined config values here.
# This is a conscious choice, so we can perform uniform controlled error checking.
sub get_boolean {
    my $config = $_[0];	# implicit argument
    my $name   = $_[1];	# required argument
    my $value  = $config->{$name};

    die "ERROR:  cannot find a config-file value for '$name'\n" if not defined $value;
    ## We need to take a reference to a scalar value so ref() will return its type.
    die "ERROR:  '$name' is not a boolean value; check for multiple definitions\n" if ref(\$value) ne "SCALAR";
    die "ERROR:  invalid boolean value for '$name'\n" if $value !~ /^[01]$/o;

    print "name = $name, value = $value\n" if $config->{"debug_config"};
    return $value;
}

# We explicitly disallow undefined config values here.
# This is a conscious choice, so we can perform uniform controlled error checking.
sub get_number {
    my $config     = $_[0];	# implicit argument
    my $name       = $_[1];	# required argument
    my $expression = $config->{$name};
    my $sandbox    = Safe->new();

    die "ERROR:  cannot find a config-file expression for '$name'\n" if not defined $expression;
    ## We need to take a reference to a scalar value so ref() will return its type.
    die "ERROR:  '$name' is not a numeric value; check for multiple definitions\n" if ref(\$expression) ne "SCALAR";
    ## We construct our pattern for a valid expression rather carefully, but the fact is that we cannot totally
    ## prevent some badly formed expressions from yielding a numeric result that we don't catch as bad.
    die "ERROR:  invalid numeric expression '$expression' for '$name'\n" if $expression !~ m@^[-+()\d.][-+*/%()\d.\s]*$@o;

    my $value = $sandbox->reval ("scalar $expression", 1) + 0;
    die "ERROR:  invalid numeric expression '$expression' for '$name'\n" if not defined $value;

    print "name = $name, value = $value\n" if $config->{"debug_config"};
    return $value;
}

# We explicitly disallow undefined config values here.
# This is a conscious choice, so we can perform uniform controlled error checking.
sub get_integer {
    my $config     = $_[0];	# implicit argument
    my $name       = $_[1];	# required argument
    my $expression = $config->{$name};
    my $sandbox    = Safe->new();

    die "ERROR:  cannot find a config-file expression for '$name'\n" if not defined $expression;
    ## We need to take a reference to a scalar value so ref() will return its type.
    die "ERROR:  '$name' is not an integer value; check for multiple definitions\n" if ref(\$expression) ne "SCALAR";
    ## We construct our pattern for a valid expression rather carefully, but the fact is that we cannot totally
    ## prevent some badly formed expressions from yielding an integer result that we don't catch as bad.
    die "ERROR:  invalid integer expression '$expression' for '$name'\n" if $expression !~ m@^[-+()\d][-+*/%()\d\s]*$@o;

    my $value = $sandbox->reval ("scalar $expression", 1);
    ## Round to nearest integer, then convert to being numeric (not string).
    $value = sprintf('%.0f', $value) + 0;

    die "ERROR:  invalid integer expression '$expression' for '$name'\n" if not defined $value;

    print "name = $name, value = $value\n" if $config->{"debug_config"};
    return $value;
}

# In this case, we handle errors by returning an undefined hash.
sub get_hash {
    my $config = $_[0];	# implicit argument
    my $name   = $_[1];	# required argument
    my $value  = $config->{$name};

    # We don't need to take a reference to a hash value in the ref() call,
    # because if it's a hash then what we have in hand is already a reference.
    if (ref($value) eq "HASH") {
	return %{$value};
    } else {
	return undef;
    }
}

# In this case, we may return an empty array, without complaining.
sub get_array {
    my $config = $_[0];	# implicit argument
    my $name   = $_[1];	# required argument
    my $value  = $config->{$name};

    # We don't need to take a reference to an array value in the ref() call,
    # because if it's an array then what we have in hand is already a reference.
    if (ref($value) eq "ARRAY") {
	## Return an incoming array as an array without an extra level of array-ness.
	return @{$value};
    } elsif (defined($value)) {
	## Turn a scalar value into a returned single-element array.
	return ($value);
    } else {
	## Return an empty array.
	return ();
    }
}

1;

__END__

=head1 NAME

TypedConfig - Type-checked Config Module

=head1 SYNOPSIS

    use TypedConfig;

    my $config_file = "/usr/local/package/etc/package.conf";
    my $debug_config = 0;

    my $config = TypedConfig->new ($config_file, $debug_config, {});
    my $config = TypedConfig->secure_new ($config_file);

    my $string_option  = $config->get_scalar  ('string_option');
    my $boolean_option = $config->get_boolean ('boolean_option');
    my $numeric_option = $config->get_number  ('numeric_option');
    my $integer_option = $config->get_integer ('integer_option');
    my %hash_option    = $config->get_hash    ('hash_option');
    my @array_option   = $config->get_array   ('array_option');

=head1 DESCRIPTION

This module is a wrapper around B<Config::General> that provides two basic
additional features:  value type validation, and enforcement of security
policy for configuration files containing sensitive data.  The intent is
to simplify the full complexity of B<Config::General> and to relieve the script
writer of the work of simple common input validation.  Should the additional
constraints enforced by B<TypedConfig> be violated, the Perl script will die.
So calls to these routines, including the constructor, are normally encapsulated
within an eval{}; block within the calling application, to catch any exceptions
and deal with them appropriately.

A fixed set of features from the B<Config::General> module is supported,
suitable for the typical kinds of data we find most critical in simple scripting.
See B<Config::General> for the general format of the supported config files.

=head1 SUBROUTINES/METHODS

=over

=item new()

The B<new()> constructor accepts a filepath for your config file, and an optional
flag specifying whether scalar, boolean, and numeric values from that file are to
be spilled out on the standard output stream for debugging purposes as they are
retrieved from the config file.  (Hash values are more complex, considering that
block values may be nested, and the appropriate debug-dump code is probably best
handled from within your own script.  Array values could be reasonably displayed,
but that extension awaits a future version.)

An optional third argument is a hashref specifying particular parsing options.
Currently, only one such option (interpolate) is supported:

    my $config = TypedConfig->new( $config_file, $debug_config, { interpolate => 0 } );

Interpolation of $variable references inside the $config_file is on by default,
and may be disabled with this option.  (Such a variable refers to the value of an
option of the same name, defined previously in the same config file.)

The B<new()> method returns an object reference which can be used to access the
methods for pulling particular values and value groups from your config file, as
illustrated in the SYNOPSIS.

The B<new()> constructor must be invoked as:

    my $config = TypedConfig->new ($config_file, $debug_config, {});

because if it is invoked instead as:

    my $config = TypedConfig::new ($config_file, $debug_config, {});

no invocant is supplied as the implicit first argument.

=item secure_new()

The B<secure_new()> constructor is used in preference to B<new()> when the config file
contains sensitive data, such as user credentials for database access.
It takes a single filepath parameter; no debug flag is supported, so as not to inadvertently
create an exposed copy of the sensitive data.  This method will refuse to open and process the
config file unless it is owned by the user accessing the file and its permissions do not
allow any other user to read the file.
Refusing to process an insecure file forces the administrator to fix the security problem
before your application will run correctly.
This is a crude but effective way to ensure that an obvious security hole gets closed.
(But beware, this is not a test of complete security; it doesn't check Access Control Lists
(ACLs), which are a much more sophisticated form of access control.)

The B<secure_new()> constructor must be invoked as:

    my $config = TypedConfig->secure_new ($config_file);

because if it is invoked instead as:

    my $config = TypedConfig::secure_new ($config_file);

no invocant is supplied as the implicit first argument.

=item get_scalar()

This method takes a single parameter, the name of the option you wish to pull from the
config file.  It returns the corresponding string value of that option.  The
config-file value can be any single value, as opposed to a hash or array value.
Most often, this method is used to fetch from the config file an arbitrary string value
which cannot be constrained to be a boolean or numeric value.
If the named option is not available in the config file, the script will die.

=item get_boolean()

This method takes a single parameter, the name of the option you wish to pull from the
config file.  It returns the corresponding boolean value of that option.  The config-file
value can be any form of boolean accepted by Config::General, specifically case-insensitive
true, false, yes, no, on, off, 1, or 0.  The returned value will be a 1 or 0.
If the named option is not available in the config file, the script will die.

=item get_number()

This method takes a single parameter, the name of the option you wish to pull from the
config file.  It returns the corresponding numeric value of that option.
The config-file value can be an expression that evaluates to a number, such as 5*60;
it need not be just a specific literal number.  Floating-point numbers can be specified
as part of the calculations, but no exponents are allowed.
If the named option is not available in the config file, the script will die.

Note that prior to TypedConfig version 1.1.0, get_integer() did not exist, and
B<get_number()> only accepted integer parameters (no decimal points were allowed in
literal numbers).  So you may find older applications that still use B<get_number()>
when they should now be using B<get_integer()> to be more precise about the intended
constraints.  (The old B<get_number()> could return a non-integer by careful use of
division, so in reality the relaxation of this routine in TypedConfig 1.1.0 to allow
decimal points in literal numbers does not provide any less protection about the
returned data value than already existed.)

=item get_integer()

This method takes a single parameter, the name of the option you wish to pull from the
config file.  It returns the corresponding integer value of that option.
The config-file value can be an expression that evaluates to an integer, such as 5*60;
it need not be just a specific number.  Only integers are supported in expressions,
and the final result will be rounded to the nearest integer.
If the named option is not available in the config file, the script will die.

=item get_hash()

This method takes a single parameter, the name of the option you wish to pull from the
config file.  It returns a hash of corresponding block values of that option,
or B<undef> if the option is not mentioned in the config file or if errors occur while
fetching the option structure.
The hash may be multi-level, depending on the structure of the config-file values.
The types of the hash leaf values are not checked.
See B<Config::General> for more details on block values in the config file.

=item get_array()

This method takes a single parameter, the name of the option you wish to pull from the
config file.  It returns an array of corresponding values of that option.  That array
will be empty if the option is not mentioned in the config file or if errors occur while
fetching the option values.  A single mention of the config option in the config file
will be returned as a single-element array.  Multiple mentions of the same config option
will be returned as a multiple-element array.  The types of the array elements are not
checked; they are treated as simple scalar values.

=back

=head1 CONFIGURATION AND ENVIRONMENT

No environment variables will be used.

=head1 SEE ALSO

The B<Config::General> documentation is required reading to grok the supported
configuration file format.

=head1 LICENSE AND COPYRIGHT

Copyright (c) 2007-2014 GroundWork Open Source, Inc.

This library is free software; you can redistribute it and/or
modify it under the same terms as Perl itself.

=head1 BUGS AND LIMITATIONS

For simplicity in application, a fixed set of the B<Config::General> options
has been chosen for use in B<TypedConfig>.  Except for variable interpolation,
which is controllable in the B<TypedConfig> constructor options, these are not
further configurable.

=head1 INCOMPATIBILITIES

None known.

=head1 DIAGNOSTICS

To debug B<TypeConfig> as it applies to your config files,
first try setting the second parameter on the B<new()> constructor to 1.
Beyond that, use the Perl debugger; see L<perldebug>.

=head1 DEPENDENCIES

B<TypedConfig> depends on B<Config::General> and its subsidiary dependencies.

=head1 AUTHOR

GroundWork Open Source, Inc. <info |AT| groundworkopensource.com>

=head1 VERSION

1.1.0

=cut

