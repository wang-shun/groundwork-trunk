#!/usr/bin/perl

use strict;

use lib qw(./mylib ../mylib);
use Test::More;

print "1..0 # SKIP not implemented yet\n";

1;
