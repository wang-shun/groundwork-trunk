package POE::Component::IKC;
# $Id: IKC.pm 497 2009-05-08 19:47:43Z fil $

use strict;
use vars qw( $VERSION );
$VERSION="0.2200";

# Force CPAN to see this

sub DEBUG () { 0 }


1;

