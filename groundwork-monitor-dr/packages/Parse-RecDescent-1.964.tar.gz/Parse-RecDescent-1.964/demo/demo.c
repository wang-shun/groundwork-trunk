int main()
{
  int i;
  int k;  
      int more_indented;  
      int l; 

  char *str = "/* this is no comment */";
  return 0;
}
