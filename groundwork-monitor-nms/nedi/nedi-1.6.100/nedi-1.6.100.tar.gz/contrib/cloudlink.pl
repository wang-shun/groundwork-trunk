#!/usr/bin/perl
=pod

=head1 PROGRAM cloudlink.pl

Add links to clouds (user added devices) and update their last discovery value

=head1 SYNOPSIS

cloudlink.pl devmatch "if|ip match" clouddevice cloudif

 Examples
 Link all devices with names containing 'wanrtr' and interfaces in the IP range 172.16.0.0/16
 to the 'MPLS' cloud (add with Devices-Status first) and 'pop' interface and its bandwidth:

 cloudlink.pl wanrtr 'ifip & -8192 = 2886729728' MPLS pop  

 Link all devices with names matching 'ip-something-ch' and interfaces in the IP range 172.16.0.0/16
 to the 'Sites' cloud and '-' interface and 10M bandwidth:

 cloudlink.pl ip-[a-z]+-ch "ifname regexp 'Gi0/0/0.[0-9]'" Sites - 10000000

=head2 DESCRIPTION

=head2 LICENSE


=head2 AUTHORS

Remo Rickli

Visit http://www.nedi.ch for more information.

=cut

unless( $ARGV[3] ){
	print "use perldoc $0 for help\n";
	exit;
}

$p      = '/var/nedi';

use vars qw(%opt $p $now $ifs);

$now      = time;
$opt{'v'} = 'on';
$opt{'d'} = 'dd';

use strict;
use warnings;
no warnings qw(once);

$misc::dbname = $misc::dbhost = $misc::dbuser = $misc::dbpass = '';

require "$p/inc/libmisc.pm";										# Use the miscellaneous nedi library
require "$p/inc/libdb.pm";										# Use the DB function library

misc::ReadConf();

db::Connect($misc::dbname,$misc::dbhost,$misc::dbuser,$misc::dbpass,0);
$ifs = &db::Select('interfaces','','device,ifname,speed',"device ~ '$ARGV[0]' AND $ARGV[1]",'networks','device,ifname');
exit unless $ifs;

my $dlnk = db::Delete('links',"device='$ARGV[2]' and ifname='$ARGV[3]' or neighbor='$ARGV[2]' and nbrifname='$ARGV[3]'");
foreach my $l ( @{$ifs} ){
	my $bw = $l->[2]?$l->[2]:1000000;
	if($ARGV[4]){
		$bw = $ARGV[4];
	}
	misc::Prt("Adding $ARGV[2],$ARGV[3]  BW:$bw\t$l->[0],$l->[1]\n");
	db::Insert('links','device,ifname,neighbor,nbrifname,bandwidth,linktype,time',"'$l->[0]','$l->[1]','$ARGV[2]','$ARGV[3]',$bw,'STAT',$now");
	db::Insert('links','device,ifname,neighbor,nbrifname,bandwidth,linktype,time',"'$ARGV[2]','$ARGV[3]','$l->[0]','$l->[1]',$bw,'STAT',$now");
}

db::Update('devices',"lastdis=$now",'device='.$db::dbh->quote($ARGV[2]) );

db::Commit();
db::Disconnect();
