#!/bin/sh
# Use this to convert a series of maps into a movie:
# mapmovie.sh username
# Yes, this is serious ;-)

cd /var/nedi/html/map

aa=0;
for i in `ls map_$1-*.png`; do
	cp $i `printf "img$1-$$-%04d" $aa`.png
	aa=$(($aa+1))
done

if [ $aa != 0 ]; then
	avconv -f image2 -r 5 -i img$1-$$-%04d.png -crf 20 -codec h264 $1-`date +%Y%m%d-%H%M`.mp4
	rm -f img$1-$$-*
	rm -f map_$1-*.png
fi
