#!/usr/bin/perl

=pod

=head1 PROGRAM cusdi.pl

Customer specific threaded discovery:

=head2 LICENSE

This program is not free software: Don't redistribute it!

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

=head2 AUTHORS

Remo Rickli
Based on Duane Walker's Discover.pl

Visit http://www.nedi.ch for more information.

=cut

use strict;
use warnings;
no warnings qw(once);

use Getopt::Std;
use Net::SNMP;
use threads;
use threads::shared;

my $threadcount = 5;

use vars qw($p $now %opt);

getopts('a:A:C:d:O:P:t:u:U:v',\%opt) || &HELP_MESSAGE;
if(!defined $opt{'d'}){$opt{'d'} = ''}									# Avoid warnings if unused
if(!defined $opt{'S'}){$opt{'S'} = ''}									# Avoid warnings if unused
if(!defined $opt{'t'}){$opt{'t'} = ''}									# Avoid warnings if unused

select(STDOUT); $| = 1;											# Disable buffering

$p   = $0;
$p   =~ s/(.*)\/(.*)/$1/;
if($0 eq $p){$p = "."};
$now = time;
require "$p/inc/libmisc.pm";										# Use the miscellaneous nedi library
misc::ReadConf($opt{'U'});
$misc::guiauth = '';											# Intended for PHP GUI, breaks SendCmd() if configured with -pass
require "$p/inc/libsnmp.pm";										# Use the SNMP function library
require "$p/inc/libmon.pm";										# Use the Monitoring lib for notifications
require "$p/inc/libcli.pm";										# Use the CLI function library
require "$p/inc/libdb.pm";										# Use the DB function library

my @threads;
my @todo : shared;
my %doip : shared;
my @done : shared;
my @donenam : shared;
my @dbopt : shared;

db::Connect($misc::dbname,$misc::dbhost,$misc::dbuser,$misc::dbpass,1);
my $nseed = misc::InitSeeds(0);
db::Disconnect();

exit if $opt{'t'} eq 's';

@todo  = @misc::todo;
%doip  = %misc::doip;
@dbopt = ($misc::dbname,$misc::dbhost,$misc::dbuser,$misc::dbpass);

#Create the threads
foreach (1..$threadcount){
	push @threads, threads->create(\&Discover,);
}

#Wait for them to finish
foreach my $thr (threads->list) {
	# Don't join the main thread or ourselves
	if ($thr->tid && !threads::equal($thr, threads->self)) {
		$thr->join;
	}
}
exit(0);

=head2 FUNCTION Discover()

Discover a single device.

B<Options> -

B<Globals> todo, done, donenam

B<Returns> -

=cut
sub Discover{
	#This is a threaded subroutine
	my $self = threads->tid;

	db::Connect($dbopt[0],$dbopt[1],$dbopt[2],$dbopt[3],1);

	my $finished = 1;
	my $id;
	my $community;
	my $session;
	my $error;
	my @oid;

	

	#Get the next host off the todo list
	{
		lock(@todo);
		$id = shift(@todo);
	}
	$finished = 0 if (length($id));

	while (!$finished){

		my $out = '';
		my $nam = '';

		#Have we already done this device?
		if( !(grep /^\Q$id\E$/,@done) ){

			my @communities;
			my $dbc = db::Select('devices','','readcomm',"inet_ntoa(devip) = '$doip{$id}'");
			if( $opt{'C'} ){
				$communities[0] = $opt{'C'};
			}elsif( $dbc ){
				$communities[0] = $dbc;
			}else{
				@communities = ( 'public', 'public2' );
			}

			my $i = 0;
			my $count = @communities;
			do {
				($session, $error) = Net::SNMP->session(
				   -hostname  => $doip{$id},
				   -community => $communities[$i],
				   -port      => '161',
				   -timeout   => '1',
				   -version   => 'snmpv2c'
				);

				if (defined($session)){
					$community = $communities[$i];

					@oid = (
						'.1.3.6.1.2.1.1.2.0',
						'.1.3.6.1.2.1.1.5.0'
						);
					if( defined $session->get_request(Varbindlist => \@oid) ){
						$nam = $session->var_bind_list()->{$oid[1]};
						my $sid = $session->var_bind_list()->{$oid[0]};
						my $des = $sid;
						if( $sid eq '.1.3.6.1.4.1.6889.1.69.5.2' ){		#AVX-H323
							$des = 'H323';
							@oid = (
								'.1.3.6.1.4.1.6889.2.69.5.6.4.0',	# extension
								'.1.3.6.1.4.1.6889.2.69.5.1.15.0',	# codec
								'.1.3.6.1.4.1.6889.2.69.5.1.105.0',	# dhcp option 242
								'.1.3.6.1.4.1.6889.2.69.5.1.68.0',	# vlan
								);
						}elsif( $sid eq '.1.3.6.1.4.1.6889.1.69.6.2' ){
							$des = 'SIP';
							@oid = (
								'.1.3.6.1.4.1.6889.2.69.6.7.27.0',
								'.1.3.6.1.4.1.6889.2.69.6.1.13.0',
								'.1.3.6.1.4.1.6889.2.69.6.7.10.0',
								);
						}else{
							@oid = (
								'.1.3.6.1.2.1.1.4.0',
								'.1.3.6.1.2.1.1.3.0',
								'.1.3.6.1.2.1.1.1.0',
								'.1.3.6.1.2.1.2.1.0',
								);
						}
						if( defined $session->get_request(Varbindlist => \@oid) ){
							my $ext = $session->var_bind_list()->{$oid[0]};
							my $cdc = $session->var_bind_list()->{$oid[1]};
							my $dhc = $session->var_bind_list()->{$oid[2]};
							my $vid = $session->var_bind_list()->{$oid[3]} if defined $oid[3];
							$ext =~ s/"//g;
							$vid = 0 unless defined $vid an $vid =~ /^\d+$/;
							$des .= " $dhc" unless $dhc =~ /noSuchObject/;

							$out .= "$doip{$id}\t$nam $community";
							
							db::Update('devices',"contact='$ext',readcomm='$community',sysobjid='$des',cusvalue=$vid,cuslabel='$cdc'","inet_ntoa(devip) = '$doip{$id}'");
						}else{
							$error .= 'no data';
							$out .= " $error with $community";
						}
					}else{
						$error .= 'no sysobj';
						$out .= " $error with $community";
					}
					$session->close;
				}
			} while (($error) && (++$i < $count));

		} else {
			$out = "already done";
		}
		
		#Update done and get next todo
		{
			lock(@done);
			push(@done, $id);
			lock(@donenam);
			push(@donenam, $nam);
			lock(@todo);
  	
			my $c1 = @done;
			my $c2 = @todo;
			Prt("$doip{$id} $id $out\t\tThread$self-$c1/$c2\n");
			$finished = 1 if ($c2 <= 0);
  	
			$id = shift(@todo);
		}
	}

	db::Disconnect();
	return(0);
}

sub Prt{
	print @_;
}

=head2 FUNCTION HELP_MESSAGE()

Display some help

B<Options> -

B<Globals> -

B<Returns> -

=cut
sub HELP_MESSAGE(){
	print "\n";
	print "usage: cusdi.pl [Sources] [Control] [Actions] | Other Actions\n\n";
	print "-a ip	Add single device or ip range (e.g. 10.10.1-9.1 or 10.10.10.1,2,3)\n";
	print "-A cond	Add devices from DB all or e.g.\"loc LIKE 'here%'\"\n";
	print "-O cond	OUI discovery (based on nodes in DB similar to -A)\n";
	print "-u file	Use specified seedlist\n";
	print "-U file	Use specified configuration (use - to read from stdin)\n";
	print "-C cmty	Prefer this community over those in nedi.conf and DB\n";
	print "-d opt	b=basic debug,d=DB queries,s=sysload,c=clilog,v=vardumps\n";
	print "-t opt	Test only s=seeds a=access i=info p=ping (with -P)\n";
	print "-v	Verbose output\n";
	print "---------------------------------------------------------------------------\n";
	print "Custom Discovery (C) 2001-2015 NeDi Consulting Rickli\n\n";
	exit;
}
