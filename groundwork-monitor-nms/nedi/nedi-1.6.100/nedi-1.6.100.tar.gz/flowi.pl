#!/usr/bin/perl

=pod

=head1 PROGRAM flowi.pl

Process nfdump data and create RRD

 Install: apt-get install gcc make flex
 Compile nfdump for use with nfsen: ./configure --enable-nfprofile
 Compile nfdump for use with sflow: ./configure --enable-sflow
 
 Configure expiration:
 nfexpire -s2G -u /var/nfdump/<device>
 
 Run collector:
 nfcapd -e -w -D -l /var/nfdump/<device>/ -p 23456
 
=head2 LICENSE

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.

=head2 AUTHORS

Remo Rickli & NeDi Community

Visit http://www.nedi.ch for more information.

=cut

use strict;
use warnings;
no warnings qw(once);

use Getopt::Std;
use RRDs;

use vars qw( %opt %usr %pov @npo %onam %opos %fnam);
use vars qw( $p $now $err $typ $dly);
use vars qw( $icmp $icmp6 $udp $tcp );

# 1=packets, 2=bytes
$typ = 1;

# Delay
$dly = 300;


$p   = $0;
$p   =~ s/(.*)\/(.*)/$1/;
if($0 eq $p){$p = "."};

$misc::dbname = $misc::dbhost = $misc::dbuser = $misc::dbpass = '';

getopts('d:t:v',\%opt) || &HELP_MESSAGE;
if(!defined $opt{'d'}){$opt{'d'} = ''}									# Avoid warnings if unused

$now = time;
my ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) = localtime(time-$dly);
if( $min % 5 ){
	$min = int($min / 5) * 5;
}
my $ts = sprintf( "%d%02d%02d%02d%02d",$year+1900,$mon+1,$mday,$hour,$min);

require "$p/inc/libmisc.pm";										# Use the miscellaneous nedi library
require "$p/inc/libmon.pm";										# Use the Monitoring lib for notifications
require "$p/inc/libdb.pm";										# Use the DB function library

misc::ReadConf($main::opt{'U'});

print "Configure nfdump path first!\n" and exit unless $misc::nfdpath;
print "Configure netflow ports first!\n" and exit unless keys %misc::nfport;

my $src = "$misc::nfdpath/".join(':',map m|([^/]+)$|, <$misc::nfdpath/*>);
misc::Prt("RRD :nfdump -M $src -r nfcapd.$ts using ".($typ==1?'packets':'bytes')."\n");

$icmp = $icmp6 = $udp = $tcp = 0;
my $r = `nfdump -M $src -r nfcapd.$ts -A proto -o "fmt:%pr %pkt %byt" -N -q`;
my @l = split(/\n/,$r);
foreach my $e (@l){
	my @f  = split(/\s+/,$e);
	if( $f[0] == 1 ){
		$icmp = $f[$typ];
	}elsif( $f[0] == 6 ){
		$tcp = $f[$typ];
	}elsif( $f[0] == 17 ){
		$udp = $f[$typ];
	}elsif( $f[0] == 58 ){
		$icmp6 = $f[$typ];
	}
	misc::Prt( sprintf( "PROT:%4.4s %10.10s pkt %10.10s B\n",$f[0],$f[1],$f[2]) );
}

foreach my $pn (sort keys %misc::nfport){
	$pov{$pn} = 0;
	push(@npo, "DS:p$pn:GAUGE:600:0:U");
}
my $poflt = 'dst port = '.join(' or dst port = ', sort keys (%misc::nfport) );
$r = `nfdump -M $src -r nfcapd.$ts -A dstport -o "fmt:%dp %pkt %byt" -N -q '$poflt'`;
@l = split(/\n/,$r);
foreach my $e (@l){
	my @f = split(/\s+/,$e);
	$pov{$f[1]} = $f[$typ+1];
	misc::Prt( sprintf( "PORT:%4.4s %10.10s pkt %10.10s B\n",$f[1],$f[2],$f[3]) );
}

WriteRRD();

$onam{'pkt'} = 'packets';
$onam{'byt'} = 'bytes';
$onam{'fl'}  = 'flows';
$onam{'bps'} = 'bps';
$onam{'pps'} = 'pps';
$onam{'bpp'} = 'bpp';

$opos{'pkt'} = 6;
$opos{'byt'} = 7;
$opos{'fl'}  = 8;
$opos{'bps'} = 9;
$opos{'pps'} = 10;
$opos{'bpp'} = 11;

$fnam{'pr'} = 'proto';
$fnam{'sa'} = 'srcip';
$fnam{'da'} = 'dstip';
$fnam{'ip'} = 'ip';
$fnam{'sp'} = 'srcport';
$fnam{'dp'} = 'dstport';
$fnam{'po'} = 'port';

my $mq = '';
db::Connect($misc::dbname,$misc::dbhost,$misc::dbuser,$misc::dbpass,1);
$misc::pol = db::Select('policies','id','*',"status=100 AND (class='pkt' OR class='byt' OR class='fl')");
foreach my $i ( keys %{$misc::pol} ){
	my $ord = $onam{$misc::pol->{$i}{'class'}};
	my $pos = $opos{$misc::pol->{$i}{'class'}};
	my @gar = split /,/, $misc::pol->{$i}{'devgroup'};
	my $grp = '';
	foreach my $g (@gar){
		$grp .= "$fnam{$g},";
	}
	chop $grp;
	$grp = "-A $grp" if $grp;
	my ($o,$ic,$lt,$ex) = split //, $misc::pol->{$i}{'polopts'};
	misc::Prt("SPTR:nfdump -M$misc::nfdpath/$misc::pol->{$i}{'device'} -r nfcapd.$ts $grp -O $ord -n 10 -q -N '$misc::pol->{$i}{'type'}'\n");
	$r = `nfdump -M$misc::nfdpath/$misc::pol->{$i}{'device'} -r nfcapd.$ts $grp -O $ord -n 10 -q -N -o 'fmt:%sa %sp %da %dp %pr %pkt %byt %fl %pps %bps %bpp' '$misc::pol->{$i}{'type'}'`;
	@l = split(/\n/,$r);
	my $none = 1;
	foreach my $e (@l){
		my @f  = split(/\s+/,$e);
		my $sa = ($f[1] ne '0.0.0.0'?" from $f[1]":'');
		my $da = ($f[3] ne '0.0.0.0'?" to $f[3]":'');

		if( $o eq '>' ){
			if( $f[$pos] > $misc::pol->{$i}{'target'} ){
				$mq = mon::Event($misc::pol->{$i}{'alert'},200,'sptr',$i,'',"$misc::pol->{$i}{'info'} - $f[$pos] $ord exceed threshold of $misc::pol->{$i}{'target'}$sa$da");
			}
		}elsif( $o eq '<' ){
			if( $f[$pos] < $misc::pol->{$i}{'target'} ){
				$mq = mon::Event($misc::pol->{$i}{'alert'},200,'sptr',$i,'',"$misc::pol->{$i}{'info'} - $f[$pos] $ord is below threshold of $misc::pol->{$i}{'target'}$sa$da");
			}
		}
		$none = 0;
	}
	if( $none and $o eq '<' ){
		$mq = mon::Event($misc::pol->{$i}{'alert'},200,'sptr',$i,'',"$misc::pol->{$i}{'info'} - No matching $misc::pol->{$i}{'target'} at all!");
	}
}

if( time - $now > 180 ){
	db::Insert('events','level,time,source,class,device,info',"30,".time.",'Flowi','bugn','','Took longer than 3 minutes, consider removing traffic policies!'" );
}
mon::AlertFlush("NeDi Traffic Alert",$mq);
db::Disconnect();

sub WriteRRD{

	if( $opt{'t'} ){
		misc::Prt("TRRD:Not writing when testing\n");
	}else{
		unless(-e "$misc::nedipath/rrd/flow.rrd"){
			RRDs::create(	"$misc::nedipath/rrd/flow.rrd",
					"-s","300",
					"DS:icmp:GAUGE:600:0:U",
					"DS:icmp6:GAUGE:600:0:U",
					"DS:udp:GAUGE:600:0:U",
					"DS:tcp:GAUGE:600:0:U",
					@npo,
					"RRA:AVERAGE:0.5:1:1000",
					"RRA:AVERAGE:0.5:10:1000");
			$err = RRDs::error;
		}
		if($err){
			misc::Prt("ERR :Create $err\n");
		}else{
			my $pvlist = '';
			foreach my $vk (sort keys %pov){
				$pvlist .= ':'.$pov{$vk};
			}
			RRDs::update "$misc::nedipath/rrd/flow.rrd","N:$icmp:$icmp6:$udp:$tcp$pvlist";
			$err = RRDs::error;
			if($err){
				misc::Prt("ERR :Update $err\n");
			}else{
				misc::Prt("TRRD:$misc::nedipath/rrd/flow.rrd update OK\n");
			}
		}
	}
}
