<?php
# Program: Devices-Graph.php
# Programmer: Remo Rickli

$exportxls = 0;
$nocache   = 1;

include_once ("inc/header.php");

$_GET = sanitize($_GET);
$dv = isset($_GET['dv']) ? $_GET['dv'] : "";
$if = isset($_GET['if']) ? $_GET['if'] : array();
$it = isset($_GET['it']) ? $_GET['it'] : array();
$sho = isset($_GET['sho']) ? 1 : 0;
$cad = isset($_GET['cad']) ? 1 : 0;
$tem = isset($_GET['tem']) ? $_GET['tem'] : 2;
$sze = $_GET['sze'] ? $_GET['sze'] : 5;

$tfarr['raw'] = isset($_GET['stt']) ? $_GET['stt'] : date("m/d/Y H:i", time() - 5*86400);
$tfarr['dur'] = isset($_GET['dur']) ? $_GET['dur'] : 5*1440;

TfInit();

?>
<h1>Device <?= $gralbl ?></h1>

<?php if( !isset($_GET['print']) ) { ?>
<form method="get" action="<?= $self ?>.php" name="dynfrm">
<table class="content">
<tr class="bgmain">
<td class="ctr s">
	<a href="<?= $self ?>.php"><img src="img/32/<?= $selfi ?>.png" title="<?= $self ?>"></a>
</td>
<td class="ctr">
	<select size="6" name="dv" onchange="this.form.submit();">
<?php
echo "\t\t<option value=\"Totals\"".(($dv == "Totals")?" selected":"").">$totlbl $gralbl\n";
if( $dv != "Totals" ){
	$link = DbConnect($dbhost,$dbuser,$dbpass,$dbname);
	$res  = DbQuery( $link,'devices','s','device,devip,snmpversion,readcomm,memcpu,temp,cuslabel,cusvalue,devopts','device','',array('snmpversion'),array('!='),array('0') );
	echo "\t\t<option value=\"\" style=\"color: blue\">- Devices -\n";
	while( ($d = DbFetchRow($res)) ){
		echo "\t\t<option value=\"$d[0]\"";
		if($dv == $d[0]){
			echo " selected";
			$ip = long2ip($d[1]);
			$sp = ($d[2] & 3);
			$hc = ($d[2] & 128);
			$co = $d[3];
			$mem = $d[4];
			$tmp = $d[5];
			$cg = $d[6];
			$cv = $d[7];
			$dop = $d[8];
		}
		echo " >$d[0]\n";
	}
	DbFreeResult($res);
}
?>
	</select>
<?php
if( $dv == "Totals" ){
?>
	<select multiple size="6" name="if[]">
		<option value="msg"<?= (in_array("msg",$if))?" selected":"" ?>> <?= $msglbl ?> <?= $sumlbl ?>

		<option value="mon"<?= (in_array("mon",$if))?" selected":"" ?>> <?= $tgtlbl ?> <?= $avalbl ?>

		<option value="nod"<?= (in_array("nod",$if))?" selected":"" ?>> <?= $totlbl ?> Nodes
		<option value="tpw"<?= (in_array("tpw",$if))?" selected":"" ?>> <?= $totlbl ?> PoE
		<option value="ttr"<?= (in_array("ttr",$if))?" selected":"" ?>> <?= $totlbl ?> <?= $acslbl ?> <?= $trflbl ?>

		<option value="ter"<?= (in_array("ter",$if))?" selected":"" ?>> <?= $totlbl ?> non-Wlan <?= $errlbl ?>

		<option value="tdi"<?= (in_array("tdi",$if))?" selected":"" ?>> <?= $totlbl ?> non-Wlan Discards
		<option value="ifs"<?= (in_array("ifs",$if))?" selected":"" ?>> IF <?= $stalbl ?>  <?= $sumlbl ?>

<?php if( file_exists("$nedipath/rrd/flow.rrd") ){ ?>
		<option value="ru"<?= (in_array("ru",$if))?" selected":"" ?>><?= $prolbl ?> UDP
		<option value="rt"<?= (in_array("rt",$if))?" selected":"" ?>><?= $prolbl ?> TCP
		<option value="ri"<?= (in_array("ri",$if))?" selected":"" ?>><?= $prolbl ?> ICMP
		<option value="rj"<?= (in_array("rj",$if))?" selected":"" ?>><?= $prolbl ?> ICMP6

<?php
	foreach ($nfport as $pn => $pt){
		echo "<option value=\"p$pn\"".(in_array("p$pn",$if)?" selected":'').">$porlbl $pn ($pt)";
	}
?>

<?php } ?>
	</select>
<?php
}elseif($dv){
?>
	<select multiple size="6" name="if[]">
<?php
if( substr($dop,1,1) != "-" ){
?>
		<option value="cpu"<?= (in_array("cpu",$if))?" selected":"" ?>><?= ((substr($dop,1,1) == "C")?'CPU':'UPS') ?> <?= $lodlbl ?>
<?php
}
if($mem){
?>
		<option value="mem"<?= (in_array("mem",$if))?" selected":"" ?>> Memory
<?php
}
if($tmp){
?>
		<option value="tmp"<?= (in_array("tmp",$if))?" selected":"" ?>> <?= $tmplbl ?>
<?php
}
if($cg){
	list($ct,$cy,$cu) = explode(";", $cg);
?>
		<option value="cuv"<?= (in_array("cuv",$if))?" selected":"" ?>> <?= $ct ?>
<?php
}
?>
		<option value="" style="color: blue">- Interfaces -
<?php
	$res = DbQuery( $link,'interfaces','s','ifname,alias,ifstat,comment','ifidx','',array('device'),array('='),array($dv) );
	if($res){
		while( ($i = DbFetchRow($res)) ){
			echo "		<option value=\"$i[0]\" ".(($i[2] == 3)?'class="grn"':'');
			if(in_array($i[0],$if)){echo "selected";}
			echo " >$i[0] " . substr("$i[1] $i[3]",0,30)."\n";
		}
		DbFreeResult($res);
	}
?>
	</select>
	<select multiple size="6" name="it[]">
		<option value="t"<?= (in_array("t",$it))?" selected":"" ?>> <?= $trflbl ?>

		<option value="e"<?= (in_array("e",$it))?" selected":"" ?>> <?= $errlbl ?>

		<option value="d"<?= (in_array("d",$it))?" selected":"" ?>> Discards
		<option value="b"<?= (in_array("b",$it))?" selected":"" ?>> Broadcast
		<option value="s"<?= (in_array("s",$it))?" selected":"" ?>> <?= $stalbl ?>

	</select>
<?php
}
?>
</td>
<td class="ctr">
<?php TfWidgets(1) ?>
</td>
<?php  if($cacticli) { ?>
<td class="ctr">
	<h3>Cacti</h3>
	<select size="1" name="tem">
		<option value="2"><?= $trflbl ?>
		<option value="22"><?= $errlbl ?>
		<option value="24">Broadcast
	</select>
	<p>
	<input type="submit" class="button" name="cad" value="<?= $addlbl ?>">
</td>
<?php } ?>
<td class="ctr s">
	<select size="1" name="sze" onchange="this.form.submit();">
		<option value=""><?= $siz['x'] ?>

		<option value="4" <?= ($sze == "4")?" selected":"" ?> ><?= $siz['l'] ?>

		<option value="3" <?= ($sze == "3")?" selected":"" ?> ><?= $siz['m'] ?>

		<option value="2" <?= ($sze == "2")?" selected":"" ?> ><?= $siz['s'] ?>

	</select>
	<p>
	<input type="submit" class="button" name="sho" value="<?= $sholbl ?>">
</td>
</tr></table>
</form>

<?php
}
if($dv){
	$ud = rawurlencode($dv);
	if($dv != "Totals" and !isset($_GET['print']) and strpos($_SESSION['group'],$modgroup['Devices-Status']) !== false ){
		echo "<h2>";
		echo ModLink('Devices','Status',"dev=$ud");
		echo " $dv</h2>\n";
	}else{
		echo "<h2>$dv</h2>\n";
	}
	echo "<h3>".date($_SESSION['timf'], $tfarr['sux'])." - ".date($_SESSION['timf'],$tfarr['eux'])."</h3>\n";
}
?>
<div class="ctr">
<?php

$grlnk = "inc/drawrrd.php?s=$sze&a=$tfarr[sux]&e=$tfarr[eux]";
$tflnk = "?stt=".urlencode($tfarr['sst'])."&dur=$tfarr[dur]";
if($cad){
	if($debug){echo "$cacticli/add_device.php --description=\"$dv\" --ip=\"$ip\" --template=1 --version=\"$sp\" --community=\"$co\"";}
	$adev = exec("$cacticli/add_device.php --description=\"$dv\" --ip=\"$ip\" --template=1 --version=\"$sp\" --community=\"$co\"");
	echo "<div class=\"textpad code pre txta half\">\t$adev\n</div>\n";
	flush();
	$devid = preg_replace("/.*device-id: \((\d+)\).*/","$1",$adev);
	if($devid){
		if($tem == 22){
			$qtyp = 2;
		}elseif($tem == 24){
			$qtyp = 3;
		}elseif($hc){
			$qtyp = 14;
		}else{
			$qtyp = 13;
		}
		foreach ($if as $i){
			if($debug){echo "$cacticli/add_graphs.php --graph-type=ds --graph-template-id=$tem --host-id=$devid --snmp-query-id=1 --snmp-query-type-id=$qtyp --snmp-field=ifName --snmp-value=\"$i\"";}
			$agrf = exec("$cacticli/add_graphs.php --graph-type=ds --graph-template-id=$tem --host-id=$devid --snmp-query-id=1 --snmp-query-type-id=$qtyp --snmp-field=ifName --snmp-value=\"$i\"");
			echo "<div class=\"textpad code pre txtb half\">\n\t$agrf\n</div>\n";
			flush();
		}
	}
}elseif ($dv == "Totals") {
	if( in_array("msg",$if) ) echo "\t<a href=\"Monitoring-Timeline.php$tflnk&det=level&sho=1\"><img src=\"$grlnk&t=msg\" title=\"$sholbl Timeline\"></a>\n";
	if( in_array("mon",$if) ) echo "\t<a href=\"Monitoring-Timeline.php$tflnk&in[]=class&op[]=LIKE&st[]=mon%25&det=source\"><img src=\"$grlnk&t=mon\" title=\"$tgtlbl $avalbl\"></a>\n";
	if( in_array("nod",$if) ) echo "\t<a href=\"Monitoring-Timeline.php$tflnk&in[]=class&op[]==&st[]=secn&det=source\"><img src=\"$grlnk&t=nod\" title=\"$totlbl Nodes\"></a>\n";
	if( in_array("tpw",$if) ) echo "\t<img src=\"$grlnk&t=tpw\" title=\"$totlbl PoE\">\n";
	if( in_array("ttr",$if) ) echo "\t<img src=\"$grlnk&t=ttr\" title=\"$totlbl $trflbl\">\n";
	if( in_array("ter",$if) ) echo "\t<a href=\"Monitoring-Timeline.php$tflnk&in[]=class&op[]=~&st[]=(if|ln)e[io]&det=source\"><img src=\"$grlnk&t=ter\" title=\"$totlbl $errlbl\"></a>\n";
	if( in_array("tdi",$if) ) echo "\t<a href=\"Monitoring-Timeline.php$tflnk&in[]=class&op[]=~&st[]=(if|ln)d[io]&det=source\"><img src=\"$grlnk&t=tdi\" title=\"$totlbl Discards\"></a>\n";
	if( in_array("ifs",$if) ) echo "\t<img src=\"$grlnk&t=ifs\" title=\"IF $stalbl $sumlbl\">\n";

	$pro = '';
	$por = '';
	foreach ( $if as $i){
		if( strpos($i,'r') === 0 ){
			$pro .= substr($i,1);
		}
		if( strpos($i,'p') === 0 ){
			$por .= $i;
		}
	}
	if( $pro ) echo "\t<a href=\"Nodes-Traffic.php$tflnk&in[]=sa&in[]=da\"><img src=\"$grlnk&t=r$pro\" title=\"$prolbl\"></a>\n";
	if( $por ) echo "\t<a href=\"Nodes-Traffic.php$tflnk&in[]=sa&in[]=da\"><img src=\"$grlnk&t=$por\" title=\"$porlbl $sumlbl\"></a>\n";
}else{
	if( in_array("cpu",$if) ) echo "\t<img src=\"$grlnk&dv=$ud&t=cpu\" title=\"% CPU\">\n";
	if( in_array("mem",$if) ) echo "\t<img src=\"$grlnk&dv=$ud&t=mem\" title=\"Mem $frelbl\">\n";
	if( in_array("tmp",$if) ) echo "\t<img src=\"$grlnk&dv=$ud&t=tmp\" title=\"$tmplbl\">\n";
	if( in_array("cuv",$if) ) echo "\t<img src=\"$grlnk&dv=$ud&&if[]=".urlencode($ct)."&if[]=".urlencode($cu)."&t=cuv\" title=\"$ct [$cu]\">\n";
	if( isset($if[0]) ){
		$uif = "";
		foreach ( $if as $i){
			if( !preg_match('/cpu|mem|tmp|cuv/',$i) ){
				$uif .= '&if[]='.rawurlencode($i);
			}
		}
		if($uif){
			if(in_array("t",$it)){echo "\t<img src=\"$grlnk&dv=$ud$uif&t=trf\" title=\"$trflbl\">\n";}
			if(in_array("e",$it)){echo "\t<img src=\"$grlnk&dv=$ud$uif&t=err\" title=\"$errlbl\">\n";}
			if(in_array("d",$it)){echo "\t<img src=\"$grlnk&dv=$ud$uif&t=dsc\" title=\"Discards\">\n";}
			if(in_array("b",$it)){echo "\t<img src=\"$grlnk&dv=$ud$uif&t=brc\" title=\"Broadcasts\">\n";}
			if(in_array("s",$it)){echo "\t<img src=\"$grlnk&dv=$ud$uif&t=sta\" title=\"IF $stalbl (no stack!)\">\n";}
		}
	}
}
?>
</div>

<?php
include_once ("inc/footer.php");
?>
