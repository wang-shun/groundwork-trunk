<?php
# Program: Monitoring-Incidents.php
# Programmer: Remo Rickli

$refresh   = 60;
$exportxls = 0;

include_once ("inc/header.php");
include_once ("inc/libdev.php");
include_once ("inc/libmon.php");

$_GET = sanitize($_GET);
$id  = isset($_GET['id']) ? $_GET['id'] : '';
$cl  = isset($_GET['cl']) ? $_GET['cl'] : '';
$ed  = (isset($_GET['ed']) and $_GET['ed'])? 'checked':'';
$do  = isset($_GET['do']) ? $_GET['do'] : '';
$val = isset($_GET['val']) ? $_GET['val'] : '';
$ilm = isset($_GET['ilm']) ? preg_replace('/\D+/','',$_GET['ilm']) : 25;
$off = isset($_GET['off'])? $_GET['off'] : 0;
$nof = $off;

$hde = isset($_GET['hde'])? $_GET['hde'] : 0;

if( isset($_GET['p']) ){
	$nof = $off - $ilm;
	if($nof < 0) $nof = 0;
}elseif( isset($_GET['n']) ){
	$nof = $off + $ilm;
}
?>

<h1 onclick="document.dynfrm.style.display = (document.dynfrm.style.display == 'none')?'':'none';">Monitoring Incidents</h1>
	
<?php
$dlim = ($nof)?"$ilm OFFSET $nof":$ilm;
$link = DbConnect($dbhost,$dbuser,$dbpass,$dbname);


if($id and $do){
	if($do == 'del'){
		if( !DbQuery($link,'incidents','d','','','',array('id'),array('='),array($id)) ){echo "<h4>".DbError($link)."</h4>";}else{echo "<h5>Incident $id $dellbl OK</h5>";}
	}elseif($do == 'upg'){
		if( !DbQuery($link,'incidents','u','','','',array('id'),array($id),array('usrname','time','grp'),array($_SESSION['user'],time(),$val)) ){echo "<h4>".DbError($link)."</h4>";}else{echo "<h5> Incident $clalbl $updlbl OK</h5>";}
	}elseif($do == 'upc'){
		if( !DbQuery($link,'incidents','u','','','',array('id'),array($id),array('comment'),array($val)) ){echo "<h4>".DbError($link)."</h4>";}else{echo "<h5> Incident $cmtlbl $updlbl OK</h5>";}
	}
	$id='';
}
?>

<?php  if( !isset($_GET['print']) ) { ?>
<form method="get" name="dynfrm" action="<?= $self ?>.php">
<table class="content">
<tr class="bgmain">
<td class="ctr s">
	<a href="<?= $self ?>.php"><img src="img/32/<?= $selfi ?>.png" title="<?= $self ?>"></a>
</td>
<td>
	<select name="cl" onchange="this.form.submit();">
		<option value=""><?= $fltlbl ?> <?= $clalbl ?> >
<?php
foreach (array_keys($igrp) as $c){
	echo "\t\t<option value=\"$c\" ";
	if($cl == $c){echo "selected ";}
	echo (strpos($c,'0')?"style=\"color:blue\">$igrp[$c]\n":">- $igrp[$c]\n");
}
?>
	</select>
	<img src="img/16/bbrt.png" title="<?= $fltlbl ?> <?= $stco['100'] ?> (<?= $nonlbl ?> <?= $endlbl ?>)">
	<input type="checkbox" name="ed" <?= $ed ?> onchange="this.form.submit();">
</td>
<td>
	<img src="img/16/form.png" title="<?= $limlbl ?>">
	<select name="ilm" onchange="this.form.submit();">
<?php selectbox("limit",$ilm) ?>
	</select>
</td>
<td class="ctr">
	<h3 title="<?= $nonlbl ?> <?= $updlbl ?>" onClick="stop_countdown(interval);">
		<img src="img/16/exit.png">
		<span id="counter"><?= $refresh ?></span>
		<a href="?cl=<?= $cl ?>&ed=<?= $ed ?>&hde=1"><img src="img/16/eyes.png" title="<?= $notlbl ?> <?= $sholbl ?>"></a>
	</h3>
</td>
<td class="ctr s nw">
	<input type="hidden" name="hde" value="<?= $hde ?>">
	<input type="hidden" name="off" value="<?= $nof ?>">
	<input type="submit" class="button" name="p" value=" < ">
	<input type="submit" class="button" name="n" value=" > ">
</td>
</tr>
</table>
</form>
<?= $hde?"<script>dynfrm.style.display='none'</script>":'' ?>
<p>

<?php
} 

if( $ed ){
	$fnop = 'AND';
	$fntx = "$stco[100] ";
}else{
	$fnop = '';
	$fntx = '';
}
if(strpos($cl,'0') ){
	$tit = "$fntx$igrp[$cl] $inclbl $lstlbl";
	$res = DbQuery( $link,'incidents','s','incidents.*,location,devgroup','id desc',$dlim,array('grp','endinc'),array('~','='),array("^".substr($cl,0,1).".",0),array($fnop),'LEFT JOIN devices USING (device)' );
}elseif($cl){
	$tit = "$fntx$igrp[$cl] $inclbl $lstlbl";
	$res = DbQuery( $link,'incidents','s','incidents.*,location,devgroup','id desc',$dlim,array('grp','endinc'),array('=','='),array($cl,0),array($fnop),'LEFT JOIN devices USING (device)' );
}elseif($id){
	$tit = "$inclbl Id $id";
	$res = DbQuery( $link,'incidents','s','incidents.*,location,devgroup','','',array('id'),array('='),array($id),array(),'LEFT JOIN devices USING (device)' );
}elseif($fnop){
	$tit = "$stco[100] $inclbl $lstlbl";
	$res = DbQuery( $link,'incidents','s','incidents.*,location,devgroup','id desc',$dlim,array('endinc'),array('='),array(0),array(),'LEFT JOIN devices USING (device)' );
}else{
	$tit  = "$alllbl $inclbl $lstlbl";
	$res = DbQuery( $link,'incidents','s','incidents.*,location,devgroup','id desc',$dlim,array(),array(),array(),array(),'LEFT JOIN devices USING (device)' );
}
?>

<h2><?= $tit ?></h2>

<table class="content">
	<tr class="bgsub">
		<th colspan="2">
			<img src="img/16/eyes.png"><br>
			<?= $inclbl ?>

		</th>
		<th colspan="2">
			<img src="img/16/trgt.png"><br>
			<?= $tgtlbl ?>

		</th>
		<th>
			<img src="img/16/bblf.png"><br>
			<?= $sttlbl ?>

		</th>
		<th>
			<img src="img/16/bbrt.png"><br>
			<?= $endlbl ?>

		</th>
		<th colspan="2">
			<img src="img/16/user.png"><br>
			<?= $usrlbl ?>

		</th>
		<th colspan="2">
			<img src="img/16/find.png"><br>
			<?= $inflbl ?>

		</th>
	</tr>
<?php
if($res){
	$nin = 0;
	$row = 0;
	while( ($i = DbFetchRow($res)) ){
		if ($row % 2){$bg = "txta"; $bi = "imga";}else{$bg = "txtb"; $bi = "imgb";}
		$row++;
		$ls = $i[5]?Ftime($i[5]):'-';
		$at = $i[7]?Ftime($i[7]):'-';
		$ud = urlencode($i[2]);
		list($fc,$lc) = Agecol($i[4],$i[5],$row % 2);
		TblRow($bg);
		TblCell( $i[0],"?id=$i[0]",'ctr xs' );
		TblCell( "<img src=\"img/16/" . $mico[$i[1]] . ".png\" title=\"" . $mlvl[$i[1]] . "\">",'',$mbak[$i[1]]." ctr xs" );
		if( isset($_GET['print']) or isset($mod['Monitoring']['Master']) ){
			TblCell( $i[2],'',"$bi b",'','font-size:130%' );
		}else{
			TblCell( $i[2],"Monitoring-Setup.php?in[]=name&op[]=%3D&st[]=$ud","$bi b",'','font-size:130%' );
		}
		echo "\t\t<td>\n";
		if( $i[3] ) echo "\t\t\t<img src=\"img/16/lndb.png\" title=\"$deplbl\">$i[3]\n";
		if( $i[12] ) echo "\t\t\t<img src=\"img/16/ugrp.png\" title=\"$grplbl\">$i[12]<br>\n";
		if( $i[11] ){
			$l = explode($locsep, $i[11]);
			 echo "\t\t\t<img src=\"img/16/home.png\" title=\"$loclbl\">$l[0] $l[1] $l[2]\n";
		}
		echo "\t\t</td>\n";
		TblCell( Ftime($i[4]),'','nw','',"background-color:#$fc" );
		TblCell( $ls,'','nw','',"background-color:#$lc" );
		TblCell( $i[6] );
		TblCell( $at );

		if( isset($_GET['print']) or isset($mod['Monitoring']['Master']) ){
			echo "\t\t<td>\n\t\t\t<img src=\"img/16/".IncImg($i[8]).".png\">".$igrp[$i[8]]."\n\t\t</td>\n\t\t<td>\n\t\t\t$i[9]";
		}else{
?>
		<td>
		<form method="get" action="<?= $self ?>.php">
			<img src="img/16/<?=IncImg($i[8]) ?>.png">
			<input type="hidden" name="cl" value="<?= $cl ?>">
			<input type="hidden" name="ed" value="<?= $ed ?>">
			<input type="hidden" name="id" value="<?= $i[0] ?>">
			<input type="hidden" name="do" value="upg">
			<input type="hidden" name="off" value="<?= $nof ?>">
			<select size="1" name="val" onchange="this.form.submit();" title="<?= $sellbl ?> <?= $clalbl ?>">
<?php
		foreach (array_keys($igrp) as $c){
			echo "\t\t\t\t<option value=\"$c\"";
			if($c == $i[8]){echo " selected";}
			echo (strpos($c,'0')?" style=\"color: blue\">$igrp[$c]\n":">- $igrp[$c]\n");
		}
?>
			</select>
		</form>
		</td>
		<td>
		<form method="get" action="<?= $self ?>.php">
			<input type="hidden" name="cl" value="<?= $cl ?>">
			<input type="hidden" name="ed" value="<?= $ed ?>">
			<input type="hidden" name="id" value="<?= $i[0] ?>">
			<input type="hidden" name="do" value="upc">
			<input type="hidden" name="off" value="<?= $nof ?>">
			<input type="text" name="val" size="30" value="<?= $i[9] ?>" onchange="this.form.submit();">
			<a href="<?= $self ?>.php?cl=<?= $cl ?>&ed=<?= $ed ?>&off=<?= $nof ?>&id=<?= $i[0] ?>&do=del"><img src="img/16/bcnl.png" onclick="return confirm('<?= $dellbl ?> Incident <?= $i[0] ?>?');" title="<?= $dellbl ?> Incident"></a>
		</form>
		</td>
	</tr>
<?php
		}
		$nin++;
		if($nin == $ilm){break;}
	}
	TblFoot("bgsub", 10, "$row $vallbl, $limlbl ".str_replace('OFFSET',$sttlbl,$dlim) );
	DbFreeResult($res);
}else{
	print DbError($link);
}

include_once ("inc/footer.php");
?>
