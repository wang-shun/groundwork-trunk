<?php
# Program: Monitoring-Map.php
# Programmer: Remo Rickli
#
# Clustermap is an unsupported user contribution by Conny Ohlsson
# It requires markerclusterer.js to be upload to inc/ in order to work
# Check "Googlemaps" in User-Profile to enable (please use only when Google licensing is properly addressed)
# Uses coordinates from locations table or 9 and 10th field in snmp location

$groups    = 6;
$rotate    = 10;
$refresh   = 180;
$exportxls = 0;
$yesterday = time() - 86400;

ini_set('default_socket_timeout', 1);

include_once ("inc/header.php");
include_once ("inc/libdev.php");
include_once ("inc/libmon.php");

$_GET = sanitize($_GET);
$do   = isset($_GET['do']) ? $_GET['do'] : '';
$id   = isset($_GET['id']) ? $_GET['id'] : '';
$sg   = isset($_GET['sg']) ? $_GET['sg'] : 0;

$flt  = isset($_GET['flt']) ? $_GET['flt'] : '';

$grp  = isset($_GET['grp']) ? $_GET['grp'] : 'A';
$pri  = isset($_GET['pri']) ? $_GET['pri'] : 0;
$siz  = isset($_GET['siz']) ? $_GET['siz'] : 0;
$acs  = isset($_GET['acs']) ? $_GET['acs'] : 0;

list($mw,$mh) = MapSize( $_SESSION['gsiz'] );

$link  = DbConnect($dbhost,$dbuser,$dbpass,$dbname);
$res = DbQuery( $link,'devices','s',"count(*),
		sum(case when snmpversion > 0 and lastdis < $yesterday then 1 else 0 end),
		sum(case when snmpversion = 0 and lastdis < $yesterday then 1 else 0 end),
		sum(case when test is not NULL then 1 else 0 end),
		sum(case when status > 0 then 1 else 0 end),
		ceil(avg(latency))"
		,'','',array(),array(),array(),array(),'LEFT JOIN monitoring USING (device)'
	);
$data  = DbFetchRow($res);
DbFreeResult($res);
if( $_SESSION['vol'] and $data[4] and !$do ){echo "<audio src=\"inc/major.mp3\" autoplay onplay=\"this.volume=.$_SESSION[vol]\">no audio</audio>\n";}

?>
<h1 onclick="document.dynfrm.style.display = (document.dynfrm.style.display == 'none')?'':'none';">Monitoring Map</h1>

<form method="get" name="dynfrm" action="<?= $self ?>.php">

<input type="hidden" name="sg" value="">

<script src="inc/Chart.min.js"></script>

<table class="content">
<tr class="bgmain">
<td class="ctr s">
	<a href="<?= $self ?>.php"><img src="img/32/<?= $selfi ?>.png" title="<?= $self ?>"></a>
</td>
<?php if($_SESSION['gsiz'] and !$do ){ ?>
<td class="ctr top">
	<h3><?= $monlbl ?></h3>
	<a href="Monitoring-Setup.php?in[]=status&op[]=>&st[]=0">
		<canvas id="mon" style="display: block;margin: 0 auto;padding: 10px;" width="<?= $mw ?>" height="<?= $mw ?>"></canvas>
	</a>
	<div style="margin-top: -<?= intval($mw/1.25) ?>px;font-size: <?= intval($mw/8) ?>px;font-weight:bolder"><span class="red"><?= $data[4] ?></span><br><span class="grn"><?= $data[3] ?></span><br><span class="gry"><?= $data[5] ?>ms</span></div>
</td>
<td class="ctr top">
	<h3><?= $dsclbl ?></h3>
	<a href="Devices-List.php?in[]=lastdis&op[]=%3C&st[]=<?= $yesterday ?>">
		<canvas id="dev" style="display: block;margin: 0 auto;padding: 10px;" width="<?= $mw ?>" height="<?= $mw ?>"></canvas>
	</a>
	<div style="margin-top: -<?= intval($mw/1.25) ?>px;font-size: <?= intval($mw/8) ?>px;font-weight:bolder"><span style="color:#eb3"><?= $data[2] ?><br><span style="color:#e93"><?= $data[1] ?><br><span class="grn"><?= $data[0] ?></div>
</td>
<td class="ctr top">
	<h3><?= (($verb1)?"$laslbl $msglbl":"$msglbl $laslbl") ?></h3>
	<a href="Monitoring-Events.php?in[]=time&op[]=>&st[]=<?= time() - $rrdstep ?>">
		<canvas id="event" style="display: block;margin: 0 auto;padding: 10px;" width="<?= $mw ?>" height="<?= $mw ?>"></canvas>
	</a>
<?php

$mon[] = array('value' => $data[3]-$data[4],'color' => '#4f4','label' => $stco['100']);
$mon[] = array('value' => $data[4],'color' => '#f44','label' => $stco['200']);

$dev[] = array('value' => ($data[0]-$data[1]-$data[2]),'color' => '#4f4','label' => $stco['100']);
$dev[] = array('value' => $data[1],'color' => '#fa4','label' => "SNMP $outlbl");
$dev[] = array('value' => $data[2],'color' => '#fc4','label' => "$nonlbl SNMP $outlbl");

$res = DbQuery( $link,'events','g','level','level desc','',array('time'),array('>'),array( (time() - $rrdstep)),array(),'LEFT JOIN devices USING (device)' );
while( ($m = DbFetchRow($res)) ){
	$evlvl[$m[0]] = $m[1];
}
DbFreeResult($res);

?>

<script language="javascript">
var data = <?= json_encode($dev,JSON_NUMERIC_CHECK) ?>

var ctd = document.getElementById("dev").getContext("2d");

var myNewChart = new Chart(ctd).Doughnut(data, { segmentStrokeWidth : 1, percentageInnerCutout : 60, animationEasing : "easeOutElastic"});

var data = <?= json_encode($mon,JSON_NUMERIC_CHECK) ?>

var ctm = document.getElementById("mon").getContext("2d");
var myNewChart = new Chart(ctm).Doughnut(data, {segmentStrokeWidth : 1, percentageInnerCutout : 60, animationEasing : "easeOutElastic"});

var data = [
	{
		value : <?= ($evlvl['30'])?$evlvl['30']:0 ?>,
		color: "#aaaaaa",
		label: "<?= $mlvl['30'] ?>"
	},
	{
		value : <?= ($evlvl['50'])?$evlvl['50']:0 ?>,
		color: "#44aa44",
		label: "<?= $mlvl['50'] ?>"
	},
	{
		value : <?= ($evlvl['100'])?$evlvl['100']:0 ?>,
		color: "#4444aa",
		label: "<?= $mlvl['100'] ?>"
	},
	{
		value : <?= ($evlvl['150'])?$evlvl['150']:0 ?>,
		color: "#aaaa44",
		label: "<?= $mlvl['150'] ?>"
	},
	{
		value : <?= ($evlvl['200'])?$evlvl['200']:0 ?>,
		color: "#aa6644",
		label: "<?= $mlvl['200'] ?>"
	},
	{
		value : <?= ($evlvl['250'])?$evlvl['250']:0 ?>,
		color: "#aa4444",
		label: "<?= $mlvl['250'] ?>"
	},
]
var cte = document.getElementById("event").getContext("2d");
var myNewChart = new Chart(cte).PolarArea(data,{segmentStrokeWidth : 1, animationEasing : "easeOutElastic"});

</script>

</td>
<?php } ?>
<td>
<?php if( !$do ){ ?>
	<h3 class="lft">
		<img src="img/16/exit.png" title="Stop" onclick="stop_countdown(interval);">
		<span id="counter"><?= $refresh ?></span>
		<img src="img/16/bbrt.png" title="<?= $fwdlbl ?>" onclick="document.dynfrm.submit();">
		<a href="?do=ed" title="<?= $edilbl ?>"><img src="img/16/note.png"></a>
	</h3>
<?php } ?>
</td>
</tr>
</table>
</form>
<p>

<?php
if( $do ){
	if( $do == 'dl' ){
		if( !DbQuery($link,'monimap','d','','','',array('id'),array('='),array($id)) ){echo "<h4>".DbError($link)."</h4>";}else{echo "<h5>$dellbl Id $id OK</h5>";}
	}elseif( $do == 'up' ){
		if( !DbQuery($link,'monimap','u','','','',array('id'),array($id),array('mapopts'),array("$grp$pri$siz$acs")) ){echo "<h4>".DbError($link)."</h4>";}else{echo "<h5>$updlbl Id $id OK</h5>";}
	}
?>

<h2><?= $maplbl ?> <?= $edilbl ?></h2>

<table class="content">
	<tr class="bgsub">
		<th colspan="4">
			<img src="img/16/paint.png"><br>
			<?= $maplbl ?>
		</th>
		<th>
			<img src="img/16/cog.png"><br>
			<?= $opolbl ?>

		</th>
	</tr>
<?php
	$res = DbQuery( $link,'monimap','s','*','mapopts','',array('usrname','mapopts'),array('=','~'),array($_SESSION['user'],'^...1'),array('OR') );
	while( ($m = DbFetchRow($res)) ){
		if ($row % 2){$bg = "txta"; $bi = "imga";}else{$bg = "txtb"; $bi = "imgb";}
		$row++;
		$ut = urlencode($m[1]);
		$op = str_split($m[4]);
		preg_match('/dim=(\d+)x/',$m[3],$warr);
		$ftxt = str_replace('&','',$m[2]);
		$ftxt = str_replace('in[]=',' ',$ftxt);
		$ftxt = str_replace('op[]=',' ',$ftxt);
		$ftxt = str_replace('st[]=',' ',$ftxt);
		$ftxt = str_replace('co[]=','<br>',$ftxt);
		
		TblRow( $bg );
		TblCell("<img src=\"drawmap.php?tit=$ut&$m[2]&$m[3]\" width=\"".$mw."px\" title=\"Id:$m[0]\">",'',"$bi ctr m");
		TblCell($m[1],'','b');
		TblCell("$sizlbl ".intval($warr[1]*($op[2]+1)/10)."<br>$warr[1] @ ".(($op[2]+1)*10)."%",'','m');
		TblCell($ftxt,'','l');
?>
		<td>
<?php		if( $_SESSION['user'] != $m[5] ){ ?>
			<?= $usrlbl ?> <?= $m[5] ?>
			<a href="Topology-Map.php?tit=<?= $ut ?>&<?= $m[2] ?>&<?= $m[3] ?>" class="frgt"><img src="img/16/copy.png" title="<?= $coplbl ?>"></a>
<?php		}else{ ?>
			<a href="?do=dl&id=<?= $m[0] ?>" class="frgt"><img src="img/16/bcnl.png" title="<?= $dellbl ?>"></a>
			<a href="Topology-Map.php?tit=<?= $ut ?>&<?= $m[2] ?>&<?= $m[3] ?>" class="frgt"><img src="img/16/copy.png" title="<?= $coplbl ?>"></a>
			<a href="Topology-Map.php?tit=<?= $ut ?>&<?= $m[2] ?>&<?= $m[3] ?>&id=<?= $m[0] ?>" class="frgt"><img src="img/16/note.png" title="<?= $edilbl ?>"></a>
			<form method="get" name="upfrm" action="<?= $self ?>.php">
			<input type="hidden" name="id" value="<?= $m[0] ?>">
			<input type="hidden" name="do" value="up">
			<img src="img/16/size.png" title="<?= $sizlbl ?>">
			<select size="1" name="siz" onchange="this.form.submit();">
<?php
for($i=9;$i;$i--){
	echo "\t\t<option value=\"$i\"".(($op[2]==$i)?" selected":"").">".($i*10+10)."%\n";
}
?>
			</select><br>
			<img src="img/16/ugrp.png" title="<?= $grplbl ?>">
			<select size="1" name="grp" onchange="this.form.submit();">
<?php
for($i=65;$i<(65+$groups);$i++){
	$ch = chr($i);
	echo "\t\t<option value=\"$ch\"".(($op[0]==$ch)?" selected":"").">$ch ($rotlbl)\n";
}
for($i=97;$i<(97+$groups);$i++){
	$ch = chr($i);
	echo "\t\t<option value=\"$ch\"".(($op[0]==$ch)?" selected":"").">$ch ($mullbl)\n";
}
?>
			</select><br>
			<img src="img/16/bup.png" title="<?= $prilbl ?>">
			<select size="1" name="pri" onchange="this.form.submit();">
<?php
for($i=0;$i<10;$i++){
	echo "\t\t<option value=\"$i\"".(($op[1]==$i)?" selected":"").">$i\n";
}
?>
			</select>
			<select size="1" name="acs" onchange="this.form.submit();">
				<option value="0"><?= $nonlbl ?> <?= $acslbl ?>
				<option value="1" <?= ($op[3] == 1)?" selected":"" ?>><?= $alllbl ?> <?= $acslbl ?>
			</select>
			</form>
<?php } ?>
		</td>
	</tr>
<?php
	}
	DbFreeResult($res);
	TblFoot("bgsub", 6, "$row $maplbl");

	include_once ("inc/footer.php");
	exit;
}elseif( !$_SESSION['map'] ){
	$pg  = '';
	$res = DbQuery( $link,'monimap','s','*','mapopts','',array('usrname'),array('='),array($_SESSION['user']) );
	while( ($m = DbFetchRow($res)) ){
		$op = str_split($m[4]);
		if( $pg != $op[0] ){
			$pg = $op[0];
			$grps[] = $op[0];
		}
		preg_match('/dim=(\d+)x/',$m[3],$warr);
		$muri[$op[0]][] = 'tit='.urlencode($m[1])."&$m[2]&$m[3]";
		$mwid[$op[0]][] = intval( $warr[1]/10*($op[2]+1) );
	}
	DbFreeResult($res);
	$ng = ($sg < count($grps)-1 )?$sg + 1:0;
	if( !is_array($muri) ){
		$grps[] = 'A';
		$muri['A'][] = "tit=Click+Monitor+in+Topology-Map+to+add+maps";
		$mwid['A'][] = "1024";
	}
	if( ord($grps[$sg]) > 96 ){
?>
<script language="javascript">
	document.dynfrm.sg.value = '<?= $ng ?>'
</script>
<div align="center">
<?php
		$i = 0;
		foreach ($muri[$grps[$sg]] as $uri){
?>
		<a href="Topology-Map.php?<?= $uri ?>&id=-1"><img class="genpad" style="width:<?= $mwid[$grps[$sg]][$i] ?>px" src="drawmap.php?<?= $uri ?>"></a>
<?php
			$i++;
		}
		echo "</div>";
	}else{
?>
<a href="javascript:linkto()"><img name="map" class="genpad bctr" src="img/32/paint.png"></a>

<script language="javascript">

	document.dynfrm.sg.value = '<?= $ng ?>'
	var maps   = ["<?=  join('","',$muri[$grps[$sg]]) ?>"]
	var mwid   = [<?=  join(',',$mwid[$grps[$sg]]) ?>]
	curmap = -1
	nummap = maps.length
	function cyclemap(){
		curmap++
		if(curmap == nummap){
			curmap = 0
		}
		document.map.src = "drawmap.php?" + maps[curmap]
		document.map.width = mwid[curmap]
		setTimeout("cyclemap()", <?= $rotate ?> * 1000)
	}

	function linkto(){
		document.location.href = "Topology-Map.php?" + maps[curmap] + "&id=-1";
	}

	window.onload = cyclemap();
</script>
<?php
	}
	include_once ("inc/footer.php");
	exit;
}

$statsRackCount=0; $statsAddressCount=0; $statsNoCoords=0;
$res = DbQuery( $link,'locations','s','region,city,building,ns,ew' );
$row = 0;
while( ($l = DbFetchRow($res)) ){
	if($l[2]){
	$nscoord[$l[0]][$l[1]][$l[2]] = $l[3]/10000000;
	$ewcoord[$l[0]][$l[1]][$l[2]] = $l[4]/10000000;
	}
}

if( $flt == 'brk' ){
	$in = 'status';
	$op = '>';
	$st = '0';
}else{
	$in = 'snmpversion';
	$op = '>';
	$st = '0';
}
$okl = 0;
$nol = 0;
$res = DbQuery( $link,'devices','s','devices.device,inet_ntoa(devip),type,location,contact,test,status,latency,latwarn','location','',array($in),array($op),array($st),array(),'LEFT JOIN monitoring on (devices.device = monitoring.name)' );
while( ($dv = DbFetchRow($res)) ){
	if( $dv[3] ){
		if( $flt != 'brk' or $flt == 'brk' and $dv[6] ){
			list($country, $town, $address, $floor, $room, $rack, $ru, $height, $coordinates) = explode(";", $dv[3]);
			if ($coordinates != "") {
				list ($lat_raw, $lng_raw) = explode(",", $coordinates);
				$lat = trim($lat_raw);
				$lng = trim($lng_raw);
			} else {
				$lat = $nscoord[$country][$town][$address];
				$lng = $ewcoord[$country][$town][$address];
			}
			if( $lat and $lng ){
				$loc["$lat;;$lng"]['dv']++;
				$loc["$lat;;$lng"]['al']  += ($dv[6])?1:0;
				$loc["$lat;;$lng"]['cou'] = $country;
				$loc["$lat;;$lng"]['tow'] = $town;
				$loc["$lat;;$lng"]['adr'] = $address;
				$okl++;
			}else{
				$nol++;
			}
		}
	}
}
?>
<script type="text/javascript"
	src="inc/markerclusterer.js">
</script> 
<script src="https://maps.googleapis.com/maps/api/js?v=3.exp"></script>
<script>
var locations = [
<?php

	foreach (array_keys($loc) as $c){
		list ($lat, $lng) = explode(";;", $c);
		$addrURLen = urlencode($loc[$c]['cou'].$locsep.$loc[$c]['tow'].$locsep.$loc[$c]['adr']);
		$msg_hover = $loc[$c][tow].'\n'.$loc[$c][adr].'\n'.$loc[$c]['al'].' Alerts';
		$msg_click ="<div class=\"s lft\">".$loc[$c]['adr']."<p>";
		$msg_click .="<a href=\"Devices-List.php?in%5B%5D=location&op%5B%5D=~&co%5B%5D=&st%5B%5D=$addrURLen\">Device $lstlbl</a><br>";
		$msg_click .="<a href=\"Nodes-List.php?in%5B%5D=location&op%5B%5D=~&st%5B%5D=$addrURLen\">Node $lstlbl</a><br>";
		$msg_click .="<a href=\"Monitoring-Events.php?in%5B%5D=location&op%5B%5D=~&st%5B%5D=$addrURLen\">$msglbl $lstlbl</a><br>";
		$msg_click .="<a href=\"Monitoring-Setup.php?in%5B%5D=location&op%5B%5D=~&st%5B%5D=$addrURLen\">Setup</a><br>";
		$msg_click .="</div>";
		printf("['%s', %s, %s, '%s', '%s',%s],\n",$address,$lat,$lng,$msg_click,$msg_hover,$loc[$c]['al']);
	}
?>
	];
var map;
var bounds = {};

function initialize() {
var stylarr = [
  {
    featureType: '',
    elementType: '',
	stylers: [
	  { saturation: -75 },
	  { gamma: 1.9 }
	]
  },
  {
    featureType: '',
    // etc...
  }
]

	var mapOptions = {
		zoom: 8,
		center: new google.maps.LatLng(0,0),
		mapTypeId: google.maps.MapTypeId.ROADMAP
	};
	map = new google.maps.Map(document.getElementById('map-canvas'),
		mapOptions);
	map.setOptions({styles: stylarr});
	setMarkers(map,locations)
}

function setMarkers(map,locations){
	var marker, i
	var markers = [];
	bounds = new google.maps.LatLngBounds();
	for (i = 0; i < locations.length; i++)
	{  

		var address = locations[i][0]
		var lat = locations[i][1]
		var lng = locations[i][2]
		var msg_click =  locations[i][3]
		var msg_hover = locations[i][4]

		latlngset = new google.maps.LatLng(lat, lng);

		if( locations[i][5] ){
			var marker = new google.maps.Marker({
				map: map,
				icon: ( locations[i][5] == 1 )?'img/32/foye.png':'img/32/ford.png',
				animation: google.maps.Animation.BOUNCE,
				title: msg_hover,
				position: latlngset
			});
		}else{
			var marker = new google.maps.Marker({
				map: map,
				icon: 'img/32/fogr.png',
				title: msg_hover,
				position: latlngset
			});
		}

		map.setCenter(marker.getPosition())
		var content = msg_click
		var infowindow = new google.maps.InfoWindow({ maxWidth: 320 })
		google.maps.event.addListener(marker,'click', (function(marker,content,infowindow){
			return function() { infowindow.setContent(content);	infowindow.open(map,marker); };	})(marker,content,infowindow));
		bounds.extend(latlngset);
		map.fitBounds(bounds);
		markers.push(marker); // Comment this out if you dont want clustering of markers
	}
	var markerCluster = new MarkerClusterer(map, markers, {
		maxZoom: 16,
		averageCenter: 1,
	});
	bounds.extend(latlngset);
	map.fitBounds(bounds);
}

function myclick(i) {
	google.maps.event.trigger(markers[i], "click");
}

google.maps.event.addDomListener(window, 'load', initialize);
</script>

<center><div id="map-canvas" style="width:1000px; height:600px;border:1px solid black"></div></center>

<div class="textpad txtb half">
	<a  href="javascript: map.fitBounds(bounds);"><img src="img/16/bbup.png" title="<?= $toplbl ?> <?= $levlbl ?>"></a>
	<a  href="?flt=brk"><img src="img/16/flag.png" title="<?= $fltlbl ?> <?= $mlvl['200'] ?>"></a>
	<?= $nonlbl ?> <?= $loclbl ?>: <?= $nol ?>/<?= $okl+$nol ?><br>
</div>
</center>
<?php

if($status and $_SESSION['vol']){echo "<audio src=\"inc/major.mp3\" autoplay onplay=\"this.volume=.$_SESSION[vol]\">no audio</audio>\n";}

include_once ("inc/footer.php");

?>
