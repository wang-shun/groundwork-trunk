<?php
# Program: Nodes-List.php
# Programmer: Remo Rickli

$exportxls = 1;

include_once ("inc/header.php");
include_once ("inc/libnod.php");
include_once ("inc/libdev.php");

$_GET = sanitize($_GET);
$in = isset($_GET['in']) ? $_GET['in'] : array();
$op = isset($_GET['op']) ? $_GET['op'] : array();
$st = isset($_GET['st']) ? $_GET['st'] : array();
$co = isset($_GET['co']) ? $_GET['co'] : array();

$ord = isset($_GET['ord']) ? $_GET['ord'] : '';
if($_SESSION['opt'] and !$ord and $st[0]) $ord = $in[0];

$map = isset($_GET['map']) ? "checked" : "";
$lim = isset($_GET['lim']) ? preg_replace('/\D+/','',$_GET['lim']) : $listlim;

$ugr = isset($_GET['ugr']) ? $_GET['ugr'] : '';

if( isset($_GET['col']) ){
	$col = $_GET['col'];
	if($_SESSION['opt']) $_SESSION['nodcol'] = $col;
}elseif( isset($_SESSION['nodcol']) ){
	$col = $_SESSION['nodcol'];
}else{
	$col = array('imBL','aname','nodip','firstseen','lastseen','device','ifname','vlanid');
}

$cols = array(	"imBL"=>$imglbl,
		"aname"=>$namlbl,
		"mac"=>"MAC $adrlbl",
		"oui"=>"$venlbl",
		"nodip"=>"IP $adrlbl",
		"ipchanges"=>"#IP $chglbl",
		"ipupdate"=>"IP $updlbl",
		"aaaaname"=>"IP6 $namlbl",
		"nodip6"=>"IP6 $adrlbl",
		"ip6update"=>"IP6 $updlbl",
		"firstseen"=>$fislbl,
		"lastseen"=>$laslbl,
		"noduser"=>"$usrlbl",
		"nodesc"=>$deslbl,
		"device"=>"Device",
		"type"=>"Device $typlbl",
		"location"=>$loclbl,
		"contact"=>$conlbl,
		"devgroup"=>$grplbl,
		"ifname"=>$porlbl,
		"ifdesc"=>"IF $deslbl",
		"alias"=>"IF Alias",
		"speed"=>$spdlbl,
		"duplex"=>"Duplex",
		"vlanid"=>"Vlan",
		"linktype"=>"$cnclbl $typlbl",
		"pvid"=>"$porlbl Vlan $idxlbl",
		"metric"=>$metlbl,
		"ifupdate"=>"$cnclbl $updlbl",
		"ifchanges"=>"#IF $chglbl",
		"lastchg"=>"IF $stalbl $chglbl",
		"poe"=>"PoE",
		"dinoct"=>"$laslbl $trflbl ".substr($inblbl,0,3),
		"doutoct"=>"$laslbl $trflbl ".substr($oublbl,0,3),
		"dinerr"=>"$laslbl $errlbl ".substr($inblbl,0,3),
		"douterr"=>"$laslbl $errlbl ".substr($oublbl,0,3),
		"dindis"=>"$laslbl $dcalbl ".substr($inblbl,0,3),
		"doutdis"=>"$laslbl $dcalbl ".substr($oublbl,0,3),
		"dinbrc"=>"$laslbl Broadcasts ".substr($inblbl,0,3),
		"tcpports"=>"TCP $porlbl",
		"udpports"=>"UDP $porlbl",
		"srvtype"=>"$srvlbl $typlbl",
		"srvos"=>"Node OS",
		"srvupdate"=>"$srvlbl $updlbl",
		"sshNS"=>"$rltlbl SSH",
		"telNS"=>"$rltlbl Telnet",
		"wwwNS"=>"$rltlbl HTTP",
		"nbtNS"=>"$rltlbl Netbios",
		"metNS"=>"$metlbl $gralbl",
		"rdrNS"=>"Radar $gralbl",
		"gfNS"=>"RRD $gralbl"
		);

$link = DbConnect($dbhost,$dbuser,$dbpass,$dbname);

?>
<script src="inc/Chart.min.js"></script>

<h1 onclick="document.list.style.display = (document.list.style.display == 'none')?'':'none';">Node <?= $lstlbl ?></h1>

<?php  if( !isset($_GET['print']) and !isset($_GET['xls']) ) { ?>

<form method="get" name="list" action="<?= $self ?>.php">
<table class="content" ><tr class="bgmain">
<td class="ctr s">
	<a href="<?= $self ?>.php"><img src="img/32/<?= $selfi ?>.png" title="<?= $self ?>"></a>
</td>
<td>
<?php Filters(); ?>
</td>
<td class="ctr">
	<a href="?in[]=dinerr&op[]=>&st[]=0&co[]=OR&in[]=douterr&op[]=>&st[]=0"><img src="img/16/brup.png" title="IF <?= $errlbl ?>"></a>
	<a href="?in[]=dindis&op[]=>&st[]=0&co[]=OR&in[]=doutdis&op[]=>&st[]=0"><img src="img/16/bbu2.png" title="IF <?= $dcalbl ?>"></a><br>
	<a href="?in[]=vlanid&op[]=~&st[]=&co[]=!%3D&in[]=pvid&op[]=~&st[]=&co[]=AND&in[]=metric&op[]=~&st[]=[A-L]"><img src="img/16/vlan.png" title="PVID != Vlan"></a>
	<a href="?in[]=metric&op[]=~&st[]=[M-Z]"><img src="img/16/wlan.png" title="Wlan Nodes"></a>

</td>
<td class="ctr">
	<select multiple name="col[]" size="6" title="<?= $collbl ?>">
<?php
foreach ($cols as $k => $v){
	echo "\t\t<option value=\"$k\"".((in_array($k,$col))?" selected":"").">$v\n";
}
?>
	</select>
</td>
<td>
	<img src="img/16/paint.png" title="<?= (($verb1)?"$sholbl $laslbl Map":"Map $laslbl $sholbl") ?>">
	<input type="checkbox" name="map" <?= $map ?>><br>
	<img src="img/16/form.png" title="<?= $limlbl ?>">
	<select size="1" name="lim">
<?php selectbox("limit",$lim) ?>
	</select>
</td>
<td class="ctr">
	<input type="submit" class="button" value="<?= $sholbl ?>"><br>
<?php  if($isadmin) { ?>
	<input type="submit" class="button" name="mon" value="<?= $monlbl ?>" onclick="return confirm('Monitor <?= $addlbl ?>?')" ><br>
	<input type="submit" class="button" name="del" value="<?= $dellbl ?>" onclick="return confirm('<?= $dellbl ?>, <?= $cfmmsg ?>')" ><br>
<?php }
if( $ismgr and $rdbhost ){
	$rlink = DbConnect($rdbhost,$rdbuser,$rdbpass,$rdbname);
	$res   = DbQuery( $rlink,'radgroupreply' );
	while( $g = DbFetchRow($res) ){
		$gval[$g[1]][$g[2]] = $g[4]; 
	}
	DbFreeResult($res);
?>
	<select size="1" name="ugr">
		<option value=""><?= $grplbl ?> >
<?php
foreach ( array_keys($gval) as $g){
	echo "\t\t<option value=\"$g\">$g\n";
}
?>
	</select>
	<input type="submit" class="button" name="rad" value="<?= $addlbl ?>" onclick="return confirm('Radius <?= $addlbl ?>?')" ><br>
<?php } ?>
</td>
</tr>
</table>
</form>
<p>

<?php
}
if( count($in) ){
	if ($map and !isset($_GET['xls']) and file_exists("map/map_$_SESSION[user].php")) {
		echo "<div class=\"ctr\">\n\t<h2>$netlbl Map</h2>\n";
		echo "\t<img src=\"map/map_$_SESSION[user].php\" class=\"genpad\">\n</div>\n<p>\n\n";
	}
	Condition($in,$op,$st,$co);
	if( isset($_GET['del']) ){
		array_push($col, "del");
		$cols['del'] = "$dellbl $stalbl";
	}
	TblHead("bgsub",1);
	
	$join = '';
	$jcol = '';
	$mgar = array_merge($in,$col);
	if( in_array('nodip',$mgar) or in_array('ipchanges',$mgar) or in_array('ipupdate',$mgar) or in_array('tcpports',$mgar) or in_array('udpports',$mgar)
			or in_array('srvtype',$mgar) or in_array('srvos',$mgar) or in_array('srvupdate',$mgar) or in_array('aname',$col) or 
			($in[0] == 'aname' and $st[0] != '') or isset($_GET['mon']) ){
		$join .= ' LEFT JOIN nodarp USING (mac) LEFT JOIN dns USING (nodip)';
		$jcol .= ',nodip,ipchanges,ipupdate,tcpports,udpports,srvtype,srvos,srvupdate,aname';
	}
	if( in_array('nodip6',$mgar) or in_array('ip6update',$mgar) or in_array('aaaaname',$mgar) ){
		$join .= ' LEFT JOIN nodnd USING (mac) LEFT JOIN dns6 USING (nodip6)';
		$jcol .= ',nodip6,ip6update,aaaaname';
	}
	$res = DbQuery( $link,'nodes','s','nodes.*,location,contact,devgroup,type,iftype,ifdesc,alias,ifstat,speed,duplex,pvid,linktype,lastchg,poe,dinoct,doutoct,dinerr,douterr,dindis,doutdis,dinbrc'.$jcol,
	$ord,$lim,$in,$op,$st,$co,'LEFT JOIN devices USING (device) LEFT JOIN interfaces USING (device,ifname)'.$join
		);

	if($res){
		$row = 0;
		while( ($n = DbFetchArray($res)) ){
			if ($row % 2){$bg = "txta"; $bi = "imga";}else{$bg = "txtb"; $bi = "imgb";}
			$row++;
			$most		= '';
			$rust		= '';
			$rgst		= '';
			$img		= VendorIcon($n['oui']);
			list($fc,$lc)	= Agecol($n['firstseen'],$n['lastseen'],$row % 2);
			list($i1c,$i2c) = Agecol($n['ifupdate'],$n['ifupdate'],$row % 2);
			list($i1l,$i2l) = Agecol($n['lastchg'],$n['lastchg'],$row % 2);
			list($ifi,$ift)	= Iftype($n['iftype']);
			list($ifb,$ifs)	= Ifdbstat($n['ifstat']);
			$wasup		= ($n['lastseen'] > time() - $rrdstep * 1.5)?1:0;
			$ud		= urlencode($n['device']);
			$ui		= urlencode($n['ifname']);
			$nip		= long2ip($n['nodip']);

			if( isset($_GET['mon']) and $isadmin and $n['nodip'] ){
				$mona = ($n['aname'])?$n['aname']:$nip;
				$most = AddRecord($link,'monitoring',
						array('name'),
						array($mona),
						array('name','monip','class','test','alert','device','depend1','latwarn'),
						array($mona,$n['nodip'],'node','ping',2,$n['device'],$n['device'],$latw)
					);
			}
			if($rdbhost and $ismgr and isset($_GET['rad']) ){
				$rust = AddRecord($rlink,'radcheck',
						array('username'),
						array($n['mac']),
						array('username','attribute','op','value'),
						array($n['mac'],'Cleartext-Password',':=',$n['mac'])
					);
				if( $ugr ) $rgst = AddRecord($rlink,'radusergroup',
							array('username'),
							array($n['mac']),
							array('username','groupname'),
							array($n['mac'],$ugr)
						);
			}
			TblRow($bg);
			if(in_array("imBL",$col))	TblCell('','',"$bi ctr xs","+<a href=\"Nodes-Status.php?st=$n[mac]&vid=$n[vlanid]\"><img src=\"img/oui/$img.png\" title=\"$n[oui] ($n[mac])\"></a>");
			if(in_array("aname",$col))	TblCell( preg_replace("/^(.*?)\.(.*)/","$1", $n['aname'])." $most $rust $rgst","?in[]=aname&op[]==&st[]=".urlencode($n['aname']),'b');
			if( in_array("mac",$col) )	TblCell($n['mac'],"?in[]=mac&op[]==&st[]=$n[mac]",'code', ModLink('Other','Flower','fsm='.rtrim(chunk_split($n['mac'],2,":"),":")) );
			if(in_array("oui",$col))	TblCell($n['oui'],"?in[]=oui&op[]==&st[]=".urlencode($n['oui']) );
			if(in_array("nodip",$col))	TblCell($nip,"?in[]=nodip&op[]==&st[]=$nip",'',ModLink('Other','Flower',"fet=2048&fsi=$nip") );
			if(in_array("ipchanges",$col))	TblCell($n['ipchanges'],"?in[]=ipchanges&op[]==&st[]=$n[ipchanges]");
			if(in_array("ipupdate",$col))	TblCell(($n['ipupdate'])?date($_SESSION['timf'],$n['ipupdate']):'-',"?in[]=ipupdate&op[]==&st[]=$n[ipupdate]",'nw','',"background-color:#$i1c");
			if(in_array("aaaaname",$col))	TblCell($n['aaaaname'],"?in[]=aaaaname&op[]==&st[]=".urlencode($n['aaaaname']),'b');
			if(in_array("nodip6",$col))	TblCell(DbIPv6($n['nodip6']),'','prp code' );
			if(in_array("ip6update",$col))	TblCell(date($_SESSION['timf'],$n['ip6update']),($n['ip6update'])?"?in[]=ip6update&op[]==&st[]=$n[ip6update]":"",'nw','',"background-color:#$i1c");
			if(in_array("firstseen",$col))	TblCell(date($_SESSION['timf'],$n['firstseen']),"?in[]=firstseen&op[]==&st[]=$n[firstseen]",'nw','',"background-color:#$fc");
			if(in_array("lastseen",$col))	TblCell(date($_SESSION['timf'],$n['lastseen']),"?in[]=lastseen&op[]==&st[]=$n[lastseen]",'nw','',"background-color:#$lc");
			if(in_array("noduser",$col))	TblCell($n['noduser'],"?in[]=noduser&op[]==&st[]=".urlencode($n['noduser']));
			if(in_array("nodesc",$col))	TblCell($n['nodesc'],"?in[]=nodesc&op[]==&st[]=".urlencode($n['nodesc']));
			if( in_array("device",$col) )	TblCell($n['device'],"?in[]=device&op[]==&st[]=$ud&ord=ifname",'nw',ModLink('Devices','Status',"dev=$ud&pop=on") );
			if(in_array("type",$col))	TblCell($n['type'],"?in[]=type&op[]==&st[]=".urlencode($n['type']) );
			if(in_array("location",$col))	TblCell($n['location'],"?in[]=location&op[]==&st[]=".urlencode($n['location']) );
			if(in_array("contact",$col))	TblCell($n['contact'],"?in[]=contact&op[]==&st[]=".urlencode($n['contact']) );
			if(in_array("devgroup",$col))	TblCell($n['devgroup'],"?in[]=devgroup&op[]==&st[]=".urlencode($n['devgroup']) );
			if( in_array("ifname",$col) )	TblCell($n['ifname'],"?in[]=device&op[]==&st[]=$ud&co[]=AND&in[]=ifname&op[]==&st[]=$ui",$ifb,"<img src=\"img/$ifi\" title=\"$ift, $ifs\"> ");
			if(in_array("ifdesc",$col))	TblCell($n['ifdesc']);
			if(in_array("alias",$col))	TblCell(htmlspecialchars($n['alias']),"?in[]=alias&op[]==&st[]=".urlencode($n[alias]) );
			if(in_array("speed",$col))	TblCell(DecFix($n['speed']),"","align=\"right\"" );
			if(in_array("duplex",$col))	TblCell($n['duplex']);
			if(in_array("vlanid",$col))	TblCell((preg_match('/[M-Z]/',$n['metric']) )?"SSID:$n[vlanid]":$n['vlanid'],"?in[]=vlanid&op[]==&st[]=$n[vlanid]",'rgt');
			if(in_array("pvid",$col))	TblCell((preg_match('/[M-Z]/',$n['metric']))?"CH:$n[pvid]":$n['pvid'],"?in[]=pvid&op[]==&st[]=$n[pvid]",'rgt');
			if(in_array("metric",$col))	TblCell($n['metric'] );
			if(in_array("ifupdate",$col))	TblCell(date($_SESSION['timf'],$n['ifupdate']),"?in[]=ifupdate&op[]==&st[]=$n[ifupdate]",'nw','',"background-color:#$i1c");
			if(in_array("ifchanges",$col))	TblCell($n['ifchanges'],"?in[]=ifchanges&op[]==&st[]=$n[ifchanges]");
			if(in_array("linktype",$col))	TblCell($n['linktype'],"?in[]=linktype&op[]==&st[]=$n[linktype]",'',$n['linktype']?'+<img src="'.LtypIcon($n['linktype']).'">':'');
			if(in_array("lastchg",$col))	TblCell(($n['lastchg'])?date($_SESSION['timf'],$n['lastchg']):'-',"?in[]=lastchg&op[]==&st[]=$n[lastchg]",'nw','',"background-color:#$i1l");
			if(in_array("poe",$col))	TblCell($n['poe'].' mW',"?in[]=poe&op[]==&st[]=$n[poe]",'rgt');
			if(in_array("dinoct",$col))	TblCell($n['dinoct']);
			if(in_array("doutoct",$col))	TblCell($n['doutoct']);
			if(in_array("dinerr",$col))	TblCell($n['dinerr']);
			if(in_array("douterr",$col))	TblCell($n['douterr']);
			if(in_array("dindis",$col))	TblCell($n['dindis']);
			if(in_array("doutdis",$col))	TblCell($n['doutdis']);
			if(in_array("dinbrc",$col))	TblCell($n['dinbrc']);
			if(in_array("tcpports",$col)){
				if( isset($_GET['xls']) ){
					TblCell($n['tcpports']);
				}else{
					$tp = explode(',',$n['tcpports']);
					echo "\t\t<td>\n";
					foreach ($tp as $i){
						if($i) echo SrvImg( $i );
					}
					echo "\t\t</td>\n";
				}
			}
			if(in_array("udpports",$col)){
				if( isset($_GET['xls']) ){
					TblCell($n['udpports']);
				}else{
					$tp = explode(',',$n['udpports']);
					echo "\t\t<td>\n";
					foreach ($tp as $i){
						if($i) echo SrvImg( $i );
					}
					echo "\t\t</td>\n";
				}
			}
			if(in_array("srvtype",$col)){
				if( isset($_GET['xls']) ){
					TblCell($n['srvtype']);
				}else{
					$svt = explode(',',$n['srvtype']);
					echo "\t\t<td>\n";
					foreach ($svt as $s){
						if($s) echo "$s ";
					}
					echo "\t\t</td>\n";
				}
			}
			if(in_array("srvos",$col))	TblCell($n['srvos'],"?in[]=srvos&op[]==&st[]=$n[srvos]",'nw',($n['srvos'])?'+'.OSImg($n['srvos']):'' );
			if(in_array("srvupdate",$col))	TblCell(($n['srvupdate'])?date($_SESSION['timf'],$n['srvupdate']):'-');

			if( !isset($_GET['xls']) ){
				if(in_array("sshNS",$col)){
					echo "\t\t<td>\n\t\t\t<a href=ssh://$nip><img src=\"img/16/lokc.png\"></a>\n";
					echo (($wasup)?CheckTCP($nip,'22',''):"-") ."\n\t\t</td>\n";
				}
				if(in_array("telNS",$col)){
					echo "\t\t<td>\n\t\t\t<a href=telnet://$nip><img src=\"img/16/loko.png\"></a>\n";
					echo (($wasup)?CheckTCP($nip,'23',''):"-") ."</td>";
				}
				if(in_array("wwwNS",$col)){
					echo "\t\t<td>\n\t\t\t<a href=http://$nip target=window><img src=\"img/16/glob.png\"></a>\n";
					echo (($wasup)?CheckTCP($nip,'80',"GET / HTTP/1.0\r\n\r\n"):"-") ."\n\t\t</td>\n";
				}
				if(in_array("nbtNS",$col)){
					echo "\t\t<td>\n\t\t\t<img src=\"img/16/nwin.png\">\n";
					echo (($wasup)?NbtStat($nip):"-") ."\n\t\t</td>";
				}
				if( in_array("metNS",$col) ){
					echo "\t\t<td class=\"ctr nw\">\n";
					MetricChart("me$row",$_SESSION['gsiz'], $n['metric']);
					echo "\n\t\t</td>\n";
				}
				if( in_array("rdrNS",$col) ){
					echo "\t\t<td class=\"ctr nw\">\n";
					IfRadar("ra$row",$_SESSION['gsiz'],'82',$n['dinoct'],$n['doutoct'],$n['dinerr'],$n['douterr'],$n['dindis'],$n['doutdis'],$n['dinbrc']);
					echo "\n\t\t</td>\n";
				}
				if( in_array("gfNS",$col) ){
					echo "\t\t<td class=\"ctr nw\">\n";
					IfGraphs($ud, $ui, $n['speed'],($_SESSION['gsiz'] == 4)?2:1 );
					echo "\n\t\t</td>\n";
				}
				if( isset($_GET['del']) ){
					echo "\t\t<td>\n";
					if($isadmin){
						NodDelete($n['mac']);
					}else{
						echo $nokmsg;
					}
					echo "\t\t</td>\n";
				}
			}
			echo "\t</tr>\n";
		}
		DbFreeResult($res);
	}else{
		print DbError($link);
	}
	TblFoot("bgsub", count($col), "$row $vallbl".(($ord)?", $srtlbl: $ord":"").(($lim)?", $limlbl: $lim":"") );
}elseif($_SESSION['opt']){
	include_once ("inc/librep.php");
	NodSum($in[0],$op[0],$st[0],$_SESSION['lim'],'');
}
include_once ("inc/footer.php");
?>
