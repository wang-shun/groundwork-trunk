<?php
# Program: System-PBX.php
# Programmer: Remo Rickli

$exportxls = 0;

include_once ("inc/header.php");

$_GET = sanitize($_GET);
$pbx = isset($_GET['pbx']) ? $_GET['pbx'] : '';
$lim = isset($_GET['lir']) ? preg_replace('/\D+/','',$_GET['lir']) : 10;

?>
<h1 onclick="document.list.style.display = (document.list.style.display == 'none')?'':'none';">PBX Status</h1>

<?php  if( !isset($_GET['print']) ) { ?>
<form method="get" name="list" action="<?= $self ?>.php">
<table class="content"><tr class="bgmain">
<td class="ctr s">
	<a href="<?= $self ?>.php"><img src="img/32/<?= $selfi ?>.png" title="<?= $self ?>"></a>
</td>
<td>
	<input type="text" name="pbx" value="<?= $pbx ?>" placeholder="User@PBX" class="l">
</td>
<td>
	<img src="img/16/form.png" title="<?= $limlbl ?>">
	<select size="1" name="lir">
<?php selectbox("limit",$lim) ?>
	</select>
</td>
<td class="ctr s">
	<input type="submit" class="button" value="<?= $sholbl ?>">
</td>
</tr></table>
</form>
<p>
<?php
}

$cmd = "/usr/sbin/asterisk -r -x 'sip show peers'";
$exe = ($pbx)?"ssh $pbx \"$cmd\"":$cmd;
$sta = exec( $exe, $out );

echo "<h2>Extensions</h2>\n";

if($debug){
	echo "<div class=\"textpad code pre txtb tqrt\">$exe\n";
	print_r($out);
	echo "</div>\n";
}

$col = array(
		'img'=>'imgBL',
		'name'=>$namlbl,
		'host'=>"IP $adrlbl",
		'port'=>$porlbl,
		'state'=>$stalbl,
		'lat'=>$latlbl
		);

TblHead("bgsub",1);
$row = 0;
array_shift($out);
foreach( $out as $l){
	if( !preg_match('/sip peers|Privilege escalation|See https/',$l) ){
		if ($row % 2){$bg = "txta"; $bi = "imga";}else{$bg = "txtb"; $bi = "imgb";}
		$row++;
		$f = preg_split('/\s+/',$l);
		TblRow( $bg );
		TblCell( ($f[2]=='D')?'<img src="img/16/voip.png">':'<img src="img/16/nhub.png">','',($f[4]=='OK'?'good':'alrm').' ctr xs' );
		TblCell($f[0]);
		TblCell($f[1]);
		TblCell($f[3]);
		TblCell($f[4]);
		TblCell( substr("$f[5] $f[6]",1,-1) );
		echo "\t</tr>\n";
	}
}
TblFoot("bgsub", count($col), "$row Extensions".(($ord)?", $srtlbl: $ord":"").(($lim)?", $limlbl: $lim":"") );

unset($out);
$cmd = "/usr/sbin/asterisk -r -x 'core show channels'";
$exe = ($pbx)?"ssh $pbx \"$cmd\"":$cmd;
$sta = exec( $exe, $out );

echo "<h2>$stco[100] Channels</h2>\n";

if($debug){
	echo "<div class=\"textpad code pre txtb tqrt\">$exe\n";
	print_r($out);
	echo "</div>\n";
}

$col = array(
	'channel'=>'Channel',
	'loc'=>$loclbl,
	'state'=>$stalbl,
	'app'=>'Application'
	);

TblHead("bgsub",1);
$row = 0;
array_shift($out);
foreach( $out as $l){
	if( strstr($l,'calls processed') ){
		$totcalls = $l;
	}elseif( strstr($l,'active call') ){
		$actcalls = $l;
	}elseif( strstr($l,'active channel') ){
		$actchnls = $l;
	}elseif( !preg_match('/Privilege escalation|See https/',$l) ){
		if ($row % 2){$bg = "txta"; $bi = "imga";}else{$bg = "txtb"; $bi = "imgb";}
		$row++;
		$f = preg_split('/\s+/',$l);
		TblRow( ($f[4]=='OK')?'good':$bg );
		TblCell($f[0]);
		TblCell($f[1]);
		TblCell($f[2]);
		TblCell("$f[3] $f[4]");
		echo "\t</tr>\n";
	}
}
TblFoot("bgsub", count($col), "$actchnls, $actcalls, $totcalls" );

unset($out);
$stat = exec( "tail -$lim /var/log/asterisk/cdr-csv/Master.csv", $out );

echo "<h2>Call $loglbl</h2>\n";

$col = array(
	'src'=>$srclbl,
	'dst'=>$dstlbl,
	'sta'=>$sttlbl,
	'dur'=>$durlbl,
	'inf'=>$inflbl
	);

TblHead("bgsub",1);
$row = 0;
$rev = array_reverse($out);
foreach( $rev as $l){
	if ($row % 2){$bg = "txta"; $bi = "imga";}else{$bg = "txtb"; $bi = "imgb";}
	$row++;
	$f = str_getcsv($l);
	if( $f[10] ){
		$d = round( (strtotime($f[11]) - strtotime($f[10]))/60,1 );
		$i = '+'.Bar($d,15,'sbar');
	}else{
		$d = '';
		$i = '';
	}
	if($debug){
		echo "<div class=\"textpad code pre txtb tqrt\">\n";
		print_r($f);
		echo "</div>\n";
	}
	TblRow( ($f[14]=='ANSWERED')?$bg:"warn" );
	TblCell($f[4]);
	TblCell( ($f[2] == 's')?$f[6]:$f[2] );
	TblCell($f[9],'','nw');
	TblCell($d,'','nw',$i );
	TblCell( $f[3] );
	echo "\t</tr>\n";
}
TblFoot("bgsub", count($col), "$row $totlbl" );

include_once ("inc/footer.php");
?>
