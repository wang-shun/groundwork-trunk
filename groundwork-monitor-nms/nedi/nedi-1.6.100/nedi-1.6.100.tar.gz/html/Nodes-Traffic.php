<?php
# Program: Nodes-Traffic.php
# Programmer: Remo Rickli

$exportxls = 1;

include_once ("inc/header.php");
include_once ("inc/libnod.php");
include_once ("inc/libdev.php");

$_GET = sanitize($_GET);
$mde = isset($_GET['mde']) ? $_GET['mde'] : 's';
$in  = isset($_GET['in']) ? $_GET['in'] : array('');
$sc  = isset($_GET['sc']) ? $_GET['sc'] : array();
$ord = isset($_GET['ord']) ? $_GET['ord'] : 'pkt';
$flt = isset($_GET['flt']) ? $_GET['flt'] : '';
$lim = isset($_GET['lir']) ? $_GET['lir'] : 10;

$cha = isset($_GET['cha']) ? "checked" : '';
$nam = isset($_GET['nam']) ? "checked" : '';
$oui = isset($_GET['oui']) ? "checked" : '';

$tfarr['raw'] = isset($_GET['stt']) ? $_GET['stt'] : date("m/d/Y H:i", time() - 300);
$tfarr['dur'] = isset($_GET['dur']) ? $_GET['dur'] : 5;

TfInit();

$qflt = '';
if( $flt ){
	if( preg_match('/^[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}$/',$flt) ){
		$flt = "host $flt";
	}elseif( preg_match('/^[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\/[0-9]{1,2}$/',$flt) ){
		$flt = "net $flt";
	}elseif( preg_match('/^[0-9]{1,5}$/',$flt) ){
		$flt = "port $flt";
	}
	$qflt = "'$flt'";
}

$mlbl['t'] = $stslbl;
$mlbl['s'] = $sumlbl;
$mlbl['l'] = $lstlbl;

$flbl['ts'] = $fislbl;
$flbl['te'] = $laslbl;
$flbl['td'] = $durlbl;
$flbl['pr'] = $prolbl;
$flbl['sa'] = "$srclbl $adrlbl";
$flbl['sp'] = "$srclbl $porlbl";
$flbl['da'] = "$dstlbl $adrlbl";
$flbl['dp'] = "$dstlbl $porlbl";
$flbl['ip'] = "IP $adrlbl";
$flbl['po'] = $porlbl;
$flbl['fl'] = 'Flows';
$flbl['pkt'] = $pktlbl;
$flbl['byt'] = 'Bytes';
$flbl['bps'] = "B/s";
$flbl['pps'] = "$pktlbl/s";
$flbl['bpp'] = "B/$pktlbl";

$fnam['pr'] = 'proto';
$fnam['sa'] = 'srcip';
$fnam['da'] = 'dstip';
$fnam['ip'] = 'ip';
$fnam['sp'] = 'srcport';
$fnam['dp'] = 'dstport';
$fnam['po'] = 'port';

$onam['byt'] = 'bytes';
$onam['pkt'] = 'packets';
$onam['fl']  = 'flows';
$onam['bps'] = 'bps';
$onam['pps'] = 'pps';
$onam['bpp'] = 'bpp';

$agglst = array('','sa','sp','da','dp','pr');
$toplst = array('sa','da','ip','sp','dp','po','pr');
$ordlst = array('pkt','byt','fl','bps','pps','bpp');

$chopt = ', {segmentStrokeWidth : 1'.$anim.'}';

foreach (glob("$nfdpath/*") as $d) {
	$s = substr($d, strlen($nfdpath)+1 );
	if( !count($sc) or in_array($s, $sc) ){
		$scarr[] = $s;
		$scopt[] = "\t\t\t<option value=\"$s\" selected>$s\n";
	}else{
		$scopt[] = "\t\t\t<option value=\"$s\">$s\n";
	}
}
$src = implode(":", $scarr);
?>

<h1 onclick="document.dynfrm.style.display = (document.dynfrm.style.display == 'none')?'':'none';">Nodes <?= $trflbl ?></h1>

<?php  if( !isset($_GET['print']) and !isset($_GET['xls']) ) { ?>
<form method="get" name="dynfrm" action="<?= $self ?>.php">
<table class="content"><tr class="bgmain">
<td class="ctr s">
	<a href="<?= $self ?>.php"><img src="img/32/<?= $selfi ?>.png" title="<?= $self ?>"></a>
</td>
<td class="ctr nw">
<?php
/*
 * 	<select name="mde" size="6" onchange="this.form.submit();">
		<option value="s" <?= ($mde == 's')?" selected":"" ?>><?= $mlbl['s'] ?>

		<option value="t" <?= ($mde == 't')?" selected":"" ?>><?= $mlbl['t'] ?>

		<option value="l" <?= ($mde == 'l')?" selected":"" ?>><?= $mlbl['l'] ?>

	</select>
<?php
*/
if( $mde != 'l' ){
	if( $mde == 't' ){
		if( !$in[0] ) $in[0] = 'pr';
		$fsel = $toplst;
?> 
	<select name="in[]" size="6">
<?php
	}elseif( $mde == 's' ){
		$fsel = $agglst;
?>
	<select multiple name="in[]" size="6">
<?php
	}
	foreach ($fsel as $i){
		echo "\t\t\t<option value=\"$i\"".( in_array($i,$in)?" selected":"").">$flbl[$i]\n";
	}
?>
	</select>
	<select name="ord" size="6">
<?php
	foreach ($ordlst as $i){
		echo "\t\t\t<option value=\"$i\"".( ($ord == $i)?" selected":"").">$flbl[$i]\n";
	}
?>
	</select>
</td>
<td class="ctr">
	<select multiple name="sc[]" size="6">
<?php
	foreach ($scopt as $i){
		echo $i;
	}
?>
		</select>
</td>
<?php } ?>
<td>
	<img src="img/16/glob.png" title="Web <?= $prolbl ?> <?= $dstlbl ?>" onclick="document.dynfrm.flt.value='dst port 80 or dst port 443';">
	<img src="img/16/mail.png" title="Email <?= $prolbl ?>" onclick="document.dynfrm.flt.value='port 25 or port 110 or port 143 or port 465 or port 993 or port 995';">
	<img src="img/16/bbdn.png" title="<?= $dstlbl ?> <?= $porlbl ?> < 1024" onclick="document.dynfrm.flt.value='dst port < 1024';">
	<img src="img/16/bcnl.png" title="<?= $reslbl ?>" onclick="document.dynfrm.flt.value='';"><br>
	<input type="text" name="flt" value="<?= $flt ?>" class="l">
<?php
	if($flt){
		foreach ($in as $i){
			$ilst .= "$i,";
		}
		echo ModLink('System','Policy',"cl=$ord&ma=>&tg=1000&dv=".urlencode($src)."&ty=".urlencode($flt)."&gr=".substr($ilst,0,-1));
	}
?>
</td>
<td class="ctr">
<?php TfWidgets(1) ?>
</td>
<?php if( $mde != 'l' ){ ?>
<td class="ctr">
	<select size="1" name="lir">
<?php selectbox("limit",$lim) ?>
	</select>
</td>
<?php
}
if( $mde == 's' ){
?>
<td class="ctr">
	<img src="img/16/chrt.png" title="<?= (($verb1)?"$sholbl $gralbl":"$gralbl $sholbl") ?>">
	<input type="checkbox" name="cha" <?= $cha ?>><br>
	<img src="img/16/find.png" title="<?= (($verb1)?"$sholbl $namlbl":"$namlbl $sholbl") ?> (WHOIS)">
	<input type="checkbox" name="nam" <?= $nam ?>><br>
	<img src="img/16/card.png" title="<?= (($verb1)?"$sholbl OUI $venlbl":"OUI $venlbl $sholbl") ?>">
	<input type="checkbox" name="oui" <?= $oui ?>><br>
</td>
<?php } ?>
<td class="ctr s">
	<input type="submit" class="button" name="sho" value="<?= $sholbl ?>">
</td>
</tr>
</table>
</form>
<p>

<script language="javascript">

var cypos = 0;
var cyval = '';

function fcycle(typ,val){

	if( cyval != val || cypos == 3 ){
		cypos = 0;
	}else{
		cypos++;
	}

	if( typ == 'pr' ){
		res = 'proto ' + val;
	}else{
		if( typ.substr(0,1) == 's' ){
			end = 'src ';
		}else{
			end = 'dst ';
		}
		if( cypos % 2 ){
			end = '';
		}

		if( typ.substr(1,1) == 'p' ){
			res = end + 'port ' + val;
		}else if( cypos > 1 ){
			res = end + 'net ' + val + '/24';
		}else{
			res = end + 'host ' + val;
		}
	}

	document.dynfrm.flt.value=res;
	cyval = val;
}


</script>

<?php
}

if($tfarr['sux'] == $tfarr['eux'] - 300){
	$dmp = "-r nfcapd.".date("YmdHi",$tfarr['sux']);
}else{
	$dmp = "-R nfcapd.".date("YmdHi",$tfarr['sux']).":nfcapd.".date("YmdHi",$tfarr['eux']);
}

$lit = '';
$tit = '';
if( $mde == 's' ){
#	$cols['ts'] = $flbl['ts'];
#	$cols['td'] = $flbl['td'];
	#$cols['pr'] = $flbl['pr'];
	if( $in{0} ){
		$ilst = '';
		$nag = 0;
		$olst = '';
		foreach ($in as $i){
			$ilst .= "$fnam[$i],";
			$olst .= "%$i;";
			$tit  .= " $flbl[$i],";
			$cols[$i] = $flbl[$i];
			$nag++;
		}
		$fnc = "-A ".substr($ilst,0,-1);
	}else{
		$olst = "%sa;%sp;%da;%dp;";
		$cols['sa'] = $flbl['sa'];
		$cols['sp'] = $flbl['sp'];
		$cols['da'] = $flbl['da'];
		$cols['dp'] = $flbl['dp'];
		$fnc = "-a";
		$nag = 4;
	}
	$fnc .= ($ord?" -O $onam[$ord]":"");
	$cols['pkt'] = $flbl['pkt'];
	$cols['byt'] = $flbl['byt'];
	$cols['fl']  = $flbl['fl'];
	$cols['pps'] = $flbl['pps'];
	$cols['bps'] = $flbl['bps'];
	$cols['bpp'] = $flbl['bpp'];
	$out = "-q -N -o 'fmt:$olst%pkt;%byt;%fl;%pps;%bps;%bpp'";
	$lit = "-n $lim";
}elseif( $mde == 't' ){
	$fnc = "-s ".$fnam[$in[0]].($ord?"/$onam[$ord]":"");
	#$out = " -q -N -o 'fmt:%$in[0] %pkt %byt %fl %pps %bps %bpp'";
	$out = "";
	$lit = "-n $lim";
}else{
	$fnc = '-b -q -N';
	$lim = '';
}

if( $cha ){
?>

<script src="inc/Chart.min.js"></script>
<canvas id="chart" style="display: block;margin: 0 auto;padding: 10px" width="800" height="400"></canvas>

<?php
}elseif( !isset($_GET['xls']) and file_exists("$nedipath/rrd/flow.rrd") ){
	$pol = $plu = '';
	foreach ($nfport as $pn => $pt){
		$pol .= "p$pn";
		$plu .= "&if[]=p$pn";
	}
	echo "<div class=\"ctr\">\n";
	echo "\t<a href=\"Devices-Graph.php?dv=Totals&if[]=ru&if[]=rt&if[]=ri&if[]=rj&stt=$tfarr[raw]&dur=$tfarr[dur]\"><img src=\"inc/drawrrd.php?s=4&a=$tfarr[sux]&e=$tfarr[eux]&t=rutij\" title=\"$prolbl $sumlbl\"></a>\n";
	echo "\t<a href=\"Devices-Graph.php?dv=Totals&$plu&stt=$tfarr[raw]&dur=$tfarr[dur]\"><img src=\"inc/drawrrd.php?s=4&a=$tfarr[sux]&e=$tfarr[eux]&t=$pol\" title=\"$porlbl $sumlbl\"></a>\n";
	echo "</div>\n";
}
$nfcmd = "nfdump -M $nfdpath/$src $dmp $fnc $lit $out $qflt";
$flows = shell_exec("$nfcmd 2>&1");

if( $debug ){

	echo "<h3>$nfcmd</h3>\n";

	echo "<div class=\"textpad code pre good tqrt\">\n";
	echo "$flows";
	echo "</div>\n";
}

/*
$w = stream_get_wrappers();
echo 'openssl: ',  extension_loaded  ('openssl') ? 'yes':'no', "\n";
echo 'http wrapper: ', in_array('http', $w) ? 'yes':'no', "\n";
echo 'https wrapper: ', in_array('https', $w) ? 'yes':'no', "\n";
echo 'wrappers: ', var_dump($w);

$debug=1;
Netinfo('121.131.194.61');
exit;
*/

$link	= DbConnect($dbhost,$dbuser,$dbpass,$dbname);

if( $mde == 't' or $mde == 'l' ){

	echo "<h2>$toplbl $lim ".$flbl[$in[0]]." / $flbl[$ord]</h2>\n";
	echo "<h3>".date($_SESSION['timf'], $tfarr['sux'])." - ".date($_SESSION['timf'],$tfarr['eux']);
	if($flt) echo ", $fltlbl: $flt\n";

	echo "</h3><div class=\"textpad code pre txta tqrt\">\n";
	echo "$flows";
	echo "</div>\n";

}elseif( $mde == 's' ){

	echo "<h2>".substr($tit,0,-1)." $mlbl[$mde]</h2>\n";
	echo "<h3>".date($_SESSION['timf'], $tfarr['sux'])." - ".date($_SESSION['timf'],$tfarr['eux']);
	if($flt) echo ", $fltlbl: $flt\n";
	echo "</h3>\n";

	$row = 0;
	$cid = array_keys($cols);
	$on  = array_search($ord,$ordlst);
	TblHead("bgsub",3);
	foreach ( explode("\n",$flows) as $l ){
		if( strpos($l,';') ){
			if ($row % 2){$bg = "txta"; $bi = "imga";}else{$bg = "txtb"; $bi = "imgb";}
			$row++;
			TblRow($bg);
			$i = 0;
			$v = explode(';',$l);
			$cclr = 'lvl100';
			if( $cha ){
				 $cclr  = GetCol('trf',$row,2);
				 $chd[] = array('value' => $v[$nag+$on],'color' => $cclr );
			 }
			$i = 0;
			foreach($v as $f){
				$t  = $f;
				$c  = '';
				$ic = '';
				$fi = '';
				$cy = '';
				$f  = trim($f);
				if( $cid[$i] == 'pr' ){
					$fi = "onclick=\"fcycle('$cid[$i]','$f');\"";
					$t  = getprotobynumber($f);
				}elseif( $cid[$i] == 'sa' or $cid[$i] == 'da'){
					$fi = "onclick=\"fcycle('$cid[$i]','$f');\"";
					$dres = DbQuery( $link,'devices','s','device,devgroup,firstdis,lastdis,location','',1,array('devip'),array('='),array(ip2long($f)),array() );
					$d    = DbFetchRow($dres);
					DbFreeResult($dres);


					if( is_array($d) ){
						$dur = intval(($d[3]-$d[2])/86400);
						$ud  = urlencode($d[0]);
						$loc = explode($locsep, $d[4]);
						$t   = $d[0];
						$ic  = "+<a href=\"Devices-Status.php?dev=$ud\"><img src=\"img/16/dev.png\" title=\"$f\"></a>";
					}else{
						$nres = DbQuery( $link,'nodes','s','device,ifname,oui,firstseen,lastseen,location,aname,mac','ipupdate desc',1,array('nodip'),array('='),array(ip2long($f)),array(),'LEFT JOIN devices USING (device) LEFT JOIN interfaces USING (device,ifname) LEFT JOIN nodarp USING (mac) LEFT JOIN dns USING (nodip)' );
						$n    = DbFetchRow($nres);
						DbFreeResult($nres);
						if( is_array($n) ){
							$dur = intval(($n[4]-$n[3])/86400);
							$ud  = urlencode($n[0]);
							$ui  = urlencode($n[1]);
							$loc = explode($locsep, $n[5]);
							$t   = $n[6]?$n[6]:"($f)";
							$ic  = "+<a href=\"Nodes-Status.php?in=ip&st=$f\"><img src=\"img/".($oui?'oui/'.VendorIcon($n[2]):'16/node').".png\" title=\"$f\"></a>";
						}else{
							list($ni,$d) = Nettype($f);
							if( $nam and $d == 'Public' ){
								list($dbic,$d,$t,$ad,$cy) = NetInfo($f);
								if( $dbic ) $ni = "net/$dbic";
							}
							$ic = "+<a href=\"Nodes-Toolbox.php?Dest=$f&Do=Lookup\"><img src=\"img/$ni\" width=\"16\" title=\"$d\"></a>";
						}
					}
				}elseif( $cid[$i] == 'sp' or $cid[$i] == 'dp' ){
					$c = "$bi m";
					$t = "$f/".getservbyport($f,'tcp');
					$fi = "onclick=\"fcycle('$cid[$i]','$f');\"";
					$ic = SrvImg( $f );
				}elseif( $nag+$on == $i ){
					$c = 'nw';
					$t = Decfix($f);
					$ic = '+'.Bar($f, $cclr,'sbar');
				}else{
					$t= Decfix($f);
				}
				if( isset($_GET['xls']) ){
					$ic = '';
				}else{
					if($fi) $t =  "<span $fi>$t</span>";
					if($cy) $t .= "<img class=\"frgt\" src=\"img/flag/$cy.png\" title=\"$cy: $ad\">";
				}
				TblCell( $t,'',$c,$ic );
				$i++;
			}
			echo "\t</tr>\n";
		}
	}
	TblFoot("bgsub", count($cols), "$row $vallbl".(($ord)?", $srtlbl: $flbl[$ord]":"").(($lim)?", $limlbl: $lim":"") );
}

if( $cha ){
?>

<script language="javascript">
var data = <?= json_encode($chd,JSON_NUMERIC_CHECK) ?>

var ctx = document.getElementById("chart").getContext("2d");
var myNewChart = new Chart(ctx).Pie(data<?= $chopt ?>);
</script>

<?php
}

include_once ("inc/footer.php");
?>
