<?php
# Program: System-Install.php
# Programmer: Remo Rickli

$exportxls = 0;

include_once ("inc/header.php");
include_once ("inc/libdev.php");
include_once ("inc/libmon.php");

$_GET = sanitize($_GET);
$in = isset($_GET['in']) ? $_GET['in'] : array();
$op = isset($_GET['op']) ? $_GET['op'] : array();
$st = isset($_GET['st']) ? $_GET['st'] : array();

$ty = isset($_GET['ty']) ? $_GET['ty'] : '';
$tg = isset($_GET['tg']) ? $_GET['tg'] : '';
$dv = isset($_GET['dv']) ? $_GET['dv'] : '';
$tp = isset($_GET['tp']) ? $_GET['tp'] : '';

$ip = isset($_GET['ip']) ? $_GET['ip'] : '';
$mk = isset($_GET['mk']) ? $_GET['mk'] : '';
$gw = isset($_GET['gw']) ? $_GET['gw'] : '';
$vl = isset($_GET['vl']) ? $_GET['vl'] : '';
$lg = isset($_GET['lg']) ? $_GET['lg'] : '';
$lo  = isset($_GET['lo']) ? $_GET['lo'] : '';
$co = isset($_GET['co']) ? $_GET['co'] : '';

$add = isset($_GET['add']) ? 1 : 0;
$del = isset($_GET['del']) ? 1 : 0;
$rst = isset($_GET['rst']) ? 1 : 0;

$cols = array(	"status"=>$stalbl,
		"target"=>$tgtlbl,
		"name"=>"Name",
		"ipaddr"=>"IP $adrlbl",
		"mask"=>$msklbl,
		"gateway"=>"Default GW",
		"vlanid"=>"VlanID",
		"type"=>"Device $typlbl",
		"location"=>$loclbl,
		"contact"=>$conlbl,
		"login"=>"Login",
		"template"=>"Template"
		);

$link	= DbConnect($dbhost,$dbuser,$dbpass,$dbname);
?>
<h1>System Install</h1>

<?php  if( !isset($_GET['print']) ) { ?>

<form method="get" action="<?= $self ?>.php" name="mons">
<table class="content">
<tr class="bgmain">
<td class="ctr s">
	<a href="<?= $self ?>.php"><img src="img/32/<?= $selfi ?>.png" title="<?= $self ?>"></a>
</td>
<td class="top">
	<h3><?= $fltlbl ?></h3>

	<?php Filters(1); ?>
</td>
<td class="top nw">
	<h3><?= $srclbl ?></h3>

	<img src="img/16/abc.png"><input type="text" name="ty" value="<?= $ty ?>" placeholder="<?= $typlbl ?>" class="m"><br>
	<img src="img/16/trgt.png"><input type="text" name="tg" value="<?= $tg ?>" placeholder="<?= $tgtlbl ?> <?= $netlbl ?>" class="m"><br>
	<img src="img/16/dev.png"><input type="text" name="dv" value="<?= $dv ?>" placeholder="Device" class="m"><br>
	<img src="img/16/note.png"><input type="text" name="tp" value="<?= $tp ?>" placeholder="Template" class="m">
</td>
<td class="top nw">
	<h3><?= $cfglbl ?></h3>

	<img src="img/16/glob.png"><input type="text" name="ip" value="<?= $ip ?>" placeholder="IP <?= $adrlbl ?>" class="m">
	<img src="img/16/calc.png"><input type="text" name="mk" value="<?= $mk ?>" placeholder="<?= $msklbl ?>" class="m"><br>
	<img src="img/16/rout.png"><input type="text" name="gw" value="<?= $gw ?>" placeholder="GW" class="m">
	<img src="img/16/vlan.png"><input type="text" name="vl" value="<?= $vl ?>" placeholder="Vlan ID" class="m"><br>
	<img src="img/16/ucfg.png"><input type="text" name="lg" value="<?= $lg ?>" placeholder="Login" class="m">
	<img src="img/16/user.png"><input type="text" name="co" value="<?= $co ?>" placeholder="<?= $conlbl ?>" class="m"><br>
	<img src="img/16/home.png"><input type="text" name="lo" value="<?= $lo ?>" placeholder="<?= $loclbl ?>" class="l">
</td>
<td class="ctr s">
	<input type="submit" class="button" value="<?= $sholbl ?>">
	<input type="submit" class="button" name="del" value="<?= $dellbl ?>" onclick="return confirm('<?= $dellbl ?> (<?= $in[0] ?> <?= $op[0] ?> <?= $st[0] ?>), <?= $cfmmsg ?>')" >
	<input type="submit" class="button" name="add" value="<?= $addlbl ?>">
</td>
</tr>
</table>
</form>
<p>
<?php
}
if ($add and $tg and $ty){
	if( !DbQuery($link,'install','i','','','',
		array('type','target','name','ipaddr','mask','gateway','vlanid','location','contact','login','template','status'),
		array(),
		array($ty,$tg,$dv,$ip,$mk,$gw,$vl,$lo,$co,$lg,$tp,10)
	) ){echo "<h4>".DbError($link)."</h4>";}else{echo "<h5>$tgtlbl $addlbl OK</h5>";}
}elseif($rst){
		if( !DbQuery($link,'install','u','','','',array('name'),array($st[0]),array('status'),array('10')) ){echo "<h4>".DbError($link)."</h4>";}else{echo "<h5>$stalbl $reslbl OK</h5>";}
}elseif($del){
	if( !DbQuery($link,'install','d','','','',$in,$op,$st) ){echo "<h4>".DbError($link)."</h4>";}else{echo "<h5>$dellbl $ina[0] $op[0] $st[0] OK</h5>";}
}

if( count($in) ){
	Condition($in,$op,$st);
?>

<table class="content">
	<tr class="bgsub">
		<th>
			<img src="img/16/idea.png"><br>
			<?= $stalbl ?>

		</th>
		<th>
			<img src="img/16/abc.png"><br>
			<?= $typlbl ?>

		</th>
		<th>
			<img src="img/16/trgt.png"><br>
			<?= $tgtlbl ?>

		</th>
		<th>
			<img src="img/16/dev.png"><br>
			<?= $namlbl ?>

		</th>
		<th>
			<img src="img/16/glob.png"><br>
			IP <?= $adrlbl ?>/<?= $msklbl ?>

		</th>
		<th>
			<img src="img/16/rout.png"><br>
			Default GW

		</th>
		<th>
			<img src="img/16/vlan.png"><br>
			VlanID

		</th>
		<th>
			<img src="img/16/home.png"><br>
			<?= $loclbl ?>

		</th>
		<th>
			<img src="img/16/user.png"><br>
			<?= $conlbl ?>

		</th>
		<th>
			<img src="img/16/ucfg.png"><br>
			Login

		</th>
		<th>
			<img src="img/16/note.png"><br>
			Template

		</th>
		<th>
			<img src="img/16/cog.png"><br>
			<?= $cmdlbl ?>

		</th>
	</tr>
<?php
	$res = DbQuery( $link,'install','s','*','name','',$in,$op,$st);
	if($res){
		$row  = 0;
		while( ($r = DbFetchRow($res)) ){
			if ($row % 2){$bg = "txta"; $bi = "imga";}else{$bg = "txtb"; $bi = "imgb";}
			$row++;

			$ut = urlencode($r[0]);
			$ur = urlencode($r[1]);
			$ud = urlencode($r[2]);
			$ul = urlencode($r[7]);
			$uc = urlencode($r[8]);
			$uo = urlencode($r[9]);
			$up = urlencode($r[10]);
			TblRow($bg);
			TblCell( '','',"$bi ctr xs","+<a href=\"?in[]=status&op[]==&st[]=$r[11]\">".Staimg($r[11])."</a>" );
			TblCell($r[0],"?in[]=type&op[]==&st[]=$ut");
			TblCell($r[1],"?in[]=target&op[]==&st[]=$ur");
			TblCell($r[2],"?in[]=name&op[]==&st[]=$ud",'nw',"<a href=\"Devices-Status.php?dev=$ud\"><img src=\"img/16/sys.png\" title=\"Devices-Status\"></a>");
			TblCell("$r[3] $r[4]");
			TblCell($r[5],"?in[]=gateway&op[]==&st[]=$r[5]");
			TblCell($r[6],"?in[]=vlanid&op[]==&st[]=$r[6]",'rgt');
			TblCell($r[7],"?in[]=location&op[]==&st[]=$ul");
			TblCell($r[8],"?in[]=contact&op[]==&st[]=$uc");
			TblCell($r[9],"?in[]=login&op[]==&st[]=$uo");
			TblCell($r[10],"?in[]=template&op[]==&st[]=$up");
			echo "\t\t<td class=\"rgt\">\n";
			if( $r[11] != 10 and $r[11] != 150 ) echo "\t\t\t<a href=\"?in[]=name&op[]==&st[]=$ud&rst=1\"><img src=\"img/16/star.png\" title=\"$reslbl\"></a>\n";
			echo "\t\t\t<a href=\"?ty=$ut&tg=$ur&dv=$ud&ip=$r[3]&mk=$r[4]&gw=$r[5]&vl=$r[6]&lo=$ul&co=$uc&lg=$uo&tp=$up\"><img src=\"img/16/copy.png\" title=\"$coplbl\"></a>\n";
			echo "\t\t\t<a href=\"?in[]=name&op[]==&st[]=$ud&del=1\"><img src=\"img/16/bcnl.png\" title=\"$dellbl\"></a>\n";
			echo "\t\t</td>\n\t</tr>\n";
		}
		DbFreeResult($res);
	}else{
		print DbError($link);
	}
	TblFoot("bgsub", 12, "$row $vallbl");
}elseif($_SESSION['opt']){
	include_once ("inc/librep.php");
	DevInstall($in[0],$op[0],$st[0],$_SESSION['lim'],'');
}
include_once ("inc/footer.php");
?>
