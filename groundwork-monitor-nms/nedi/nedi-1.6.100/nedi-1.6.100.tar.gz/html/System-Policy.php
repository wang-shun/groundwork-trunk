<?php
# Program: System-Policy.php
# Programmer: Remo Rickli

$exportxls = 0;

include_once ("inc/header.php");
include_once ("inc/libdev.php");

$_GET = sanitize($_GET);
$in = isset($_GET['in']) ? $_GET['in'] : array();
$op = isset($_GET['op']) ? $_GET['op'] : array();
$st = isset($_GET['st']) ? $_GET['st'] : array();

$cl = isset($_GET['cl']) ? $_GET['cl'] : '';
$sa = isset($_GET['sa']) ? $_GET['sa'] : '';
$ma = isset($_GET['ma']) ? $_GET['ma'] : '';
$tg = isset($_GET['tg']) ? $_GET['tg'] : '';
if( $cl == 'ntg' ) $ma = '-';

$if = isset($_GET['if']) ? $_GET['if'] : '';
$vl = isset($_GET['vl']) ? $_GET['vl'] : '';
$ic = isset($_GET['ic']) ? $_GET['ic'] : '';
$lt = isset($_GET['lt']) ? $_GET['lt'] : '';

$dv = isset($_GET['dv']) ? $_GET['dv'] : '';
$ty = isset($_GET['ty']) ? $_GET['ty'] : '';
$co = isset($_GET['co']) ? $_GET['co'] : '';
$gr = isset($_GET['gr']) ? $_GET['gr'] : '';
$lo = isset($_GET['lo']) ? $_GET['lo'] : '';

$al  = isset($_GET['al']) ? $_GET['al'] : 0;
$io  = isset($_GET['io']) ? $_GET['io'] : '';

$ac  = isset($_GET['ac']) ? $_GET['ac'] : '';
$rp  = isset($_GET['rp']) ? $_GET['rp'] : 0;
$rev = ($_GET['rev']) ? "checked" : '';
if($rev) $al += 128;

$add = isset($_GET['add']) ? 1 : 0;
$eid = isset($_GET['eid']) ? $_GET['eid'] : 0;
$did = isset($_GET['did']) ? $_GET['did'] : 0;
$dei = isset($_GET['dei']) ? $_GET['dei'] : 0;
$del = isset($_GET['del']) ? $_GET['del'] : 0;

$cols = array(	"id"=>"Id",
		"status"=>$stalbl,
		"class"=>$clalbl,
		"target"=>$tgtlbl,
		"polopts"=>$opolbl,
		"value"=>$vallbl,
		"device"=>"Device",
		"type"=>$typlbl,
		"location"=>$loclbl,
		"contact"=>$conlbl,
		"devgroup"=>$grplbl,
		"ifname"=>$porlbl,
		"vlan"=>"Vlan",
		"alert"=>$mlvl['200'],
		"info"=>$inflbl,
		"respolicy"=>"$reslbl Policy",
		"clisend"=>"CLI $sndlbl",
		"usrname"=>$usrlbl,
		"time"=>$timlbl
		);

$pocl['mac'] = "MAC $adrlbl";
$pocl['nbr'] = "$neblbl $namlbl";
$pocl['nty'] = "$neblbl $typlbl";
$pocl['cnb'] = "$cnclbl $tim[b]";
$pocl['cfg'] = "$cfglbl";
$pocl['pop'] = "$poplbl";
$pocl['byt'] = "Bytes";
$pocl['pkt'] = "$pktlbl";
$pocl['fl']  = "Flows";
$pocl['res'] = "$reslbl";

$poic['mac'] = 'node';
$poic['nbr'] = 'dev';
$poic['nty'] = 'abc';
$poic['cnb'] = 'link';
$poic['cfg'] = 'conf';
$poic['pop'] = 'nods';
$poic['byt'] = 'tap';
$poic['pkt'] = 'tap';
$poic['fl']  = 'tap';
$poic['res'] = 'exit';

$ict['S'] = "$stalbl $chglbl";
$ict['P'] = "PoE $chglbl $stco[100]";
$ict['B'] = "PoE $alrlbl $stco[100]";

$ici['S'] = "<a href=\"?in[]=polopts&op[]=~&st[]=^.S\" class=\"genpad warn\"><img src=\"img/p45.png\" title=\"$ict[S]\"></a>";
$ici['P'] = "<a href=\"?in[]=polopts&op[]=~&st[]=^.P\" class=\"genpad txtd\"><img src=\"img/16/batt.png\" title=\"$ict[P]\"></a>";
$ici['B'] = "<a href=\"?in[]=polopts&op[]=~&st[]=^.B\" class=\"genpad good\"><img src=\"img/16/batt.png\" title=\"$ict[B]\"></a>";

$ltt['F'] = 'Phone';
$ltt['A'] = 'Wireless AP';
$ltt['C'] = 'Controlled AP';
$ltt['H'] = 'Hypervisor';
$ltt['T'] = 'Telepresence';
$ltt['V'] = 'Video Camera';
$ltt['D'] = 'Device';
$ltt['N'] = 'Node';

$aci['S'] = "<a href=\"?in[]=polopts&op[]=~&st[]=^...S\"><img src=\"img/16/bbr2.png\" title=\"$skplbl $actlbl\"></a>";
$aci['D'] = "<a href=\"?in[]=polopts&op[]=~&st[]=^...D\"><img src=\"img/16/bdis.png\" title=\"$porlbl $dsalbl\"></a>";
$aci['P'] = "<a href=\"?in[]=polopts&op[]=~&st[]=^...P\"><img src=\"img/16/batt.png\" title=\"PoE $dsalbl\"></a>";

$link	= DbConnect($dbhost,$dbuser,$dbpass,$dbname);
?>
<h1>System Policy</h1>

<?php  if( !isset($_GET['print']) ) { ?>

<script>
function portvis(val){

	if(val == 'cfg' || val == 'pop'){
		document.getElementById('loco').style.visibility="visible";
		document.getElementById('pcon').style.visibility="hidden";
		document.getElementById('actn').style.visibility="hidden";
	}else if(val == 'byt' || val == 'pkt' || val == 'fl'){
		document.getElementById('loco').style.visibility="hidden";
		document.getElementById('pcon').style.visibility="hidden";
		document.getElementById('actn').style.visibility="hidden";
	}else{
		document.getElementById('loco').style.visibility="visible";
		document.getElementById('pcon').style.visibility="visible";
		document.getElementById('actn').style.visibility="visible";
	}
}

</script>

<form method="get" action="<?= $self ?>.php" name="pols">
<table class="content">
<tr class="bgmain">
<td class="ctr s">
	<a href="<?= $self ?>.php"><img src="img/32/<?= $selfi ?>.png" title="<?= $self ?>"></a>
</td>
<td class="top">
	<h3><?= $fltlbl ?></h3>

	<?php Filters(1); ?>
</td>
<td class="top nw">

	<h3><?= $cndlbl ?></h3>

	<img src="img/16/idea.png" title="<?= $stalbl ?>">
	<select size="1" name="sa">
		<option value="100"><?= $stco['100'] ?>

		<option value="120" <?= ($sa == 120)?" selected":"" ?>><?= $stco['120'] ?>

	</select>
	<select size="1" name="cl" title="<?= $clalbl ?>" onchange="portvis(this.value);">
<?php
foreach ($pocl as $k => $v){
	if( $k != 'res' ) echo "\t\t<option value=\"$k\"".(($cl == $k)?" selected":"").">$v\n";
}
?>
	</select>
	<select name="ma">
		<option value="I">~
		<option value="E" <?= ($ma == 'E')?" selected":"" ?>>!~
		<option value=">" <?= ($ma == '>')?" selected":"" ?>>&gt;
		<option value="<" <?= ($ma == '<')?" selected":"" ?>>&lt;
	</select>
	<input type="text" name="tg" value="<?= $tg ?>" placeholder="<?= $tgtlbl ?>" class="m">	<br>
	<img src="img/16/dev.png"> <input type="text" name="dv" value="<?= $dv ?>" placeholder="Device" class="m"><br>
	<img src="img/16/abc.png"> <input type="text" name="ty" value="<?= $ty ?>" placeholder="<?= $typlbl ?> / <?= $fltlbl ?>"" class="m">
	<img src="img/16/ugrp.png"> <input type="text" name="gr" value="<?= $gr ?>" placeholder="<?= $grplbl ?>" class="m">
	<div id="loco">
		<img src="img/16/home.png"> <input type="text" name="lo" value="<?= $lo ?>" placeholder="<?= $loclbl ?>" class="m">
		<img src="img/16/user.png"> <input type="text" name="co" value="<?= $co ?>" placeholder="<?= $conlbl ?>" class="m">
	</div>
	<p>
	<div id="pcon">
		<img src="img/16/vlan.png"> <input type="text" name="vl" value="<?= $vl ?>" placeholder="Vlan" class="m">
		<img src="img/16/link.png">
		<select name="lt">
			<option value="-"><?= $cnclbl ?> <?= $typlbl ?> >
<?php
foreach ($ltt as $k => $v){
	echo "\t\t\t<option value=\"$k\"".(($lt == $k)?" selected":"").">$v\n";
}
?>
		</select><br>
		<img src="img/16/port.png">
		<input type="text" name="if" value="<?= $if ?>" placeholder="<?= $porlbl ?>" class="m">
		<img src="img/16/qmrk.png">
		<select name="ic">
			<option value="-"> <?= $cndlbl ?> >
<?php
foreach ($ict as $k => $v){
	echo "\t\t\t<option value=\"$k\"".(($ic == $k)?" selected":"").">$v\n";
}
?>
		</select>
	</div>
</td>
<td class="top nw">

	<h3><?= $actlbl ?></h3>

	<img src="img/16/flag.png" title="<?= $mlvl['200'] ?>">
	<select size="1" name="al">
		<option value="0"><?= $mlvl['200'] ?> >
		<option value="1" <?= ($al == 1)?" selected":"" ?>><?= $msglbl ?>

		<option value="2" <?= ($al == 2)?" selected":"" ?>>Mail
		<option value="6" <?= ($al == 6)?" selected":"" ?>>Mail & SMS
	</select><br>
	<img src="img/16/find.png" class="top">
	<textarea rows="4" name="io" cols="12" placeholder="<?= $inflbl ?>"><?= $io ?></textarea>
	<p>
	<div id="actn">
	<img src="img/16/walk.png" title="<?= $actlbl ?>">
	<select size="1" name="ac">
		<option value="-"><?= $actlbl ?> >
		<option value="S" <?= ($ac == 'S')?" selected":"" ?>><?= $verb1?"$skplbl $actlbl":"$actlbl $skplbl" ?>

		<option value="D" <?= ($ac == 'D')?" selected":"" ?>><?= $porlbl ?> <?= $dsalbl ?>

		<option value="P" <?= ($ac == 'P')?" selected":"" ?>>PoE  <?= $dsalbl ?>

	</select><br>
	<img src="img/16/exit.png" title="<?= $verb1?"$addlbl $reslbl Policy":"$reslbl Policy $addlbl" ?>">
	<select size="1" name="rp">
		<option value="0"><?= $reslbl ?> <?= $stco[100] ?> >
		<option value="3" <?= ($rp == '3')?" selected":"" ?>><?= $tim['a'] ?> 3 <?= $tim['i'] ?>

		<option value="180" <?= ($rp == '180')?" selected":"" ?>><?= $tim['a'] ?> 3 <?= $tim['h'] ?>

		<option value="4320" <?= ($rp == '4320')?" selected":"" ?>><?= $tim['a'] ?> 3 <?= $tim['d'] ?>

		<option value="43200" <?= ($rp == '43200')?" selected":"" ?>><?= $tim['a'] ?> 30 <?= $tim['d'] ?>

	</select>
	<input type="checkbox" title="<?= $verb1?"$addlbl $msglbl":"$msglbl $addlbl" ?>" <?= $rev ?> name="rev">
	</div>
</td>
<td class="ctr s">
	<input type="submit" class="button" value="<?= $sholbl ?>">
	<input type="submit" class="button" name="del" value="<?= $dellbl ?>" onclick="return confirm('<?= $dellbl ?> (<?= $in[0] ?> <?= $op[0] ?> <?= $st[0] ?>), <?= $cfmmsg ?>')">
	<input type="submit" class="button" name="add" value="<?= $addlbl ?>">
</td>
</tr>
</table>
</form>
<script>
	window.onload = portvis('<?= $cl ?>');
</script>
<p>
<?php
}
if ( $add ){
	if( $ac == 'S' ) $rp = 0;
	if( !DbQuery($link,'policies','i','','','',
		array('status','class','polopts','target','device','type','location','contact','devgroup','ifname','vlan','alert','info','respolicy','usrname','time'),
		array(),
		array($sa,$cl,$ma.$ic.$lt.$ac,$tg,$dv,$ty,$lo,$co,$gr,$if,$vl,$al,$io,$rp,$_SESSION['user'],time() )
	) ){echo "<h4>".DbError($link)."</h4>";}else{echo "<h5>$tgtlbl $addlbl OK</h5>";}
}elseif($eid){
		if( !DbQuery($link,'policies','u','','','',array('id'),array($eid),array('status'),array('100')) ){echo "<h4>".DbError($link)."</h4>";}else{echo "<h5>$stalbl $enalbl OK</h5>";}
}elseif($did){
		if( !DbQuery($link,'policies','u','','','',array('id'),array($did),array('status'),array('120')) ){echo "<h4>".DbError($link)."</h4>";}else{echo "<h5>$stalbl $dsalbl OK</h5>";}
}elseif($dei){
		if( !DbQuery($link,'policies','d','','','',array('id'),array('='),array($dei)) ){echo "<h4>".DbError($link)."</h4>";}else{echo "<h5>$dellbl Id $dei OK</h5>";}
}elseif($del){
	if( !DbQuery($link,'policies','d','','','',$in,$op,$st) ){echo "<h4>".DbError($link)."</h4>";}else{echo "<h5>$dellbl $ina[0] $op[0] $st[0] OK</h5>";}
}

if( count($in) ){
	Condition($in,$op,$st);
?>

<table class="content">
	<tr class="bgsub">
		<th class="xs">
			<img src="img/16/key.png"><br>
			Id

		</th>
		<th class="xs">
			<img src="img/16/idea.png"><br>
			<?= $stalbl ?>

		</th>
		<th>
			<img src="img/16/abc.png"><br>
			<?= $clalbl ?>

		</th>
		<th>
			<img src="img/16/trgt.png"><br>
			<?= $tgtlbl ?>

		</th>
		<th>
			<img src="img/16/dev.png"><br>
			Device
		</th>
		<th>
			<img src="img/16/port.png"><br>
			<?= $porlbl ?>

		</th>
		<th>
			<img src="img/16/vlan.png"><br>
			Vlan
		</th>
		<th>
			<img src="img/16/walk.png"><br>
			<?= $actlbl ?>

		</th>
		<th>
			<img src="img/16/find.png"><br>
			<?= $inflbl ?>

		</th>
		<th>
			<img src="img/16/user.png"><br>
			<?= $usrlbl ?>

		</th>
		<th>
			<img src="img/16/date.png"><br>
			<?= $timlbl ?>

		</th>
		<th>
			<img src="img/16/cog.png"><br>
			<?= $cmdlbl ?>

		</th>
	</tr>
<?php
	$res = DbQuery( $link,'policies','s','*','class,polopts desc,id','',$in,$op,$st );
	if($res){
		$row = 0;
		$flt = "?in[]=$in[0]&op[]=$op[0]&st[]=".urlencode($st[0]);
		while( ($r = DbFetchRow($res)) ){
			if ($row % 2){$bg = "txta"; $bi = "imga";}else{$bg = "txtb"; $bi = "imgb";}
			$row++;
			
			$ma = substr($r[3],0,1);
			$ic = substr($r[3],1,1);
			$lt = substr($r[3],2,1);
			$ac = substr($r[3],3,1);
			$ut = urlencode($r[4]);
			$ud = urlencode($r[5]);
			$uy = urlencode($r[6]);
			$ul = urlencode($r[7]);
			$uc = urlencode($r[8]);
			$ug = urlencode($r[9]);
			$ui = urlencode($r[10]);
			$uo = urlencode($r[13]);
			
			$mclass = "$bi nw";
			if( !$r[4] ){
				$mclass = '';
			}elseif( $ma == 'E' ){
				$lop = '!~';
				$mclass = 'warn nw';
			}elseif( $ma == 'I' ){
				$lop = '~';
				$mclass = 'good nw';
			}
			$mimg = '';
			if( $r[4] and $r[4] != '.'){
				if( $r[2] == 'mac' ){
					$mimg = "+<a href=\"Nodes-List.php?in[]=mac&op[]=$lop&st[]=$ut\"><img src=\"img/16/nods.png\" title=\"Node $lstlbl\"></a>";
				}elseif( $r[2] == 'nbr' ){
					$mimg = "+<a href=\"Topology-Links.php?in[]=neighbor&op[]=$lop&st[]=$ut\"><img src=\"img/16/dev.png\" title=\"$neblbl $namlbl $lstlbl\"></a>";
				}elseif( $r[2] == 'nty' ){
					$mimg = "+<a href=\"Topology-Links.php?in[]=linkdesc&op[]=$lop&st[]=$ut\"><img src=\"img/16/abc.png\" title=\"$neblbl $typlbl $lstlbl\"></a>";
				}elseif( $r[2] == 'cnb' ){
					$mimg = "+<a href=\"Devices-Interfaces.php?in[]=linktype&op[]=$lop&st[]=$ut\"><img src=\"img/16/link.png\" title=\"$cnclbl $typlbl $lstlbl\"></a>";
				}elseif( $r[2] == 'cfg' ){
					$mimg = "+<a href=\"/Devices-Config.php?shl=$ma&sta=$ut&gen=1\"><img src=\"img/16/conf.png\" title=\"$cfglbl $lstlbl\"></a>";
				}else{
					$r[4] = "$ma $r[4]";
				}
			}
			TblRow($bg);
			TblCell( $r[0] );
			TblCell( '','',"$bi ctr","+<a href=\"?in[]=status&op[]==&st[]=$r[1]\">".Staimg($r[1])."</a>" );
			TblCell( $pocl[$r[2]],"?in[]=class&op[]==&st[]=$r[2]" );
			TblCell($r[4],"?in[]=target&op[]==&st[]=$ut",$mclass,$mimg );
			if( $r[2] == 'res' ){
				TblCell( $r[5],"?device&op[]==&st[]=$ud",'nw',"<a href=\"Devices-Status.php?dev=".urlencode($r[5])."\"><img src=\"img/16/sys.png\"></a>");
			}elseif( $r[2] == 'pkt' or $r[2] == 'byt' or $r[2] == 'fl' ){
				echo "\t\t<td>\n\t\t\t";
				$scarr = explode(':',$r[5]);
				$sct = '';
				foreach ($scarr as $i){
					$sct .= "&sc[]=".urlencode($i);
				}
				$grarr = explode(',',$r[9]);
				$grt = '';
				foreach ($grarr as $i){
					$grt .= "&in[]=".urlencode($i);
				}
				echo ModLink('Nodes','Traffic',"ord=$r[2]$sct$grt&flt=".urlencode($r[6]));
				echo "\t\t\t$srclbl:<span class=\"b\">$r[5]</span> $fltlbl:<span class=\"b\">$r[6]</span> $grplbl:<span class=\"b\">$r[9]</span>";
				echo "\t\t</td>\n";
			}else{
				echo "\t\t<td>\n";
				if($r[5]) echo "\t\t\t<a href=\"Devices-List.php?in[]=device&op[]=~&st[]=$ud\"><img src=\"img/16/dev.png\" title=\"$typlbl\"></a><a href=\"?in[]=device&op[]==&st[]=$ud\">$r[5]</a><br>\n";
				if($r[6]) echo "\t\t\t<a href=\"Devices-List.php?in[]=type&op[]=~&st[]=$uy\"><img src=\"img/16/abc.png\" title=\"$typlbl\"></a><a href=\"?in[]=type&op[]==&st[]=$uy\">$r[6]</a><br>\n";
				if($r[7]) echo "\t\t\t<a href=\"Devices-List.php?in[]=location&op[]=~&st[]=$ul\"><img src=\"img/16/home.png\" title=\"$loclbl\"></a><a href=\"?in[]=location&op[]==&st[]=$ul\">$r[7]</a><br>\n";
				if($r[8]) echo "\t\t\t<a href=\"Devices-List.php?in[]=contact&op[]=~&st[]=$uc\"><img src=\"img/16/user.png\" title=\"$usrlbl\"></a><a href=\"?in[]=contact&op[]==&st[]=$uc\">$r[8]</a><br>\n";
				if($r[9]) echo "\t\t\t<a href=\"Devices-List.php?in[]=devgroup&op[]=~&st[]=$ug\"><img src=\"img/16/ugrp.png\" title=\"$grplbl\"></a><a href=\"?in[]=devgroup&op[]==&st[]=$ug\">$r[9]</a><br>\n";
				echo "\t\t</td>\n";
			}
			echo "\t\t<td>\n";
			if($ic != '-') echo "\t\t\t$ici[$ic]\n";
			if($lt != '-') echo "\t\t\t<a href=\"?in[]=polopts&op[]=~&st[]=^..$lt\"><img src=\"".LtypIcon('abc'.$lt)."\" title=\"$ltt[$lt]\"></a>\n";
			if($r[10]) echo "\t\t\t<a href=\"?in[]=ifname&op[]==&st[]=$ui\">$r[10]</a>\n";
			echo "\t\t</td>\n";
			TblCell( $r[11],"?in[]=vlan&op[]==&st[]=$r[11]",'rgt' );
			echo "\t\t<td class=\"nw\">\n";
			if($r[12] & 1) echo "\t\t\t<img src=\"img/16/bell.png\" title=\"$msglbl\">\n";
			if($r[12] & 2) echo "\t\t\t<img src=\"img/16/mail.png\" title=\"Mail\">\n";
			if($r[12] & 4) echo "\t\t\t<img src=\"img/16/sms.png\" title=\"SMS\">\n";
			if($ac != '-') echo "\t\t\t$aci[$ac]\n";
			if($r[12] & 128) echo "\t\t\t<img src=\"img/16/bell.png\" title=\"$reslbl $msglbl\">\n";
			if($r[14]) echo "\t\t\t<a href=\"?in[]=respolicy&op[]==&st[]=$r[14]\"><img src=\"img/16/exit.png\" title=\"$reslbl Policy $tim[a] $r[14] $tim[i]\"></a>\n";
			echo "\t\t</td>\n";
			TblCell( $r[13] );
			TblCell( $r[15],"?in[]=usrname&op[]==&st[]=$r[15]" );
			TblCell( date($_SESSION['timf'],$r[16]) );
			echo "\t\t<td class=\"rgt nw\">\n";
			if( $r[2] != 'res' ){
				echo "\t\t\t<a href=\"$flt&cl=$r[2]&sa=$r[1]&ma=$ma&tg=$ut&ic=$ic&lt=$lt&if=$ui&vl=$r[11]&al=$r[12]&dv=$ud&ty=$uy&lo=$ul&co=$uc&gr=$ug&io=$uo&ac=$ac&rp=$r[14]\"><img src=\"img/16/copy.png\" title=\"$coplbl\"></a>\n";
				echo ($r[1]==100)?"\t\t\t<a href=\"$flt&did=$r[0]\"><img src=\"img/16/bdis.png\" title=\"$chglbl $dsalbl\"></a>\n":"\t\t\t<a href=\"$flt&eid=$r[0]\"><img src=\"img/16/bchk.png\" title=\"$chglbl $enalbl\"></a>\n";
			}
			echo "\t\t\t<a href=\"$flt&dei=$r[0]\"><img src=\"img/16/bcnl.png\" title=\"$dellbl\" onclick=\"return confirm('$dellbl id $r[0], $cfmmsg')\"></a>\n";
			echo "\t\t</td>\n\t</tr>\n";
		}
		DbFreeResult($res);
	}else{
		print DbError($link);
	}
	TblFoot("bgsub", 12, "$row $vallbl");
}elseif($_SESSION['opt']){
	include_once ("inc/librep.php");
	SysPolicy($in[0],$op[0],$st[0],$_SESSION['lim'],'');
}

include_once ("inc/footer.php");
?>
