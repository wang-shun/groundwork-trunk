<?PHP
//===============================
// MySQL functions.
//===============================

$dbregexp = 'regexp';

function DbConnect($host,$user,$pass,$db){
	$l = mysqli_connect($host,$user,$pass,$db) or die("Could not connect to $db@$host with $user");
	return $l;
}

function DbClose($l){
	return mysqli_close($l);
}

function DbFieldName($r, $n){
	$o = mysqli_fetch_field_direct($r, $n);
	return $o->name;
}

function DbNumFields($r){
	return mysqli_num_fields($r);
}

function DbNumRows($r){
	return mysqli_num_rows($r);
}

function DbFetchRow($r){
	return mysqli_fetch_row($r);
}

function DbFetchArray($r){
	return mysqli_fetch_assoc($r);
}

function DbFreeResult($r){

	global $debug;

	if($debug){
		echo "<div class=\"textpad code pre good xxl\">";
		debug_print_backtrace();
		echo DecFix(memory_get_usage(),1).'B @'.round(microtime(1) - $debug,2)."s</div>\n";
	}
	return mysqli_free_result($r);
}

function DbAffectedRows($l){
	return mysqli_affected_rows($l);
}

function DbEscapeString($l,$s){
	if ( is_array($s) ){
		$a = array();
		foreach ($s as $e){
			$a[] = mysqli_real_escape_string($l,$e);
		}
		return $a;
	}else{
		return mysqli_real_escape_string($l,$s);
	}
}

function DbError($l){
	return mysqli_error($l);
}

function DbCast($v,$t){											# Based on GH's idea
	return $v;
}

function DbIPv6($v){
	return ($v)?inet_ntop($v):'';
}

//===================================================================
// Add record if it doesn't exist yet
function AddRecord($lnk,$table,$in,$st,$col,$val){

	global $alrlbl, $addlbl;

	$tbl = preg_replace('/[^\w+]/','',$table);

	$x = 0;
	foreach ($in as $c){
		if($c){$w[]= DbEscapeString($lnk,$c)." = '".DbEscapeString($lnk,$st[$x])."'";}
		$x++;
	}
	$mres = mysqli_query( $lnk,"SELECT 1 FROM $table WHERE ".implode(' AND ',$w) );
	if($mres){
		if( mysqli_num_rows($mres) ){
			$status = "<img src=\"img/16/bdis.png\" title=\"$alrlbl OK\">";
		}else{
			if( !mysqli_query($lnk,"INSERT INTO $table (". implode(',',DbEscapeString($lnk,$col)) .") VALUES ('". implode("','",DbEscapeString($lnk,$val)) ."')") ){
				$status = "<img src=\"img/16/bcnl.png\" title=\"".mysqli_error($lnk)."\">";
			}else{
				$status = "<img src=\"img/16/bchk.png\" title=\"$addlbl OK\">";
			}
		}
	}else{
		print mysqli_error($lnk);
	}
	return $status;
}

//===================================================================
// Adds devices. to device columns. This callback function is needed for certain join queries
function AddDevs($col){
	if($col == 'device'){
		return 'devices.device';
	}else{
		return $col;
	}
}

//===================================================================
// Adapt operator and value for special fields
function AdOpVal($c,$o,$v){

	if( $v != 'NULL' and preg_match("/^(first|last|start|end|time|(if|ip|os|as)?update)/",$c) and !preg_match("/^[0-9]+$/",$v) ){
		$v = strtotime($v);
	}elseif( preg_match("/^(if)?mac$/",$c) ){
		$v = preg_replace("/[.:-]/","", $v);
	}elseif(preg_match("/^(dev|orig|nod|if|mon)ip$/",$c) and !preg_match('/^[0-9]+$/',$v) ){	# Do we have an dotted IP?
		if( strstr($v,'/') ){									# CIDR?
			list($ip, $prefix) = explode('/', $v);
			$dip = sprintf("%u", ip2long($ip));
			$dmsk = 0xffffffff << (32 - $prefix);
			$dnet = sprintf("%u", ip2long($ip) & $dmsk );
			$c = "$c & $dmsk";
			$v = $dnet;
		}elseif( $v != 'NULL' ){
			if( preg_match('/~$/',$o) ){							# regexp operator?
				$c = "inet_ntoa($c)";
			}else{										# converting plain address
				$v = sprintf("%u", ip2long($v));
			}
		}
	}elseif( preg_match("/^(if|nod|mon)ip6$/",$c) ){
		$v = inet_pton($v);
		#$c = "HEX($c)";TODO migrate to IPv6 fields as soon as mysql supports them!
	}
	if( strstr($o, 'COL ') ){
		$o = substr($o,4);
	}elseif( $o == '=' and $v == 'NULL' ){
		$o = 'IS';
	}elseif( $o == '!=' and $v == 'NULL' ){
		$o = 'IS NOT';
	}else{
		$v = "'$v'";
	}

	if( $o == '!~' ){
		return "$c not regexp $v";
	}elseif( $o == '~' ){
		return "$c regexp $v";
	}else{
		return "$c $o $v";
	}
}

//===============================================================================
// Execute SQL queries:
//
// $lnk	= DB connection
// $tbl	= table to apply query to (entire query in rawmode)
// $do 	s= select (is default), i=insert (using $in for columns and $st for values), o=optimize, d=delete, p=drop db
//	b=show DBs ($col used as operator with $tbl), h=show tables, c=show columns, t=truncate,
//	u=update (using ANDed $in=$op elements to match and $st=$co to set values), g=group,r=rawquery
// $col	= column(s) to display, with $do=g column(s)[;sum functions or -[;having condition]] or columns(s)#x to limit location level
// $ord	= order by (where ifname also takes numerical interface sorting (e.g. 0/1) into account)
// $lim	= limiting results
// $in,op,st	= array of columns,operators and strings to be used for WHERE in UPDATE, INSERT, SELECT and DELETE queries
// $co	= combines current values with the next series of $in,op,st
//
// SELECT and DELETE columns treatment:
// * ip:	Input will be converted to decimal, in case of dotted notation and masked if a prefix is set.
// * time:	Time will be turned into EPOC, if it's not a number already.
// * mac:	. : - are removed
//
function DbQuery($lnk,$tbl,$do='s',$col='*',$ord='',$lim='',$in=array(),$op=array(),$st=array(),$co=array(),$jn=''){

	global $debug,$locsep;

	if($do == 'r'){											# Process rawqueries from API and System-Database
		return mysqli_query($lnk,$tbl);
	}

	$tbl = preg_replace('/[^\w+%]/','',$tbl);

	if($do == 'i'){
		$qry = "INSERT INTO $tbl (". implode(',',DbEscapeString($lnk,$in)) .") VALUES ('". implode("','",DbEscapeString($lnk,$st)) ."')";
	}elseif($do == 'u'){
		$x = 0;
		foreach ($in as $c){
			if($c){$w[]= DbEscapeString($lnk,$c)." = '".DbEscapeString($lnk,$op[$x])."'";}
			$x++;
		}
		$x = 0;
		foreach ($st as $c){
			if($c){$s[]= DbEscapeString($lnk,$c)." = '".DbEscapeString($lnk,$co[$x])."'";}
			$x++;
		}
		$qry = "UPDATE $tbl SET ". implode(',',$s) ." WHERE ". implode(' AND ',$w);
	}elseif($do ==  'b'){
		$qry = "SHOW DATABASES $col '$tbl'";
	}elseif($do ==  'p'){
		$qry = "DROP DATABASE $tbl";
	}elseif($do ==  'h'){
		$qry = "SHOW TABLES $tbl";
	}elseif($do ==  't'){
		$qry = "TRUNCATE $tbl";
	}elseif($do ==  'o'){
		$qry = "OPTIMIZE TABLE $tbl";
	}elseif($do == 'c'){
		$qry = "SHOW COLUMNS FROM $tbl";
	}elseif($do == 'r'){
		$qry = "REPAIR TABLE $tbl";
	}elseif($do == 'v'){
		$qry = "SELECT concat('MySQL ', version())";
	}elseif($do == 'x'){
		$qry = "SHOW processlist";
	}else{
		$l   = $lim?'LIMIT '.preg_replace('/[^\w+\s]/','',$lim):'';
		$ord = DbEscapeString($lnk,$ord);
		if( strstr($ord, 'ifname') ){
			$desc = strpos($ord, 'desc')?" desc":"";
			$ord  = ($desc)?substr($ord,0,-5):$ord;						# Cut away desc for proper handling below
			$oar = explode(".", $ord);							# Handle table in join queries
			$icol = ($oar[0] == 'ifname' or $oar[0] == 'nbrifname')?'ifname':"$oar[0].ifname";
			$dcol = ($oar[0] == 'ifname' or $oar[0] == 'nbrifname')?'device':"$oar[0].device";
			$od = "ORDER BY $dcol $desc,SUBSTRING_INDEX($icol, '/', 1), SUBSTRING_INDEX($icol, '/', -1)*1+0";
		}elseif($ord){
			$od = "ORDER BY $ord";
		}else{
			$od = '';
		}

		$w = Condition(DbEscapeString($lnk,$in),DbEscapeString($lnk,$op),DbEscapeString($lnk,$st),DbEscapeString($lnk,$co),2);

		if(isset($_SESSION) and $_SESSION['view'] and (strstr($jn,'JOIN devices') or $tbl == 'devices')){
			$viewq = explode(' ', $_SESSION['view']);
			$w = (($w)?"WHERE ($w) AND ":"WHERE ").AdOpVal( 'devices.'.$viewq[0],$viewq[1],$viewq[2] );
		}elseif($w){
			$w = "WHERE $w";
		}

		if($do == 'd'){
			$qry = "DELETE FROM $tbl $w $od $l";
		}elseif($do == 's'){
			$qry = "SELECT $col FROM $tbl $jn $w $od $l";
		}else{
			$cal = '';
			$hav = '';
			if( strpos($col,'#') ){
				$xcol = explode('#',$col);
				$col = preg_replace('/(location|modloc)/',"SUBSTRING_INDEX($1, '$locsep', $xcol[1])",$xcol[0] );
			}elseif( strpos($col,';') ){
				$xcol = explode(";",$col);
				$col = $xcol[0];
				if( $xcol[1] != '-'){$cal = ", $xcol[1]";}
				if( isset($xcol[2]) ){$hav = "having($xcol[2])";}
			}
			$qry = "SELECT $col,count(*) as cnt$cal FROM  $tbl $jn $w GROUP BY $col $hav $od $l";
		}
	}

	if($debug){
		echo "<div class=\"textpad code pre warn xxl\">";
		debug_print_backtrace();
		echo "<p><a href=\"System-Database.php?act=c&query=".urlencode($qry)."\">$qry</a>\n";
		echo DecFix(memory_get_usage(),1).'B @'.round(microtime(1) - $debug,2)."s</div>\n";
	}

	return mysqli_query($lnk,$qry);
}

?>
