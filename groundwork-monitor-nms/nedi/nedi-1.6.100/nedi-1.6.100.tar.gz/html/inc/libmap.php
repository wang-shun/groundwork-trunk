<?php
#============================================================================
#
# Program: libmap.php
# Programmer: Remo Rickli
#
# Functions for creating a map.
#
#============================================================================

#===================================================================
# Generate the PHP script for the image.

function WritePNG($flt,$fna=''){

	global $xm,$ym,$mde,$fmt,$tit,$lit,$now,$dev;
	global $mapbg,$mapinfo,$mapframes,$maplinks,$mapitems;

	$maphdr = array();
	$mapftr = array();

	$map = "session_start();\n";
	$map .= "if(!isset(\$_SESSION['group'])){exit;}\n"; #TODO implement for stricter security?
	$map .= "# PNG map created on $now by $_SESSION[user] using NeDi (visit http://www.nedi.ch for more info)\n";
	$map .= "header(\"Content-type: image/png\");\n";
	$map .= "error_reporting(0);\n";
	if( $mde == "g" ){
		$map .= "\$image = Imagecreatefromjpeg(\"topo/$mapbg\");\n";
		$map .= "Imagealphablending(\$image,true);\n";
		$map .= "\$gainsboro  = Imagecolorallocatealpha(\$image, 230, 230, 230, 40);\n";
		$map .= "\$whitesmoke = Imagecolorallocatealpha(\$image, 245, 245, 245, 40);\n";
	}else{
		$map .= "\$image = Imagecreatetruecolor($xm, $ym);\n";
		$map .= "Imagealphablending(\$image,true);\n";
		$map .= "\$gainsboro  = Imagecolorallocatealpha(\$image, 230, 230, 230, 25);\n";
		$map .= "\$whitesmoke = Imagecolorallocatealpha(\$image, 245, 245, 245, 25);\n";
		$wbg = $_SESSION['brght']+55;
		$map .= "\$white      = ImageColorAllocate(\$image, $wbg, $wbg, $wbg);\n";
		$map .= "ImageFilledRectangle(\$image, 0, 0, $xm, $ym, \$white);\n";
	}
	$map .= "\$red       = ImageColorAllocate(\$image, 200, 0, 0);\n";
	$map .= "\$purple    = ImageColorAllocate(\$image, 128, 0,128 );\n";
	$map .= "\$yellow    = ImageColorAllocate(\$image, 220, 200, 0);\n";
	$map .= "\$orange    = ImageColorAllocate(\$image, 250, 150, 0);\n";
	$map .= "\$green     = ImageColorAllocate(\$image, 0, 130, 0);\n";
	$map .= "\$limegreen = ImageColorAllocate(\$image, 50, 200, 50);\n";
	$map .= "\$navy      = ImageColorAllocate(\$image, 0, 0, 130);\n";
	$map .= "\$blue      = ImageColorAllocate(\$image, 80, 100, 250);\n";
	$map .= "\$burlywood = ImageColorAllocate(\$image,222,184,135);\n";
	$map .= "\$cornflowerblue = ImageColorAllocate(\$image, 100, 150, 220);\n";
	$map .= "\$cyan      = ImageColorAllocate(\$image, 0, 220, 220);\n";
	$map .= "\$gray      = ImageColorAllocate(\$image, 100, 100, 100);\n";
	$map .= "\$lightgray = ImageColorAllocate(\$image, 211, 211, 211);\n";
	$map .= "\$black     = ImageColorAllocate(\$image, 0, 0, 0);\n";
	if( $tit == '#' ){
		$map .= "ImageString(\$image, 1, 8, 8, \"".count($dev)." Devs\", \$gray);\n";
	}elseif( $tit ){
		$map .= "ImageString(\$image, 5, 8, 8, \"$tit\", \$black);\n";
		$map .= "ImageString(\$image, 1, 8, 26, \"".count($dev)." Devs ($flt)\", \$gray);\n";
		$map .= "ImageString(\$image, 1, ".($xm - strlen("$_SESSION[user] $now")*6).",".($ym - 10).", \"$_SESSION[user] $now\", \$gray);\n";
		if( $lit == 'l' ){									# Legend, tx ScholzSte
			$map .= "ImageString(\$image, 1, ".($xm - 50).",".($ym - 90).", \" = 0%\", \$lightgray);\n";
			$map .= "ImageString(\$image, 1, ".($xm - 50).",".($ym - 80).", \" < 2%\", \$cornflowerblue);\n";
			$map .= "ImageString(\$image, 1, ".($xm - 50).",".($ym - 70).", \" < 5%\", \$blue);\n";
			$map .= "ImageString(\$image, 1, ".($xm - 50).",".($ym - 60).", \" < 10%\", \$green);\n";
			$map .= "ImageString(\$image, 1, ".($xm - 50).",".($ym - 50).", \" < 25%\", \$limegreen);\n";
			$map .= "ImageString(\$image, 1, ".($xm - 50).",".($ym - 40).", \" < 50%\", \$yellow);\n";
			$map .= "ImageString(\$image, 1, ".($xm - 50).",".($ym - 30).", \" < 75%\", \$orange);\n";
			$map .= "ImageString(\$image, 1, ".($xm - 50).",".($ym - 20).", \">= 76%\", \$red);\n";
		}elseif( $lit != 'n' ){
			$map .= "ImageString(\$image, 1, ".($xm - 50).",".($ym - 60).", \"x1Mb/s\", \$green);\n";
			$map .= "ImageString(\$image, 1, ".($xm - 50).",".($ym - 50).", \"x10Mb/s\", \$blue);\n";
			$map .= "ImageString(\$image, 1, ".($xm - 50).",".($ym - 40).", \"x100Mb/s\", \$orange);\n";
			$map .= "ImageString(\$image, 1, ".($xm - 50).",".($ym - 30).", \"x1Gb/s\", \$red);\n";
			$map .= "ImageString(\$image, 1, ".($xm - 50).",".($ym - 20).", \"x10Gb/s\", \$purple);\n";
		}
	}
	$map .= $mapinfo . $mapframes . $maplinks . "imagesetthickness(\$image,1);\n" . $mapitems;
	if( $dpt = substr($fmt,3,1) ) $map .= "imagetruecolortopalette(\$image,FALSE, ".(pow(2,$dpt)-1).");\n";
	$map .= "Imagepng(\$image);\n";
	$map .= "Imagedestroy(\$image);\n";

	if( $fna == 'stdout' ){
		eval($map);
	}else{
		ob_start();
		eval($map);
		$data = ob_get_contents();
		ob_end_clean();

		$fd =  @fopen("$fna.png","w") or die ("can't create $fna");
		fwrite($fd,$data);
		fclose($fd);
	}
}

#===================================================================
# Generate the SVG xml.

function WriteSVG($flt){

	global $xm,$ym,$dev,$mde,$tit,$now,$mapinfo,$mapframes,$maplinks,$mapitems;

       	$map  = "<?php xml version=\"1.0\" encoding=\"iso-8859-1\" standalone=\"no\" ?>\n";
	$map .= "<!DOCTYPE svg PUBLIC \"-//W3C//DTD SVG 1.0//EN\" \"http://www.w3.org/TR/SVG/DTD/svg10.dtd\">\n";
	$map .= "<svg viewBox=\"0 0 $xm $ym\" xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\">\n";
	$map .= "<g id=\"main\" font-size=\"9\">\n";
	$map .= "<rect id=\"canvas\" width=\"$xm\" height=\"$ym\" x=\"0\" y=\"0\" fill=\"white\" />\n";
	$map .= "<g id=\"title\">\n";
	$map .= "	<text x=\"8\" y=\"20\" font-size=\"16\" font-weight=\"bold\">$tit</text>\n";
	$map .= "	<text x=\"8\" y=\"32\" style=\"fill:gray;\">".count($dev)." Devices $flt</text>\n";
	$map .= "	<text x=\"".($xm - 120)."\" y=\"".($ym - 5)."\" style=\"fill:gray;\">$_SESSION[user] $now</text>\n";
	$map .= "</g>\n";

	$map .= "<g id=\"info\">\n";
	$map .= $mapinfo;
	$map .= "</g>\n";

	$map .= "<g id=\"frames\">\n";
	$map .= $mapframes;
	$map .= "</g>\n";

	$map .= "<g id=\"links\">\n";
	$map .= $maplinks;
	$map .= "</g>\n";

	$map .= "<g id=\"items\">\n";
	$map .= $mapitems;
	$map .= "</g>\n";

	$map .= "</g></svg>\n";

	$fd =  @fopen("map/map_$_SESSION[user].svg","w") or die ("can't create map/map_$_SESSION[user].svg");
	fwrite($fd,$map);
	fclose($fd);
}

#===================================================================
# Generate the Json script. TheJit compatble output on flat and d3 on other maps
function WriteJson($mod=0) {

	global $debug,$xm,$ym,$len,$mde,$tit,$mapinfo,$mapframes,$maplinks,$mapitems,$srclbl;

	$jsdata = "{\n  \"nodes\":[\n".substr($mapitems,0,-2)."\n  ],\n  \"links\":[\n".substr($maplinks,0,-2)."\n  ]\n}";
	if($mod){
		echo $jsdata;
	}else{
		$fd =  @fopen("map/map_$_SESSION[user].json","w") or die ("can't create map/map_$usr.json");
		fwrite($fd, $jsdata);
		fclose($fd);
		if($debug) var_dump(json_decode($jsdata));
	}
}

#===================================================================
# Draws a link.
function DrawLink($x1,$y1,$x2,$y2,$opt) {

	global $fmt,$lev,$lix,$liy,$lis,$lit,$lil,$lal,$ipi,$ifi,$ifa,$pos,$xm,$ym,$debug;
	global $dev,$maplinks,$mapitems,$errlbl,$trflbl,$rrdcmd,$rrdstep,$nedipath;

	if($x1 == $x2){											# offset coherent, horizontal links...
		$lix[$x1]++;
		$x1 += ($lix[$x1]%2)?$lix[$x1]:-$lix[$x1];
		$x2 = $x1;
	}elseif($y1 == $y2){										# offset coherent, verical links...
		$liy[$y1]++;
		$y1 += ($liy[$y1]%2)?$liy[$y1]:-$liy[$y1];
		$y2 = $y1;
	}
	$xlm = $xll = intval($x1 + $x2) / 2;									# middle of link
	$ylm = $yll = intval($y1 + $y2) / 2;

	$dctr1 = sqrt( pow(($x1 - $xm/2),2) + pow(($y2 - $ym/2),2) );					# Pythagoras tells distance to map center of either possible arc centerpoint
	$dctr2 = sqrt( pow(($x2 - $xm/2),2) + pow(($y1 - $ym/2),2) );

	if($dctr1 < $dctr2){										# Ensure 'concave' arcs
		$xctr = $x1;
		$yctr = $y2;
		$xedg = $x2;
		$yedg = $y1;
	}else{
		$xctr = $x2;
		$yctr = $y1;
		$xedg = $x1;
		$yedg = $y2;
	}
	if($debug) $maplinks .= "ImageString(\$image, 3, $x1,$y1,\"S\", \$blue);\n";
	if($debug) $maplinks .= "ImageString(\$image, 3, $xctr,$yctr,\"C\", \$blue);\n";
	if($debug) $maplinks .= "ImageString(\$image, 3, $xedg,$yedg,\"E\", \$blue);\n";

	list($t,$cf,$futl)  = LinkStyle( $opt['fbw'],$opt['ftr'] );
	list($tr,$cr,$rutl) = LinkStyle( $opt['rbw'],$opt['rtr'] );

	if( $cf == $cr ){										# Optimize single colored links
		$lsty = "\$$cf";
	}else{
	$maplinks .= "\$stylarr = array(\$$cf,\$$cf,\$$cf,\$$cf,\$$cf,\$$cf,\$$cf,\$$cf,
						\$$cf,\$$cf,\$$cf,\$$cf,\$$cf,\$$cf,\$$cf,\$$cf,
						\$$cf,\$$cf,\$$cf,\$$cf,\$$cf,\$$cf,\$$cf,\$$cf,
						\$$cf,\$$cf,\$$cf,\$$cf,\$$cf,\$$cf,\$$cf,\$$cf,
						\$$cr,\$$cr,\$$cr,\$$cr,\$$cr,\$$cr,\$$cr,\$$cr,
						\$$cr,\$$cr,\$$cr,\$$cr,\$$cr,\$$cr,\$$cr,\$$cr,
						\$$cr,\$$cr,\$$cr,\$$cr,\$$cr,\$$cr,\$$cr,\$$cr,
						\$$cr,\$$cr,\$$cr,\$$cr,\$$cr,\$$cr,\$$cr,\$$cr);\n";
		$maplinks .= "imagesetstyle(\$image,\$stylarr);\n";
		$lsty = 'IMG_COLOR_STYLED';
	}

	#$maplinks .= "\$bru = imagecreatefrompng('../img/netr.png');\n";
	#$maplinks .= "imagesetbrush(\$image, \$bru);\n";
	#$lsty = 'IMG_COLOR_BRUSHED';

	if($lis == "a1" or $x2 == $x1 and $y2 == $y1){
		if($x2 == $x1 and $y2 == $y1){
			$y1 += 1;
			$w = 100;
			$h = 50;
			$s = 0;
			$e = 360;
			$xctr  += 50;
			$xlm = $xll = $xctr + 50;
			$ylm = $yll = $y1;
		}else{
			$w = 2*abs($x2-$x1);
			$h = 2*abs($y2-$y1);

			$l = sqrt($w*$h)/10;

			if($xctr > $xedg){								# Left half
				if($yctr > $yedg){							# Upper Quadrant
					$s = 180;$e = 270;$ylm -= $l;
				}else{
					$s = 90;$e = 180;$ylm += $l;
				}
				$xlm -= $l;
			}else{
				if($yctr > $yedg){
					$s = 270;$e = 0;$ylm -= $l;
				}else{
					$s = 0;$e = 90;$ylm += $l;
				}
				$xlm += $l;
			}
		}
		if($fmt == "svg"){
			$maplinks .= "<path d=\"M $x1 $y1 A $w $h 0 0 1 $x2 $y2\" stroke=\"$cf\" stroke-width=\"$t\" fill = \"none\"/>\n";
		}else{
			$maplinks .= "imagesetthickness(\$image,$t);\n";
			$maplinks .= "imagearc(\$image, $xctr, $yctr, $w, $h, $s, $e, $lsty);\n";
		}
	}elseif($lis == "a2" or $lis == "a3"){
		$xlm = $xll = $xedg;
		$ylm = $yll = $yedg;
		if($pos == "d" or $pos == "a"){
			$xs = 2;
			$ys = 2;
			$rs = 5;
		}else{
			$xs = 6;
			$ys = 4;
			$rs = 25;
		}
		$liy["I$xll;$yll"]++;
		if( $x1 == $xlm ){
			if( $y1 > $y2 ){
				$lix["B$x1;$y1"]++;
				$yl1 = $lix["B$x1;$y1"]*9;
				$x1 += ($lix["B$x1;$y1"]%2)?$xs:-$xs;
				$y2 += $ys;
				$yr1 = $y2+$rs;
			}elseif( $y1 < $y2 ){
				$lix["T$x1;$y1"]++;
				$yl1 = $lix["T$x1;$y1"]*9;
				$x1 += ($lix["T$x1;$y1"]%2)?$xs:-$xs;
				$y2 -= $ys;
				$yr1 = $y2-$rs;
			}else{
				$yr1 = $y1;
				$rs  = 0;
			}
			$xlm = $xr1 = $x1;
			$ylm = $yr2 = $y2;
			$xr2 = ($x1 > $x2)?$xlm-$rs:$xlm+$rs;
		}else{
			if( $y2 > $y1 ){
				$lix["B$x2;$y2"]++;
				$yl2 = $lix["B$x2;$y2"]*9;
				$x2 += ($lix["B$x2;$y2"]%2)?$xs:-$xs;;
				$y1 += $ys;
				$yr2 = $y1+$rs;
			}elseif( $y2 < $y1 ){
				$lix["T$x2;$y2"]++;
				$yl2 = $lix["T$x2;$y2"]*9;
				$x2 += ($lix["T$x2;$y2"]%2)?$xs:-$xs;;
				$y1 -= $ys;
				$yr2 = $y1-$rs;
			}else{
				$yr2 = $y2;
				$rs  = 0;
			}
			$xlm = $xr2 = $x2;
			$ylm = $yr1 = $y1;
			$xr1 = ($x2 > $x1)?$xlm-$rs:$xlm+$rs;
		}
		if($fmt == "svg"){
			$maplinks .= "<line x1=\"$x1\" y1=\"$y1\" x2=\"$xlm\" y2=\"$ylm\" stroke=\"$cf\" stroke-width=\"$t\"/>\n";
			$maplinks .= "<line x1=\"$xlm\" y1=\"$ylm\" x2=\"$x2\" y2=\"$y2\" stroke=\"$cf\" stroke-width=\"$t\"/>\n";
		}elseif($lis == "a3"){
			$maplinks .= "imagesetthickness(\$image,$t);\n";
			$maplinks .= "imageline(\$image,$x1,$y1,$xr1,$yr1,$lsty);\n";
			$maplinks .= "imageline(\$image,$xr2,$yr2,$x2,$y2,$lsty);\n";
			$maplinks .= "imageline(\$image,$xr1,$yr1,$xr2,$yr2,$lsty);\n";
		}else{
			$maplinks .= "imagesetthickness(\$image,$t);\n";
			$maplinks .= "imageline(\$image,$x1,$y1,$xlm,$ylm,$lsty);\n";
			$maplinks .= "imageline(\$image,$xlm,$ylm,$x2,$y2,$lsty);\n";
		}
	}elseif($lis == "a4"){
		$xlm = $xll = $xedg-intval(($xedg-$xctr)/5);
		$ylm = $yll = $yedg-intval(($yedg-$yctr)/5);
		if($fmt == "svg"){
			$maplinks .= "<line x1=\"$x1\" y1=\"$y1\" x2=\"$xlm\" y2=\"$ylm\" stroke=\"$cf\" stroke-width=\"$t\"/>\n";
			$maplinks .= "<line x1=\"$xlm\" y1=\"$ylm\" x2=\"$x2\" y2=\"$y2\" stroke=\"$cf\" stroke-width=\"$t\"/>\n";
		}else{
			$maplinks .= "imagesetthickness(\$image,$t);\n";
			$maplinks .= "imageline(\$image,$x1,$y1,$xlm,$ylm,$lsty);\n";
			$maplinks .= "imageline(\$image,$xlm,$ylm,$x2,$y2,$lsty);\n";
		}
	}else{
		if($fmt == "svg"){
			$maplinks .= "<line x1=\"$x1\" y1=\"$y1\" x2=\"$x2\" y2=\"$y2\" stroke=\"$cf\" stroke-width=\"$t\"/>\n";
		}else{
			$maplinks .= "imagesetthickness(\$image,$t);\n";
			$maplinks .= "imageline(\$image,$x1,$y1,$x2,$y2,$lsty);\n";
		}
	}

	$xlm = $xlm + $lil/10*intval($xm/($xlm - $xm/2.1));						# move info on a ray from the center
	$ylm = $ylm + $lil/10*intval($ym/($ylm - $ym/2.1));						# .1 to avoid div 0

	if( is_array($opt['fif']) ){
		foreach ($opt['fif'] as $fi){
			$f = explode(';;', $fi);
			$ifal = ($ifa and $dev[$f[0]]['ifal'][$f[1]])?" ".$dev[$f[0]]['ifal'][$f[1]]:"";
			if( preg_match('/^[febd]/',$lit) and $rrdcmd ){
				$rrd = "$nedipath/rrd/" . rawurlencode($f[0]) . "/" . rawurlencode($f[1]) . ".rrd";
				if (file_exists($rrd)){
					$rrdif["$f[0]-$f[1]"] = $rrd;
				}elseif($debug){
					echo "<div class=\"textpad alrm\">FRRD:$rrd not found!</div>\n";
				}
			}
			if($lev > 3){
				$ifl = ($ifi and $f[1] != '-')?$f[1]:'';
			}else{
				$ifl = ($ifi)?"$f[0] $f[1]":"";
			}
			$ipl = ($ipi)?$dev[$f[0]]['ifip'][$f[1]]:"";
			$alpha = atan2( ($ylm-$y1),($xlm-$x1) );
			$mapitems .= DrawLabel(	$x1+cos($alpha)*$lal,
						$y1+sin($alpha)*$lal+$yl1,
						Safelabel("$ifl$ipl$ifal"),1,"gray");
			$yl1 += 9;
		}
	}
	if( is_array($opt['rif']) ){
		foreach ($opt['rif'] as $ri){
			$r = explode(';;', $ri);
			$ifal = ($ifa and $dev[$r[0]]['ifal'][$r[1]])?" ".$dev[$r[0]]['ifal'][$r[1]]:"";
			if($lev > 3){
				$ifl = ($ifi and $r[1] != '-')?$r[1]:'';
			}else{
				$ifl = ($ifi)?"$r[0] $r[1]":"";
			}
			$ipl = ($ipi)?$dev[$r[0]]['ifip'][$r[1]]:"";
			$alpha = atan2( ($ylm-$y2),($xlm-$x2) );
			$mapitems .= DrawLabel(	$x2+cos($alpha)*$lal,
						$y2+sin($alpha)*$lal+$yl2,
						Safelabel("$ifl$ipl$ifal"),1,"gray");
			$yl2 += 9;
		}
	}

	if($lit == 'w'){
		$mapitems .= DrawLabel($xlm,$ylm-8-9*$liy["I$xll;$yll"],DecFix($opt['fbw']) . "/" . DecFix($opt['rbw']),1,"green");
	}elseif($lit == 't'){
		foreach ($opt['fty'] as $t => $c){
			$ftyp .= ($c > 1)?"${c}x $t ":"$t ";
		}
		foreach ($opt['rty'] as $t => $c){
			$rtyp .= ($c > 1)?"${c}x $t ":"$t ";
		}
		$mapitems .= DrawLabel($xlm,$ylm- 8-9*$liy["I$xll;$yll"],$ftyp,1,"blue");
		$mapitems .= DrawLabel($xlm,$ylm-16-9*$liy["I$xll;$yll"],$rtyp,1,"blue");
	}elseif($lit == 'l' and $pos != "d" and $pos != "a"){
		if( $futl > 10 or $rutl > 10 ) $mapitems .= DrawLabel($xlm,$ylm-8,"$futl%/$rutl%",3,"black");
	}elseif( is_array($rrdif) ){
		if( preg_match('/^f/',$lit) ){
			$opts = GraphOpts(substr($lit,1),0,0,$trflbl,$opt['fbw']);
			list($draw,$tit) = GraphTraffic($rrdif,'trf');
			$mapitems .= DrawLabel($xlm,$ylm-25,DecFix($opt['fbw']) . "/" . DecFix($opt['rbw']),1,"green");
		}elseif( preg_match('/^e/',$lit) ){
			$opts = GraphOpts(substr($lit,1),0,0,$errlbl,1);
			list($draw,$tit) = GraphTraffic($rrdif,'err');
		}elseif( preg_match('/^d/',$lit) ){
			$opts = GraphOpts(substr($lit,1),0,0,"Discards",0);
			list($draw,$tit) = GraphTraffic($rrdif,'dsc');
		}else{
			$opts = GraphOpts(substr($lit,1),0,0,"Broadcasts",0);
			list($draw,$tit) = GraphTraffic($rrdif,'brc');
		}
		exec("$rrdcmd graph map/$xlm$ylm.png -a PNG $opts $draw");
		if($fmt == "json"){
		}elseif($fmt == "svg"){
			$mapitems .= "	<text x=\"$xlm\" y=\"$ylm\" fill=\"gray\">no RRDs in SVG!</text>\n";
		}else{
			$mapitems .= "\$icon = Imagecreatefrompng(\"map/$xlm$ylm.png\");\n";
			$mapitems .= "\$w = Imagesx(\$icon);\n";
			$mapitems .= "\$h = Imagesy(\$icon);\n";
			$mapitems .= "Imagecopy(\$image, \$icon,$xlm-\$w/2,$ylm-\$h/2,0,0,\$w,\$h);\n";
			$mapitems .= "Imagedestroy(\$icon);\n";
			$mapitems .= "unlink(\"map/$xlm$ylm.png\");\n";
		}
	}
}
#===================================================================
# Draws box

function DrawBuilding($x,$y,$r,$c,$b) {

	global $lev,$loi,$flr,$fsz,$fco,$fmt,$imas;
	global $pos,$dev,$mapframes,$mapitems,$imgmap;

	$row = $rows = $cols = 0;
	foreach(array_keys($flr[$r][$c][$b]) as $f){							# Determine building size
		$curcol = count($flr[$r][$c][$b][$f]);
		$cols   = max($curcol,$cols);
		if($curcol > $fco){									# Break row, if > Floor columns
			$rows += ceil($curcol / $fco);							# How many rows result?
			$cols = $fco;
		}else{
			$rows++;
		}
	}
	$woff = intval($fsz*($cols-1)/2);
	$hoff = intval($fsz*($rows-1)/2);

	$x1 = $x - $woff - intval($fsz/2) - $imas/2;
	$y1 = $y - $hoff - intval($fsz/2);
	$x2 = $x + $woff + intval($fsz/2);
	$y2 = $y + $hoff + intval($fsz/2);

	if($fmt == "json"){
	}elseif($fmt == "svg"){
		$mapframes .= "	<rect fill=\"whitesmoke\" x=\"$x1\" y=\"$y1\" width=\"".($x2-$x1)."\" height=\"".($y2-$y1)."\" fill-opacity=\"0.6\" />\n";
		if($pos == "d" or $pos == "a"){
			if($loi) $mapframes .= "	<text x=\"$x1\" y=\"".($y1-4)."\" font-size=\"12\" fill=\"blue\">".substr($b,0,$_SESSION['lsiz'])."</text>\n";
		}else{
			$mapframes .= "	<rect fill=\"gainsboro\" x=\"$x1\" y=\"".($y1+15)."\" width=\"20\" height=\"".($y2-$y1-20)."\" fill-opacity=\"0.6\" />\n";
			$mapframes .= "	<text x=\"".($x1+4)."\" y=\"".($y1+12)."\" font-size=\"12\" fill=\"blue\">".substr($b,0,$_SESSION['lsiz'])."</text>\n";
		}
		$mapframes .= "	<rect fill=\"none\" stroke=\"black\" x=\"$x1\" y=\"$y1\" width=\"".($x2-$x1)."\" height=\"".($y2-$y1)."\"/>\n";
	}else{
		$mapframes .= "Imagefilledrectangle(\$image, $x1, $y1, $x2, $y2, \$whitesmoke);\n";
		if($pos == "d" or $pos == "a"){
			if($loi) $mapframes .= "ImageString(\$image, 3, $x1, ".($y1-14).",\"".substr($b,0,$_SESSION['lsiz'])."\", \$blue);\n";
		}else{
			$mapframes .= "Imagefilledrectangle(\$image, $x1, ".($y1+15).", ".($x1+20).", $y2, \$gainsboro);\n";
			$mapframes .= "ImageString(\$image, 3, ".($x1+4).", $y1,\"".substr($b,0,$_SESSION['lsiz'])."\", \$blue);\n";
		}
		$mapframes .= "Imagerectangle(\$image, $x1, $y1, $x2, $y2, \$black);\n";
	}
	uksort($flr[$r][$c][$b], "Floorsort");
	foreach(array_keys($flr[$r][$c][$b]) as $f){
		$mapitems .= DrawItem(	$x - $woff - intval($fsz/2),
					$y - $hoff + $row*$fsz,
					0,$f,'fl');
		usort( $flr[$r][$c][$b][$f],"Roomsort" );
		$col = 0;
		foreach($flr[$r][$c][$b][$f] as $dv){
			if($col == $fco){
				$col = 0;
				$row++;
			}
			$dev[$dv]['x'] = $x - $woff + $col*$fsz;
			$dev[$dv]['y'] = $y - $hoff + $row*$fsz;
			$mapitems .= DrawItem($dev[$dv]['x'],$dev[$dv]['y'],'0',$dv,'d',$dev[$dv]['sta']);
			$imgmap   .= "<area href=\"Devices-Status.php?dev=".urlencode($dv)."\" coords=\"".($dev[$dv]['x']-$imas) .",". ($dev[$dv]['y']-$imas) .",". ($dev[$dv]['x']+$imas) .",". ($dev[$dv]['y']+$imas)."\" shape=\"rect\" title=\"$dv ".$dev[$dv]['ip']." CPU:".$dev[$dv]['cpu']."%  T:".$dev[$dv]['tmp']."C\">\n";
			if( $lev == 6){DrawNodes($dv);}
			$col++;
		}
		$row++;
	}

}

//===================================================================
// Return device shape style based on icon
function Devshape($ico="xxan"){

	$lev = substr($ico,1,1);
	$col = substr($ico,2,1);
	$shd = substr($ico,3,1);

	if($shd == 'd' or $lev == 'b'){
		$x = 16;
	}elseif($shd == 'n' or $lev == 'm'){
		$x = 12;
	}elseif($shd == 'p' or $lev == 's'){
		$x = 10;
	}else{
		$x = 6;
	}

	$shp = 'r';
	if( preg_match('/^c[23]/',$ico) ){
		$y = $x;
	}elseif( preg_match('/^w[23]/',$ico) ){
		$y = $x/2;
	}elseif( preg_match('/^ph/',$ico) ){
		$x = 6;
		$y = 8;
	}elseif( preg_match('/^w[ab]/',$ico) ){
		$shp = 'c';
		$x = 6;
		$y = 8;
	}elseif( preg_match('/^r/',$ico) ){
		$shp = 'c';
		$y = intval($x/1.5);
	}else{
		$x /= 2;
		$y = $x;
	}

	if($col == "b"){
		return array("blue",$x,$y,$shp);
	}elseif($col == "c"){
		return array("cyan",$x,$y,$shp);
	}elseif($col == "g"){
		return array("green",$x,$y,$shp);
	}elseif($col == "o"){
		return array("orange",$x,$y,$shp);
	}elseif($col == "r"){
		return array("red",$x,$y,$shp);
	}elseif($col == "p"){
		return array("purple",$x,$y,$shp);
	}elseif($col == "y"){
		return array("yellow",$x,$y,$shp);
	}else{
		return array("gray",$x,$y,$shp);
	}
}

#===================================================================
# Draws a single item

function DrawItem($x,$y,$opt,$label,$typ,$sta=0) {# TODO refactor (ShapeStatus too)

	global $fmt,$dev,$nod,$pos,$pwt,$loi,$dvi,$ipd,$redbuild,$cpua,$tmpa;

	$r = 16;
	if($fmt == "json") $r = intval($r/10*$pwt);
	$lx = intval($x-strlen($label) * 2);

	if($typ == 3){											# Building
		$bc = ( preg_match('/$redbuild/',$label) )?"red":"burlywood";
		if($pos == "s"){
			$itxt = IconRect($x,$y,$r,$r,$bc);
		}elseif($pos == "a" or $pos == "l"){
			list($stabg,$statxt) = ShapeStatus($sta);
			$itxt = IconRect($x,$y,$r/3,$r/3,$stabg);
		}elseif($pos == "A" or $pos == "L"){
			list($stabg,$statxt,$wd) = ShapeStatus($sta,$r);
			$itxt = IconRect($x,$y,$wd,$r,$stabg);
			$itxt .= DrawLabel($x,$y-6,$statxt,3,"whitesmoke");
		}elseif($pos == "d"){
			$itxt = IconRect($x,$y,$r/3,$r/3,$bc);
		}else{
			$itxt = IconPng($x,$y,BldImg($opt,$label),30);
			$r += 4;
		}
		if($fmt == "json"){
			$itxt .= ',"name":"'.Safelabel($label)."\"},\n";
		}elseif($pos != "a" and $pos != "d" and $pos != "l" ){
			$itxt .= DrawLabel($x,$y+$r,Safelabel($label),2,"navy");
		}
	}elseif($typ == 2){										# City
		if($pos == "s"){
			$itxt = IconCircle($x,$y,$r,$r,"purple");
		}elseif($pos == "a" or $pos == "l"){
			list($stabg,$statxt) = ShapeStatus($sta);
			$itxt = IconCircle($x,$y,$r/3,$r/3,$stabg);
		}elseif($pos == "A" or $pos == "L"){
			list($stabg,$statxt,$wd) = ShapeStatus($sta,$r);
			$itxt = IconCircle($x,$y,$wd,$r,$stabg);
			$itxt .= DrawLabel($x,$y-6,$statxt,3,"whitesmoke");
		}elseif($pos == "d"){
			$itxt = IconCircle($x,$y,$r/3,$r/3,"purple");
			if($fmt == "json") $itxt .= ',"name":"'.Safelabel($label)."\"},\n";
		}else{
			$itxt = IconPng($x,$y,CtyImg($opt),48);
			$r += 10;
		}
		if($fmt == "json"){
			$itxt .= ',"name":"'.Safelabel($label)."\"},\n";
		}elseif($pos != "a" and $pos != "d" and $pos != "l" ){
			$itxt .= DrawLabel($x,$y+$r,Safelabel($label),3,"navy");
		}
	}elseif($typ == 1){										# Region
		if($pos == "s"){
			$itxt = IconCircle($x,$y,$r,$r,"cornflowerblue");
		}elseif($pos == "a" or $pos == "l"){
			list($stabg,$statxt) = ShapeStatus($sta);
			$itxt = IconCircle($x,$y,$r/3,$r/3,$stabg);
		}elseif($pos == "A" or $pos == "L"){
			list($stabg,$statxt,$wd) = ShapeStatus($sta,$r);
			$itxt = IconCircle($x,$y,$wd,$r,$stabg);
			$itxt .= DrawLabel($x,$y-6,$statxt,3,"whitesmoke");
		}elseif($pos == "d"){
			$itxt = IconCircle($x,$y,$r/3,$r/3,"cornflowerblue");
			if($fmt == "json") $itxt .= ',"name":"'.Safelabel($label)."\"},\n";

		}else{
			$itxt = IconPng($x,$y,"32/glob",32);
		}
		if($fmt == "json"){
			$itxt .= ',"name":"'.Safelabel($label)."\"},\n";
		}else{
			$itxt .= DrawLabel($x,$y+$r,Safelabel($label),4,"navy");
		}
	}elseif($typ == "ri"){										# Regioninfo
		if($pos == "s"){
			$itxt = IconCircle($x,$y,10,6,"gainsboro");
		}elseif($pos == "d" or $pos == "a"){
			$itxt = IconCircle($x,$y,4,2,"gainsboro");
		}else{
			$itxt = IconPng($x,$y,"regg",25);
		}
		$itxt .= DrawLabel($x,$y+10,Safelabel($label),2,"cornflowerblue");
	}elseif($typ == "ci"){										# Cityinfo
		if($pos == "s"){
			$itxt = IconRect($x,$y,10,6,"whitesmoke");
		}elseif($pos == "d" or $pos == "a"){
			$itxt = IconRect($x,$y,4,2,"whitesmoke");
		}else{
			$itxt = IconPng($x,$y,"cityg",30);
		}
		$itxt .= DrawLabel($x,$y+10,Safelabel($label),2,"cornflowerblue");
	}elseif($typ == "bi"){										# Bldinfo
		if($pos == "s"){
			$itxt .= IconRect($x,$y,4,4,"whitesmoke");
		}elseif($pos == "d" or $pos == "a"){
			$itxt .= IconRect($x,$y,2,2,"whitesmoke");
		}else{
			$itxt .= IconPng($x,$y,"bldg",30);
		}
		$itxt .= DrawLabel($x,$y+10,Safelabel($label),2,"cornflowerblue");
	}elseif($typ == "fl"){										# Floorinfo
		if($pos == "s"){
			$itxt = IconRect($x,$y,3,2,"black");
			$itxt .= DrawLabel($x,$y+6,Safelabel($label),3,"navy");
		}elseif($pos == "d" or $pos == "a"){
			$itxt .= IconRect($x,$y,1,0.5,"black");
		}else{
			$itxt = IconPng($x,$y,"stair",10);
			$itxt .= DrawLabel($x,$y+6,Safelabel($label),3,"navy");
		}
	}elseif($typ == "cl"){										# Cloud
		list($clr,$sx,$sy,$shp) = Devshape($opt);
		if($pos == "s"){
			$itxt .= IconCircle($x,$y,4,4,"whitesmoke");
		}elseif($pos == "d" or $pos == "a"){
			$itxt .= IconCircle($x,$y,2,2,"whitesmoke");
		}else{
			$itxt .= IconPng($x,$y,"dev/$opt",30);
		}
		if($fmt == "json"){
			$itxt .= ',"name":"'.Safelabel($label)."\"},\n";
		}elseif($pos != "a" and $pos != "d" and $pos != "l" ){
			$itxt .= DrawLabel($x,$y+10,Safelabel($label),2,"cornflowerblue");
		}
	}elseif($typ == "d"){										# Device
		list($clr,$sx,$sy,$shp) = Devshape($dev[$label]['ico']);
		if($pos == "s"){
			if($shp == "c"){
				$itxt = IconCircle($x,$y,$sx,$sy,$clr);
			}else{
				$itxt = IconRect($x,$y,$sx,$sy,$clr);
			}
			if($dev[$label]['stk'] > 1){
				$itxt .= DrawLabel($x+20,$y-6,$dev[$label]['stk'],2,"blue");
			}
		}elseif($pos == "d"){
			if($shp == "c"){
				$itxt = IconCircle($x,$y,$sx/3,$sy/3,$clr);
			}else{
				$itxt = IconRect($x,$y,$sx/3,$sy/3,$clr);
			}
		}elseif($pos == "c"){
			if($dev[$label]['cpu'] == "-"){
				$itxt = IconCircle($x,$y,8,4,"gray");
			}elseif($dev[$label]['cpu'] < $cpua/2){
				$itxt = IconRect($x,$y,12,6,"green");
				$itxt .= DrawLabel($x,$y-3,$dev[$label]['cpu']."%",1,"whitesmoke");
			}elseif($dev[$label]['cpu'] < $cpua){
				$itxt = IconRect($x,$y,16,8,"yellow");
				$itxt .= DrawLabel($x,$y-3,$dev[$label]['cpu']."%",1,"black");
			}else{
				$itxt = IconRect($x,$y,intval(0.5*$dev[$label]['cpu']),intval(0.2*$dev[$label]['cpu']),"orange");
				$itxt .= DrawLabel($x,$y-3,$dev[$label]['cpu']."%",2,"whitesmoke");
			}
			if($dev[$label]['stk'] > 1){
				$itxt .= DrawLabel($x+20,$y-6,$dev[$label]['stk'],3,"blue");
			}
		}elseif($pos == "h"){
			if(!$dev[$label]['tmp']){
				$itxt = IconCircle($x,$y,8,4,"gray");
			}elseif($dev[$label]['tmp'] < $tmpa/2){
				$itxt = IconRect($x,$y,12,6,"blue");
				$itxt .= DrawLabel($x,$y-3,$dev[$label]['tlb'],1,"whitesmoke");
			}elseif($dev[$label]['tmp'] < $tmpa){
				$itxt = IconRect($x,$y,16,8,"purple");
				$itxt .= DrawLabel($x,$y-3,$dev[$label]['tlb'],1,"whitesmoke");
			}else{
				$itxt = IconRect($x,$y,intval(0.5*$dev[$label]['tmp']),intval(0.2*$dev[$label]['tmp']),"red");
				$itxt .= DrawLabel($x,$y-3,$dev[$label]['tlb'],3,"whitesmoke");
			}
			if($dev[$label]['stk'] > 1){
				$itxt .= DrawLabel($x+20,$y-6,$dev[$label]['stk'],2,"blue");
			}
		}elseif($pos == 'a' or $pos == 'l'){
			list($stabg,$statxt,$wd) = ShapeStatus($sta,$sx,1);
			$itxt = IconRect($x,$y,$wd/2,$sy/2,$stabg);
		}elseif($pos == 'A' or $pos == 'L'){
			list($stabg,$statxt,$wd) = ShapeStatus($sta,$sx,1);
			$itxt = IconRect($x,$y,$wd+4,$sy+4,$stabg);
			$itxt .= DrawLabel($x,$y-6,$statxt,3,"whitesmoke");
			if( $dev[$label]['stk'] > 1 ){
				$itxt .= DrawLabel($x+20,$y-6,$dev[$label]['stk'],2,"blue");
			}
		}elseif($pos == "p" or $pos == "P" or $pos == "D"){
			$itxt = Panel($x,$y,$dev[$label]['typ'],$dev[$label]['stk'],$dev[$label]['ico'],$dev[$label]['siz']);
			if( $pos != "D" ) $boxw = strlen($label);
		}else{
			$itxt = IconPng($x,$y,"dev/" . $dev[$label]['ico'],30);
			if($dev[$label]['stk'] > 1 and $fmt != "json"){
				$itxt .= IconPng($x+30,$y,$dev[$label]['stk'],16);
			}
		}

		if($fmt == "json"){
			$itxt .= ',"name":"'.Safelabel($label)."\"},\n";
		}elseif($pos != "d" and $pos != "a" and $pos != "l" ){
			$clr  = ($dev[$label]['ord']<0)?'red':'black';
			$devl = DrawLabel($x,$y+$sy+6,Safelabel($label),1,$clr);
			if($loi){
				if($loi == 1){
					$locl = $dev[$label]['rom'];
				}elseif($loi == 2){
					$locl = $dev[$label]['rak'];
				}else{
					$locl = $dev[$label]['rom']." ".$dev[$label]['rak'];
				}
				$locw  = strlen($locl);
				$devl .= DrawLabel($x,$y-$sy-14,Safelabel($locl),1,"cornflowerblue");
			}
			if($ipd){
				$iplw  = strlen($dev[$label]['ip']);
				$devl .= DrawLabel($x,$y+$sy+14,$dev[$label]['ip'],1,"blue");
			}
			if($dvi){
				$dvil = '';
				if($dvi == 1){
					$dvil = $dev[$label]['con'];
				}elseif($dvi == 2){
					$dvil = $dev[$label]['mod'];
				}elseif($dvi == 3){
					$dvil = $dev[$label]['con']." ".$dev[$label]['mod'];
				}
				$dviw  = strlen($dvil);
				$devl .= DrawLabel($x,$y+(($ipd)?34:26),Safelabel($dvil),1,"gray");
			}
			if($boxw){
				$boxw  = ($iplw > $boxw)?$iplw:$boxw;
				$boxw  = ($locw > $boxw)?$locw:$boxw;
				$boxw  = ($dviw > $boxw)?$dviw:$boxw;
				$pof   = (($ipd)?4:0) + (($dvi)?4:0);
				$itxt .= IconRect($x,$y+$sy+12+$pof/2,$boxw*3,8+$pof,"whitesmoke");
			}
			$itxt .= $devl;
		}
	}elseif($typ == "n"){
		if($pos == "s"){
			$itxt .= IconCircle($x,$y,5,5,"limegreen");
		}elseif($pos == "d"){
			$itxt = IconCircle($x,$y,2,2,"limegreen");
		}elseif($pos == "P"){
			$itxt = IconPng($x,$y,"32/node",32);
			$y += 6;
		}else{
			$itxt = IconPng($x,$y,"oui/" . $nod[$label]['ico'],20);
		}
		if($fmt == "json"){
			$itxt .= ',"name":"'.Safelabel($nod[$label]['nam'])."\"},\n";
		}elseif($pos != "d"){
			$itxt .= DrawLabel($x,$y+8,Safelabel($nod[$label]['nam']),1,"black");
			if ($ipd){$itxt .= DrawLabel($x,$y+16,$nod[$label]['ip'],1,"blue");}
		}
	}
	return $itxt;
}

#===================================================================
# Creates a Json device
function JsonDev($d,$jgrp){

	global $dev,$pos,$tmpa,$cpua,$stco;

	if($pos == "c"){
		if($dev[$d]['cpu'] == '-'){
			$jval = 1;
			$jtit = "$d CPU:-";
			if($jgrp === 'f')$jgrp = 2;
		}elseif($dev[$d]['cpu'] > $cpua){
			$jval = intval(($dev[$d]['cpu']-$cpua)/3+5);
			if($jgrp === 'f')$jgrp = 1;
		}else{
			$jval = 4;
			if($jgrp === 'f')$jgrp = 0;
		}
		$jimg = "16/cpu.png";
		$jtit = "$d CPU:".$dev[$d]['cpu']."%";
	}elseif($pos == "h"){
		if($dev[$d]['tmp'] > $tmpa){
			$jval = intval(($dev[$d]['tmp']-$tmpa)/2+5);
			if($jgrp === 'f')$jgrp = 2;
		}elseif($dev[$d]['tmp']){
			$jval = 4;
			if($jgrp === 'f')$jgrp = 1;
		}else{
			$jval = 1;
			if($jgrp === 'f')$jgrp = 0;
		}
		$jtit = "$d ".$dev[$d]['tlb'];
	}elseif($pos == "a"){
		if($dev[$d]['sta'] == 1){
			$jtit = "$d $stco[250]";
			$jval = 5;
			if($jgrp === 'f')$jgrp = 2;
		}elseif($dev[$d]['sta']){
			$jtit = "$d $stco[200]";
			$jval = intval(sqrt($dev[$d]['sta']))+3;
			if($jgrp === 'f')$jgrp = 1;
		}else{
			$jval = 2;
			$jtit = "$d $stco[100]";
			if($jgrp === 'f')$jgrp = 0;
		}
	}else{
		$jval = intval(sqrt($dev[$d]['siz'])*2)+1;
		$jtit = "$d ".(($dev[$d]['siz'])?$dev[$d]['siz'].'RU':'');
		if($jgrp === 'f')$jgrp = 0;
	}
	return "    {\"name\":\"$jtit\",\"img\":\"$jimg\",\"group\":$jgrp,\"value\":$jval},\n";
}

#===================================================================
# Draws nodes around device
function DrawNodes($dv){

	global $link,$fsz,$fco,$fmt,$len,$lsf,$in,$op,$st,$imas;
	global $dev,$nod,$nlnk,$mapframes,$mapitems,$imgmap,$cud,$jnod;

	include_once ('inc/libnod.php');

	if($in[0] == "vlanid" or $in[0] == "mac" or $in[0] == 'nodip' or $in[0] == 'aname' or $in[0] == 'oui'){
		$nres = DbQuery( $link,'nodes','s','aname,nodip,mac,oui,ifname,metric,iftype,speed,duplex,pvid,alias,dinoct,doutoct','ifname','',array('device',$in[0]),array('=',$op[0]),array($dv,$st[0]),array('AND'),'LEFT JOIN interfaces USING (device,ifname) LEFT JOIN nodarp USING (mac) LEFT JOIN dns USING (nodip)' );
	}else{
		$nres = DbQuery( $link,'nodes','s','aname,nodip,mac,oui,ifname,metric,iftype,speed,duplex,pvid,alias,dinoct,doutoct','ifname','',array('device'),array('='),array($dv),array(),'LEFT JOIN interfaces USING (device,ifname) LEFT JOIN nodarp USING (mac) LEFT JOIN dns USING (nodip) ' );
	}
	if($nres){
		$cun = 0;
		$nn  = DbNumRows($nres);
		while( ($n = DbFetchRow($nres)) ){
			$nod[$n[2]]['nam']  = $n[0];
			$nod[$n[2]]['ip'] = long2ip($n[1]).(($n[9])?" Vl$n[9]":"");
			$nod[$n[2]]['ico'] = VendorIcon($n[3]);
			list($nod[$n[2]]['x'],$nod[$n[2]]['y']) = CircleCoords($dev[$dv]['x'],$dev[$dv]['y'],$cun,$nn,2+($cun % 2),$len/pow($lsf/5,3),0,-1);
			$mapitems .= DrawItem($nod[$n[2]]['x'],$nod[$n[2]]['y'],'0',$n[2],'n');
			$imgmap   .= "<area href=\"Nodes-Status.php?st=$n[2]\" coords=\"".($nod[$n[2]]['x']-$imas) .",". ($nod[$n[2]]['y']-$imas) .",". ($nod[$n[2]]['x']+$imas) .",". ($nod[$n[2]]['y']+$imas)."\" shape=\"rect\" title=\"".$nod[$n[2]]['nam']." ".$nod[$n[2]]['ip']."\">\n";
			$m = substr($n[5],0,1);
			$nlnk["$dv;;$n[2]"]['fbw'] = $n[7];
			$nlnk["$dv;;$n[2]"]['rbw'] = $n[8];
			$nlnk["$dv;;$n[2]"]['ftr'] = $n[11];
			$nlnk["$dv;;$n[2]"]['rtr'] = $n[12];
			$nlnk["$dv;;$n[2]"]['ifal'][] = $n[10];
			$nlnk["$dv;;$n[2]"]['fif'][] = "$dv;;$n[4]";
			$nlnk["$dv;;$n[2]"]['rif'][] = (preg_match('/[M-Z]/',$m))?';;'.(3*(90-ord($m))).'db':'';# Draws SNR...
			if($fmt == "json") $cud++;
			$jnod["$dv;;$n[2]"] = $cud;
			$cun++;

		}
		DbFreeResult($nres);
	}else{
		echo DbError($link);
	}
}

#===================================================================
# Generate PNG icon text
function IconPng($x,$y,$i,$s){

	global $fmt,$pwt;

	if($i){
		if($fmt == "json"){
			$s = intval($s/15*$pwt);
			return "	{\"type\":\"icon\",\"height\":$s,\"width\":$s,\"style\":\"$i\"";
		}elseif($fmt == "svg"){
			return "<image x=\"".($x-$s/2)."\" y=\"".($y-$s/2)."\" width=\"$s\" height=\"$s\" xlink:href=\"../img/$i.png\"/>\n";
		}else{
			$icon = "\$icon = Imagecreatefrompng(\"img/$i.png\");\n";
			$icon .= "\$w = Imagesx(\$icon);\n";
			$icon .= "\$h = Imagesy(\$icon);\n";
			$icon .= "Imagecopy(\$image, \$icon,intval($x - \$w/2),intval($y - \$h/2),0,0,\$w,\$h);\n";
			$icon .= "Imagedestroy(\$icon);\n";
			return $icon;
		}
	}
}

#===================================================================
# Generate Jpeg icon text
function Panel($x,$y,$t,$s,$i,$z){

	global $fmt,$pos;

	$pnl = DevPanel($t,$i,$z);

	if($fmt == "json"){
		if($pos == "D"){
			$sc = 10;
		}elseif($pos == "p"){
			$sc = 20;
		}else{
			$sc = 80;
		}
		return "\t{\"type\":\"panel\",\"height\":".(($z)?$z*$sc:$sc).",\"width\":".(($z)?2*$sc:$sc).",\"style\":\"$pnl\"\n";
	}elseif($fmt == "svg"){
		$stk = "";
		if($s > 1){
			$stk = DrawLabel($x+55,$y,$s,2,"blue");
		}
		if($pos == "D"){
			$sc = 12;
		}elseif($pos == "p"){
			$sc = 50;
		}else{
			$sc = 100;
		}
		return "<image x=\"".($x-$sc)."\" y=\"".($y-$sc/2)."\" width=\"".($sc*2)."\" height=\"$sc\" xlink:href=\"$pnl\"/>$stk\n";
	}else{
		if($pos == "D"){
			$sc = 10;
		}elseif($pos == "p"){
			$sc = 5;
		}else{
			$sc = 2;
		}
		$icon = "\$icon = imagecreatefromjpeg(\"$pnl\");\n";
		$icon .= "\$w = Imagesx(\$icon);\n";
		$icon .= "\$h = Imagesy(\$icon);\n";
		if($s > 1 and strstr($t,'N5K-') ){# TODO add FEXs?
			$s = 1;
		}
		for ($c = 1; $c <= $s; $c++) {
			$icon .= "imagecopyresized(\$image, \$icon,intval($x-\$w/$sc), intval($y-$c*\$h/".($sc/2)."+($s*\$h/$sc) ),0,0,intval(\$w/".($sc/2)."),intval(\$h/".($sc/2)."+1),\$w,\$h );\n";
		}
		$icon .= "Imagedestroy(\$icon);\n";
		return $icon;
	}
}

#===================================================================
# Generate rectangular shape (and set $h to height for following labeloffset)
function IconRect($x,$y,$w,$h,$c){

	global $fmt,$pwt;

	if($fmt == "json"){
		$w = intval($w/16*$pwt);
		$h = intval($h/16*$pwt);
		return "	{\"type\":\"rect\",\"height\":".(2*$h).",\"width\":".(2*$w).",\"style\":\"$c\"";
	}elseif($fmt == "svg"){
		return "<rect fill=\"$c\" stroke=\"black\" x=\"".($x-$w)."\" y=\"".($y-$h)."\" width=\"".(2*$w)."\" height=\"".(2*$h)."\" />\n";
	}else{
		$icon = "Imagefilledrectangle(\$image, ".($x-$w).", ".($y-$h).", ".($x+$w).", ".($y+$h).", \$$c);\n";
		$icon .= "Imagerectangle(\$image, ".($x-$w).", ".($y-$h).", ".($x+$w).", ".($y+$h).", \"\$black\");\n";
		$icon .= "\$h = $h;";
		return $icon;
	}
}

#===================================================================
# Generate circular shape  (and set $h to height for following labeloffset)
function IconCircle($x,$y,$rx,$ry,$c){

	global $fmt,$pwt;

	if($fmt == "json"){
		$rx = intval($rx/16*$pwt);
		$ry = intval($ry/16*$pwt);
		return "	{\"type\":\"circle\",\"height\":$ry,\"width\":$rx,\"style\":\"$c\"";
	}elseif($fmt == "svg"){
		return "<ellipse  fill=\"$c\" stroke=\"black\" cx=\"$x\" cy=\"$y\" rx=\"$rx\" ry=\"$ry\"/>\n";
	}else{
		$icon = "Imagefilledellipse(\$image, $x, $y, ".(2*$rx).", ".(2*$ry).", \"\$$c\");\n";
		$icon .= "Imageellipse(\$image, $x, $y, ".(2*$rx).", ".(2*$ry).", \"\$black\");\n";
		$icon .= "\$h = $ry;";
		return $icon;
	}
}

#===================================================================
# Generate label text
function DrawLabel($x,$y,$t,$s,$c){

	global $fmt;

	if($fmt == "json") return;

	if($t != ""){
		$tl = substr($t,0,$_SESSION['lsiz']);
		$fs = ($s == 1)?10:(4*$s);
		$lx = intval($x-strlen($tl) * $fs/4);

		if($fmt == "svg"){
			return "<text x=\"$lx\" y=\"".($y+$fs)."\" font-size=\"$fs\" fill=\"$c\">$tl</text>\n";
		}else{
			return "ImageString(\$image, $s, $lx, $y, \"$tl\", \$$c);\n";
		}
	}

}

#===================================================================
# Generate the map.
function Map(){

	global $debug,$link,$locsep,$vallbl,$maplbl,$sumlbl,$lodlbl,$imas,$fmt,$lit,$fsz,$pos,$pwt,$fco;
	global $xm,$ym,$xo,$yo,$rot,$cro,$bro,$len,$lsf,$mde,$in,$op,$st,$co,$lev,$loo,$loa,$loi,$ipi,$ifa;
	global $mapbg,$mapitems,$maplinks,$mapinfo,$imgmap,$reg,$cty,$bld,$flr,$dev,$nod,$nlnk,$jnod,$cud;
	global $mapframes,$usxy,$nodprop,$ly;

	$rlnk = array();
	$clnk = array();
	$blnk = array();
	$dlnk = array();
	$usxy = array();

	$lyrn = explode(',',$ly);

	if( $in[1] == 'range' ){
		$r = is_numeric($st[1])?$st[1]:1;
		ReadDevs(array($in[0]),array($op[0]),array($st[0]),array(),-1);
		for($i=0;$i<$r;$i++){
			foreach( array_keys($dev) as $d){
				ReadDevs(array('neighbor',$in[2],$in[3]),array('=',$op[2],$op[3]),array($d,$st[2],$st[3]),array($co[1],$co[2]),$i);
			}
		}
	}elseif( $mde == 'l' ){
		if( $st[0] ) ReadDevs(array($in[0]),array($op[0]),array($st[0]),array(),0);
		if( $co[0] and $st[1] ) ReadDevs(array($in[1]),array($op[1]),array($st[1]),array(),1);
		if( $co[1] and $st[2] ) ReadDevs(array($in[2]),array($op[2]),array($st[2]),array(),2);
		if( $co[2] and $st[3] ) ReadDevs(array($in[3]),array($op[3]),array($st[3]),array(),3);
	}else{
		ReadDevs($in,$op,$st,$co);
	}

	# Precalculate Links after all selected devices/locations are defined
	if( $lit != 'n' ){
		foreach(array_keys($dev) as $d){							# Devs sorted by snmpversion creates links with stats first!
			if($dev[$d]['ver'] and ($ifa or $lit == 'l') ){					# Get IF alias
				$lres = DbQuery( $link,'links','s','id,device,ifname,neighbor,nbrifname,bandwidth,links.linktype,linkdesc,nbrduplex,nbrvlanid,time,iftype,alias,dinoct,doutoct','','',array('device'),array('='),array($d),array(),'LEFT JOIN interfaces USING (device,ifname)' );
			}else{
				$lres = DbQuery( $link,'links','s','*','','',array('device'),array('='),array($d) );
			}
			while( ($k = DbFetchRow($lres)) ){
				$n = $k[3];
				if($ifa) $dev[$d]['ifal'][$k[2]] = $k[12];
				if( isset($dev[$n]['reg']) ){						# Only create link if nbr exists as dev
					if($debug){echo "<div class=\"textpad txta half\">LINK:$d to $n with BW of $k[5] Traffic $k[13]/$k[14]</div>\n";}

					$ra = $dev[$d]['reg'];
					$rb = $dev[$n]['reg'];
					$ca = $dev[$d]['cty'];
					$cb = $dev[$n]['cty'];
					$ba = $dev[$d]['bld'];
					$bb = $dev[$n]['bld'];

					if( $lev > 3 ){
						if( isset($dlnk["$n;;$d"]) ){
							$dlnk["$n;;$d"]['rbw'] += $k[5];
							$dlnk["$n;;$d"]['rif'][] = "$d;;$k[2]";
							$dlnk["$n;;$d"]['rty']["$k[6]:".date('j.M',$k[10])]++;
						}else{
							$dlnk["$d;;$n"]['fbw'] += $k[5];
							$dlnk["$d;;$n"]['ftr'] += $k[14];
							$dlnk["$d;;$n"]['rtr'] += $k[13];
							$dlnk["$d;;$n"]['fif'][] = "$d;;$k[2]";
							$dlnk["$d;;$n"]['fty']["$k[6]:".date('j.M',$k[10])]++;
						}
						$dev[$d]['nlk']++;					# Count devlinks for flatmode
						if ($mde == "r") {# TODO find arrange method for building rings (only links within bld matter!)
							# fix error! if($ra == $rb and $ca == $cb and $ba == $bb) $flr[$ra][$ca][$ba][$d]['alk'][$n]++;
						}elseif($n != $d){					# Loops mess up 'alk'
							$dev[$d]['alk'][$n]++;				# Needed for arranging
						}
					}
					if($ra != $rb){
						$reg[$ra]['nlk']++;
						$reg[$ra]['alk'][$rb]++;				# Needed for arranging
						if( $lev == 1 ){
							if( isset($rlnk["$rb;;$ra"]) ){			# Reverse link exists?
								$rlnk["$rb;;$ra"]['rbw'] += $k[5];
								$rlnk["$rb;;$ra"]['rif'][] = "$d;;$k[2]";
								$rlnk["$rb;;$ra"]['rty']["$k[6]:".date('j.M',$k[10])]++;
							}else{
								$rlnk["$ra;;$rb"]['fbw']  += $k[5];
								$rlnk["$ra;;$rb"]['ftr']  += $k[14];
								$rlnk["$ra;;$rb"]['rtr']  += $k[13];
								$rlnk["$ra;;$rb"]['fif'][] = "$d;;$k[2]";
								$rlnk["$ra;;$rb"]['fty']["$k[6]:".date('j.M',$k[10])]++;
							}
						}
					}
					if("$ra;;$ca" != "$rb;;$cb"){
						$cty[$ra][$ca]['nlk']++;
						if($ra == $rb) $cty[$ra][$ca]['alk'][$cb]++;
						if( $lev == 2 ){
							if( isset($clnk["$rb;;$cb;;$ra;;$ca"]) ){
								$clnk["$rb;;$cb;;$ra;;$ca"]['rbw']  += $k[5];
								$clnk["$rb;;$cb;;$ra;;$ca"]['rif'][] = "$d;;$k[2]";
								$clnk["$rb;;$cb;;$ra;;$ca"]['rty']["$k[6]:".date('j.M',$k[10])]++;
							}else{
								$clnk["$ra;;$ca;;$rb;;$cb"]['fbw']  += $k[5];
								$clnk["$ra;;$ca;;$rb;;$cb"]['ftr']  += $k[14];
								$clnk["$ra;;$ca;;$rb;;$cb"]['rtr']  += $k[13];
								$clnk["$ra;;$ca;;$rb;;$cb"]['fif'][] = "$d;;$k[2]";
								$clnk["$ra;;$ca;;$rb;;$cb"]['fty']["$k[6]:".date('j.M',$k[10])]++;
							}
						}
					}
					if("$ra;;$ca;;$ba" != "$rb;;$cb;;$bb"){
						$bld[$ra][$ca][$ba]['nlk']++;
						if("$ra;;$ca" == "$rb;;$cb") $bld[$ra][$ca][$ba]['alk'][$bb]++;
						if( $lev == 3 ){
							if( isset($blnk["$rb;;$cb;;$bb;;$ra;;$ca;;$ba"]) ){
								$blnk["$rb;;$cb;;$bb;;$ra;;$ca;;$ba"]['rbw']  += $k[5];
								$blnk["$rb;;$cb;;$bb;;$ra;;$ca;;$ba"]['rif'][] = "$d;;$k[2]";
								$blnk["$rb;;$cb;;$bb;;$ra;;$ca;;$ba"]['rty']["$k[6]:".date('j.M',$k[10])]++;
							}else{
								$blnk["$ra;;$ca;;$ba;;$rb;;$cb;;$bb"]['fbw']  += $k[5];
								$blnk["$ra;;$ca;;$ba;;$rb;;$cb;;$bb"]['ftr']  += $k[14];
								$blnk["$ra;;$ca;;$ba;;$rb;;$cb;;$bb"]['rtr']  += $k[13];
								$blnk["$ra;;$ca;;$ba;;$rb;;$cb;;$bb"]['fif'][] = "$d;;$k[2]";
								$blnk["$ra;;$ca;;$ba;;$rb;;$cb;;$bb"]['fty']["$k[6]:".date('j.M',$k[10])]++;
							}
						}
					}
				}
			}
			DbFreeResult($lres);
		}
	}

# Draw Layout
	$cud = 0;
	$rk  = array_keys($reg);
	$nr  = count($rk);
	if($mde == "l"){
		$lrot[0] = $rot;
		$lrot[1] = $cro;
		$lrot[2] = $bro;
		$lrs = array_keys($flr);
		$cuy = intval(300/count($lrs)) + $yo;
		foreach( $lrs as $lr){
			$max = count($flr[$lr]);
			if ($max > $fco) $max = $fco;
			$cux = 0;
			$sty = $cuy;
			$spc = $fsz/(1+($lsf-1)*$lr);							# Compress length after Core layer
			foreach( $flr[$lr] as $dv){
				$jdev[$dv]  = $cud;
				if ($cux >= $fco){
					$cux = 0;
					$cuy += $len;
				}
				$dev[$dv]['x'] = $xm/2 + $xo + $lrot[$lr] + intval( ($cux - ($max-1)/2 ) * $spc );
				$dev[$dv]['y'] = $cuy + ($lr>1?$cux%2*$pwt:0);				# Access fanout with "Node Range"
				$mapitems .= DrawItem($dev[$dv]['x'],$dev[$dv]['y'],'0',$dv,'d',$dev[$dv]['sta']);
				$imgmap   .= "<area href=\"Devices-Status.php?dev=".urlencode($dv)."\" coords=\"".($dev[$dv]['x']-$imas) .",". ($dev[$dv]['y']-$imas) .",". ($dev[$dv]['x']+$imas) .",". ($dev[$dv]['y']+$imas)."\" shape=\"rect\" title=\"$dv ".$dev[$dv]['ip']." (".$dev[$dv]['typ'].") $lodlbl:".$dev[$dv]['cpu']."% ".$dev[$dv]['tlb']."\">\n";
				if( $lev == 6) DrawNodes($dv);
				if ($loi){
					$mapinfo .= DrawLabel($dev[$dv]['x'],$dev[$dv]['y']-40,Safelabel($dev[$dv]['cty']." ".$dev[$dv]['bld']),1,"cornflowerblue");
				}elseif ($debug){
					$mapinfo .= DrawLabel($dev[$dv]['x'],$dev[$dv]['y']-40,"Pos$cud",1,"cornflowerblue");
				}
				$cud++;
				$cux++;
			}
			if($fmt != "svg"){
				$mapframes .= "Imagefilledrectangle(\$image, 0, ".intval($sty-$len/2.1).", 20, ".intval($cuy+$len/2.1).", \$gainsboro);\n";
				$mapframes .= "Imagefilledrectangle(\$image, 20, ".intval($sty-$len/2.1).", $xm, ".intval($cuy+$len/2.1).", \$whitesmoke);\n";
				$mapframes .= "ImageStringup(\$image, ".intval($len/30).", 2, ".intval($cuy+$len/2.2).", \"$lyrn[$lr]\", \$gray);\n";
			}
			$cuy += $len;
		}
	}elseif($mde == "f"){
		$nd = count( array_keys($dev) );
		foreach(Arrange($dev) as $dv){
			$jdev[$dv]  = $cud;
			list($dev[$dv]['x'],$dev[$dv]['y']) = CircleCoords(intval($xm/2 + $xo),intval($ym/2 - $yo),$cud,$nd,($pwt>0)?$nodprop[$dv]['lvl']:($pwt*$dev[$dv]['nlk']),$len,$rot,$nodprop[$dv]['leafs']);
			$mapitems .= DrawItem($dev[$dv]['x'],$dev[$dv]['y'],'0',$dv,'d',$dev[$dv]['sta']);
			$imgmap   .= "<area href=\"Devices-Status.php?dev=".urlencode($dv)."\" coords=\"".($dev[$dv]['x']-$imas) .",". ($dev[$dv]['y']-$imas) .",". ($dev[$dv]['x']+$imas) .",". ($dev[$dv]['y']+$imas)."\" shape=\"rect\" title=\"$dv ".$dev[$dv]['ip']." (".$dev[$dv]['typ'].") $lodlbl:".$dev[$dv]['cpu']."% ".$dev[$dv]['tlb']."\">\n";
			if( $lev == 6) DrawNodes($dv);
			if ($loi){
				$mapinfo .= DrawLabel($dev[$dv]['x'],$dev[$dv]['y']-40,Safelabel($dev[$dv]['cty']." ".$dev[$dv]['bld']),1,"cornflowerblue");
			}elseif ($debug){
				$mapinfo .= DrawLabel($dev[$dv]['x'],$dev[$dv]['y']-40,"Pos$cud",1,"cornflowerblue");
			}
			$cud++;
		}
	}else{
		if ($mde == "g") {									# Prepare geographic stuff
			if( $nr == 1 ){
				$ck = array_keys($cty[$rk[0]]);
				if( count($ck) == 1 ){
					$mapbg = TopoMap($rk[0],$ck[0]);
				}else{
					$mapbg = TopoMap($rk[0]);
				}
			}else{
				$mapbg = TopoMap();
			}
			$bg = Imagecreatefromjpeg("topo/$mapbg");
			$xm = Imagesx($bg);
			$ym = Imagesy($bg);
			Imagedestroy($bg);
		}
		$cur = 0;
		$toc = 0;
		$tob = 0;
		foreach(Arrange($reg) as $r){
			if ($mde == "g") {
				list($reg[$r]['x'],$reg[$r]['y'],$reg[$r]['cmt']) = DbCoords($r);
			}
			if(!$reg[$r]['x']){
				list($reg[$r]['x'],$reg[$r]['y']) = CircleCoords(intval($xm/2 + $xo),intval($ym/2 - $yo),$cur,$nr,$nodprop[$r]['lvl'],$len,$rot,$nodprop[$r]['leafs']);
			}
			if( $lev == 1){
				$jreg[$r] = $cur;
				if( $reg[$r]['ndv'] == 1 and $reg[$r]['ico'] ){				# draw cloud
					$mapitems .= DrawItem($reg[$r]['x'],$reg[$r]['y'],$reg[$r]['ico'],$r,'cl',$reg[$r]['sta']);
				}else{
					$mapitems .= DrawItem($reg[$r]['x'],$reg[$r]['y'],$reg[$r]['ndv'],$r,1,$reg[$r]['sta']);
					$imgmap   .= "<area href=\"?lev=2&mde=$mde&pos=$pos&fmt=png&loo=$loo&loa=$loa&st[]=". urlencode( "$r$locsep%" ) ."\" coords=\"".($reg[$r]['x']-$imas) .",". ($reg[$r]['y']-$imas) .",". ($reg[$r]['x']+$imas) .",". ($reg[$r]['y']+$imas)."\" shape=\"rect\" title=\"$r $maplbl\">\n";
				}
			}else{
				if ($loi){
					if(count($cty[$r]) > 1){
						$mapinfo .= DrawItem($reg[$r]['x'],$reg[$r]['y'],'0',$r." ".$reg[$r]['cmt'],'ri');
					}else{
						$mapinfo .= DrawLabel($reg[$r]['x'],$reg[$r]['y']-42,Safelabel($r),1,"cornflowerblue");
					}
				}
				$cuc = 0;
				$nc  = count( array_keys($cty[$r]) );
				foreach(Arrange($cty[$r]) as $c){
					if ($mde == "g") {
						list($cty[$r][$c]['x'],$cty[$r][$c]['y'],$cty[$r][$c]['cmt']) = DbCoords($r,$c);
					}
					if(!$cty[$r][$c]['x']){
						list($cty[$r][$c]['x'],$cty[$r][$c]['y']) = CircleCoords($reg[$r]['x'],$reg[$r]['y'],$cuc,$nc,$nodprop[$c]['lvl'],$len*10/$lsf,$cro,$nodprop[$c]['leafs']);
					}
					if( $lev == 2){
						$jcty["$r;;$c"] = $toc;
						if( $cty[$r][$c]['ndv'] == 1 and $cty[$r][$c]['ico'] ){	# draw cloud
							$mapitems .= DrawItem($cty[$r][$c]['x'],$cty[$r][$c]['y'],$cty[$r][$c]['ico'],$c,'cl',$cty[$r][$c]['sta']);
						}else{
							$mapitems .= DrawItem($cty[$r][$c]['x'],$cty[$r][$c]['y'],$cty[$r][$c]['ndv'],$c,2,$cty[$r][$c]['sta']);
							$imgmap   .= "<area href=\"?lev=3&mde=$mde&pos=$pos&fmt=png&loo=$loo&loa=$loa&st[]=". urlencode( "$r$locsep$c$locsep%" ) ."\" coords=\"".($cty[$r][$c]['x']-$imas) .",". ($cty[$r][$c]['y']-$imas) .",". ($cty[$r][$c]['x']+$imas) .",". ($cty[$r][$c]['y']+$imas)."\" shape=\"rect\" title=\"$c $maplbl\">\n";
						}
					}else{
						if ($loi){
							if(count($bld[$r][$c]) > 1){
								$mapinfo .= DrawItem($cty[$r][$c]['x'],$cty[$r][$c]['y'],'0',$c." ".$cty[$r][$c]['cmt'],'ci');
							}else{
								$mapinfo .= DrawLabel($cty[$r][$c]['x']+8,$cty[$r][$c]['y']-30,Safelabel($c),1,"cornflowerblue");
							}
						}
						$cub = 0;
						$nb  = count( array_keys($bld[$r][$c]) );
						foreach(Arrange($bld[$r][$c]) as $b){
							if ($mde == "g") {
								list($bld[$r][$c][$b]['x'],$bld[$r][$c][$b]['y'],$bld[$r][$c][$b]['cmt']) = DbCoords($r,$c,$b);
							}
							if(!$bld[$r][$c][$b]['x']){
								list($bld[$r][$c][$b]['x'],$bld[$r][$c][$b]['y']) = CircleCoords($cty[$r][$c]['x'],$cty[$r][$c]['y'],$cub,$nb,$nodprop[$b]['lvl'],$len/pow($lsf/5,2),$bro,$nodprop[$b]['leafs']);
							}
							if($lev == 3){
								$jbld["$r;;$c;;$b"] = $tob;
								if( $bld[$r][$c][$b]['ndv'] == 1 and $bld[$r][$c][$b]['ico'] ){	# draw cloud
									$mapitems .= DrawItem($bld[$r][$c][$b]['x'],$bld[$r][$c][$b]['y'],$bld[$r][$c][$b]['ico'],$c,'cl',$bld[$r][$c][$b]['sta']);
								}else{
									$mapitems .= DrawItem($bld[$r][$c][$b]['x'],$bld[$r][$c][$b]['y'],$bld[$r][$c][$b]['ndv'],$b,3,$bld[$r][$c][$b]['sta']);
									$imgmap   .= "<area href=\"?lev=4&mde=$mde&pos=$pos&fmt=png&loo=$loo&loa=$loa&st[]=". urlencode( "$r$locsep$c$locsep$b$locsep%" ) ."\" coords=\"".($bld[$r][$c][$b]['x']-$imas) .",". ($bld[$r][$c][$b]['y']-$imas) .",". ($bld[$r][$c][$b]['x']+$imas) .",". ($bld[$r][$c][$b]['y']+$imas)."\" shape=\"rect\" title=\"$b $maplbl\">\n";
								}
							}elseif ($mde == "b" or $mde == "g"){
								DrawBuilding($bld[$r][$c][$b]['x'],$bld[$r][$c][$b]['y'],$r,$c,$b);
							}else{
								if ($loi){
									if(count($flr[$r][$c][$b]) > 1){
										$mapinfo .= DrawItem($bld[$r][$c][$b]['x'],$bld[$r][$c][$b]['y'],'0',$b." ".$bld[$r][$c][$b]['cmt'],'bi');
									}else{
										$mapinfo .= DrawLabel($bld[$r][$c][$b]['x'],$bld[$r][$c][$b]['y']-30,Safelabel($b),1,"cornflowerblue");
									}
								}
								$cd = 0;
								$nd = count( array_keys($flr[$r][$c][$b]) );

								foreach(Arrange($flr[$r][$c][$b]) as $d){
									$jdev[$d] = $cud;
									list($dev[$d]['x'],$dev[$d]['y']) = CircleCoords($bld[$r][$c][$b]['x'],$bld[$r][$c][$b]['y'],$cd,$nd,$nodprop[$d]['lvl'],$fsz,$bro,$nodprop[$d]['leafs']);
									$mapitems .= DrawItem($dev[$d]['x'],$dev[$d]['y'],'0',$d,'d',$dev[$dv]['sta']);
									$imgmap   .= "<area href=\"Devices-Status.php?dev=".urlencode($d)."\" coords=\"".($dev[$d]['x']-$imas) .",". ($dev[$d]['y']-$imas) .",". ($dev[$d]['x']+$imas) .",". ($dev[$d]['y']+$imas)."\" shape=\"rect\" title=\"$dv ".$dev[$d]['ip']." CPU:".$dev[$d]['cpu']."%  T:".$dev[$d]['tmp']."C\">\n";
									if( $lev == 6){DrawNodes($d);}
									$cd++;
									$cud++;
								}
							}
							$cub++;
							$tob++;
						}
					}
					$cuc++;
					$toc++;
				}
			}
			$cur++;
		}
	}

# Draw Links
	if($lev == 1){
		$rlkeys = array_keys($rlnk);
		foreach($rlkeys as $li){
			$l = explode(';;', $li);
			if($fmt == "json"){
				list($lw,$cf,$futl)  = LinkStyle( $rlnk[$li]['fbw'],$rlnk[$li]['ftr'] );
				$maplinks .= "    {\"source\":".$jreg[$l[0]].",\"target\":".$jreg[$l[1]].",\"width\":$lw,\"color\":\"$cf\"},\n";
			}else{
				DrawLink($reg[$l[0]]['x'],
					$reg[$l[0]]['y'],
					$reg[$l[1]]['x'],
					$reg[$l[1]]['y'],
					$rlnk[$li]);
			}
		}
	}elseif($lev == 2){
		foreach(array_keys($clnk) as $li){
			$l = explode(';;', $li);
			if($fmt == "json"){
				list($lw,$cf,$futl)  = LinkStyle( $clnk[$li]['fbw'],$clnk[$li]['ftr'] );
				$maplinks .= "    {\"source\":".$jcty["$l[0];;$l[1]"].",\"target\":".$jcty["$l[2];;$l[3]"].",\"width\":$lw,\"color\":\"$cf\"},\n";
			}else{
				DrawLink($cty[$l[0]][$l[1]]['x'],
					$cty[$l[0]][$l[1]]['y'],
					$cty[$l[2]][$l[3]]['x'],
					$cty[$l[2]][$l[3]]['y'],
					$clnk[$li]);
			}
		}
	}elseif($lev == 3){
		foreach(array_keys($blnk) as $li){
			$l = explode(';;', $li);
			if($fmt == "json"){
				list($lw,$cf,$futl)  = LinkStyle( $blnk[$li]['fbw'],$blnk[$li]['ftr'] );
				$maplinks .= "    {\"source\":".$jbld["$l[0];;$l[1];;$l[2]"].",\"target\":".$jbld["$l[3];;$l[4];;$l[5]"].",\"width\":$lw,\"color\":\"$cf\"},\n";
			}else{
				DrawLink($bld[$l[0]][$l[1]][$l[2]]['x'],
					$bld[$l[0]][$l[1]][$l[2]]['y'],
					$bld[$l[3]][$l[4]][$l[5]]['x'],
					$bld[$l[3]][$l[4]][$l[5]]['y'],
					$blnk[$li]);
			}
		}
	}elseif($lev > 3){
		foreach(array_keys($dlnk) as $li){
			$l = explode(';;', $li);
			if($fmt == "json"){
				list($lw,$cf,$futl)  = LinkStyle( $dlnk[$li]['fbw'],$dlnk[$li]['ftr'] );
				$maplinks .= "    {\"source\":".$jdev[$l[0]].",\"target\":".$jdev[$l[1]].",\"width\":$lw,\"color\":\"$cf\"},\n";
			}else{
				DrawLink($dev[$l[0]]['x'],
					$dev[$l[0]]['y'],
					$dev[$l[1]]['x'],
					$dev[$l[1]]['y'],
					$dlnk[$li]);
			}
		}
		if($lev == 6){
			foreach(array_keys($nlnk) as $li){
				$l = explode(';;', $li);
				if($fmt == "json"){
					list($lw,$cf,$futl)  = LinkStyle( $nlnk[$li]['fbw'],$nlnk[$li]['ftr'] );
					$maplinks .= "    {\"source\":".$jdev[$l[0]].",\"target\":".$jnod["$l[0];;$l[1]"].",\"width\":$lw,\"color\":\"$cf\"},\n";
				}else{
					DrawLink($dev[$l[0]]['x'],
						$dev[$l[0]]['y'],
						$nod[$l[1]]['x'],
						$nod[$l[1]]['y'],
						$nlnk[$li]);
				}
			}
		}
	}
}

#===================================================================
# Read devices from DB
function ReadDevs($in,$op,$st,$co,$ord=0){

	global $debug,$link,$locsep,$vallbl,$maplbl,$sumlbl,$lodlbl,$imas,$fmt,$lit,$fsz,$pos,$pwt;
	global $xm,$ym,$xo,$yo,$rot,$cro,$bro,$len,$lsf,$mde,$lev,$loo,$loa,$loi,$ipi,$ifa;
	global $reg,$cty,$bld,$flr,$dev,$nod,$nlnk,$jnod,$cud;

	$mcol = '';
	$join = '';
	if( $pos == 'a' or $pos == 'A' or $pos == 'l' or $pos == 'L' ){
		$mcol = ',test,status,latency,latwarn';
		$join .= 'LEFT JOIN monitoring USING (device) ';
	}
	if( in_array('vlanid', $in) or in_array('vlanname', $in) ) $join .= 'LEFT JOIN vlans USING (device) ';
	if( in_array('ifip', $in) or in_array('vrfname', $in) )	$join .= 'LEFT JOIN networks USING (device) ';
	if( in_array('neighbor', $in) )	$join .= 'LEFT JOIN links USING (device) ';
	if( in_array('mac', $in) or in_array('oui', $in) or in_array('nodip', $in) or in_array('aname', $in) ) $join .= 'LEFT JOIN nodes USING (device) LEFT JOIN nodarp USING (mac) LEFT JOIN dns USING (nodip)';

	$res = DbQuery( $link,'devices','s',"distinct device,devip,type,location,contact,devmode,icon,cpu,temp,devopts,size,stack,snmpversion$mcol",'snmpversion desc','',$in,$op,$st,$co,$join );
	while( ($d = DbFetchRow($res)) ){
		if( !isset($dev[$d[0]]) ){								# Muuuuuuch faster than array_key_exists!
			$l = explode($locsep, $d[3]);
			$reg[$l[0]]['ndv']++;
			$reg[$l[0]]['nlk'] = 0;
			if( $d[2] == 'gen-cloud') $reg[$l[0]]['ico'] = $d[6];
			if( is_numeric($d[14]) ){
				if( $pos == 'l' or $pos == 'L' ){
					$reg[$l[0]]['sta'] += $d[15]>$d[16]?1:0;
				}else{
					$reg[$l[0]]['sta'] += $d[14]?1:0;
				}
			}
			$dev[$d[0]]['ord'] = $ord;
			$dev[$d[0]]['ver'] = $d[12];
			$dev[$d[0]]['reg'] = $l[0];
			if($d[12] and $ipi){								# Get IP info for interfaces on snmpdevs
				$nres = DbQuery( $link,'networks','s','ifname,ifip,ifip6,vrfname','','',array('device'),array('='),array($d[0]) );
				if($nres){
					while( ($n = DbFetchRow($nres)) ){
						if($n[1]){
							$dev[$d[0]]['ifip'][$n[0]] .= " ". long2ip($n[1]).(($n[3])?" ($n[3])":"");
						}else{
							$dev[$d[0]]['ifip'][$n[0]] .= " ". DbIPv6($n[2]).(($n[3])?" ($n[3])":"");
						}
					}
				}else{
					echo DbError($link);
				}
				DbFreeResult($nres);
			}
			if($lev > 1){
				$dev[$d[0]]['cty'] = $l[1];
				$cty[$l[0]][$l[1]]['ndv']++;
				$cty[$l[0]][$l[1]]['nlk'] = 0;
				if( $d[2] == 'gen-cloud') $cty[$l[0]][$l[1]]['ico'] = $d[6];
				if( is_numeric($d[14]) ){
					if( $pos == 'l' or $pos == 'L' ){
						$cty[$l[0]][$l[1]]['sta'] += $d[15]>$d[16]?1:0;
					}else{
						$cty[$l[0]][$l[1]]['sta'] += $d[14]?1:0;
					}
				}
			}
			if($lev > 2){
				$dev[$d[0]]['bld'] = $l[2];
				$bld[$l[0]][$l[1]][$l[2]]['ndv']++;
				$bld[$l[0]][$l[1]][$l[2]]['nlk'] = 0;
				if( $d[2] == 'gen-cloud') $bld[$l[0]][$l[1]][$l[2]]['ico'] = $d[6];
				if( is_numeric($d[14]) ){
					if( $pos == 'l' or $pos == 'L' ){
						$bld[$l[0]][$l[1]][$l[2]]['sta'] += $d[15]>$d[16]?1:0;
					}else{
						$bld[$l[0]][$l[1]][$l[2]]['sta'] += $d[14]?1:0;
					}
				}
			}
			if($lev > 3){
				if ($mde == "r") {
					$flr[$l[0]][$l[1]][$l[2]][$d[0]] = 1;				# devs in ring mode
				}elseif ($mde == "l") {
					$flr[$ord][] = $d[0];						# Current layer treated as floor
				}else{
					$flr[$l[0]][$l[1]][$l[2]][$l[3]][] = $d[0];
				}
				$dev[$d[0]]['ip']  = $d[1]?long2ip($d[1]):'';
				$dev[$d[0]]['rom'] = $l[4];
				$dev[$d[0]]['rak'] = ($l[5])?$l[5]:'';
				$dev[$d[0]]['typ'] = $d[2];
				$dev[$d[0]]['con'] = $d[4];
				$dev[$d[0]]['mod'] = Devmode($d[5]);
				$dev[$d[0]]['ico'] = $d[6];
				if( substr($d[9],1,1) == "C" ){
					$dev[$d[0]]['cpu'] = $d[7];
				}else{
					$dev[$d[0]]['cpu'] = "-";
				}
				$dev[$d[0]]['tmp'] = $d[8];
				if($d[8] != 0){
					$dev[$d[0]]['tlb'] = ($_SESSION['far'])?intval($dev[$d[0]]['tmp']*1.8+32)."F":$dev[$d[0]]['tmp']."C";
				}else{
					$dev[$d[0]]['tlb'] = "-";
				}
				$dev[$d[0]]['stk'] = ($d[11] > 1)?$d[11]:1;
				$dev[$d[0]]['siz'] = $d[10] * $dev[$d[0]]['stk'];
				$dev[$d[0]]['nlk'] = 0;
				if( is_numeric($d[14]) ){
					if( $d[13] == 'none' ){
						$dev[$d[0]]['sta'] = -1;
					}elseif( $pos == 'l' or $pos == 'L' ){
						$dev[$d[0]]['sta'] = $d[15]>$d[16]?$d[15]:0;
					}else{
						$dev[$d[0]]['sta'] = $d[14];
					}
				}
			}
		}
	}
	DbFreeResult($res);
}

#===================================================================
# Calculate circular coordinates, opt is used to center hubs and
# keep single nodes away from center when negative
function CircleCoords($xm,$ym,$curp,$nump,$lvl,$l,$r,$opt){

	global  $debug,$pwt,$usxy;

	if($nump == 1 and $opt != -1){
		$l = 0;
	}
	if($opt == -1) $opt = 0;


	if( $nump < 5 or $pwt == 0 ){
		$len = $l;
		$opt = 0;
	}elseif( $lvl > 0 ){
		$len = $lvl/2 * $l + ($curp % 3)*$pwt;
	}elseif( $lvl == 0 ){										# Hub
		$len = ($nump - $curp)*$l/10;
	}else{												# Isolated
		$len =  10*$l/( 10 + abs($lvl) );
	}

	$phi = $r * 0.0174533 + 2 * intval($curp + $opt/2) * M_PI / $nump;
	$x = intval($xm + cos($phi) * 1.3 * $len);
	$y = intval($ym + sin($phi) * $len);

	if($debug){echo "<div class=\"textpad code noti half\">Circle: $xm,$ym,$curp,$nump,$lvl,$l,$r,$opt = $x,$y</div>\n";}

	while( isset($usxy["$x;$y"]) ){$x+=8;$y+=8;}							# avoid using same coords twice
	$usxy["$x;$y"] = 1;

	return array($x,$y);
}

#===================================================================
# Lookup coordinates and return if map matches
function DbCoords($r='', $c='', $b=''){

	global $mapbg,$link;

	$res  = DbQuery( $link,'locations','s','x,y,locdesc','','',array('region','city','building'),array('=','=','='),array($r,$c,$b),array('AND','AND') );
	$nloc = DbNumRows($res);
	if(!$c){$r="";}elseif(!$b){$c="";}								# Clear those for Topomap()
	if ($nloc == 1 and $mapbg == TopoMap($r,$c) ) {
		return DbFetchRow($res);
	}
}

#===================================================================
# Arrange locations according to links
function Arrange($circle){

	global $debug,$fmt,$arranged,$nodprop;

	$nodetree = array();
	$arranged = array();
	$nodprop  = array();

	if($fmt == "json") return array_keys($circle);

	if($debug){echo "<div class=\"textpad code pre txta tqrt\"><h3>ARRANGE</h3>\n";}

	$iter = 0;
	do{
		$nadd = 0;
		foreach(array_keys($circle) as $node){
			if($debug) echo "$node<br>";
			if( is_array($circle[$node]['alk']) ){
				$nbr = array_keys($circle[$node]['alk']);
				if (count($nbr) == 1 ){							# 1 neighbor, node is a leaf!
					$nodetree[$nbr[0]][$node]++;					# Add node to upstream nbr
					if( isset($nodetree[$node]) ){					# Did we add this node as an upstream nbr before?
						$nodetree[$nbr[0]][$node] = $nodetree[$node];		# Move branch here...
						unset($nodetree[$node]);				# ...and delete from "trunk"
					}
					if($debug) echo "LEAF:$node -> $nbr[0]<br>";
					unset($circle[$node]);						# Remove node from next iteration
					unset($circle[$nbr[0]]['alk'][$node]);				# Remove node from nbr's list
					$nadd++;
					#break;
				}else{
					if($debug) echo "Several nbr on $node<br>";
				}
			}else{
				$arranged[$node] = 1;							# hash to avoid duplicates (PHP keeps order)
				$nodprop[$node]['lvl'] = -1;
				unset($circle[$node]);							# Remove isolated node from loop
				if($debug) echo "Isolated node $node<br>";
			}
		}
		$iter++;
	}while($nadd);											# Iterate while nodes were added

	if($debug) print_r($nodetree);

	Fanout($nodetree,2);
	$cur = 0;

	foreach(array_keys($circle) as $node){								# Place remaining nodes
		if( !isset($nodetree[$node]) ){
			$arranged[$node] = 1;
			$nodprop[$node]['lvl'] = 0;
		}
	}
	if($debug) print_r($nodprop);
	if($debug) print_r($arranged);
	if($debug) echo "Required $iter Iterations</div>";

	return array_keys($arranged);
}

#===================================================================
# Return flat array from tree structure
function Fanout($tree,$lvl){

	global $arranged,$nodprop;

	foreach(array_keys($tree) as $node){				# Turn tree into arranged circle
		$arranged[$node] = 1;
		$nodprop[$node]['lvl'] = $lvl;
		if( is_array($tree[$node]) ){
			$nodprop[$node]['leafs'] = count( $tree[$node],COUNT_RECURSIVE  );
			Fanout($tree[$node],$lvl+1);
		}else{
			$nodprop[$node]['leafs'] = 0;
		}
	}
}

#===================================================================
# Return shorter distance between 2 nodes
function Dist($a, $b,$s){

	$d1 = abs($a - $b);
	$d2 = $s - $d1;

	return ($d1 < $d2)?$d1:$d2;
}

#===================================================================
# Sort by room and #device links within floor
function Roomsort($a, $b){

	global $dev,$debug;

	if ($dev[$a]['rom'] == $dev[$b]['rom']){
		if($debug){echo $dev[$a]['nlk']." == ".$dev[$b]['nlk']." linksort $a,$b<br>";}
		if ($dev[$a]['nlk'] == $dev[$b]['nlk']) return 0;
		return ($dev[$a]['nlk'] > $dev[$b]['nlk']) ? -1 : 1;
	}
        return ($dev[$a]['rom'] < $dev[$b]['rom']) ? -1 : 1;
}

#===================================================================
# Return status based properties

function ShapeStatus($s,$r=0,$n=0){

	global $pos,$stco,$slolbl,$nonlbl,$tstlbl;

	if($pos == 'l' or $pos == 'L'){
		$l = $n?"$s ms":$slolbl;
		
	}else{
		$l = $stco[200];
	}

	if( !isset($s) ){
		return array('gray','',intval($r/2));
	}elseif( $s == 0 ){
		return array('green','OK',$r);
	}elseif($n){
		if($s == -1){
			return array('blue',"$nonlbl $tstlbl",$r*2);
		}else{
			return array('red',$l,$r*2);
		}
	}elseif($s == 1){
		return array('orange',"$s $l",$r*2);
	}elseif($s < 10){
		return array('red',"$s $l",$r*2);
	}else{
		return array('purple',"$s $l",$r*2);
	}
}

?>
