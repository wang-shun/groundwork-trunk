NeDi - 1.6.100
==============

Introduction
------------
NeDi discovers, maps and inventories your network devices and tracks connected end-nodes.
It contains a lot of features in a user-friendly GUI for managing enterprise networks.
For example: MAC address mapping/tracking, traffic & error graphing, uptime monitoring,
correlate collected syslog & trap messages with customizable notification, drawing
network maps, extensive reporting features such as device software, PoE usage, disabled
interfaces, link errors, switch usage and many more. It's modular architecture allows for
simple integration with other tools. For example Cacti graphs can be created purely based
on discovered information. Due to NeDi's versatility things like printer resources can be
monitored as well...

Changes from 1.5.225
--------------------
"under-the-hood" Enhancements:
- Changed seedlist format to match agentlist allowing for location and contact mappings
- Added "Connection Before" policy to detect specific link changes
- Added config backup via ftp (e.g. for Zyxel devices)
- Added support for Panasonic KX-NT550 series VoIP phones
- Added population threshold policy, to alert if mac address table gets too big
- Added 2nd retire option for links
- Added -R option for retrying SNMP read access
- Added option to use regex no mapna (to replace or cut off unwanted parts of the name)
- Removed old code for Mysql-5.0 support
- Removed some inherited values on NoSNMP devices for use with customer specific scripts (e.g. contact and sysobjid)
- Improved ESX version and VM retrieval
- Improved total node RRD to factor in parallel discoveries
- nedi.pl -A joins on configs for more specific backups (e.g. match on last backup or short configs: length(config) < 500)
- Nodes with a description set will not be retired automatically

GUI Enhancements:
- Added nfdump integration and whois lookup of external IPs
- New policies for flows and # of MAC addresses on switches
- Added API key support for Openweathermap
- Added dashboard editor in Monitoring-Map
- Rackview support for partitioned devices (VDC,MDC) and device types with spaces (e.g. servers)
- Realtime display of an OID in Devices-List
- Removed obsolete mysql functions in favor of mysqli and refactored backend functions
- Removed "show log" in Devices-Status (use CLI-send instead)
- Improved Location-Editor's workflow, (e.g. if geocordinates aren't found)
- Improved Monitoring-Incidents with that it can be used as a NOC dashboard
- Redesigned Timeframe input for various modules
- Added timer and feature to hide input form by clicking on title to Monitoring-Incidents and Monitoring-Events
- RRDs now display client time on x-axis, if different from server and use -r option for better scaling
- Icon based links to other modules are only shown, if the user is authorized for using them
- Deleting a device that exists in inventory changes status to inactive (applies to its modules as well)
- Replaced the Crystal icons be those from http://www.fatcow.com/free-icons
- Many smaller bug fixes and optimizations

Topology-Map Specific:
- Added range option and "layer" mode
- Added drag & zoom to D3js maps
- Maps can be added to Monitoring-Map or tracked (to generate animation from image sequence)
- Improved RRD support and performance (large maps in particular)

DB Changes
----------
Updating the DB is very easy with mysql:
- "nedi.pl -i updatedb" updates the DB from 1.5.225

CONSIDER DELETING html/test from older versions, to get rid of some security issues!
