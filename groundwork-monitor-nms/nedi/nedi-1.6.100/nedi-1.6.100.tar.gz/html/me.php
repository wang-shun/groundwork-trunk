<?php
# Program: me.php (Locate me IP)
# Programmer: Remo Rickli

error_reporting(E_ALL ^ E_NOTICE);

$refresh  = 60;
$anim     = ',animation: false';
$nedipath = preg_replace( "/^(\/.+)\/html\/.+.php/","$1",$_SERVER['SCRIPT_FILENAME']);			# Guess NeDi path for nedi.conf

$_SESSION['gsiz'] = 6;
$_SESSION['lsiz'] = 8;
$_SESSION['view'] = "";
$_SESSION['timf'] = 'j.M y G:i';
$_SESSION['tz'] = "GMT";

require_once ("inc/libmisc.php");
ReadConf();
include_once ("languages/english/gui.php");
include_once ("inc/libdb-" . strtolower($backend) . ".php");
include_once ("inc/libdev.php");
include_once ("inc/libnod.php");

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN">
<html>

<head>
	<title>NeDi Find Me</title>
	<meta http-equiv="Content-Type" content="text/html;charset=iso-8859-1">
	<link href="inc/print.css" type="text/css" rel="stylesheet">
	<link rel="shortcut icon" href="img/favicon.ico">
</head>

<body>
<script src="inc/Chart.min.js"></script>

<?php
$link = DbConnect($dbhost,$dbuser,$dbpass,$dbname);
$res  = DbQuery( $link,'nodes','s','nodes.*,location,speed,duplex,pvid,dinoct,doutoct,dinerr,douterr,dindis,doutdis,dinbrc,nodip,aname','lastseen desc','1',array('nodip'),array('='),array( ip2long($_SERVER[REMOTE_ADDR]) ),array(),'LEFT JOIN devices USING (device) LEFT JOIN nodarp USING (mac) LEFT JOIN dns USING (nodip) LEFT JOIN interfaces USING (device,ifname)' );
if($res){
	$n = DbFetchRow($res);
	if($n[2]){
		$img = VendorIcon($n[1]);
		$l   = explode($locsep,$n[12]);
		echo "<table class=\"content\">";
		echo "<tr class=\"bgmain\"><td class=\"imga ctr xs\"><img src=\"img/oui/$img.png\" title=\"$n[1]\"></td><td><strong>$n[24]</strong></td><td class=\"mrn code\">$n[0]</td></tr>\n";
		echo "<tr class=\"txtb\"><td class=\"imgb ctr\"><img src=\"img/16/net.png\" title=\"Network\"></td><td class=\"blu code\">".long2ip($n[23])."</td><td title=\"$laslbl\">".date($_SESSION['timf'],$n[3])."</td></tr>\n";
		echo "<tr class=\"txta\"><td class=\"imga ctr\"><img src=\"img/16/dev.png\" title=\"Device\"></td><td>$n[4]</td><td>$l[2] $l[3]</td></tr>\n";
		echo "<tr class=\"txtb\"><td class=\"imgb ctr\"><img src=\"img/16/port.png\" title=\"Port\"></td><td>$n[5]</td><td>".DecFix($n[13])."-$n[14] vl$n[6]</td></tr>\n";
		echo "<tr class=\"txta\"><td class=\"imga ctr\"><img src=\"img/16/grph.png\" title=\"In/Out\"></td><td class=\"ctr\" colspan=\"2\">\n";
		MetricChart("met",4, $n[7]);
		IfRadar('radlast',4,'284',$n[16],$n[17],$n[18],$n[19],$n[20],$n[21],$n[22]);
		echo "</td></tr>\n";
		echo "</table>";
	}else{
		echo "<h4>$_SERVER[REMOTE_ADDR] was not found</h4>";
	}
	DbFreeResult($res);
}else{
	print DbError($link);
}
?>

</body>
