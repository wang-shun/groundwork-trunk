#!/usr/bin/perl

#use Net::SNMP qw(snmp_dispatcher oid_lex_sort);
#use Net::SNMP v5.1.0 qw(snmp_type_ntop DEBUG_ALL);
use Net::SNMP;

my $finished = 0;
my $host = '10.10.10.4';
my $community;
my @communityNames = ( 'test', 'public', 'giodcs', 'nograss' );

#The MIB2 sysinfo oids
my @oids = (
	".1.3.6.1.2.1.1.1.0", ".1.3.6.1.2.1.1.2.0",
	".1.3.6.1.2.1.1.3.0", ".1.3.6.1.2.1.1.4.0",
	".1.3.6.1.2.1.1.5.0", ".1.3.6.1.2.1.1.6.0",
	".1.3.6.1.2.1.1.7.0", ".1.3.6.1.2.1.2.1.0"
	);

my $i = 0;
my $count = @communityNames;
do {
	#printf("Host - %s %s\n", $host, $communityNames[$i]);
	#Try to estalish a session
	($session, $error) = Net::SNMP->session(
	   -hostname  => $host,
	   -community => $communityNames[$i],
	   -port      => '161',
	   -timeout   => '1',
	   -version   => 'snmpv2c'
	);

	if (defined($session)){
		$community = $communityNames[$i];

		print "GET $community: ";
		if (defined($session->get_request(Varbindlist => \@oids))){
			#Put the sysinfo into variables
			$sysDescr =	$session->var_bind_list()->{$oids[0]};
			$sysOid =	$session->var_bind_list()->{$oids[1]};
			$sysUptime =	$session->var_bind_list()->{$oids[2]};
			$sysContact =	$session->var_bind_list()->{$oids[3]};
			$sysName = 	$session->var_bind_list()->{$oids[4]};
			$sysLocation =	$session->var_bind_list()->{$oids[5]};
			$ifCount =	$session->var_bind_list()->{$oids[7]};

			print " $sysUptime $sysDescr $sysOid\n";
		}else{
			$error = 'no response';
		}
		$session->close;
	}
} while (($error) && (++$i < $count));
