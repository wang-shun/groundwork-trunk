<?php
# Program: Devices-List.php
# Programmer: Remo Rickli

$exportxls = 1;

snmp_set_quick_print(1);
snmp_set_oid_numeric_print(1);
snmp_set_valueretrieval(SNMP_VALUE_LIBRARY);

include_once ("inc/header.php");
include_once ("inc/libdev.php");
include_once ("inc/libsnmp.php");

$_GET = sanitize($_GET);
$in = isset($_GET['in']) ? $_GET['in'] : array();
$op = isset($_GET['op']) ? $_GET['op'] : array();
$st = isset($_GET['st']) ? $_GET['st'] : array();
$co = isset($_GET['co']) ? $_GET['co'] : array();

$ord = isset($_GET['ord']) ? $_GET['ord'] : '';
if($_SESSION['opt'] and !$ord and count($in)) $ord = $in[0];

$map = isset($_GET['map']) ? "checked" : "";
$lim = isset($_GET['lim']) ? preg_replace('/\D+/','',$_GET['lim']) : $listlim;
$get = isset($_GET['get']) ? $_GET['get'] : '';
if( $get ) include_once ("inc/libsnmp.php");

$mon = isset($_GET['mon']) ? 1 : 0;
$del = isset($_GET['del']) ? $_GET['del'] : '';

if( isset($_GET['col']) ){
	$col = $_GET['col'];
	if( $get and !in_array("getNS",$col) ) $col[] = 'getNS';
	if($_SESSION['opt']) $_SESSION['devcol'] = $col;
}elseif( isset($_SESSION['devcol']) ){
	$col = $_SESSION['devcol'];
}else{
	$col = array('device','devip','serial','type','contact','firstdis','lastdis');
}

$cols = array(	"device"=>"Device",
		"imgNS"=>$imglbl,
		"devip"=>"$manlbl IP",
		"origip"=>"$orilbl IP",
		"serial"=>"$serlbl",
		"vendor"=>$venlbl,
		"type"=>"Device $typlbl",
		"services"=>$srvlbl,
		"description"=>$deslbl,
		"devos"=>"Device OS",
		"bootimage"=>"Bootimage",
		"location"=>$loclbl,
		"contact"=>$conlbl,
		"devgroup"=>$grplbl,
		"devmode"=>$modlbl,
		"snmpversion"=>"SNMP $verlbl",
		"readcomm"=>"$realbl Community",
		"writecomm"=>"$wrtlbl Community",
		"cliport"=>"CLI $porlbl",
		"login"=>"Login",
		"icon"=>"Icon",
		"firstdis"=>"$fislbl $dsclbl",
		"lastdis"=>"$laslbl $dsclbl",
		"cpu"=>$lodlbl,
		"memcpu"=>"$memlbl $frelbl",
		"temp"=>$tmplbl,
		"cusvalue"=>"$cuslbl $vallbl",
		"cuslabel"=>"$cuslbl $titlbl",
		"sysobjid"=>"SysObjID",
		"devopts"=>$opolbl,
		"size"=>$sizlbl,
		"stack"=>"Stack",
		"maxpoe"=>"$maxlbl PoE",
		"totpoe"=>"$totlbl PoE",
		"cfgchange"=>"$cfglbl $chglbl",
		"cfgstatus"=>"$cfglbl $stalbl",
		"time"=>"$cfglbl $buplbl",
		"test"=>"$tstlbl",
		"status"=>"$stalbl",
		"poNS"=>$poplbl,
		"efNS"=>"Ethernet $frelbl",
		"dfNS"=>"xDSL $frelbl",
		"logNS"=>$loglbl,
		"stpNS"=>"$rltlbl STP",
		"dtNS"=>$cmdlbl,
		"csNS"=>"CLI $sndlbl",
		"gfNS"=>"$gralbl",
		"getNS"=>"SNMP Get"
		);

$link = DbConnect($dbhost,$dbuser,$dbpass,$dbname);							# Above print-header!
?>
<h1 onclick="document.list.style.display = (document.list.style.display == 'none')?'':'none';">Device <?= $lstlbl ?></h1>

<?php  if( !isset($_GET['print']) and !isset($_GET['xls']) ) { ?>
<form method="get" name="list" action="<?= $self ?>.php">
<table class="content">
<tr class="bgmain">
<td class="ctr s">
	<a href="<?= $self ?>.php"><img src="img/32/<?= $selfi ?>.png" title="<?= $self ?>"></a>
</td>
<td>
	<br>
<?php Filters(); ?>
</td>
<td class="ctr">
	<a href="?in[]=snmpversion&op[]=>&st[]=0&lim=<?= $listlim ?>"><img src="img/16/dev.png" title="SNMP Devices"></a>
	<a href="?in[]=stack&op[]=>&st[]=1&lim=<?= $listlim ?>"><img src="img/16/db.png" title="Stacks"></a>
	<a href="?in[]=cliport&op[]=%3D&st[]=1&co[]=&in[]=lastdis&op[]=~&col[]=device&col[]=devip&col[]=location&col[]=contact&col[]=firstdis&col[]=lastdis&ord=lastdis+desc"><img src="img/16/kons.png" title="CLI <?= $errlbl ?>"></a><br>
	<a href="?in[]=firstdis&op[]=~&st[]=&co[]=%3D&in[]=lastdis&col[]=device&col[]=devip&col[]=location&col[]=contact&col[]=firstdis&col[]=lastdis&ord=lastdis+desc"><img src="img/16/eyes.png" title="<?= (($verb1)?"$dsclbl $onclbl":"$onclbl $dsclbl") ?>"></a>
	<a href="?in[]=cfgstatus&op[]=~&st[]=[ECO]&col[]=device&col[]=devip&col[]=location&col[]=contact&col[]=lastdis&col[]=cfgstatus&col[]=time&ord=time"><img src="img/16/conf.png" title="<?= $cfglbl ?> <?= $errlbl ?>"></a>
	<a href="?in[]=test&op[]==&st[]=NULL&co[]=AND&in[]=snmpversion&op[]=>&st[]=0&col[]=device&col[]=devip&col[]=serial&col[]=location&col[]=contact&col[]=lastdis&col[]=test"><img src="img/16/bino.png" title="<?= $notlbl ?> Monitor"></a><br>
	<a href="?in[]=lastdis&op[]=<&st[]=<?= date($_SESSION['timf'],time()-2*$rrdstep) ?>&col[]=device&col[]=devip&col[]=location&col[]=contact&col[]=firstdis&col[]=lastdis&ord=lastdis+desc"><img src="img/16/date.png" title="Devices <?= $undlbl ?>"></a>
	<a href="?in[]=cpu&op[]=>&st[]=0&col[]=device&col[]=location&col[]=contact&col[]=firstdis&col[]=lastdis&col[]=cpu&col[]=gfNS&lim=10&ord=cpu+desc"><img src="img/16/cpu.png" title="<?= $toplbl ?> 10 CPU/UPS <?= $lodlbl ?>"></a>
	<a href="?in[]=temp&op[]=>&st[]=0&col[]=device&col[]=location&col[]=contact&col[]=firstdis&col[]=lastdis&col[]=temp&col[]=gfNS&lim=10&ord=temp+desc"><img src="img/16/temp.png" title="<?= $toplbl ?> 10 <?= $tmplbl ?>"></a>
</td>
<td class="ctr">
	<select multiple name="col[]" size="6" title="<?= $collbl ?>">
<?php
foreach ($cols as $k => $v){
	echo "\t\t<option value=\"$k\"".((in_array($k,$col))?" selected":"").">$v\n";
}
?>
	</select>
</td>
<td>
	<a href="Topology-Map.php?in[0]=<?= $in[0] ?>&op[0]=<?= $op[0] ?>&st[0]=<?= urlencode($st[0]) ?>&co[0]=<?= $co[0] ?>&in[1]=<?= $in[1] ?>&op[1]=<?= $op[1] ?>&st[1]=<?= urlencode($st[1]) ?>&co[1]=<?= $co[1] ?>&in[2]=<?= $in[2] ?>&op[2]=<?= $op[2] ?>&st[2]=<?= urlencode($st[2]) ?>&co[2]=<?= $co[2] ?>&in[3]=<?= $in[3] ?>&op[3]=<?= $op[3] ?>&st[3]=<?= urlencode($st[3]) ?>"><img src="img/16/paint.png" title="<?= "$fltlbl Map" ?>"></a>
	<input type="checkbox" name="map" title="<?= (($verb1)?"$sholbl $laslbl Map":"Map $laslbl $sholbl") ?>" <?= $map ?>><br>
	<img src="img/16/form.png" title="<?= $limlbl ?>">
	<select size="1" name="lim">
<?php selectbox("limit",$lim) ?>
	</select><br>
<?php  if($ismgr) { ?>
	<img src="img/16/brgt.png" title="SNMP Get">
	<input type="text" name="get" value="<?= $get ?>" class="m">
<?php } ?>
</td>
<td class="ctr s">
	<input type="submit" class="button" value="<?= $sholbl ?>"><br>
<?php  if($isadmin) { ?>
	<input type="submit" class="button" name="mon" value="<?= $monlbl ?>" onclick="return confirm('<?= $monlbl ?> <?= $addlbl ?>?')" ><br>
	<input type="submit" class="button" name="del" value="<?= $dellbl ?>" onclick="return confirm('<?= $dellbl ?>, <?= $cfmmsg ?>')" >
<?php } ?>
</td>
</tr>
</table>
</form>
<p>

<?php
}

if( count($in) ){
	if ($map and !isset($_GET['xls']) and file_exists("map/map_$_SESSION[user].php")) {
		echo "<div class=\"ctr\">\n\t<h2>$netlbl Map</h2>\n";
		echo "\t<img src=\"map/map_$_SESSION[user].php\" class=\"genpad\">\n</div>\n<p>\n\n";
	}

	$moq = 0;
	$jco = '';
	$jst = '';
	$mma = explode('/', $mema);
	$mgar = array_merge($in,$col);
	if( in_array('time',$mgar) ){
		$jst .= ' LEFT JOIN configs USING (device)';
		$jco  .= ',length(config) as cfglen,length(changes) as chglen,time';
	}
	if( in_array('test',$mgar) or in_array('status',$mgar) ){
		$moq   = 1;
		include_once ("inc/libmon.php");
		$in    = array_map("AddDevs", $in);
		$jst .= ' LEFT JOIN monitoring on (devices.device = monitoring.name)';
		$jco  .= ',test,status,lost,ok';
	}
	$res = DbQuery( $link,'devices','s','devices.*'.$jco,$ord,$lim,$in,$op,$st,$co,$jst);

	Condition($in,$op,$st,$co);
	if( $del ){
		if($isadmin){
			echo "<table class=\"content\">\n\t<tr>\n\t\t<td class=\"bgsub ctr b\">\n\t\t\t<img src=\"img/16/dev.png\"><br>\n\t\t\tDevice\n\t\t</td>\n";
			echo "\t\t<td class=\"bgsub ctr\">\n\t\t\t<img src=\"img/16/bcnl.png\"><br>\n\t\t\t$dellbl $stalbl\n\t\t</td>\n";
			$mon = 0;
		}else{
			echo $nokmsg;
			$del = 0;
		}
	}else{
		TblHead("bgsub",1);
	}

	if($res){
		$row   = 0;
		$most = '';
		while( ($dev = DbFetchArray($res)) ){
			if ($row % 2){$bg = "txta"; $bi = "imga";}else{$bg = "txtb"; $bi = "imgb";}
			$row++;
			TblRow($bg);
			$ip  = long2ip($dev['devip']);
			if( $del ){
				echo "\t\t<td class=\"$bi ctr b\">\n\t\t\t<img src=\"img/dev/$dev[icon].png\" title=\"$dev[type]\"><br>\n\t\t\t$dev[device]\n\t\t</td>\n\t\t<td>\n";
				DevDelete( $dev['device'],$dev['serial'] );
				echo "\t\t</td>\n\t</tr>\n";
			}else{
				$oi		= long2ip($dev['origip']);
				$dv		= $dev['device'];
				$ud		= urlencode($dev['device']);
				$wasup		= ($dev['lastdis'] > time() - $rrdstep*2)?1:0;
				$os		= $dev['devos'];
				$boot		= $dev['bootimage'];
				$ug		= urlencode($dev['devgroup']);
				$rver		= $dev['snmpversion'] & 3;
				$wver		= ($dev['snmpversion'] & 12) >> 2;
				$rcomm		= (($guiauth != 'none')?$dev['readcomm']:"***");
				$cliport	= $dev['cliport'];
				$login		= $dev['login'];
				$devopts	= $dev['devopts'];
				$dvip		= Devcli( $ip, $cliport );
				list($fc,$lc)	= Agecol($dev['firstdis'],$dev['lastdis'],$row % 2);

				if($isadmin and $mon and $dev['devip']){
					if( $rver ){
						$mma  = explode('/', $mema);
						$myma = ($dev['memcpu'] > 100)?$mma[0]:$mma[1];
						$most = AddRecord($link,'monitoring',
								array('name'),
								array($dev['device']),
								array('name','monip','test','alert','device','memalert','latwarn','arppoison'),
								array($dev['device'],$dev['devip'],'uptime',130,$dev['device'],$myma,$latw,$arppoison)
							);
					}else{
						$most = AddRecord($link,'monitoring',
								array('name'),
								array($dev['device']),
								array('name','monip','test','alert','device','latwarn'),
								array($dev['device'],$dev['devip'],'ping',130,$dev['device'],$latw)
							);
					}
				}

				if( in_array('device',$col) ){
					if( $moq ){
						list($statbg,$stat) = StatusBg(1,$dev['test'],$dev['status'],$bi);
					}else{
						$statbg = $bi;
						$stat = '';
					}
					TblCell($dev['device'],'',"$statbg ctr b s","+<a href=\"Devices-Status.php?dev=$ud\"><img src=\"img/dev/$dev[icon].png\" title=\"$dev[type] $stat\"></a>".Digit($dev['stack'])." $most<br>");
				}
				if( in_array("imgNS",$col) )	TblCell($dev['device'],'',"imgw ctr b","+<a href=\"Devices-Status.php?dev=$ud\"><img class=\"panel\" width=\"".(($dev['size'])?'100':'50')."\" src=\"".DevPanel($dev['type'],$dev['icon'],$dev['size'])."\" title=\"$dev[type]\"></a><br>");
				if(in_array("devip",$col))	TblCell($dvip);
				if(in_array("origip",$col))	TblCell( Devcli($oi,$cliport) );
				if(in_array("serial",$col))	TblCell( InvCheck( $dev['serial'],$dev['type'],3,$dev['location'],$dev['contact'] ),'','nw' );
				if(in_array("vendor",$col))	TblCell($dev['vendor'],"?in[]=vendor&op[]==&st[]=$dev[vendor]" );
				if(in_array("type",$col))	TblCell( $dev['type'],"?in[]=type&op[]==&st[]=".urlencode($dev['type']),'nw',"+<a href=\"http://www.google.com/search?q=".urlencode("$dev[vendor] $dev[type]")."&btnI=1\" target=\"window\"><img src=\"img/oui/".VendorIcon($dev['vendor']).".png\" title=\"$dev[vendor]\"></a> ");
				if(in_array("services",$col))	TblCell( Syssrv($dev['services'])." ($dev[services])","?in[]=services&op[]==&st[]=$dev[services]");
				if(in_array("description",$col))TblCell($dev['description']);
				if(in_array("devos",$col))	TblCell( $dev['devos'],"?in[]=devos&op[]==&st[]=$dev[devos]" );
				if(in_array("bootimage",$col))	TblCell( $dev['bootimage'],"?in[]=bootimage&op[]==&st[]=".urlencode($dev['bootimage']) );
				if(in_array("location",$col))	TblCell( $dev['location'],"?in[]=location&op[]==&st[]=".urlencode($dev['location']) );
				if(in_array("contact",$col))	TblCell( $dev['contact'],"?in[]=contact&op[]==&st[]=".urlencode($dev['contact']) );
				if(in_array("devgroup",$col))	TblCell( $dev['devgroup'],"?in[]=devgroup&op[]==&st[]=".urlencode($dev['devgroup']) );
				if(in_array("devmode",$col))	TblCell( DevMode($dev['devmode']),"?in[]=devmode&op[]==&st[]=".urlencode($dev['devmode']) );
				if(in_array("snmpversion",$col))TblCell( "$realbl:$rver".(($dev['snmpversion'] & 128)?'-HC ':' ').($wver?" $wrtlbl:$wver (<a href=\"?in[]=snmpversion&op[]==&st[]=$dev[snmpversion]\">$dev[snmpversion]</a>)":'') );
				if(in_array("readcomm",$col))	TblCell( $rcomm );
				if(in_array("writecomm",$col))	TblCell( (($isadmin and $guiauth != 'none')?$dev['writecomm']:"***") );
				if(in_array("cliport",$col))	TblCell( $cliport,"?in[]=cliport&op[]==&st[]=".urlencode($cliport) );
				if(in_array("login",$col))	TblCell( $login,"?in[]=login&op[]==&st[]=".urlencode($login) );
				if(in_array("icon",$col))	TblCell( $dev['icon'],"?in[]=icon&op[]==&st[]=".urlencode($dev['icon']) );
				if( in_array("firstdis",$col) )	TblCell( Ftime($dev['firstdis']),"?in[]=firstdis&op[]==&st[]=$dev[firstdis]",'nw','',"background-color:#$fc" );
				if( in_array("lastdis",$col) )	TblCell( Ftime($dev['lastdis']),"?in[]=lastdis&op[]==&st[]=$dev[lastdis]",'nw','',"background-color:#$lc" );
				if(in_array("cpu",$col)){
					if(substr($devopts,1,1) != "-"){
						TblCell($dev['cpu'].'%','','nw','+'.Bar($dev['cpu'],$cpua/2,'sbar') );
					}else{
						TblCell();
					}
				}
				if(in_array("memcpu",$col)){
					if($dev['memcpu'] > 100){
						TblCell( DecFix($dev['memcpu']).'B','','rgt' );
					}elseif($dev['memcpu'] > 0){
						TblCell( $dev['memcpu'].'%','','rgt' );
					}else{
						TblCell();
					}
				}
				if(in_array("temp",$col)){
					if($dev['temp']){
						TblCell( ($_SESSION['far'])?($dev['temp']*1.8+32)."F":"$dev[temp]C",'','','+'.Bar($dev['temp'],$tmpa/2,'sbar') );
					}else{
						TblCell();
					}
				}
				if(in_array("cusvalue",$col)){
					TblCell( $dev['cusvalue'],'','rgt' );
				}
				if(in_array("cuslabel",$col)){
					TblCell( $dev['cuslabel'],'','rgt' );
				}
				if(in_array("sysobjid",$col)){
					if( strstr($dev['sysobjid'],'1.3.6.1.4.1.') ){
						TblCell($dev['sysobjid'],"Other-Defgen.php?so=$dev[sysobjid]&ip=$ip&co=$rcomm");
					}else{
						TblCell($dev['sysobjid'],"?in[]=sysobjid&op[]==&st[]=$dev[sysobjid]");
					}
				}
				if(in_array("devopts",$col))	TblCell($devopts);
				if(in_array("size",$col))	TblCell($dev['size'],"?in[]=size&op[]==&st[]=$dev[size]",'rgt');
				if(in_array("stack",$col))	TblCell($dev['stack'],"?in[]=stack&op[]==&st[]=$dev[stack]",'rgt');
				if(in_array("maxpoe",$col))	TblCell($dev['maxpoe'].'W',"?in[]=maxpoe&op[]==&st[]=$dev[maxpoe]",'rgt');
				if(in_array("totpoe",$col))	TblCell($dev['totpoe'].'W','','rgt');
				if( in_array("cfgchange",$col) )TblCell( $dev['cfgchange'],"?in[]=cfgchange&op[]==&st[]=".urlencode($dev['cfgchange']) );
				if( in_array("cfgstatus",$col) )TblCell( $dev['cfgstatus'],"?in[]=cfgstatus&op[]==&st[]=".urlencode($dev['cfgstatus']),'','+'.DevCfg($dev['cfgstatus']) );
				if( in_array("time",$col) ){
					$cfchg = $dev['chglen']?", $chglbl:".DecFix($dev['chglen'])."B":'';
					$cbup  = ($dev['time'])?"$buplbl:".Ftime($dev['time']).", $sizlbl:".DecFix($dev['cfglen'])."B".$cfchg:'';
					TblCell($cbup,"?in[]=time&op[]==&st[]=$dev[time]",'nw',$dev['time']?ModLink('Devices','Config',"shc=$ud"):'' );
				}
				if(in_array("test",$col))TblCell($dev['test'],"Monitoring-Setup.php?in[]=name&op[]==&st[]=$ud",'nw','+'.TestImg($dev['test']));
				if( in_array("status",$col) ){
					if( $dev['ok'] ){
						$av = round($dev['ok']/($dev['lost']+$dev['ok'])*100,3);
						TblCell( "$av%",'','nw','+'.Bar($av,-99,'sbar',$avalbl) );
					}else{
						TblCell();
					}
				}
				if(in_array("poNS",$col)){
					$pop = NodPop( array('device'),array('='),array($dv),array() );
					if($pop){
						TblCell($pop,"Nodes-List.php?in[]=device&op[]==&st[]=$ud",'nw','+'.Bar($pop,100,'sbar') );
					}else{
						TblCell();
					}
				}
				if( in_array("efNS",$col) ){
					echo "\t\t<td>\n";
					IfFree( isset($_GET['xls'])?0:7,'eth','device','=',$dv );
					echo "\t\t</td>\n";
				}
				if( in_array("dfNS",$col) ){
					echo "\t\t<td>\n";
					IfFree( isset($_GET['xls'])?0:7,'dsl','device','=',$dv );
					echo "\t\t</td>\n";
				}
				if( in_array("logNS",$col) and !isset($_GET['xls']) ){
					$log = array();
					$log[$dev['firstdis']] = "bblf;$fislbl $dsclbl";
					$log[$dev['lastdis']] = "bbrt;$laslbl $dsclbl";
					$lres = DbQuery($link,'configs','s','time','','',array('device'),array('='),array($dv) );
					if($lres){
						$lro = DbFetchRow($lres);
						DbFreeResult($lres);
						if($lro[0]){
							$log[$lro[0]] = "conf;$cfglbl $buplbl";
						}
					}
					$lres = DbQuery($link,'monitoring','s','uptime','','',array('name','uptime'),array('=','!='),array($dv,0),array('AND') );
					if($lres){
						$lro = DbFetchRow($lres);
						$t = time()-$lro[0];
						DbFreeResult($lres);
						if($lro[0]){
							$log[$t] = "exit;$reslbl";
						}
					}
					ksort($log);
					echo "\t\t<td class=\"rgt\">\n";
					$pt = 0;
					foreach ($log as $t => $v){
						if($pt){
							$d = round(($t-$pt)/86400);
							if($d){
								echo Bar( $d,'lvl100','sbar',"$d $tim[d]");
							}
						}
						$pt = $t;
						$lb = explode(";", $v);
						echo "\t\t\t<img src=\"img/16/$lb[0].png\" title=\"$lb[1] ".Ftime($t)."\">\n";
					}
					echo "\t\t</td>\n";
				}
				if( in_array("stpNS",$col) and !isset($_GET['xls']) ){
					if($rver and $dev['lastdis'] > time() - $rrdstep * 2){
						$stppri	= str_replace('"','', Get($ip, $rver, $dev['readcomm'], "1.3.6.1.2.1.17.2.2.0") );
						if( preg_match("/^No Such|^$/",$stppri) ){
							TblCell("?");
						}else{
							$numchg	= str_replace('"','', Get($ip, $rver, $dev['readcomm'], "1.3.6.1.2.1.17.2.4.0") );
							if( preg_match("/^No Such|^$/",$numchg) ){
								TblCell("TC:?");
							}else{
								$laschg	= str_replace('"','', Get($ip, $rver, $dev['readcomm'], "1.3.6.1.2.1.17.2.3.0") );
								sscanf($laschg, "%d:%d:%0d:%0d.%d",$tcd,$tch,$tcm,$tcs,$ticks);
								$tcstr  = sprintf("%dD-%d:%02d:%02d",$tcd,$tch,$tcm,$tcs);
								$rport	= str_replace('"','', Get($ip, $rver, $dev['readcomm'], "1.3.6.1.2.1.17.2.7.0") );
								if($rport){
									$rootif = str_replace('"','', Get($ip, $rver, $dev['readcomm'], "1.3.6.1.2.1.17.1.4.1.2.$rport") );
									$ifres  = DbQuery($link,'interfaces','s','ifname,alias','','',array('device','ifidx'),array('=','='),array($dv,$rootif),array('AND') );
									if( DbNumRows($ifres) == 1 ){
										$if = DbFetchRow($ifres);
										$it = "RP:<span class=\"grn\">$if[0] <i>$if[1]</i></span>";
									}else{
										$it = "Rootport n/a!";
									}
								}else{
									$it = "<span class=\"drd\">Root</span>";
								}
								TblCell("$prilbl:<span class=\"prp\">$stppri</span> $it TC:<span class=\"blu\">$numchg</span> $tcstr","",($tch + 1440*$tcd)?'good':'warn',"<a href=\"Topology-Spanningtree.php?dev=$ud\"><img src=\"img/16/traf.png\" title=\"Topology-Spanningtree\"></a>");
							}
						}
					}else{
						TblCell("-");
					}
				}
				if( in_array("dtNS",$col) and !isset($_GET['xls']) ){
					echo "\t\t<td>\n";
					include ("log/devtools.php");
					echo "\t\t</td>\n";
				}
				if( in_array("csNS",$col) and !isset($_GET['xls']) ){
					echo "\t\t<td>\n";
					if( $dev['login'] ){							# Only show, if login is available
?>
			<form method="post" name="nedi" action="System-NeDi.php">
				<input type="hidden" name="mde" value="d">
				<input type="hidden" name="sed" value="a">
				<input type="hidden" name="opt" value="<?=$ip?>">
				<input type="hidden" name="tst" value="i">
				<input type="hidden" name="skp" value="AFGgsjmvpadobewit">
				<input type="hidden" name="vrb" value="on">
				<?= (strpos($devopts,'f') )?'<input type="hidden" name="uip" value="1">':'' ?>


				<select size="1" name="cli" onchange="if (confirm(' <?= $sndlbl ?>, <?= $cfmmsg ?>'))this.form.submit();else this.selectedIndex=0">
					<option value="">CLI <?= $sndlbl ?> ->
<?php
foreach (glob("$nedipath/cli/*") as $f){
	if( !is_dir($f) ){
		$l = substr($f,strlen("$nedipath/cli/") );
		echo "\t\t\t<option value=\"$l\" ".( ($cli == $f)?" selected":"").">$l\n";
	}
}
?>
				</select>
			</form>
<?php
					}
					echo "\t\t</td>\n";
				}
				if( in_array("gfNS",$col) and !isset($_GET['xls']) ){
					echo "\t\t<td>\n";
					if($_SESSION['gsiz']){
						$gsiz = ($_SESSION['gsiz'] == 4)?2:1;
						if( substr($devopts,1,1) != "-" ) echo "\t\t\t<a href=\"Devices-Graph.php?dv=$ud&if[]=cpu\"><img src=\"inc/drawrrd.php?dv=$ud&t=cpu&s=$gsiz\" title=\"$dev[cpu]% $lodlbl\">\n";
						$unit = ( substr($devopts,1,1) == "W" )?"Battery $avalbl":"$memlbl $frelbl";
						if($dev['memcpu']) echo "\t\t\t<a href=\"Devices-Graph.php?dv=$ud&if[]=mem\"><img src=\"inc/drawrrd.php?dv=$ud&t=mem&s=$gsiz\" title=\"".(($dev['memcpu'] > 100)?DecFix($dev['memcpu']).'B':$dev['memcpu'].'%')." $unit\">\n";
						if($dev['temp']) echo "\t\t\t<a href=\"Devices-Graph.php?dv=$ud&if[]=tmp\"><img src=\"inc/drawrrd.php?dv=$ud&t=tmp&s=$gsiz\" title=\"$tmplbl ".(($_SESSION['far'])?($dev['temp']*1.8+32)."F":"$dev[temp]C")."\">\n";
						if($dev['cusvalue']){
							list($ct,$cy,$cu) = explode(";", $dev['cuslabel']);
							echo "\t\t\t<a href=\"Devices-Graph.php?dv=$ud&if[]=cuv\"><img src=\"inc/drawrrd.php?dv=$ud&if[]=".urlencode($ct)."&if[]=".urlencode($cu)."&s=$gsiz&t=cuv\" title=\"$ct ".DecFix($dev['cusvalue'])."$cu\">";
						}
					}
					echo "\t\t</td>\n";
				}
				if( in_array("getNS",$col) ){
					if( $rver and $get ){
						TblCell( Get($ip, $rver, $dev['readcomm'], $get) );
					}else{
						TblCell('-');
					}
				}
			}
			echo "\t</tr>\n";
		}
		DbFreeResult($res);
	}else{
		print DbError($link);
	}
	TblFoot("bgsub", count($col), "$row Devices".(($ord)?", $srtlbl: $ord":"").(($lim)?", $limlbl: $lim":"") );
}elseif($_SESSION['opt']){
	include_once ("inc/librep.php");
	DevType('','','',$_SESSION['lim'],'',0);
}
include_once ("inc/footer.php");
?>
