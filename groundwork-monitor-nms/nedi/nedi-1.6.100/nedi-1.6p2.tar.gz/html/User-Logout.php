<?php
session_start(); 

require_once ("inc/libmisc.php");
ReadConf('usr');

if( isset($_SESSION['group']) ){
	array_map('unlink', glob("map/map_$_SESSION[user]*"));
	unset($_SESSION['group']);
	session_destroy();
}
echo "<script>document.location.href='$authurls[1]';</script>\n";

?>
