<?php
//===============================
// Node related functions.
//===============================

//===================================================================
// Emulate good old nbtstat on port 137
function NbtStat($ip) {

	global $timeout, $nonlbl, $rpylbl;

	if ($ip == "0.0.0.0") {
		return "<img src=\"img/16/bcls.png\"> No IP!";
	}else{
		$nbts	= pack('C50',129,98,00,00,00,01,00,00,00,00,00,00,32,67,75,65,65,65,65,65,65,65,65,65,65,65,65,65,65,65,65,65,65,65,65,65,65,65,65,65,65,65,65,65,65,00,00,33,00,01);
		$fp		= @fsockopen("udp://$ip", 137, $errno, $errstr);
		if (!$fp) {
			return "ERROR! $errno $errstr";
		}else {
			fwrite($fp, "$nbts");
			stream_set_timeout($fp,$timeout);
			$data =  fread($fp, 400);
			fclose($fp);

			if (preg_match("/AAAAAAAAAA/",$data) ){
				$nna = unpack('cnam',substr($data,56,1));  							# Get number of names
				$out = substr($data,57);                							# get rid of WINS header

				for ($i = 0; $i < $nna['nam'];$i++){
					$nam = preg_replace("/ +/","",substr($out,18*$i,15));
					$id = unpack('cid',substr($out,18*$i+15,1));
					$fl = unpack('cfl',substr($out,18*$i+16,1));
					$na = "";
					$gr = "";
					$co = "";
					if ($fl['fl'] > 0){
						if ($id['id'] == "3"){
							if ($na == ""){
								$na = $nam;
							}else{
								$co = $nam;
							}
						}
					}else{
						if ($na == ""){
							$gr = $nam;
						}
					}
				}
				return "<img src=\"img/16/bchk.png\"> $na $gr $co";
			}else{
				return "<img src=\"img/16/bstp.png\"> $nonlbl $rpylbl";
			}
		}
	}
}

//===================================================================
// Check for open port and return server information, if possible.
function CheckTCP ($ip, $p,$d){

	global $debug,$sndlbl,$timeout;

	if ($ip == "0.0.0.0") {
		return "<img src=\"img/16/bcls.png\"> No IP!";
	}else{
		if($debug){echo "<div class=\"textpad noti \">$sndlbl $ip:$p \"$d\"</div>\n";}

		$fp = @fsockopen($ip, $p, $errno, $errstr, 1 );

		flush();
		if (!$fp) {
			return "<img src=\"img/16/bstp.png\"> $errstr";
		} else {
			fwrite($fp,$d);
			stream_set_timeout($fp,$timeout);
			$ans = fread($fp, 255);
			$ans .= fread($fp, 255);
			$ans .= fread($fp, 255);
			fclose($fp);

			if( preg_match("/Server:(.*)/i",$ans,$mstr) ){
				$srv = "<i>$mstr[1]</i>";
			}else{
				$srv = "";
			}
			if( preg_match("/<address>(.*)<\/address>/i",$ans,$mstr) ){
				return "<img src=\"img/16/bchk.png\"> $mstr[1] $srv";
			}elseif( preg_match("/<title>(.*)<\/title>/i",$ans,$mstr) ){
				return "<img src=\"img/16/bchk.png\"> $mstr[1] $srv";
			}elseif( preg_match("/content=\"(.*)\">/i",$ans,$mstr) ){
				return "<img src=\"img/16/bchk.png\"> $mstr[1] $srv";
			}else{
				$mstr = substr(preg_replace("/[^\x20-\x7e]|<!|!>|(<script.*)/i",'',$ans),0,50);
				return "<img src=\"img/16/bchk.png\"> $mstr $srv";
			}
		}
	}
}

//===================================================================
// Create and send magic packet (copied from the PHP webiste)
function Wake($ip, $mac, $port){

	global $errlbl, $sndlbl;

	$nic = fsockopen("udp://" . $ip, $port);
	if($nic){
		$packet = "";
		for($i = 0; $i < 6; $i++)
			$packet .= chr(0xFF);
		for($j = 0; $j < 16; $j++){
			for($k = 0; $k < 6; $k++){
				$str = substr($mac, $k * 2, 2);
				$dec = hexdec($str);
				$packet .= chr($dec);
			}
		}
		$ret = fwrite($nic, $packet);
		fclose($nic);
		if($ret){
			echo "<h5>WoL $sndlbl $ip OK</h5>\n";
			return true;
		}
	}
	echo "<h4>WoL $sndlbl $ip $errlbl</h4>\n";
	return false;
}

//===================================================================
// Draw Node's Metric Chart
function MetricChart($id, $sz, $str){

	global $spdlbl,$debug,$anim;

	if($sz == 4){
		$w = 320;
		$h = 200;
		$f = 9;
	}elseif($sz == 3){
		$w = 200;
		$h = 100;
		$f = 8;
	}else{
		$w = 110;
		$h = 70;
		$f = 8;
	}

	$i = 0;
	if( preg_match('/[M-Z]/',$str) ){
		foreach( str_split($str) as $ch ){
			$met['labels'][] = $i++;
			$snr['data'][] = 3*(90-ord($ch));
		}
		$snr['label']           = "SNR";
		$snr['fillColor']       = "rgba(100,200,100,0.5)";
		$snr['strokeColor']     = "rgba(50,150,50,1)";
		$snr['highlightFill']   = "rgba(75,175,75,0.5)";
		$snr['highlightStroke'] = "rgba(25,150,25,1)";
		$met['datasets'][]      = $snr;
		$typ = 'Bar';
	}else{
		foreach( str_split($str) as $ch ){
			$met['labels'][] = $i++;
			$v = 76 - ord($ch);
			if( $v > 5 ){
				$spd['data'][] = $v-6;
				$dup['data'][] = 0;
			}else{
				$spd['data'][] = $v;
				$dup['data'][] = 1;
			}
		}
		$spd['label']       = $spdlbl;
		$spd['fillColor']   = "rgba(100,150,200,0.5)";
		$spd['strokeColor'] = "rgba(100,150,200,1)";
		$spd['pointColor']  = "rgba(100,150,200,1)";
		$spd['pointHighlightFill']  = "rgba(20,30,20,1)";
		$dup['label']       = 'Duplex';
		$dup['fillColor']   = "rgba(200,100,100,0.5)";
		$dup['strokeColor'] = "rgba(200,100,100,1)";
		$dup['pointColor']  = "rgba(200,100,100,1)";
		$dup['pointHighlightFill']  = "rgba(40,20,20,1)";
		$met['datasets'][]  = $spd;
		$met['datasets'][]  = $dup;
		$typ = 'Line';
	}

?>
<canvas id="<?= $id ?>" class="genpad" width="<?= $w ?>" height="<?= $h ?>"></canvas>

<script language="javascript">
var data = <?= json_encode($met,JSON_NUMERIC_CHECK) ?>

var ctx = document.getElementById("<?= $id ?>").getContext("2d");
var myNewChart = new Chart(ctx).<?= $typ ?>(data, {pointDotRadius : 2, scaleFontSize: <?= $f ?><?= $anim ?>});
</script>

<?php
	if($debug){
		echo "<div class=\"textpad code pre txta\">\n";
		print_r($met);
		echo "</div>\n";
	}
}

//===================================================================
// Delete node and related tables
function NodDelete($dln){

	global $link,$delbl,$errlbl,$updlbl,$nedipath;

	echo DbQuery($link,'nodes','d','','','',array('mac'),array('='),array($dln)  )?"<span class=\"olv\">Node</span> ":"<span class=\"drd\">".DbError($link)."</span> ";
	echo DbQuery($link,'nodarp','d','','','',array('mac'),array('='),array($dln) )?"<span class=\"olv\">IP ARP</span> ":"<span class=\"drd\">".DbError($link)."</span> ";
	echo DbQuery($link,'nodnd','d','','','',array('mac'),array('='),array($dln)  )?"<span class=\"olv\">IPv6 ND</span> ":"<span class=\"drd\">".DbError($link)."</span> ";
	echo DbQuery($link,'iptrack','d','','','',array('mac'),array('='),array($dln))?"<span class=\"olv\">IPtrack</span> ":"<span class=\"drd\">".DbError($link)."</span> ";
	echo DbQuery($link,'iftrack','d','','','',array('mac'),array('='),array($dln))?"<span class=\"olv\">IFtrack</span> ":"<span class=\"drd\">".DbError($link)."</span> ";
}

//===================================================================
// Fetch favicon
function Favicon($url,$in,$i=FALSE){

	global $debug;

	$ic  = '';
	if($debug) echo "<h3>Favicon $url".($i?" (Expecting Icon)":"")."</h3>\n";
	$options = array(
			'http'=>array(
			'method'=>"GET",
			'header'=>"Accept-language: en\r\n" .
			"User-Agent: Mozilla/5.0 (X11; Linux x86_64; rv:31.0) Gecko/20100101\r\n",
			'timeout' => 3)
			);
	flush();
	$context = stream_context_create($options);
	$idata = file_get_contents($url, false, $context);
	if($debug){
		echo "<div class=\"textpad code pre tqrt txtd\">\n";
		print_r($http_response_header);
		echo "</div>\n";
	}
	if( $idata ){
		preg_match('#(http[s]?)://([^/]+)#i',$url,$uarr);
		if( preg_grep('/301 Redirect|301 Moved Permanently|302 Found|307 Temporary Redirect/i',$http_response_header) ){
			foreach( $http_response_header as $l ){
				preg_match('/location: (.*)$/i',$l,$rl);
				if( count($rl) ) break;
			}
			if( count($rl) ){
				if($debug) echo "<div class=\"textpad code pre half txta\">Header redirect to $rl[1]</div>\n";
				if( strpos($rl[1],'http') === 0 ){
					$ic = Favicon($rl[1],$in);
				}elseif( strpos($rl[1],'/') === 0 ){
					$ic = Favicon("$uarr[1]://$uarr[2]$rl[1]",$in);
				}else{
					$ic = Favicon("$url$rl[1]",$in);
				}
			}
		}elseif( stristr($idata,'window.location = "') or stristr($idata,'window.location="') ){
			if($debug){
				echo "<div class=\"textpad code pre tqrt txtd\">\n";
				echo htmlspecialchars($idata);
				echo "</div>\n";
			}
			preg_match('/window.location = "(.*)"/i',$idata,$rl);
			if( count($rl) ){
				if($debug) echo "<div class=\"textpad code pre half txta\">Javascript redirect to $rl[1]</div>\n";
				$ic = Favicon($rl[1],$in);
			}
		}elseif( preg_grep('/Content-Type: text/i',$http_response_header) ){
			preg_match('/<base href="([^"]+)"/i',$idata,$buri);
			preg_match_all('/<link([^>]+)rel="(shortcut )?icon"([^>]+)>/i',$idata,$lgrp);
			$iurl = '';
			if($buri){
				if($debug) echo "<div class=\"textpad code pre half txta\">Found base href $buri[1]</div>\n";
				$url = $buri[1];
				preg_match('#(http[s]?)://([^/]+)#i',$url,$uarr);
			}
			array_shift($lgrp);
			foreach($lgrp as $gm){
				foreach($gm as $e){
					preg_match('/href="([^"]+)"/i',$e,$iurls);
					if( count($iurls) and !strpos($iurls[0],'svg') ){
						if($debug) echo "<div class=\"textpad code pre half txta\">Found shortcut href $iurls[1]</div>\n";
						$iurl = $iurls[1];
						break;
					}
				}
				if( $iurl ) break;
			}
			if( $i ){
				if($debug) echo "<div class=\"textpad code pre half warn\">Got HTML response with $url, giving up!</div>\n";
			}elseif( !$iurl ){
				if($debug) echo "<div class=\"textpad code pre half txta\">No favicon link in HTML response, trying /favicon.ico</div>\n";
				$ic = Favicon("$uarr[1]://$uarr[2]/favicon.ico",$in,TRUE);
			}elseif( stripos($iurl,'http') === 0 ){
				$ic = Favicon($iurl,$in,TRUE);
			}elseif( strpos($iurl,'//') === 0 ){
				$ic = Favicon("http:$iurl",$in,TRUE);
			}elseif( strpos($iurl,'/') === 0 ){
				$ic = Favicon("$uarr[1]://$uarr[2]$iurl",$in,TRUE);
			}else{
				$iu = preg_replace('/^\//','',$iurl);
				$ls = strrpos($url,'/');
				if( $ls > 7 ) $url = substr($url,0,$ls);
				$ic = Favicon("$url/$iu",$in,TRUE);
			}
		}else{
			$by = file_put_contents("img/net/$in.ico", $idata);
			$ic = "$in.ico";
			if($debug) echo "<div class=\"textpad code pre half good\">$by Bytes written to $in.ico</div>\n";
		}
	}else{
		if($debug) echo "<div class=\"textpad code pre l alrm\">No response</div>\n";
	}

	return $ic;
}

//===================================================================
// Whois lookip an IP
function NetInfo($ip){

	global $link,$debug;

	$dnet  = ip2long($ip)&-256;
	$nres = DbQuery( $link,'netinfo','s','*','','',array('netip'),array('='),array($dnet) );
	if( DbNumRows($nres) ){
		$n = DbFetchRow($nres);
		DbFreeResult($nres);
		return array($n[9],"$n[7], $n[3] $n[1]",$n[2],$n[5],$n[6]); 
	}else{
		$ic = '';
		$nd = gethostbyaddr($ip);
		if( $nd != $ip ){
			$d  = explode('.', $nd );
			$td = end($d);
			$md = prev($d);
			$ic = Favicon("http://www.$md.$td",$dnet);
		}

		#$wsarr = array("whois.ripe.net","whois.apnic.net","whois.arin.net","whois.lacnic.net"); rely on joint whois for speed
		$wsarr = array('whois.arin.net','whois.ripe.net','whois.apnic.net','whois.afrinic.net');
		foreach($wsarr as $ws) {
			$fp = fsockopen($ws,43, $errno, $errstr, 2);
			if( !$fp ){
				if($debug) echo "<div class=\"textpad pre code warn half\">Whois to $ws failed: $errstr</div>\n";
				break;
			}else{
				$out = '';
				$opt = ( $ws == 'whois.arin.net' )?'n + ':'';
				fwrite($fp,"$opt $ip\n");
				stream_set_timeout($fp, 10);
				$out = stream_get_contents($fp, -1);
				fclose( $fp );
				if($debug) echo "<div class=\"textpad pre code txta tqrt\"><h3>$ws for $ip</h3>\n$out</div>\n";
				if( preg_match('/not (allocated|managed) by |Allocated to (APNIC)|further assigned to/i',$out) ){
					if($debug) echo "<div class=\"textpad pre code warn half\">No result with $ws</div>\n";
				}else{
					$od = '';
					$as = '';
					$ad = '';
					$ph = '';
					$cy = '';
					$ls = explode("\n", $out );
					foreach($ls as $l) {
						$f = preg_split('/:\s+/', $l );
						if( $f[0] == 'OriginAS' or $f[0] == 'origin' ){
							$as = substr($f[1],0,31);
						}elseif( $f[0] == 'Customer' or $f[0] == 'OrgName' or $f[0] == 'netname' ){
							$na = substr($f[1],0,31);
						}elseif( $f[0] == 'NetName' or $f[0] == 'descr' ){
							$de = substr($f[1],0,31);
						}elseif( $f[0] == 'Address' or $f[0] == 'City' or $f[0] == 'address' ){
							$ad .= trim($f[1]).' ';
						}elseif( !$cy and ($f[0] == 'Country' or $f[0] == 'country') ){
							$cy = substr(strtoupper($f[1]),0,2);
						}elseif( $f[0] == 'OrgTechPhone' or $f[0] == 'OrgAbusePhone' or $f[0] == 'phone' ){
							$ph = substr($f[1],0,15);
						}elseif( $f[0] == 'OrgAbuseEmail' or $f[0] == 'abuse-mailbox' or $f[0] == 'e-mail' ){
							$od = substr($f[1], strpos($f[1],'@')+1 );
						}elseif( preg_match("/^% Abuse contact.*'[-\.\w]+@([-\.\w]+)'$/",$l,$odm) ){
							$od = strtolower($odm[1]);
						}
						#if( $od ) break;
					}
					$od = substr($od,0,31);
					$nd = substr($nd,0,63);
					$ad = substr($ad,0,63);
					if( !$ic and $od ) $ic = Favicon("http://www.$od",$dnet);
					DbQuery( $link,'netinfo','i','','','',array('netip','netdomain','orgname','orgdomain','phone','address','country','description','origin','icon','time'),array(),array($dnet,$nd,$na,$od,$ph,$ad,$cy,$de,$as,$ic,time()) );
					break;
				}
			}
		}

		return array($ic,"$de, $od $nd",$na,$ad,$cy); 
	}
}

?>
