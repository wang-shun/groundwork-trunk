<?php
# Program: System-NeDi.php
# Programmer: Remo Rickli

$exportxls = 0;

include_once ("inc/header.php");

$_POST = sanitize($_POST);

$sed = isset($_POST['sed']) ? $_POST['sed'] : '';
$opt = isset($_POST['opt']) ? $_POST['opt'] : '';

$vrb = isset($_POST['vrb']) ? 'checked' : '';
$fqd = isset($_POST['fqd']) ? 'checked' : '';

$tst = isset($_POST['tst']) ? $_POST['tst'] : '';
$usr = isset($_POST['usr']) ? $_POST['usr'] : '';
$skp = isset($_POST['skp']) ? $_POST['skp'] : '';

if( file_exists("$nedipath/nodi.conf") ){
	$nodicfg = file("$nedipath/nodi.conf");
}elseif (file_exists("../nodi.conf")) {
	$nodicfg = file("../nodi.conf");
}else{
	echo "<h1>Can't find nodi.conf!</h1>\n";
	die;
}
foreach ($nodicfg as $cl) {
	if ( $cl and strpos($cl,'#') !== 0 and strpos($cl,';') !== 0 ){
		$v =  preg_split('/\s+/', rtrim($cl,"\n\r\0") );
		if ($v[0] == "usr"){
			$nodiusr[] = $v[1];
		}
	}
}

$arg = '';
$cmd = "$nedipath/nodi.pl";
if( $opt ){
	if($vrb) $arg .= "v";
	if($fqd) $arg .= "F";
	if($arg) $arg = "-" . $arg;

	if($tst) $arg .= " -t$tst ";
	if($usr) $arg .= " -u$usr ";
	if($skp) $arg .= " -S$skp ";

	$cmd .= " $arg";
	if( ($sed == 'A' or $sed == 'O') and $opt != 'all' ){
		$cmd .= " -$sed \"$opt\"";
	}elseif($sed){
		$cmd .= " -$sed $opt";
	}
}else{
	$cmd .= " --help";
}

?>
<script language="JavaScript">
<!--
var interval = "";

function RockBottom(){

	if( interval ){
		window.clearInterval(interval);
		interval = 0;
		document.getElementById('nodi').setAttribute('class', 'textpad code pre txta tqrt');
	}else{
		interval = window.setInterval("Down()",500);
		document.getElementById('nodi').setAttribute('class', 'textpad code pre warn tqrt');
	}
}

function Down(){
	window.scrollTo(0, document.body.scrollHeight);
}

// rufers idea
function UpCmd(){

	var arg = "";
	if(document.nodi.vrb.checked){arg += "v"}
	if(document.nodi.fqd.checked){arg += "F"}
	if(arg != ""){arg = "-" + arg}

	if(document.nodi.tst.selectedIndex){arg += " -t" + document.nodi.tst.options[document.nodi.tst.selectedIndex].value}
	if(document.nodi.usr.selectedIndex){arg += " -u" + document.nodi.usr.options[document.nodi.usr.selectedIndex].value}
	if(document.nodi.skp.value){arg += " -S" + document.nodi.skp.value}
	if(document.nodi.opt.value){arg += " -N" + document.nodi.opt.value}

	cmd = document.getElementById('cmd');
	cmd.innerHTML = "<?= $nedipath ?>/nodi.pl " + arg;
	cmd.style.opacity = 0.6;
}
//--></script>

<h1><?= $verb1?"$dsclbl $nodlbl":"$nodlbl $dsclbl" ?></h1>

<form name="nodi" action="<?= $self ?>.php" method="post">
<table class="content">
<tr class="bgmain">
<td class="ctr s">
	<a href="<?= $self ?>.php"><img src="img/32/<?= $selfi ?>.png" title="<?= $self ?>"></a>
</td>
<td class="top">
	<select size="1" name="sed" onchange="UpCmd();">
		<option value=""><?= $srclbl ?> ->
		<option value="N" <?= $sed=="N"?" selected":"" ?> ><?= $adrlbl ?>
		<option value="A" <?= $sed=="A"?" selected":"" ?> ><?= $devlbl ?>
		<option value="O" <?= $sed=="O"?" selected":"" ?> ><?= $nodlbl ?>
	</select>
	<input type="text" name="opt" value="<?= htmlspecialchars($opt) ?>" class="m" placeholder="<?= $opolbl ?>" onfocus="select();" onchange="UpCmd();">

	<input type="checkbox" name="vrb" <?= $vrb ?> title="<?= ($verb1?"$sholbl $deslbl":"$deslbl $sholbl") ?>" onchange="UpCmd();"> <?= $notlbl ?> <?= $qutlbl ?>
	<input type="checkbox" name="fqd" <?= $fqd ?> title="<?= $devlbl ?> <?= $namlbl ?> & Domain" onchange="UpCmd();"> FQDN
	<br>

	<select size="1" name="tst" onchange="UpCmd();">
		<option value=""><?= $tstlbl ?> ->
		<option value="i" <?= $tst=="i"?" selected":"" ?> ><?= $inflbl ?>
		<option value="s" <?= $tst=="s"?" selected":"" ?> ><?= $srclbl ?>
	</select>
	<select size="1" name="usr" onchange="UpCmd();">
		<option value=""><?= $usrlbl ?> ->
<?php
foreach ($nodiusr as $u){
	echo "\t\t<option value=\"$u\"".($usr==$u?" selected":"").">$u\n";
}
?>
	</select>
	<input type="text" name="skp" value="<?= $skp ?>" class="m" placeholder="<?= $skplbl ?>" onfocus="select();" onchange="UpCmd();">
	<img src="img/16/nwin.png" onClick="document.nodi.skp.value='w';UpCmd();" title="WMI">
	<img src="img/16/nlin.png" onClick="document.nodi.skp.value='u';UpCmd();" title="SSH">
	<img src="img/16/pkg.png" onClick="document.nodi.skp.value='h';UpCmd();" title="HW">
	<img src="img/16/cbox.png" onClick="document.nodi.skp.value='s';UpCmd();" title="SW">
</td>
<td class="ctr s">
	<input type="submit" class="button" name="go" value="<?= $cmdlbl ?>">
</td>
</tr>
</table>
</form>
<p>

<h2 id="cmd"><?= $cmd ?></h2>

<div class="textpad code pre txta tqrt" id="nodi" ondblClick="RockBottom();">
<?php
	session_write_close();
	ob_end_flush();
	system("$cmd 2>&1");
?>
</div>
<?php

include_once ("inc/footer.php");
?>
