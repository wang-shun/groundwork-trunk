#!/usr/bin/perl
=pod

=head1 PROGRAM nodi.pl

Collects Unix and Window node info.

=head2 DESCRIPTION

Uses wmic binary to add Windows specific info to the nodarp and
optionally devices or modules tables.

 Relies on Openvas' wmic. Install as follows:

 apt-get install autoconf build-essential

 wget http://www.openvas.org/download/wmi/wmi-1.3.14.tar.bz2
 bzip2 -cd wmi-1.3.14.tar.bz2 | tar xf -
 cd wmi-1.3.14/
 wget http://www.openvas.org/download/wmi/openvas-wmi-1.3.14.patch5
 patch -p1 < openvas-wmi-1.3.14.patch5

 #On Perl 5.22+ you get "Can't use 'defined(@array)'...":
 sed -i '583d' Samba/source/pidl/pidl

 make "CPP=gcc -E -ffreestanding"

 If authentication fails:
 winrm quickconfig

Using ssh for unix hosts. No further steps necessary

=head2 LICENSE

This program is not free software: Don't redistribute it!

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

=head2 AUTHORS

Remo Rickli

Visit http://www.nedi.ch for more information.

=cut

$VERSION = "1.8.100";

use vars qw(%opt %dev $cp $p $VERSION $wmic $now $ncmd);

$wmic = 'wmic';

$cp   = $0;
$cp   =~ s/(.*)\/(.*)/$1/;
if($0 eq $cp){$cp = '.'};
$p    = $cp eq '.'?'/var/nedi':$cp;

$now  = time;
$ncmd = "$0 ".join(" ",@ARGV);

use strict;
use warnings;
no warnings qw(once);
use Getopt::Std;

getopts('A:Fd:N:O:S:t:u:U:v',\%opt) || &HELP_MESSAGE;
$opt{'S'} = '' unless defined $opt{'S'};								# Avoid warnings if unused
$opt{'d'} = '' unless defined $opt{'d'};								# Avoid warnings if unused
$opt{'t'} = '' unless defined $opt{'t'};								# Avoid warnings if unused
$opt{'U'} = "$p/nodi.conf" unless $opt{'U'};

require "$p/inc/libmisc.pm";										# Use the miscellaneous nedi library
require "$p/inc/libmon.pm";										# Use the Monitoring lib for notifications
require "$p/inc/libcli.pm";										# Use the Monitoring lib for notifications
require "$p/inc/libdb.pm";										# Use the DB function library

misc::ReadConf($opt{'U'});

print "\nNode Discovery ($VERSION) $ncmd at ". localtime($now)."\n";
print "===============================================================================\n";

if( $opt{'N'} ){
	db::Connect($misc::dbname,$misc::dbhost,$misc::dbuser,$misc::dbpass,1);
	db::ReadDev('devmode>9 AND devmode<19');							# 10=SSH, 11=WMI device
	my @r = split(/\./,$opt{'N'});
	foreach my $ipa ( misc::ExpandRange($r[0]) ){
		foreach my $ipb ( misc::ExpandRange($r[1]) ){
			foreach my $ipc ( misc::ExpandRange($r[2]) ){
				foreach my $ipd ( misc::ExpandRange($r[3]) ){
					Discover("$ipa.$ipb.$ipc.$ipd") if misc::IPType("$ipa.$ipb.$ipc.$ipd") == 4;
				}
			}
		}
	}
	db::Disconnect();
}elsif( $opt{'A'} ){
	db::Connect($misc::dbname,$misc::dbhost,$misc::dbuser,$misc::dbpass,1);
	db::ReadDev('devmode>9 AND devmode<19');
	my $qry = ($opt{'A'} eq 'all')?'devmode>9 AND devmode<19':"devmode>9 AND devmode<19 AND ($opt{'A'})";
	my $dv  = db::Select('devices','devip','device,devip', $qry );
	for my $dip (keys %{$dv}){
		my $ip = misc::Dec2Ip($dip);
		Discover($ip) if misc::IPType($ip) == 4;
	}
	db::Disconnect();
}elsif( $opt{'O'} ){
	db::Connect($misc::arpwatch?$misc::arpwatch:$misc::dbname,$misc::dbhost,$misc::dbuser,$misc::dbpass,0);
	my $mtch = ($opt{'O'} eq 'all')?'':$opt{'O'};
	my $nods = db::Select('nodarp','nodip','mac,nodip,device,ifname,location',$mtch,'LEFT JOIN nodes USING (mac) LEFT JOIN devices USING (device)');
	db::Disconnect();

	db::Connect($misc::dbname,$misc::dbhost,$misc::dbuser,$misc::dbpass,1);
	db::ReadDev('devmode>9 AND devmode<19');
	for my $nip (keys %{$nods}){
		my $ip = misc::Dec2Ip($nip);
		Discover($ip,$nods->{$nip}{'mac'},$nods->{$nip}{'device'},$nods->{$nip}{'ifname'},$nods->{$nip}{'location'}) if misc::IPType($ip) == 4;
	}
	db::Disconnect();
}else{
	HELP_MESSAGE();
}

print "\nEND :Took ".int((time - $now)/60)." minutes\n\n";

=head2 FUNCTION DiscoverWMI()

Discover a node

B<Options> IP

B<Globals>

B<Returns> -

=cut
sub Discover{

	my ($ip,$mac,$dv,$po,$lo) = @_;

	if( $main::opt{t} eq 's' ){
		misc::Prt("TODO:$ip".(exists $misc::seedini{$ip}?"\tin DB as $misc::seedini{$ip}{dn}":'') );
	}elsif( exists $misc::seedini{$ip} ){
		misc::Prt("\nUpdate $misc::seedini{$ip}{dn} --------------------------------------------------------\n");
		my $usr = $opt{'u'}?$opt{'u'}:$dev{$misc::seedini{$ip}{dn}}{'us'};
		if( $dev{$misc::seedini{$ip}{dn}}{'cp'} == 135 and $opt{'S'} !~ /w/ ){
			DiscoverWMI($ip,$usr,$mac,$dv,$po,$lo) if mon::PingService($ip,'tcp',135,$misc::timeout) != -1;
		}elsif( $dev{$misc::seedini{$ip}{dn}}{'cp'} == 22 and $opt{'S'} !~ /u/ ){
			DiscoverSSH($ip,$usr,$mac,$dv,$po,$lo) if mon::PingService($ip,'tcp',22,$misc::timeout) != -1;
		}
	}else{
		misc::Prt("\nDiscover $ip --------------------------------------------------------\n");
		if( $opt{'S'} !~ /w/ and mon::PingService($ip,'tcp',135,$misc::timeout) != -1 ){
			my $usr = $opt{'u'}?$opt{'u'}:$misc::users[0];
			DiscoverWMI($ip,$usr,$mac,$dv,$po,$lo);
		}elsif( $opt{'S'} !~ /u/ and mon::PingService($ip,'tcp',22,$misc::timeout) != -1 ){
			die "Pleae add 2.user in nodi.conf for SSH!\n" unless  $opt{'u'} or exists $misc::users[1];
			my $usr = $opt{'u'}?$opt{'u'}:$misc::users[1];
			DiscoverSSH($ip,$usr,$mac,$dv,$po,$lo);
		}
	}
	misc::Prt("\n");
}

=head2 FUNCTION DiscoverWMI()

Discover a Windows node

B<Options> IP

B<Globals>

B<Returns> -

=cut
sub DiscoverWMI{

	my ($ip,$usr,$mac,$nbr,$nbrif,$loc) = @_;

	misc::Prt("WMIC:$ip user $usr\n","$ip\t");

	misc::Prt("GET :--- Win32_ComputerSystem ---\n");
	my $ho = getwmi($ip,$usr,'Domain,Manufacturer,Model,Name,NumberOfProcessors,TotalPhysicalMemory,UserName','Win32_ComputerSystem');

	if( $ho ){
		my $dv = ( $opt{'F'} )?"$ho->[0][0]/$ho->[0][3]":$ho->[0][3];
		my $pu = ( $ho->[0][6] and $ho->[0][6] ne '(null)' )?$ho->[0][6]:'';
		$pu =~ s/(.*)\\(.*)/$2/;
		misc::Prt("COMP:$ho->[0][3] is part of $ho->[0][0] and used by $pu\n","$dv\t");
		my $desc = "$ho->[0][1] $ho->[0][2] with $ho->[0][4] CPU and ".int($ho->[0][5]/1048576+1)."MB RAM";
		misc::Prt("COMP:$desc\n");
		misc::Prt("GET :--- Win32_OperatingSystem ---\n");
		my $os = getwmi($ip,$usr,'BootDevice,Caption,FreePhysicalMemory,Manufacturer,Name,SerialNumber,TotalVisibleMemorySize,Version','Win32_OperatingSystem');

		if( $os ){
			my $osde = $os->[0][4];
			my $ossn = $os->[0][7];
			my $ossw = $os->[0][6];

			$dev{$dv}{'fs'} = $now unless exists $dev{$dv}{'fs'};
			misc::Prt("OPER:$os->[0][3], $os->[0][4] $ossw first:".localtime($dev{$dv}{'fs'})."\n","$ossw\t");

			misc::Prt("GET :--- Win32_Processor ---\n");
			my $cpu = getwmi($ip,$usr,'Name,LoadPercentage,ProcessorId,Revision,Version','Win32_Processor');
			if( $cpu ){
				foreach my $r ( @{$cpu} ){
					$r->[5] = '' if !defined $r->[5];
					misc::Prt("CPU :$r->[0] $r->[4] $r->[3] $cpu->[0][1]%\n","c");
					db::Insert('modules','device,slot,model,moddesc,serial,hw,modclass,status',"'$dv','$r->[0]','$r->[5]','$r->[2]','$r->[3]','$r->[4]',61,128");
				}
			}

			if( $cpu->[0][1] =~ /^\d+$/ ){						# Only calculate, if numeric
				$dev{$dv}{'cpu'} = $cpu->[0][1];
			}else{
				misc::Prt("ERR :%CPU ($cpu->[0][1]) not numeric!",'Dc');
				$dev{$dv}{'cpu'} = 0;
			}
			if( $os->[0][2] =~ /^\d+$/ and $os->[0][8] =~ /^\d+$/){			# Only calculate, if both are numeric
				$dev{$dv}{'mcp'} = $os->[0][2] / $os->[0][8] * 100;
			}else{
				misc::Prt("ERR :Mem ($os->[0][2]/$os->[0][8]) not numeric!",'Dc');
				$dev{$dv}{'mcp'} = 0;
			}
			$dev{$dv}{'tmp'} = 0;
			$dev{$dv}{'cul'} = 'IO;G;#';
			$dev{$dv}{'cuv'} = 0;

			#my $brd = getwmi($ip,$usr,'Manufacturer,Model,Product,SerialNumber,Version','Win32_BaseBoard');
			misc::Prt("GET :--- Win32_BIOS ---\n");
			my $bos = getwmi($ip,$usr,'Name,SerialNumber,SMBIOSBIOSVersion,SoftwareElementID,SoftwareElementState,TargetOperatingSystem,Version','Win32_BIOS');
			my $sn  = $bos?substr($bos->[0][1],-32):'-';
			my $dip = misc::Ip2Dec($ip);
			my $gr  = substr($ho->[0][0],-32);
			my $dlo = defined $loc?$loc:'-';
			misc::Prt("BIOS:$ip $gr $sn\n");

			if( $opt{'S'} !~ /h/ ){
				db::Delete('modules',"device='$dv' and modclass != 81");
				db::Insert('modules','device,slot,model,moddesc,serial,sw,modclass,status',"'$dv','$os->[0][6]','$os->[0][3]','$os->[0][4]','$os->[0][7]','$os->[0][9]',80,128");

				misc::Prt("GET :--- Win32_PhysicalMemory ---\n");
				my $mem = getwmi($ip,$usr,'Capacity,DeviceLocator,Manufacturer,MemoryType,PartNumber,SerialNumber,Speed,Tag','Win32_PhysicalMemory');
				if( $mem ){
					foreach my $r ( @{$mem} ){
						my $sz = $r->[0] / 1024 / 1024;
						misc::Prt("MEM :$r->[1] $sz MB $r->[6]MHz $r->[2] $r->[4]\n","m");
						db::Insert('modules','device,slot,model,moddesc,serial,hw,fw,modclass,status',"'$dv','$r->[1]','$r->[2]','$r->[4] ($r->[3])','$r->[5]','$sz MB','$r->[6]',62,128");
					}
				}

				misc::Prt("GET :--- Win32_DiskDrive ---\n");
				my $hdd = getwmi($ip,$usr,'Availability,FirmwareRevision,MediaType,Model,SerialNumber,Size','Win32_DiskDrive',"BytesPerSector > 0");
				if( $hdd ){
					foreach my $r ( @{$hdd} ){
						$r->[1] =~ s/[\\\.]//g;
						my $mo = substr($r->[4],-32);
						my $sn = substr($r->[5],-32);
						misc::Prt("HDD :$r->[1] $r->[4] $sn\n","d");
						db::Insert('modules','device,slot,model,moddesc,serial,hw,fw,modclass,status',"'$dv','$r->[1]','$mo','$r->[3]','$sn','$r->[6]','$r->[2]',63,".(($r->[0]==0)?130:129) );
					}
				}

				misc::Prt("GET :--- WmiMonitorID ---\n");
				my $mon = getwmi($ip,$usr,'Active,InstanceName,ManufacturerName,ProductCodeID,SerialNumberID,UserFriendlyName,WeekOfManufacture,YearOfManufacture','WmiMonitorID','','wmi');
				if( $mon ){
					foreach my $r ( @{$mon} ){
						my @ms = split('&',$r->[1]);
						misc::Prt("DISP:$ms[3] $r->[6] $r->[7]\n","d");
						db::Insert('modules','device,slot,model,moddesc,serial,hw,fw,modclass,status',"'$dv','$ms[3]','".hex2char($r->[2])."','".hex2char($r->[5])."','".hex2char($r->[4])."','".hex2char($r->[3])."','$r->[6]-$r->[7]',69,".(($r->[0] eq 'True')?130:129) );
					}
				}

				if( $opt{'S'} !~ /v/ ){
					misc::Prt("GET :--- Msvm_ComputerSystem ---\n");
					my $vm = getwmi($ip,$usr,'Description,ElementName,EnabledState,HealthState,Name','Msvm_ComputerSystem',"Caption = 'Virtual Machine'",'virtualization\\v2'); # Msvm_SummaryInformation is empty?
					if( $vm ){
						my $nvm = 0;
						foreach my $r ( @{$vm} ){
							misc::Prt("VM  :$r->[2] Status $r->[3] Slot $r->[5]\n");
							db::Insert('modules','device,slot,model,moddesc,modclass,status',"'$dv','$r->[2]','$r->[0]','$r->[1]',40,".($r->[3]==2?130:129) );
							$nvm++;
						}
						misc::Prt(""," VM$nvm");
					}
				}
			}

			if( $opt{'S'} !~ /s/ ){
				db::Delete('modules',"device='$dv' and modclass = 81");
				misc::Prt("GET :--- Win32Reg_AddRemovePrograms ---\n");
				my $sw = getwmi($ip,$usr,'InstallState,Vendor,Version','Win32Reg_AddRemovePrograms'); # Only available with SMS client, but faster than Win32_Product
				if( $sw ){
					my $nsw = 0;
					foreach my $r ( @{$sw} ){
						misc::Prt("SW  :$r->[0] $r->[3] $r->[2]\n");
						db::Insert('modules','device,slot,model,moddesc,sw,modclass,status',"'$dv','$r->[0]',".$db::dbh->quote(substr($r->[3],0,60)).",".$db::dbh->quote($r->[2]).",'$r->[4]',81,".(($r->[1]==5)?130:129) );
						$nsw++;
					}
					misc::Prt(""," SW$nsw");
				}else{
					misc::Prt("GET :--- Win32_Product ---\n");
					my $sw = getwmi($ip,$usr,'InstallState,Vendor,Version','Win32_Product'); # Fallback to Win32_Product
					if( $sw ){
						my $nsw = 0;
						foreach my $r ( @{$sw} ){
							misc::Prt("SW  :$r->[0] $r->[3] $r->[2]\n");
							db::Insert('modules','device,slot,model,moddesc,sw,modclass,status',"'$dv','$r->[0]',".$db::dbh->quote(substr($r->[3],0,60)).",".$db::dbh->quote($r->[2]).",'$r->[4]',81,".(($r->[1]==5)?130:129) );
							$nsw++;
						}
						misc::Prt(""," SW$nsw");
					}
				}
			}

			if( $opt{'S'} !~ /i/ ){
				db::Delete('interfaces',"device='$dv'");
				misc::Prt("GET :--- Win32_NetworkAdapter ---\n");
				my $nic = getwmi($ip,$usr,'Availability,DeviceID,MACAddress,ProductName,ServiceName,NetConnectionID,Speed','Win32_NetworkAdapter',"AdapterType='Ethernet 802.3' AND ServiceName != 'NdisWan'");
				if( $nic ){
					my $lif  = '-';
					my $spd  = 0;
					foreach my $r ( @{$nic} ){
						if( $r->[2] ){
							$r->[2] =~ s/[:]//g;
							my $nicm = lc $r->[2];
							if( defined $mac and $nicm eq $mac){
								$lif = $r->[1];
								$spd = $r->[6];
							}
							misc::Prt("NIC :$r->[1] $r->[4] $r->[2]\n","n");
							db::Insert('interfaces','device,ifname,ifidx,iftype,ifmac,ifdesc,alias,ifstat,speed',"'$dv','$r->[1]',$r->[1],6,'$nicm','$r->[4]','$r->[5]',".($r->[0]==3?3:2).",".$r->[6]);
							db::Update('nodes',"noduser='$pu'","mac='".lc($r->[2])."'" ) if $opt{'S'} !~ /n/ and $pu and $r->[2];
						}
					}

					if( $opt{'S'} !~ /l/ and defined $nbr ){
						db::WriteLink(	$dv,
								$lif,
								$nbr,
								$nbrif,
								'WMI',
								$spd,
								'',
								'',
								"Constructed by NoDi");
						db::WriteLink(	$nbr,
								$nbrif,
								$dv,
								$lif,
								'WMI',
								$spd,
								'',
								'',
								"Constructed by NoDi");

						misc::Prt(""," LNK:$nbr");
					}
				}
			}

			if( $opt{'S'} !~ /r/ ){
				db::Delete('vlans',"device='$dv'");
				misc::Prt("GET :--- Win32_ServerFeature ---\n");
				my $rls  = getwmi($ip,$usr,'ID,Name','Win32_ServerFeature','ParentID=0');# Get Roles and store as vlans
				if( $rls ){
					my $nrls = 0;
					foreach my $r ( @{$rls} ){
						misc::Prt("ROLE:$r->[0]\t$r->[1]\n");
						db::Insert('vlans','device,vlanid,vlanname',"'$dv',50000+$r->[0],'$r->[1]'" );
						$nrls++;
					}
					misc::Prt(""," ROL$nrls");
				}
			}

			db::Update('nodarp',"srvos='$osde',srvupdate=$now",'nodip='.misc::Ip2Dec($ip) ) unless $opt{'S'} =~ /n/;

			my $dbip = 0;
			$usr = $db::dbh->quote($usr);							# Escape Windows user\domain
			if( $dev{$dv}{'fs'} == $now ){
				db::Insert('devices','device,devip,serial,type,firstdis,lastdis,services,description,devos,bootimage,location,contact,devgroup,devmode,cliport,login,icon,cpu,memcpu,devopts,vendor',
				"'$dv',$dip,'$sn','$ho->[0][2]',$now,$now,96,'$desc','Windows','$osde','$dlo','$pu','$gr',11,135,$usr,'hvms',$cpu->[0][1],$dev{$dv}{'mcp'},'-C','$ho->[0][1]'");
			}else{
				db::Update('devices',"devip=$dip,serial='$sn',type='$ho->[0][2]',lastdis=$now,description='$desc',bootimage='$osde',location='$dlo',devgroup='$gr',login=$usr,cpu=$cpu->[0][1],memcpu=$dev{$dv}{'mcp'},vendor='$ho->[0][1]'","device = '$dv'");
			}
			misc::DevRRD($dv,'tedb') if $misc::rrdcmd and $opt{'S'} !~ /g/;


			delete $dev{$dv};
			misc::Prt("","\n");
		}
	}
}

sub hex2char{

	return '' if $_[0] eq 'NULL';
	$_[0] =~ s/[()]//g;
	my $s = '';
	my @vals = split(',',$_[0]);
	foreach my $v (@vals){
		$s .= chr($v) if $v;
	}
	return $s;
}

sub getwmi{

	my ($ip,$usr,$col,$class,$wopt,$nsopt) = @_;

        my $w = ($wopt)?" WHERE $wopt":"";
        my $n = ($nsopt)? "--namespace=\"root\\$nsopt\" ":"";
        my $l = "$usr%$misc::login{$usr}{pw}";
	$l =~ s/\\/\\\\/;
	$l =~ s/\$/\\\$/;
	misc::Prt("DBG :$wmic -U $l //$ip $n\"select $col from $class$w\"\n") if $opt{'d'};
	my @res = `$wmic -U "$l" //$ip $n"select $col from $class$w"`;
	if( exists $res[0] and $res[0] =~ /CLASS:/ ){
		shift @res;
		shift @res;
		chomp @res;

		my @out = ();
		my $i=0;
		foreach my $l (@res){
			my @r = split('\|',$l);
			foreach my $f (@r){
				push @{$out[$i]}, $f;
			}
			$i++;
		}
		return \@out;
	}else{
		return 0;
	}
}

=head2 FUNCTION DiscoverSSH()

Discover a SSH (Unix) node

B<Options> IP

B<Globals>

B<Returns> -

=cut
sub DiscoverSSH{

	my ($ip,$usr,$mac,$nbr,$nbrif,$loc) = @_;

	misc::Prt('',"$ip $usr \t");
	($cli::session, $cli::status) = cli::Connect($ip,22,$usr,'Unix');

	if( defined $cli::session ){

		my $co  = my $ty = my $sn = my $ven = '-';

		my $dic = 'svan';
		my $dip = misc::Ip2Dec($ip);
		my $dlo = defined $loc?$loc:'-';

		my @r = cli::SendCmd( 'uname -a', 'Unix', '' );
		my @v  = split / /,$r[1];
		my $os = shift @v;
		my $dv = shift @v;
		my $bi = shift @v;
		my $de = join(' ',@v);
		my $gr = substr($dv,-32);

		$dv =~ s/\..*// unless $opt{'F'};
		$gr =~ s/.*?\.//;
		$gr = '' if $dv eq $gr;

		$dev{$dv}{'fs'} = $now unless exists $dev{$dv}{'fs'};
		$dev{$dv}{'cpu'} = 0;
		$dev{$dv}{'mcp'} = 0;
		$dev{$dv}{'cul'} = '';
		$dev{$dv}{'cuv'} = 0;
		$dev{$dv}{'tmp'} = 0;
		misc::Prt("SSH :$dv $os $bi $gr $de\n","$dv\t");
		if( $os eq 'Linux' ){

			@r = cli::SendCmd( 'cat /etc/os-release', 'Unix', '' );
			foreach my $l ( @r ){
				if( $l ){
					misc::Prt("OS  :$l\n") if $opt{'d'};
					my @v = split /=/,$l;
					$v[1] =~ s/"//g if defined $v[1];
					if( $v[0] eq 'ID' ){
						$os = $v[1];
					}elsif( $v[0] eq 'PRETTY_NAME' ){
						$de = "$v[1] $de";
					}
				}
			}
			if( $os eq 'raspbian' ){							# Test for Raspberry with BME280 sensor (modified bme280.py output to only print temperature,pressure,humidity)
				$dic = 'sean';
				$ven = "Raspberry Pi";
				#@r = cli::SendCmd( 'sed -e "s/\x0/\n/" /proc/device-tree/model', 'Unix', '' ); No matter what I do, my RPI3 adds weird Escape-chars to prompt and breaks down
				#@r = cli::SendCmd( 'grep Revision /proc/cpuinfo|cut -c12-', 'Unix', '' );
				#@r = cli::SendCmd( 'awk "/Revision/{print $3}" /proc/cpuinfo', 'Unix', '' );
				#misc::Prt("SSH :$r[1]\n");
				#$ty  = $r[1];
				$ty  = 'RPI';

				@r = cli::SendCmd( 'python tmpprshum.py', 'Unix', '' );
				misc::Prt("SSH :$r[1]\n");
				@v = split / +/,$r[1];
				$dev{$dv}{'mcp'} = $v[2];
				$dev{$dv}{'cul'} = 'Pressure;G;hPa';
				$dev{$dv}{'cuv'} = $v[1];
				$dev{$dv}{'tmp'} = $v[0];

			}else{
				@r = cli::SendCmd( 'vmstat -a 1 2', 'Unix', '' );
				misc::Prt("SSH :vmstat $r[4]\n");
				@v = split / +/,$r[4];
				$dev{$dv}{'cpu'} = 100 - $v[15];
				$dev{$dv}{'mcp'} = $v[5] * 1024;
				$dev{$dv}{'cul'} = 'IO;G;#';
				$dev{$dv}{'cuv'} = $v[9] + $v[10];
				@r = cli::SendCmd( 'cat /sys/class/thermal/thermal_zone0/temp', 'Unix', '' );
				$dev{$dv}{'tmp'} = $r[1] =~ /^\d+$/?$r[1]/1000:0;

				my @r = cli::SendCmd( 'grep --color=never "" /sys/class/dmi/id/*', 'Unix', '' );
				foreach my $l ( @r ){
					my @v = split /:/,$l;
					if( defined $v[1] ){
						misc::Prt("DMI :$v[0]	$v[1]\n") if $opt{'d'};
						if( $v[0] =~ /sys_vendor/ ){
							$ven = $v[1];
						}elsif( $v[0] =~ /product_name/ ){
							$ty = $v[1];
						}elsif( $v[0] =~ /product_serial/ ){
							$sn = substr($v[1],-32);
						}
					}
				}

				if( $opt{'S'} !~ /h/ ){
					db::Delete('modules',"device='$dv'");
					my $ar = my $de = my $sp = '-';
					@r = cli::SendCmd( 'lscpu', 'Unix', '' );
					foreach my $l ( @r ){
						my @v = split /:\s+/,$l;
						if( defined $v[1] ){
							misc::Prt("CPU :$v[0]	$v[1]\n") if $opt{'d'};
							if( $v[0] =~ /Architecture/ ){
								$ar = $v[1];
							}elsif( $v[0] =~ /Model name/ ){
								$de = $v[1];
							}elsif( $v[0] =~ /CPU max MHz/ ){
								$sp = $v[1];
								$sp =~ s/\..*//;
							}
						}
					}
					misc::Prt("CPU :$de $ar\n","c");
					db::Insert('modules','device,slot,model,moddesc,serial,fw,modclass,status',"'$dv','-','$ar','$de','-','$sp MHz',61,128");

					if( $cli::status eq 'OK-enpr' ){
						my $ar = my $ty = my $ve = my $de = my $sn = my $sl = my $sp = my $sz = '-';
						my @r = cli::SendCmd( 'dmidecode --type 17', 'Unix', '' );
						foreach my $l ( @r ){
							my @v = split /: ?/,$l;
							if( defined $v[1] ){
								misc::Prt("MEM :$v[0]	$v[1]\n") if $opt{'d'};
								if( $v[0] =~ /Size/ ){
									$sz = $v[1];
								}elsif( $v[0] =~ /Type$/ and $v[1] !~ /Other|Unknown/ ){
									$ty = $v[1];
								}elsif( $v[0] =~ /Manufacturer/ ){
									$ve = $v[1];
								}elsif( $v[0] =~ /Speed/ ){
									$sp = $v[1];
								}elsif( $v[0] =~ /Bank Locator/ ){
									$sl = $v[1];
								}elsif( $v[0] =~ /Serial Number/ ){
									$sn = substr($v[1],-32);
								}elsif( $v[0] =~ /Part Number/ and $v[1] ne ' [Empty]' and $sz !~ /No Module Installed/ ){
									misc::Prt("MEM :$ve $ty $sz $sp\n","m");
									db::Insert('modules','device,slot,model,moddesc,serial,hw,fw,modclass,status',"'$dv','$sl','$ve','$v[1]','$sn','$sz $ty','$sp',62,128");
								}
							}
						}
					}
				}
			}
		}elsif( $os eq 'VMkernel' ){
			$dic = 'hvvw';
			@r = cli::SendCmd( 'esxcfg-info -w -F perl|head -8', 'Unix', '' );
			foreach my $l ( @r ){
				if( $l =~ /=>/ ){
					if( $l =~ /product_name/ ){
						$ty = $l;
						$ty =~ s/ +product_name => "|",//g;
					}elsif( $l =~ /vendor_name/ ){
						$ven = $l;
						$ven =~ s/ +vendor_name => "|",//g;
					}elsif( $l =~ /serial_number/ ){
						$sn = $l;
						$sn =~ s/ +serial_number => "|",//g;
					}
				}
			}
		}elsif( $os =~ /(Net|Open)BSD/ ){
			my @r = cli::SendCmd( '/sbin/sysctl kern.osrelease kern.osrevision hw', 'Unix', '' );
			foreach my $l ( @r ){
				my @v = split /=/,$l;
				if( defined $v[1] ){
					misc::Prt("DBGS:$v[0]	$v[1]\n") if $opt{'d'};
					if( $v[0] =~ /hw.vendor/ ){
						$ven = $v[1];
					}elsif( $v[0] =~ /kern.osrelease/ ){
						$bi = $v[1];
					}elsif( $v[0] =~ /kern.osrevision/ ){
						$bi .= "-$v[1]";
					}elsif( $v[0] =~ /hw.product/ ){
						$ty = $v[1];
					}elsif( $v[0] =~ /hw.uuid/ ){
						$sn = substr($v[1],-32);
					}
				}
			}
		}

		misc::Prt("SSH :$os $bi\n");

		db::Update('nodarp',"srvos='$os',srvupdate=$now",'nodip='.misc::Ip2Dec($ip) ) unless $opt{'S'} =~ /n/;
		if( $dev{$dv}{'fs'} == $now ){
			db::Insert('devices','device,devip,serial,type,firstdis,lastdis,services,description,devos,bootimage,location,contact,devgroup,devmode,cliport,login,icon,cpu,memcpu,temp,cusvalue,cuslabel,devopts,vendor',
			"'$dv',$dip,'$sn','$ty',$now,$now,96,'$de','$os','$bi','$dlo','$co','$gr',10,22,'$usr','$dic','$dev{$dv}{cpu}','$dev{$dv}{mcp}','$dev{$dv}{tmp}','$dev{$dv}{cuv}','$dev{$dv}{cul}','-C','$ven'");
		}else{
			db::Update('devices',"devip=$dip,serial='$sn',type='$ty',lastdis=$now,devos='$os',description='$de',bootimage='$bi',location='$dlo',devgroup='$gr',login='$usr',cpu='$dev{$dv}{cpu}',memcpu='$dev{$dv}{mcp}',temp='$dev{$dv}{tmp}',vendor='$ven'","device = '$dv'");
		}

		misc::DevRRD($dv,'tedb') if $misc::rrdcmd and $opt{'S'} !~ /g/;

		delete $dev{$dv};
		misc::Prt("","\n");
	}else{
		misc::Prt("$cli::status\n"," $cli::status");
	}
}

=head2 FUNCTION HELP_MESSAGE()

Display some help

B<Options> -

B<Globals> -

B<Returns> -

=cut
sub HELP_MESSAGE{
	print "\n";
	print "usage: nodi.pl <Option(s)>\n\n";
	print "---------------------------------------------------------------------------\n";
	print "Options:\n";
	print "-d opt	b=basic debug,d=DB queries\n";
	print "-v	verbose output\n";
	print "-F 	Use domain and name\n";
	print "-N opt	ip or range, e.g. 1.1.3,7.10-99\n";
	print "-O cond	Use IPs from DB, e.g. -O\"inet_ntoa(nodip)='1.2.3.4'\"\n";
	print "-A cond	Add devices from DB all or e.g.\"loc LIKE 'here%'\"\n";
	print "-u user	Use specified username\n";
	print "-U file	Use specified configuration\n";
	print "-S opt	Skip w=WMI u=Unix h=HW s=SW v=VM r=roles l=links i=interfaces g=devrrd\n";
	print "\tn=node update\n";
	print "-t opt	Test only s=seeds a=access i=info\n\n";
	print "Output Legend =============================================================\n";
	print "Dx	Discover i=IP in DB c=CPU m=Mem\n";
	print "---------------------------------------------------------------------------\n";
	print "(C) 2018 NeDi Consulting GmbH\n\n";
	exit;
}
