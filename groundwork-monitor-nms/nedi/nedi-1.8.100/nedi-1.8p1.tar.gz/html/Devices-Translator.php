<?php
# Program: Devices-Translator
# Programmer: Remo Rickli

$exportxls = 0;

include_once ("inc/header.php");
include_once ("inc/libdev.php");

$_GET = sanitize($_GET);
$in = isset($_GET['in']) ? $_GET['in'] : array();
$op = isset($_GET['op']) ? $_GET['op'] : array();
$st = isset($_GET['st']) ? $_GET['st'] : array();

$eid = isset($_GET['eid']) ? $_GET['eid'] : 0;
$dei = isset($_GET['dei']) ? $_GET['dei'] : 0;
$sdv = isset($_GET['sdv']) ? $_GET['sdv'] : '';
$oty = isset($_GET['oty']) ? $_GET['oty'] : '';
$tgr = isset($_GET['tgr']) ? $_GET['tgr'] : array();

$styp = isset($_GET['ty']) ? $_GET['ty'] : '';
$tgrp = isset($_GET['gr']) ? $_GET['gr'] : '';
$ctxt = isset($_GET['ct']) ? $_GET['ct'] : '';
$scfg = isset($_GET['sc']) ? $_GET['sc'] : '';
$trpr = isset($_GET['pr']) ? $_GET['pr'] : '';
$dcfg = isset($_GET['dc']) ? $_GET['dc'] : '';

$ed  = isset($_GET['ed']) ? $_GET['ed'] : 0;
$upd = isset($_GET['upd']) ? $_GET['upd'] : 0;
$del = isset($_GET['del']) ? $_GET['del'] : 0;
$add = isset($_GET['add']) ? 1 : 0;
$upb = isset($_GET['upb']) ? 1 : 0;
$clf = ($add or $upb)?1:0;

$cols = array(	"srctype"=>"$srclbl $typlbl",
		"tgtgroup"=>"$tgtlbl $grplbl",
		"context"=>"$cfglbl $ctxlbl",
		"srccfg"=>"$srclbl $cfglbl",
		"dstcfg"=>"$dstlbl $cfglbl",
		"usrname"=>$usrlbl,
		"time"=>$timlbl,
		);

$link = DbConnect($dbhost,$dbuser,$dbpass,$dbname);
?>
<h1><?= $cfglbl ?> <?= $tralbl ?> </h1>

<?php  if( !isset($_GET['print']) ){ ?>
<?php  if( $sdv ){ ?>
<table class="content"><tr class="bgmain">
<td class="ctr s">
	<a href="<?= $self ?>.php"><img src="img/32/<?= $selfi ?>.png" title="<?= $self ?>"></a>
</td>
<td class="b">

	<h3><?= $srclbl ?>: <?= $sdv ?></h3>

</td>
<td>
	<form method="get" action="<?= $self ?>.php">
		<input type="hidden" name="sdv"  value="<?= $sdv ?>">
<?php
	$res = DbQuery( $link,'configs','s','config,devip,type,location,contact,devgroup','','',array('device'),array('='),array($sdv),array(),'LEFT JOIN devices USING (device)' );
	$src = DbFetchArray($res);
	DbFreeResult($res);

	$res = DbQuery( $link,'translations','s','distinct tgtgroup','tgtgroup','',array('srctype'),array('='),array($src['type']) );
	echo "\t\t<select multiple name=\"tgr[]\" size=\"6\" onchange=\"this.form.submit();\">\n";
	echo "\t\t\t<option disabled value=\"\">- $tgtlbl $grplbl -";
	while( ($r = DbFetchRow($res)) ){
		echo "	\t\t\t<option value=\"$r[0]\"".(in_array($r[0],$tgr)?" selected":"").">$r[0]\n";
	}
	echo "\t\t</select>\n";
	DbFreeResult($res);
?>
	</form>
</td>
<td>
<?php // Place custom notifications here:
	$res = DbQuery( $link,'nodes','s','distinct ifname','','',array('oui','pvid','device'),array('like','=','='),array('AVM%','999',$sdv),array('AND','AND'), 'LEFT JOIN interfaces USING (device,ifname)' );
	while( ($if = DbFetchArray($res)) ){
		echo "<h4>Fritzbox on $porlbl $if[ifname] with PVID 999</h4>";
	}
	DbFreeResult($res);

	if( $src['type'] == 'ES-2024A' ){
		$res = DbQuery( $link,'interfaces','s','ifname,ifstat','','',array('device','ifname'),array('=','regexp'),array($sdv,'^swp2[23]$'),array('AND') );
		while( ($if = DbFetchArray($res)) ){
			if( $if['ifstat'] == 3 ) echo "<h4>$porlbl $if[ifname] = $stco[100]</h4>";
		}
		DbFreeResult($res);
	}
?>
</td>
<td>
<?php
if( $tgr ){
	$dbvp = 0;
	$res  = DbQuery( $link,'translations','s','id,context,srccfg,dstcfg,tropts','context,tropts','',array('srctype','tgtgroup'),array('=','~'),array($src['type'],implode("|",$tgr)),array('AND') );
	while( ($r = DbFetchRow($res)) ){
		$d = str_replace("\r",'',$r[3]);
		$p = substr($r[4],0,1);									# Attach group to rule for sorting, also used as context list
		$trpri[$r[1]][$r[2]][$r[0]] = $p;
		if( $r[2] == 'VLANNAMES' ){								# Global DB based translation
			$vres = DbQuery( $link,'vlans','s','vlanid,vlanname','','',array('device'),array('='),array($sdv) );
			while( ($v = DbFetchRow($vres)) ){
				if( !isset($cfgarr[$p]) ) $cfgarr[$p] = '';				# avoid notice in debug mode
				$cfgarr[$p] .= str_replace('%VLID%',$v[0],str_replace('%VLANNAME%',$v[1],$d));
			}
			DbFreeResult($vres);
		}elseif( $r[2] == 'VLPORT-UNTAG' ){
			$dbvp = 1;
			$trpu[$r[1]] = $d;
		}elseif( $r[2] == 'VLPORT-TAG' ){
			$dbvp = 1;
			$trpt[$r[1]] = $d;
		}elseif( $r[2] == 'VLCONTEXT-TAG' ){
			$trpt[$r[1]] = $d;
		}elseif( strpos($r[2], 'VLPORT-TAG-COPY') === 0 ){
			foreach( explode(',',$r[3]) as $d ){
				$vlcp[$d] = substr($r[2],16);
			}
#		}elseif( $r[1] and is_numeric($r[2]) ){							# Context # of lines match
#			$trcl[$r[1]] = [$r[2]];
#			echo "--$r[1]-- ";
		}else{
			$tr[$r[1]][$r[2]][$r[0]] = $d;							# Translate rule by context and source
		}
	}
	DbFreeResult($res);

	if( $dbvp ){
		$res = DbQuery( $link,'vlanport','s','*','','',array('device'),array('='),array($sdv) );
		while( ($r = DbFetchRow($res)) ){
			if( $r[3] == 'U' ){
				$pvlu[$r[1]] = $r[2];
			}elseif( $r[3] == 'T' ){
				$pvlt[$r[1]][$r[2]] = 1;
			}
		}
		DbFreeResult($res);
	}

	$line  = 0;
	$warn  = '';
	$cttyp = '';
	$ctnam = '';
	$ctpri = '';
	$config = explode("\n",$src['config']);
	foreach ( $config as $l ){
		$match = 0;
		if( $cttyp and strpos($l,' ') === 0 ){							# Space at beginning, we're in a context, only enter if cttyp is set
			foreach( array_keys($tr[$cttyp]) as $s ){
				$curpri = $ctpri;
				$ctft = explode('_&&_',$s);						# Split context filter
				if( !isset($ctft[1]) ){
					$ctft[1] = '';							# Avoid notice in debug mode
				}elseif( $ctft[1] == 'USEPRI' ){					# Use priority from rule, not context
					$ctft[1] = '';
					$curpri = '';
				}
				if( !$ctft[1] or preg_match($ctft[1],$ctnam) ){				# None or matching conext filter
					if( is_numeric($ctft[0]) ){					# Context # of lines match, not regexp
						if( $ctlin ){						# Keep match if $ctlin=TRUE to avoid wildcard duplicates
							$match = 1;
						}else{
							$cl = $line;
							while( strpos($config[$cl],' ') === 0 ){	# Get context # of lines
								$cl++;
							}
							if ( $ctft[0] == ($cl-$line) ){
								foreach ( array_keys($tr[$cttyp][$s]) as $i ){
									$cfgarr[$curpri] .= $tr[$cttyp][$s][$i]."\n";
								}
								$ctlin = 1;				# Only apply once per context
								$match = 1;
							}
						}
					}elseif( preg_match($ctft[0],$l) ){
						foreach ( array_keys($tr[$cttyp][$s]) as $i ){		# Iterate through rules with same source
							if(!$curpri) $curpri = $trpri[$cttyp][$s][$i];
							if( $tr[$cttyp][$s][$i] == 'VLCONTEXT-TAG-ADD' ){
								PortVlans(preg_replace($s,'$1',$l),$ctnam,1);
							}elseif( $tr[$cttyp][$s][$i] == 'VLCONTEXT-TAG-DEL' ){
								PortVlans(preg_replace($s,'$1',$l),$ctnam,0);
							}else{
								if( !isset($cfgarr[$curpri]) ) $cfgarr[$curpri] = '';
								$cfgarr[$curpri] .= ProTrans($ctft[0],$tr[$cttyp][$s][$i],$l);
							}
						}
						$match = 1;
					}
				}
			}
		}else{
			$cttyp = '';									# Clear context
			$ctpri = '';
			$match = 0;
			$fndct = substr($l,0,strpos($l,' '));
			if( $fndct and isset($trpri[$fndct]) ){						# $tpri contains contexts only using VLPORT as well
				$cttyp = $fndct;							# Set it for next line in translation
				$ctnam = substr($l,strpos($l,' ')+1);					# Set general context name by using 2nd word
				foreach ( array_keys($tr['']) as $s ){					# Search translations for setting context name
					if( strpos($s,"$cttyp ") == 1 ){				# Got it (with space before and after)
						if( strpos($s,'(') and preg_match($s,$l) ){		# Source match must have () to set $1
							$ctnam = preg_replace($s,'$1',$l);		# Set general context name using translation for more accuracy (e.g. fix inconsisten IF names)
							$ctpri = $trpri[''][$s][key($tr[''][$s])];	# Set group for sorting
							$nl = preg_replace($s,$tr[''][$s][key($tr[''][$s])],$l)."\n";
							if( !isset($cfgarr[$ctpri]) ) $cfgarr[$ctpri] = '';
							$cfgarr[$ctpri] .= $nl;//.$cttyp.$ctnam
							if( !isset($nlcount[$nl]) ) $nlcount[$nl] = 0;	# Avoid notice in debug mode
							$nlcount[$nl]++;
							if( $nlcount[$nl] > 1 ) $warn .= "$mullbl $vallbl: $nl\n";
							$ctlin = 0;					# Reset context # of lines match
							$match = 1;
						}
					}
				}
				if( isset($trpu[$cttyp]) and isset($pvlu[$ctnam]) ){			# Contextual DB based translation
					if( !isset($cfgarr[$ctpri]) ) $cfgarr[$ctpri] = '';
					$cfgarr[$ctpri] .= str_replace('%VLID%',$pvlu[$ctnam],$trpu[$cttyp])."\n";//.$cttyp.$ctnam
				}
				if( isset($trpt[$cttyp]) and isset($vlcp[$ctnam])  and count(array_keys($pvlt[$vlcp[$ctnam]])) ){
					if( !isset($cfgarr[$ctpri]) ) $cfgarr[$ctpri] = '';
					ksort($pvlt[$vlcp[$ctnam]]);
					$cfgarr[$ctpri] .= str_replace('%VLID%',implode(',',array_keys($pvlt[$vlcp[$ctnam]])),$trpt[$cttyp])."\n";
				}elseif( isset($trpt[$cttyp]) and isset($pvlt[$ctnam]) and count(array_keys($pvlt[$ctnam])) ){
					if( !isset($cfgarr[$ctpri]) ) $cfgarr[$ctpri] = '';
					ksort($pvlt[$ctnam]);
					$cfgarr[$ctpri] .= str_replace('%VLID%',implode(',',array_keys($pvlt[$ctnam])),$trpt[$cttyp])."\n";
				}
			}
			if( !$match ){										# Global config
				foreach ( array_keys($tr['']) as $s ){
					if( strpos($s,'_&&_') ) $warn .= "$srclbl '$s' $woulbl $ctxlbl\n";
					if( $s != '*' and preg_match($s,$l) ){
						foreach ( array_keys($tr[''][$s]) as $i ){		# Iterate through rules with same source
							if( !isset($cfgarr[$trpri[''][$s][$i]]) ) $cfgarr[$trpri[''][$s][$i]] = '';
							$cfgarr[$trpri[''][$s][$i]] .= ProTrans($s,$tr[''][$s][$i],$l);
						}
						$match = 1;
					}
				}
			}
		}
		if( !$match and isset($tr['']['*']) ){
			foreach ( array_keys($tr['']['*']) as $i ){
				$cfgarr[$trpri['']['*'][$i]] .= "$l\n";
			}
		}
		$line++;
	}
	ksort($cfgarr);
	$out = "$sdv-".time();
	$cfgstr = implode(array_values($cfgarr));
?>
</td>
<td class="ctr s">
	<form method="POST" action="System-Files.php" name="trns">
		<input type="hidden" name="typ"  value="tft">
		<input type="hidden" name="file" value="<?= $out ?>.cfg">
		<input type="hidden" name="txt"  value="<?= htmlspecialchars($cfgstr) ?>">
		<input type="submit" class="button" name="trf" value="<?= $wrtlbl ?>">
	</form>
<?php  } ?>
</td>
</tr>
</table>
<?php  }else{ ?>
<form method="GET" action="<?= $self ?>.php">
<table class="content"><tr class="bgmain">
<td class="ctr s">
	<a href="<?= $self ?>.php"><img src="img/32/<?= $selfi ?>.png" title="<?= $self ?>"></a>
</td>
<td class="top">
	<h3><?= $fltlbl ?></h3>

	<?php Filters(1); ?>
</td>
<td class="top nw">
	<h3><?= $cndlbl ?></h3>

	<img src="img/16/abc.png"> <input type="text" name="ty" value="<?= $clf?'':$styp ?>" placeholder="<?= $typlbl ?>" class="m"><br>
	<img src="img/16/ugrp.png"> <input type="text" name="gr" value="<?= $clf?'':$tgrp ?>" placeholder="<?= $grplbl ?>" class="m"><br>
<?php if( isset($_GET['pdu']) ){ ?>
</td>
<td class="ctr s">
	<input type="hidden" name="oty" value="<?= $styp ?>">
	<input type="submit" class="button" value="<?= $coplbl ?>">
<?php }else{ ?>
	<img src="img/16/cntx.png"> <input type="text" name="ct" value="<?= $clf?'':$ctxt ?>" placeholder="<?= $ctxlbl ?>" class="m">
</td>
<td class="top nw">
	<h3><?= $tralbl ?></h3>

	<img src="img/16/bbl2.png"> <input type="text" name="sc" value="<?= $clf?'':htmlspecialchars($scfg) ?>" placeholder="<?= $srclbl ?>" class="l">
	<select name="pr" title="<?= $prilbl ?>">
<?php
	$prchk = $clf?'':$trpr;
	for($i=65;$i<91;$i++){
		$ch = chr($i);
		echo "\t\t<option value=\"$ch\"".(($prchk==$ch)?" selected":"").">$ch\n";
	}
?>
	</select><br>
	<img src="img/16/bbr2.png" class="top">
	<textarea rows="3" name="dc" cols="40" placeholder="<?= $dstlbl ?>"><?= $clf?'':htmlspecialchars($dcfg) ?></textarea>
</td>
<td class="ctr s">
	<input type="submit" class="button" value="<?= $sholbl ?>">
	<input type="submit" class="button" name="del" value="<?= $dellbl ?>" onclick="return confirm('<?= $dellbl ?> (<?= $in[0] ?> <?= $op[0] ?> <?= $st[0] ?>), <?= $cfmmsg ?>')">
<?php  if( $ed ){ ?>
	<input type="hidden" name="upd" value="<?= $ed ?>">
	<input type="submit" name="upb" class="button" value="<?= $updlbl ?>">
<?php  }else{ ?>
	<input type="submit" class="button" name="add" value="<?= $addlbl ?>">
<?php  } ?>
<?php } ?>
</td>
</tr>
</table>
</form>
<?php } ?>
<p>

<?php
}
if ( $add ){
	if( $ac == 'S' ) $rp = 0;
	if( !DbQuery($link,'translations','i','','','',
		array('srctype','tgtgroup','context','srccfg','tropts','dstcfg','usrname','time'),
		array(),
		array($styp,$tgrp,$ctxt,$scfg,$trpr,$dcfg,$_SESSION['user'],time() )
	) ){
		echo "<h4>".DbError($link)."</h4>";
	}else{
		echo "<h5>$tgtlbl $addlbl</h5>";
	}
}elseif( $upd and $upb ){
		if( !DbQuery($link,'translations','u','','','',array('id'),array($upd),array(srctype,tgtgroup,context,srccfg,tropts,dstcfg,usrname,time),array($styp,$tgrp,$ctxt,$scfg,$trpr,$dcfg,$_SESSION['user'],time())) ){echo "<h4>".DbError($link)."</h4>";}else{echo "<h5>$updlbl #$upd</h5>";}
}elseif($dei){
		if( !DbQuery($link,'translations','d','','','',array('id'),array('='),array($dei)) ){echo "<h4>".DbError($link)."</h4>";}else{echo "<h5>$dellbl #$dei</h5>";}
}elseif( $oty ){
	echo "<h2>$addlbl $styp / $tgrp</h2>\n";

	echo "<div class=\"textpad code pre txtb half\">\n$coplbl: ";
	$res = DbQuery( $link,'translations','s','tgtgroup,context,srccfg,tropts,dstcfg','tropts','',array('srctype'),array('='),array($oty) );
	while( ($r = DbFetchRow($res)) ){
		if( !DbQuery($link,'translations','i','','','',
			array('srctype','tgtgroup','context','srccfg','tropts','dstcfg','usrname','time'),
			array(),
			array($styp,$tgrp,$r[1],$r[2],$r[3],$r[4],$_SESSION['user'],time() )
		) ){
			echo DbError($link);
		}else{
			echo '.';
		}
	}
	echo "</div>\n";

}elseif($del){
	if( !DbQuery($link,'translations','d','','','',$in,$op,$st) ){echo "<h4>".DbError($link)."</h4>";}else{echo "<h5>$dellbl $ina[0] $op[0] $st[0]</h5>";}
}elseif($sdv and $tgr){

	echo "<h2>$out</h2>\n";

	if( $debug ){
		echo "<div class=\"textpad code pre txtb tqrt\">\n";

		echo "Translations ----------------------------------------------\n";
		print_r($tr);

		echo "\nPort Vlan Tagged ------------------------------------------\n";
		print_r($pvlt);

		echo "\nConfiguration ---------------------------------------------\n";
		print_r($cfgarr);
		echo "</div>\n";
	}

	if( $warn ){
		echo "<div class=\"textpad code pre warn half\">$warn\n";
		echo "</div>\n";
	}

	echo "<div class=\"textpad code pre txta tqrt\">\n";
	$lnr = 0;
	foreach ( explode("\n",$cfgstr) as $cl ){
		$lnr++;
		echo Shoconf($cl,1,$lnr);
	}
	echo "</div>\n";
}

if( count($in) ){
	Condition($in,$op,$st);
?>

<table class="content">
	<tr class="bgsub">
		<th>
			<img src="img/16/key.png"><br>
			Id
		</th>
		<th>
			<img src="img/16/abc.png"><br>
			<?= $srclbl ?> <?= $typlbl ?>

		</th>
		<th>
			<img src="img/16/ugrp.png"><br>
			<?= $tgtlbl ?> <?= $grplbl ?>

		</th>
		<th>
			<img src="img/16/cntx.png"><br>
			<?= $ctxlbl ?>

		</th>
		<th>
			<img src="img/16/bbl2.png"><br>
			<?= $srclbl ?>

		</th>
		<th>
			<img src="img/16/bbr2.png"><br>
			<?= $dstlbl ?>

		</th>
		<th>
			<img src="img/16/user.png"><br>
			<?= $usrlbl ?>

		</th>
		<th>
			<img src="img/16/cog.png"><br>
			<?= $cmdlbl ?>

		</th>
	</tr>
<?php
	$res = DbQuery( $link,'translations','s','*','srctype,tgtgroup,context,tropts','',$in,$op,$st );

	$pty = '';
	$row = 0;
	$flt = "?in[]=$in[0]&op[]=$op[0]&st[]=".urlencode($st[0]);
	while( ($r = DbFetchRow($res)) ){
		if ($row % 2){$bg = "txta"; $bi = "imga";}else{$bg = "txtb"; $bi = "imgb";}
		$row++;

		$ut = urlencode($r[1]);
		$ug = urlencode($r[2]);
		$uc = urlencode($r[3]);
		$us = urlencode($r[4]);
		$ud = urlencode($r[5]);

		list($fc,$lc) = Agecol($r[8],$r[8],$row % 2);

		TblRow($bg);
		TblCell( $r[0],'',"$bi ctr" );
		TblCell( $r[1],"?in[]=srctype&op[]=%3D&st[]=$ut" );
		TblCell( $r[2],"?in[]=tgtgroup&op[]=%3D&st[]=$ug" );
		TblCell( $r[3],"?in[]=context&op[]=%3D&st[]=$uc" );
		TblCell( '<div class="imgb code pre">'.$r[4].'</div>' );
		TblCell( '<div class="imgb code pre"><span class="frgt gry">'.$r[6].'</span>'.$r[5].'</div>' );
		TblCell( $r[7],"?in[]=usrname&op[]=%3D&st[]=$r[7]",'','',"background-color:#$fc" );
		echo "\t\t<td class=\"rgt nw\">\n";
		if( $pty != $r[1]){
			echo "\t\t\t<a href=\"Devices-List.php?in[]=type&op[]==&st[]=$ut&col[]=device&col[]=devip&col[]=config&col[]=time\"><img src=\"img/16/dev.png\" title=\"$typlbl $lstlbl\"></a>\n";
			echo "\t\t\t<a href=\"?pdu=1&ty=$ut&gr=$ug\"><img src=\"img/16/abc.png\" title=\"$coplbl $srclbl $typlbl\"></a>\n";
		}
		echo "\t\t\t<a href=\"$flt&ed=$r[0]&ty=$ut&gr=$ug&ct=$uc&sc=$us&pr=$r[6]&dc=$ud\"><img src=\"img/16/note.png\" title=\"$edilbl\"></a>\n";
		echo "\t\t\t<a href=\"$flt&ty=$ut&gr=$ug&ct=$uc&sc=$us&pr=$r[6]&dc=$ud\"><img src=\"img/16/copy.png\" title=\"$coplbl\"></a>\n";
		echo "\t\t\t<a href=\"$flt&dei=$r[0]\"><img src=\"img/16/bcnl.png\" title=\"$dellbl #$r[0]\" onclick=\"return confirm('$dellbl #$r[0], $cfmmsg')\"></a>\n";
		echo "\t\t</td>\n\t</tr>\n";
		$pty = $r[1];
	}
	DbFreeResult($res);

	TblFoot("bgsub", 9, "$row $vallbl");
}elseif( $_SESSION['opt'] and !$sdv ){
	include_once ("inc/librep.php");
	DevTranslation($in[0],$op[0],$st[0],$_SESSION['lim'],'');
}

include_once ("inc/footer.php");


//===================================================================
// Create port vlan listy
function PortVlans($s,$v,$o){

        global $pvlt,$warn,$porlbl, $notlbl, $numlbl,$ctxlbl,$nonlbl,$namlbl;

	$s = trim($s);
	$v = trim($v);
	if( strpos($s,',') ){
		foreach(explode(',',$s) as $i){
			PortVlans($i,$v,$o);
		}
	}elseif( strpos($s,'-') ){
		$r = explode('-',$s);
		for($i = $r[0]; $i <= $r[1]; ++$i) {
			PortVlans($i,$v,$o);
		}
	}elseif( !$v ){
		$warn .=  "$nonlbl $ctxlbl $namlbl ($s)\n";
	}elseif( is_numeric($s) ){
		if( $o ){
			if( !(isset($pvlt[$s][$v]) and $pvlt[$s][$v] > 1) ) $pvlt[$s][$v] = $o;
		}elseif( !(isset($pvlt[$s][$v]) and $pvlt[$s][$v] == 2) ){
			unset( $pvlt[$s][$v] );
		}
        }else{
		$warn .=  "$porlbl $s $notlbl $numlbl\n";
	}
}

//===================================================================
// Collapse vlan list on interface
function CollapseVlans($i){

	global $pvlt;

}

//===================================================================
// Process actual translation
function ProTrans($s,$d,$l){

	global $src;

	if( strpos($d,"%DEVIP%") ){
		return str_replace('%DEVIP%',long2ip($src['devip']),$d);
	}elseif( strpos($d,'%LOCATION%') ){
		return str_replace('%LOCATION%',$src['location'],$d);
	}elseif( strpos($d,'%CONTACT%') ){
		return str_replace('%CONTACT%',$src['contact'],$d);
	}elseif( strpos($d,'%DEVGROUP%') ){
		return str_replace('%DEVGROUP%',$src['devgroup'],$d);
	}elseif( strpos($d,'hostname_') === 0 ){							# Customer specific example where spaces in a hostname are replaced by _ and put in single quotes (put dest = hostname_')
		$h = preg_replace($s,'$1',$l);
		$q = substr($d,-1);
		$d = str_replace(' ','_',$h);
		return "hostname $q$d$q\n";
	}elseif( strpos($d,'%PPPOEVLAN%') ){								# Customer specific example how a Vlan is mapped to the device group

		$pppoe['POP1'] = 102;
		$pppoe['POP2'] = 202;
		$pppoe['POP5'] = 502;
		$pppoe['POP7'] = 702;
		$pppoe['POP8'] = 802;
		$pppoe['POP9'] = 902;
		$pppoe['POP11'] = 1102;
		$pppoe['POP12'] = 1202;
		$pppoe['POP12'] = 1303;
		$pppoe['POP100'] = 2529;
		$pppoe['POP101'] = 2523;
		$pppoe['POP104'] = 2521;
		$pppoe['POP106'] = 2520;
		$pppoe['POP107'] = 2527;
		$pppoe['POP108'] = 2526;
		$pppoe['POP109'] = 2525;
		$pppoe['POP110'] = 2528;
		$pppoe['POP111'] = 2510;
		$pppoe['POP112'] = 2511;
		$pppoe['POP113'] = 2512;
		$pppoe['POP114'] = 2513;
		$pppoe['POP115'] = 2514;
		$pppoe['POP116'] = 2537;
		$pppoe['POP50'] = 2541;
		$pppoe['POP17'] = 1535;
		$pppoe['POP19'] = 2530;
		$pppoe['POP20'] = 2531;
		$pppoe['POP21'] = 2535;

		return str_replace('%PPPOEVLAN%',$pppoe[$src['devgroup']],$d);
	}else{
		return preg_replace($s,$d,$l)."\n";
	}
}

?>
