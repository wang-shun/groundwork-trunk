<?php
# Program: Devices-Write.php
# Programmer: Remo Rickli

$exportxls = 0;

include_once ("inc/header.php");
include_once ("inc/libdev.php");

$_GET = sanitize($_GET);
$in = isset($_GET['in']) ? $_GET['in'] : array();
$op = isset($_GET['op']) ? $_GET['op'] : array();
$st = isset($_GET['st']) ? $_GET['st'] : array();
$co = isset($_GET['co']) ? $_GET['co'] : array();

$_POST = sanitize($_POST);
$in = isset($_POST['in']) ? $_POST['in'] : $in;
$op = isset($_POST['op']) ? $_POST['op'] : $op;
$st = isset($_POST['st']) ? $_POST['st'] : $st;
$co = isset($_POST['co']) ? $_POST['co'] : $co;
$dl = isset($_POST['dl']) ? $_POST['dl'] : "";
$do = isset($_POST['do']) ? $_POST['do'] : "";

$cmd = isset( $_POST['cmd']) ? $_POST['cmd'] : "";
$int = isset( $_POST['int']) ? $_POST['int'] : "";
$pwd = isset( $_POST['pwd']) ? $_POST['pwd'] : "";

$ssub = isset( $_POST['ssub']) ? $_POST['ssub'] : "";
$esub = isset( $_POST['esub']) ? $_POST['esub'] : "";
$sint = isset( $_POST['sint']) ? $_POST['sint'] : 1;
$eint = isset( $_POST['eint']) ? $_POST['eint'] : 1;
$emod = isset( $_POST['emod']) ? $_POST['emod'] : 0;
$smod = isset( $_POST['smod']) ? $_POST['smod'] : 0;
$icfg = isset( $_POST['icfg']) ? $_POST['icfg'] : "";

$cols = array(	"device"=>" $devlbl $namlbl",
		"devip"=>"$manlbl $adrlbl",
		"origip"=>"$orilbl $adrlbl",
		"serial"=>$serlbl,
		"vendor"=>$venlbl,
		"type"=>$typlbl,
		"services"=>$srvlbl,
		"description"=>$deslbl,
		"devos"=>$osylbl,
		"bootimage"=>$boolbl,
		"location"=>$loclbl,
		"contact"=>$conlbl,
		"devgroup"=>$grplbl,
		"devmode"=>$modlbl,
		"snmpversion"=>"SNMP $verlbl",
		"readcomm"=>"SNMP $realbl",
		"cliport"=>"CLI $porlbl",
		"login"=>$usrlbl,
		"firstdis"=>"$fislbl $dsclbl",
		"lastdis"=>"$laslbl $dsclbl",
		"cfgstatus"=>"$cfglbl $stalbl",
		"config"=>"$cfglbl",
		"changes"=>"$chglbl"
		);
?>
<h1><?= $devlbl ?> <?= $wrtlbl ?></h1>

<form method="post" name="list" action="<?= $self ?>.php">
<table class="content">
<tr class="bgmain">
<td class="ctr s">
	<a href="<?= $self ?>.php"><img src="img/32/<?= $selfi ?>.png" title="<?= $self ?>"></a>
</td>
<td>
<?php Filters(); ?>
</td>
<td class="ctr">
	<textarea rows="4" name="dl" cols="60" placeholder="<?= $devlbl ?>"><?= $dl ?></textarea>
</td>
</tr><tr class="bgsub">
<td class="s">
</td>
<td class="top ctr b">

	<h3><?= $cmdlbl ?> / <?= $cfglbl ?></h3>

	<textarea rows="6" name="cmd" cols="60"><?= $cmd ?></textarea>
</td>
<td class="top ctr b">

	<h3><?= $intlbl ?> <?= $cfglbl ?></h3>

	<select size="1" name="int">
		<option value=""><?= $sellbl ?> ->
		<option value="Et" <?php if($int == "Et"){echo "selected";} ?>>Ethernet
		<option value="Fa" <?php if($int == "Fa"){echo "selected";} ?>>Fastethernet
		<option value="Gi" <?php if($int == "Gi"){echo "selected";} ?>>Gigabit
		<option value="Te" <?php if($int == "Te"){echo "selected";} ?>>TenGigabit
		<option value="Vi" <?php if($int == "Vi"){echo "selected";} ?>>Vlan IF
		<option value="Vl" <?php if($int == "Vl"){echo "selected";} ?>>Vlan
	</select>
	   <input type="number" class="xs" name="smod" value="<?= $smod ?>" OnFocus="select();">
	 / <input type="number" class="xs" name="sint" value="<?= $sint ?>" OnFocus="select();">
	 / <input type="number" class="xs" name="ssub" value="<?= $ssub ?>" OnFocus="select();">
	 - <input type="number" class="xs" name="emod" value="<?= $emod ?>" OnFocus="select();">
	 / <input type="number" class="xs" name="eint" value="<?= $eint ?>" OnFocus="select();">
	 / <input type="number" class="xs" name="esub" value="<?= $esub ?>" OnFocus="select();">
	<p>
	<textarea rows="4" name="icfg" cols="60"><?= $icfg ?></textarea>
</td>
</tr><tr class="bgmain">
<td class="top ctr b" colspan="3">
<?php
if ( strstr($guiauth,'-pass') ){
?>
	Password <input type="password" value="<?= $pwd ?>" name="pwd">
<?php
}
?>
	<select size="1" name="do">
		<option value=""><?= $sholbl ?>

		<option value="cmd" <?php if($do == "cmd"){echo "selected";} ?>><?= $cmdlbl ?>

		<option value="cfg" <?php if($do == "cfg"){echo "selected";} ?>><?= $cfglbl ?>

		<option value="cfb" <?php if($do == "cfb"){echo "selected";} ?>><?= $cfglbl ?> & <?= $buplbl ?>

	</select>
	<input type="submit" class="button" value="<?= $sttlbl ?>">
</td>
</tr></table>
</form>
<p>

<?php
ob_end_flush();
session_write_close();
if( count($in) ){
	if( $dl and $in[0] == 'device' and $op[0] == '~' and $co[0] == '' ){
		$st[0] = implode('|',preg_split('/[ ,;\n]+/',$dl));
	}

	$link = DbConnect($dbhost,$dbuser,$dbpass,$dbname);
	if( in_array('config',$in) or in_array('changes',$in) ){
		$join .= ' LEFT JOIN configs USING (device)';
	}
	$res  = DbQuery( $link,'devices','s','devices.*','','',$in,$op,$st,$co,$join);
	$prevos = '';
	$oserr  = 0;
	$ndev   = 0;
	while( ($d = DbFetchArray($res)) ){
		if($d['login'] and $d['cliport']){
			$devip[$d['device']] = long2ip($d['devip']);
			if ($prevos and $prevos != $d['devos']){$oserr = 1;}
			$prevos = $d['devos'];
			$devos[$d['device']] = $d['devos'];
			$devtyp[$d['device']] = $d['type'];
			$devcfg[$d['device']] = $d['cfgstatus'];
			$devpo[$d['device']] = $d['cliport'];
			$devlo[$d['device']] = $d['login'];
			$ndev++;
		}else{
			echo "<h4>No login for $d[device]!</h4>\n";
		}
	}
	if ( $oserr ){
		echo "<h4>$mullbl $osylbl</h4>";
		if( !$do ){
			include_once ("inc/footer.php");
			exit;
		}
	}

	if( !isset($devip) ){
		echo "<h4>$nonlbl $devlbl</h4>";
	}elseif( !$do ){
		echo "<h3>$sholbl $cmdlbl</h3>\n\n";
		echo "<div class=\"textpad code pre txta tqrt\">\n\n";
		echo Buildcmd();
		echo "\n</div><br>\n";
		Condition($in,$op,$st,$co);
		echo "<table class=\"content\">\n\t<tr class=\"bgsub\">\n";
		echo "\t<th>$namlbl</th>\n\t\t<th>$typlbl</th>\n\t\t<th>$osylbl</th>\n";
		echo "\t\t<th>$usrlbl</th>\n\t\t<th>IP/$porlbl</th>\n\t\t<th>$cfglbl $stalbl</th>\n\t</tr>\n";
		$row = 0;
		foreach ($devip as $dv => $ip){
			if ($row % 2){$bg = "txta"; $bi = "imga";}else{$bg = "txtb"; $bi = "imgb";}
			$row++;
			$ud = urlencode($dv);
			echo "\t<tr class=\"$bg\">\n";
			TblCell( $dv,"Devices-Status.php?dev=$ud",'b');
			TblCell( $devtyp[$dv] );
			TblCell( $devos[$dv] );
			TblCell( $devlo[$dv] );
			TblCell( DevCli($ip,$devpo[$dv])." $devpo[$dv]" );
			TblCell( DevCfg($devcfg[$dv]).$devcfg[$dv],"Devices-Config.php?shc=$ud" );
			echo "\t</tr>\n";
		}
		TblFoot("bgsub", 6, "$row Devices");
	}else{
		$fd =  @fopen("$nedipath/cli/cmd_$_SESSION[user]","w") or die ("$errlbl $wrtlbl $nedipath/cli/cmd_$_SESSION[user]");
		$cmds = Buildcmd('',$do=='cmd'?'':$prevos);
		fwrite($fd,$cmds);
		fclose($fd);
		echo "<h2>$actlbl $lstlbl</h2>\n";
		foreach ($devip as $dv => $ip){
			$ud = urlencode($dv);
			echo "<h3>";
			echo "\t<a href=\"Devices-Status.php?dev=$ud\"><img src=\"img/16/sys.png\"></a>\n";
			echo DevCli($ip,$devpo[$dv],1);
			echo " $dv</h3>\n";
			echo "<div class=\"textpad code pre txtb half\">$rpylbl ";
			$cred = ( strstr($guiauth,'-pass') )?"$_SESSION[user] $pwd":"$devlo[$dv] dummy";
			$cred = addcslashes($cred,';$!');
			$out  = system("perl $nedipath/inc/devwrite.pl $nedipath \"$dv\" $ip $devpo[$dv] $cred $devos[$dv] cmd_$_SESSION[user]", $err);
			echo "\n</div>\n";
			echo $err?"<h4>$wrtlbl $errlbl</h4>":"<h5>$wrtlbl $mlvl[40]</h5>";

			$nout = array_sum( explode(' ',$out) );
			$outh = ($nout > 50)?500:$nout*20;
			echo "<div class=\"textpad code pre txta bctr tqrt\" height=\"$outh\">\n";
			include("$nedipath/cli/".rawurlencode($dv)."/cmd_$_SESSION[user].log");
			echo "</div>\n";
			$cstr = preg_replace('/[\r\n\"\']/',' ',$cmds);
			if( strlen($cstr) > 40 ){$cstr = substr( $cstr,0,40)."...";}
			if($err){
				$lvl = 150;
				$msg = "User $_SESSION[user] wrote $cstr causing error: $err";
			}else{
				$lvl = 100;
				$msg = "User $_SESSION[user] wrote \"$cstr\" successfully";
			}
			if( !DbQuery($link,'events','i','','','',array('level','time','source','info','class','device'),array(),array($lvl,time(),$dv,$msg,'usrw',$dv)) ){echo "<h4>".DbError($link)."</h4>";}
			flush();
		}
		if( $do=='cfb' ){
?>
<div class="textpad code pre txta tqrt">
<?php system("$nedipath/nedi.pl -a $ip -b -SAFGgadobewitjumpvs 2>&1"); ?>
</div>
<?php
		}
	}
}
include_once ("inc/footer.php");

function Buildcmd($arg='',$configureos=''){

	global $cmd, $stb, $sint, $eint, $smod, $emod, $ssub, $esub, $int, $icfg;

	if( preg_match('/^(IOS|NXOS|ProCurve|DPC)/',$configureos) ){# TODO refactor to use $cmd{'OS'}{'conf'} in devwrite.pl
		$config .= "conf t\n";
	}elseif($configureos == "Comware"){
		$config .= "sys\n";
	}
	$config .= $cmd;
	if($int){
		for($m = $smod;$m <= $emod;$m++){
			for($i = $sint;$i <= $eint;$i++){
				if($ssub and $esub){
					for($s = $ssub;$s <= $esub;$s++){
						$config .= "int $int $m/$i/$s\n";
						$config .= "$icfg\n";
					}
				}elseif($int == "Vl" or $int == "Vi"){
					$config .= ($int == "Vl")?"Vlan $m\n":"int Vlan $m\n";
					$config .= "$icfg\n";
				}else{
					$config .= "int $int $m/$i\n";
					$config .= "$icfg\n";
				}
			}
		}
	}
	$config .= "\n";
	if( preg_match('/^(IOS|NXOS)/',$configureos) ){
		$config .= "end\ncopy running startup\n";
	}elseif( preg_match('/^(ProCurve|DPC)/',$configureos) ){
		$config .= "end\nwrite mem\n";
	}elseif($configureos == "Comware"){
		$config .= "quit\nsave force\n";
	}
	return $config;
}

?>
