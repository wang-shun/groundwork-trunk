<?php
# Program: Other-Invoice.php
# Programmer: Remo Rickli

$exportxls = 0;

include_once ("inc/header.php");

$_GET = sanitize($_GET);
$to = isset($_GET['to']) ? $_GET['to'] : "Happy User\n5000 Supportive Rd\nNicetown, JO\nGreatland\n";
$no = isset($_GET['no']) ? $_GET['no'] : "";

if( isset($_GET['cu']) ){
	$cu = $_GET['cu'];
	$sdc = ($_GET['sdc']) ? 'checked' : '';
	$ndc = ($_GET['ndc']) ? 'checked' : '';
	$noc = ($_GET['noc']) ? 'checked' : '';
}else{
	$cu = 'c';
	$sdc = 'checked';
	$ndc = 'checked';
	$noc = 'checked';
}

$inr = substr(ip2long($_SERVER['SERVER_ADDR']),-6) + date("z") * date("j");

$link = DbConnect($dbhost,$dbuser,$dbpass,$dbname);							# Above print-header!
$res  = DbQuery( $link,'devices','s','count(*)','','',array('snmpversion'),array('>'),array('0') );
if ($res) {
	$sdv = DbFetchRow($res);
	DbFreeResult($res);
}else{
	print DbError($link);
	die;
}

$res = DbQuery( $link,'nodes','s','count(*)' );
if ($res) {
	$nod = DbFetchRow($res);
	DbFreeResult($res);
}else{
	print DbError($link);
	die;
}
$res = DbQuery( $link,'cables','s','count(*)' );
if ($res) {
	$cbl = DbFetchRow($res);
	DbFreeResult($res);
}else{
	print DbError($link);
	die;
}

if($cu == "u"){
	$cuf = 0.96;
	$cul = 'USD';
	$ibn = 'CH72 0070 0130 0072 8546 9';
}elseif($cu == "e"){
	$cuf = 1.16;
	$cul = 'EUR';
	$ibn = 'CH77 0070 0130 0079 5031 4';
}elseif($cu == "c"){
	$cuf = 1;
	$cul = 'CHF';
	$ibn = 'CH31 0070 0110 0061 9064 4';
}

/*
$sdv[0] =  1000;
$nod[0] = 50000;
$cbl[0] =  1000;
*/

$nda = intval(2000*log(1+$sdv[0]/200)+500*log(1+$nod[0]/1500) / $cuf);
if( $nda < 500 ) $nda = 500;

$cba = intval(500*log(1+$cbl[0]/1500) / $cuf) + 500;

$tot = $nda + $cba;

$sup = ceil(($tot-500)/1000);
?>

<form method="get" name="bill" action="<?= $self ?>.php">
<?php  if( !isset($_GET['print']) ) { ?>

<h1>NeDi <?= $icelbl ?></h1>

<table class="content">
<tr class="bgmain">
<td class="ctr s">
	<a href="<?= $self ?>.php"><img src="img/32/<?= $selfi ?>.png" title="<?= $self ?>"></a>
</td>
<td>
</td>
<td class="ctr s">
	<input type="submit" class="button" value="<?= $updlbl ?>">
</td>
</tr>
</table>
<p>

<div class="textpad txta half">
	<h5>Annual Subscription</h5>
	
	Use this module to generate an official invoice and have it paid by your company to support NeDi's development!<br>
	<p>
	<div class="genpad bctr half ctr warn b">
	Please <a class="b" href="http://www.nedi.ch/about/impressum/">contact us</a> for an individual quote!
	</div>
<?php if( $tot > 500 ){ ?>
	<p>
	Paying this invoice as shown entitles to:
	<ul>
		<li><a class="b" href="http://www.nedi.ch/customer-area/">access</a> to the latest version and additional content
<?php if($sup) echo "<li>$sup support request".(($sup>1)?'s':'')." in the year ".date("Y")."\n" ?>
	</ul>
<?php  } ?>
</div>
<?php  } ?>
<p>

<div class="imga" style="position: relative;margin:10px auto;height:780px;width:96%;border:1px solid #111111;font-size:110%">
<table class="full fixed">
	<tr>
		<td>
			<b>NeDi Consulting GmbH</b><br>
			Schulhausstrasse 4<br>
			CH-6045 Meggen<br>
			Switzerland<br>
		</td>
		<td class="rgt">
			<?= $icelbl ?> #<?= $inr ?><br>
			<?= date($_SESSION['datf']) ?>

		</td>
	</tr>
	<tr class="txtb">
		<td class="top">
			<b><?= $igrp['33'] ?></b><br>
<?php
if( isset($_GET['print']) ){
	echo "<pre class=\"imga\">$to</pre>\n";

}else{
	echo "<textarea rows=\"5\" name=\"to\" cols=\"25\">$to</textarea>\n";
}
?>
		</td>
		<td class="top">
			<b><?= $cmtlbl ?></b><br>
<?php
if( isset($_GET['print']) ){
	echo "<pre>$no</pre>\n";

}else{
	echo "<textarea rows=\"5\" name=\"no\" cols=\"25\">$no</textarea>\n";
}
?>
		</td>
	</tr>
</table><p>

<h3>NeDi <?= $srvlbl ?> 1.Jan.<?= date("Y") ?> - 31.Dec.<?= date("Y") ?></h3>

<table class="full">
	<tr class="bgmain">

<?php
TblCell($deslbl,'','','','th');
TblCell($qtylbl,'','m','','th');
TblCell($totlbl,'','m','','th');
echo "\t</tr>\n";
if( isset($mod['Assets']['Cabled']) ){
	TblRow('txtb');
	TblCell( "$cbllbl $mgtlbl");
	TblCell( $cbl[0],'','rgt' );
	TblCell( $cba,'','rgt','');
	echo "\t</tr>\n";
}
TblRow('txta');
TblCell( "SNMP $devlbl" );
TblCell( $sdv[0],'','rgt' );
TblCell( $nda,'','rgt' );
echo "	</tr>\n";
TblRow('txta');
TblCell( $nodlbl );
TblCell( $nod[0],'','rgt' );
TblCell( $noa,'','rgt','','border-bottom:solid 1px #444' );
echo "	</tr>\n";
if( $sup ){
	TblRow('txtb');
	TblCell( "Support request".($sup>1?'s':'') );
	TblCell( $sup,'','rgt b' );
	echo "	</tr>\n";
}
TblRow('imga');
TblCell($totlbl,'','rgt b');
echo "\n\t\t<td>\n";
if( isset($_GET['print']) ){
	echo "\t\t\t$cul\n";
}else{
	echo "\t\t\tCurrency\n\t\t\t<select size=\"1\" name=\"cu\" onchange=\"this.form.submit();\">\n";
	echo "\t\t\t\t<option value=\"u\"".( ($cu == "u")?" selected":"").">USD\n";
	echo "\t\t\t\t<option value=\"e\"".( ($cu == "e")?" selected":"").">EUR\n";
	echo "\t\t\t\t<option value=\"c\"".( ($cu == "c")?" selected":"").">CHF\n";
	echo "\t\t\t</select>\n";
}
echo "\n\t\t</td>\n";
TblCell($tot,'','rgt b','','border-bottom:double 4px #444');
?>
	</tr>
</table>

<div style='position: absolute;bottom: 0px;width: 100%;font-size:90%'>
	<img src="img/16/mail.png">rickli@nedi.ch &nbsp;&nbsp;&nbsp;
	<img src="img/16/sms.png">+41 41 511 98 41 &nbsp;&nbsp;&nbsp;
	<img src="img/16/cash.png">Remo Rickli - SWIFT-BIC:ZKBKCHZZ80A &nbsp; IBAN:<?= $ibn ?>

</div>
</div>
</form>
<?php
include_once ("inc/footer.php");
?>
