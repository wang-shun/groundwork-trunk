<?php
# Program: System-Setup.php
# Programmer: Remo Rickli
#
# PW fields are text, because Firefox notoriousely autocompletes them!
$exportxls = 0;

include_once ("inc/header.php");

?>
<h1><?= $igrp[20] ?> <?= $setlbl ?></h1>

<table class="content"><tr class="bgmain">
<td class="ctr s">
	<a href="<?= $self ?>.php"><img src="img/32/<?= $selfi ?>.png" title="<?= $self ?>"></a>
</td>
<td>
<?php

$nec = file("$nedipath/nedi.conf");
$crt = file("$nedipath/inc/crontab");

$_POST= sanitize($_POST);
if( $_POST['du'] ){											# Edit users...
	$nec = EditUser($nec,$_POST['du'],$_POST['dp'],$_POST['de'],$_POST['ad'],$_POST['se']);
}
if( $_POST['cm'] ){											# ---and communities, if entered by user or...
	$c = 0;
	$out = array();
	foreach( $nec as $l ){
		if( $c != 2 and strpos($l,'comm') === 0 ){
			$c = 1;
			if( $_POST['ad'] ) $out[] = $l;
		}elseif( $c == 1 ){
			if( $_POST['ap'] and $_POST['aw'] ){
				$k = "comm\t$_POST[cm]";
				if( $_POST['se'] ){
					$k = "commsec\t$_POST[cm]";
					$astr = "\t$_POST[ap]\t".implode('',unpack("H*",XORpass($_POST['aw'])));
				}else{
					$astr = "\t$_POST[ap]\t$_POST[aw]";
				}
				$pstr = '';
				if( $_POST['pp'] and $_POST['pw'] ) $pstr = "\t$_POST[pp]\t".($_POST['se']?implode('',unpack("H*",XORpass($_POST['pw']))):$_POST['pw']);
				$out[] = "$k$astr$pstr\n";
			}else{
				$out[] = "comm\t$_POST[cm]\n";
			}
			$out[] = $l;
			$c = 2;
		}else{
			$out[] = $l;
		}
	}
	$wr = file_put_contents("$nedipath/nedi.conf",$out);
}elseif( $_POST['du'] ){										# ... just save edited users
	$wr = file_put_contents("$nedipath/nedi.conf",$nec);
}else{
	$wr = 0;
}
if( $wr === FALSE ){
	echo "<img src=\"img/16/bdis.png\" title=\"$wrtlbl $errlbl\">nedi.conf\n";
}elseif( $wr ){
	echo "<img src=\"img/16/bchk.png\" title=\"$wr Bytes $wrtlbl\">nedi.conf\n";
}else{
	echo "<img src=\"img/16/dev.png\" title=\"".count($nec)." $linlbl\">nedi.conf\n";
}

if( file_exists("$nedipath/nodi.conf") ){
	$noc = file("$nedipath/nodi.conf");
	if( $_POST['nu'] ){
		$wr = file_put_contents("$nedipath/nodi.conf",EditUser($noc,$_POST['nu'],$_POST['np'],$_POST['nr'],$_POST['ad'],$_POST['se']));
	}else{
		$wr = 0;
	}
	if( $wr === FALSE ){
		echo "<img src=\"img/16/bdis.png\" title=\"$wrtlbl $errlbl\">nodi.conf\n";
	}elseif( $wr ){
		echo "<img src=\"img/16/bchk.png\" title=\"$wr Bytes $wrtlbl\">nodi.conf\n";
	}else{
		echo "<img src=\"img/16/node.png\" title=\"".count($noc)." $linlbl\">nodi.conf\n";
	}
}

if( $_POST['rs'] or $_POST['ns'] ){

	$necmd = $_POST['rs']?CronTimes($_POST['rs'])." $nedipath/nedi.pl".($_POST[ip]?" -a $_POST[ip]":'').($_POST[dp]?' -p':'')." > /var/log/nedi/nedi-`date +\%H`.run 2>&1\n":'';
	$cfcmd = $_POST['cf']?"30 0 * * * $nedipath/nedi.pl -Aall -B5 -SAFGgadobewitjumpv"." > /var/log/nedi/nedi-`date +\%H`.bup 2>&1\n":'';
	$nocmd = $_POST['ns']?CronTimes($_POST['ns'],15)." $nedipath/nodi.pl ".($_POST[ip]?" -N $_POST[ip]":' -Aall')." > /var/log/nedi/nodi-`date +\%H`.run 2>&1\n":'';
	$out   = array();
	foreach( $crt as $l ){
		if( strpos($l,'#') === 0 ){
			$out[] = $l;
		}elseif( strpos($l,'nedi.pl ') and $_POST['rs'] ){
			if( $necmd ){
				$out[] = $necmd;
				if( $cfcmd ) $out[] = $cfcmd;
				$necmd = '';
				$cfcmd = '';
			}
		}elseif( strpos($l,'nodi.pl ') and $_POST['ns'] ){
			if( $nocmd ){
				$out[] = $nomcd;
				$nocmd = '';
			}
		}else{
			$out[] = $l;
		}
	}
	if( $necmd ) $out[] = "\n".$necmd;								# No existing entries found, append
	if( $cfmcd ) $out[] = $cfcmd;
	if( $nocmd ) $out[] = "\n".$nocmd;
	$wr = file_put_contents("$nedipath/inc/crontab",$out);
	if( $wr ){
		system("crontab $nedipath/inc/crontab", $fail);
		$ups = $fail?" ($updlbl $errlbl!)":'';
	}
}else{
	$wr = 0;
}
if( $wr === FALSE ){
	echo "<img src=\"img/16/bdis.png\" title=\"$wrtlbl $errlbl\">crontab\n";
}elseif( $wr ){
	echo "<img src=\"img/16/bchk.png\" title=\"$wr Bytes $wrtlbl\">crontab$ups\n";
}elseif( $ups ){
	echo "<img src=\"img/16/bstp.png\" title=\"$wr Bytes $wrtlbl\">crontab$ups\n";
}else{
	echo "<img src=\"img/16/clock.png\" title=\"".count($crt)." $linlbl\">crontab\n";
}

?>
</td>
</tr></table>

<h2><?= $acslbl ?></h2>

<table class="content"><tr class="bgmain">
<td class="ctr s">
	<img src="img/16/dev.png" title="<?= $devlbl ?>" onclick="document.getElementById('nec').style.display = (document.getElementById('nec').style.display == 'none')?'':'none';">

	<div id="nec" class="textpad code pre txtb" style="display:none"><?php
	$us = preg_grep('/^usr|^comm/',$nec);
	#print_r($us);
	foreach( $us as $u ){
		echo $u;
	}
?>	</div>
</td>
<td>
	<form method="post" name="snmp" autocomplete="off" action="<?= $self ?>.php">
		<img src="img/16/walk.png" title="SNMP">
		<input type="text" name="cm" class="m" placeholder="<?= $namlbl ?>">
		<select size="1" name="ap">
			<option value="">v2
			<option value="md5">v3-md5
			<option value="sha">v3-sha
		</select>
		<input type="text" name="aw" class="m" placeholder="<?= $paslbl ?>">
		<select size="1" name="pp">
			<option value="">-
			<option value="des">v3-des
			<option value="aes">v3-aes
		</select>
		<input type="text" name="pw" class="m" placeholder="<?= $paslbl ?>">
		<input type="checkbox" name="se" title="<?= $paslbl ?> <?= $seclbl ?>">
		<p>
		<img src="img/16/kons.png" title="Telnet/SSH">
		<input type="text" name="du" class="m" placeholder="<?= $usrlbl ?>">
		<input type="text" name="dp" class="m" placeholder="<?= $paslbl ?>">
		<input type="text" name="de" class="m" placeholder="Enable <?= $paslbl ?>">
		<input type="checkbox" name="se" title="<?= $seclbl ?>">
</td>
<td class="ctr m">
		<input type="submit" name="ad" class="button" value="<?= $addlbl ?>">
		<input type="submit" name="rp" class="button" value="<?= $rpllbl ?>">
	</form>
</td>
</tr>
</table>
<p>
<?php if( count($noc) ){ ?>

<form method="post" autocomplete="off" name="cli" action="<?= $self ?>.php">
<table class="content"><tr class="bgmain">
<td class="ctr s">
	<img src="img/16/node.png" title="<?= $nodlbl ?>" onclick="document.getElementById('noc').style.display = (document.getElementById('noc').style.display == 'none')?'':'none';">

	<div id="noc" class="textpad code pre txtb" style="display:none"><?php
	$us = preg_grep('/^usr|^comm/',$noc);
	#print_r($us);
	foreach( $us as $u ){
		echo $u;
	}
?>	</div>
</td>
<td>
	<img src="img/16/kons.png" title="1.WMI,2+.SSH">
	<input type="text" name="nu" class="m" placeholder="<?= $usrlbl ?>">
	<input type="text" name="np" class="m" placeholder="<?= $paslbl ?>">
	<input type="text" name="nr" class="m" placeholder="Root <?= $paslbl ?>">
	<input type="checkbox" name="se" title="<?= $seclbl ?>">
</td>
<td class="ctr m">
	<input type="submit" name="ad" class="button" value="<?= $addlbl ?>">
	<input type="submit" name="rp" class="button" value="<?= $rpllbl ?>">
</td>
</tr>
</table>
</form>
<p>
<?php } ?>

<h2><?= $dsclbl ?></h2>

<form method="post" name="ned" action="<?= $self ?>.php">
<table class="content"><tr class="bgmain">
<td class="ctr s">
	<img src="img/16/dev.png" title="<?= $devlbl ?>" onclick="document.getElementById('nes').style.display = (document.getElementById('nes').style.display == 'none')?'':'none';">

	<div id="nes" class="textpad code pre txtb" style="display:none"><?php
	$nr = preg_grep('/nedi.pl/',$crt);
	foreach( $nr as $n ){
		echo $n;
	}
?>	</div>
</td>
<td>
	<img src="img/16/ip.png" title="<?= $sttlbl ?>">
	<input type="text" name="ip" class="l" placeholder="<?= $adrlbl ?>/<?= $rnglbl ?>">
	<img src="img/16/clock.png" title="<?= $rptlbl ?>">
	<select name="rs">
		<option value="36">60 <?= $tim['i'] ?>
		<option value="144">4 <?= $tim['h'] ?>
		<option value="864">24 <?= $tim['h'] ?>
	</select>
	<img src="img/16/link.png" title="<?= $verb1?"$dsclbl $neblbl":"$neblbl $dsclbl" ?>">
	<input type="checkbox" name="dp">
	<img src="img/16/conf.png" title="<?= $verb1?"$buplbl $cfglbl":"$cfglbl $buplbl" ?>">
	<input type="checkbox" name="cf">
</td>
<td class="ctr m">
	<input type="submit" class="button" value="<?= $wrtlbl ?>">
</td>
</tr></table>
</form>
<p>

<?php if( count($noc) ){ ?>

<form method="post" name="nod" action="<?= $self ?>.php">
<table class="content"><tr class="bgmain">
<td class="ctr s">
	<img src="img/16/node.png" title="<?= $nodlbl ?>" onclick="document.getElementById('nos').style.display = (document.getElementById('nos').style.display == 'none')?'':'none';">

	<div id="nos" class="textpad code pre txtb" style="display:none"><?php
	$nr = preg_grep('/nodi.pl/',$crt);
	foreach( $nr as $n ){
		echo $n;
	}
?>	</div>
</td>
<td>
	<img src="img/16/ip.png" title="<?= $sttlbl ?>">
	<input type="text" name="ip" class="l" placeholder="<?= $adrlbl ?>/<?= $rnglbl ?>">
	<img src="img/16/clock.png" title="<?= $rptlbl ?>">
	<select name="ns">
		<option value="36">60 <?= $tim['i'] ?>
		<option value="144">4 <?= $tim['h'] ?>
		<option value="864">24 <?= $tim['h'] ?>
		<option value="6048">7 <?= $tim['d'] ?>
	</select>
</td>
<td class="ctr m">
	<input type="submit" class="button" value="<?= $wrtlbl ?>">
</td>
</tr></table>
</form>
<p>

<?php 
}

function EditUser($cfg,$u,$p,$e,$a,$s){

	$c = 0;												# 0 = not changed
	foreach( $cfg as $l ){
		if( $c != 2 and preg_match('/^;?usr/',$l) ){
			$c = 1;										# 1 = change next line
			if( $a ) $out[] = $l;
		}elseif( $c == 1 ){
			if( $s ){
				$sp = implode('',unpack("H*",XORpass($p)));
				$se = $e?"\t".implode('',unpack("H*",XORpass($p))):'';
				$out[] = "usrsec\t$u\t$sp$se\n";
			}else{
				$ep = $e?"\t$e":'';
				$out[] = "usr\t$u\t$p$ep\n";
			}
			$out[] = $l;
			$c = 2;										# 2 = changed
		}else{
			$out[] = $l;
		}
	}

	return $out;
}

function CronTimes($i,$s=0){

	$hs = $s%23;

	if( $i == 36 ){
		return "$s * * * *";
	}elseif( $i == 144 ){
		return "$s */4 * * *";
	}elseif( $i == 864 ){
		return "0 $hs 0 0 *";
	}elseif( $i == 6048 ){
		return "0 $hs 0 0 1";
	}
}

include_once ("inc/footer.php");
?>
