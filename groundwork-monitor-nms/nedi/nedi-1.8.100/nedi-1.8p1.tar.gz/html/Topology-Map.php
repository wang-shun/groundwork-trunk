<?php
# Program: Topology-Map.php
# Programmer: Remo Rickli, Thiago Perrini (many beautiful improvememnts to d3js)

$nocache   = 1;
$exportxls = 0;

$vid = 0;
if( isset($_GET['vid']) ){
	$refresh = 300;
	$vid = is_numeric($_GET['vid'])?$_GET['vid']+1:1;
}
if( isset($_GET['end']) ) $refresh = 0;

include_once ("inc/header.php");
include_once ("inc/libdev.php");
include_once ("inc/libmap.php");
include_once ("inc/librrd.php");

error_reporting( ~'E_Notice');										# Don't display notices with debug, due to optimized creation of (large) hashes

# Debian/Ubuntu with avconv installed
$timst = date("Ymd-G:i");
$convcmd = "avconv -f image2 -r 5 -i /tmp/map_$_SESSION[user]-%06d.png -crf 20 -codec h264 -y map/map_$_SESSION[user]-$timst.mp4";

$dev  = array();
$reg  = array();
$nlnk = array();

$imgmap    = '';
$mapinfo   = '';
$mapframes = '';
$maplinks  = '';
$mapitems  = '';
$hidefrm   = '';

$_GET = sanitize($_GET);
$id = isset($_GET['id']) ? $_GET['id'] : 0;
if( $id==-1 ){
	$hidefrm = "<script>document.dynfrm.style.display='none'</script>";
	$id=0;
}

$st = isset($_GET['st']) ? $_GET['st'] : array('%');
$in = isset($_GET['in']) ? $_GET['in'] : array('location');
$op = isset($_GET['op']) ? $_GET['op'] : array('LIKE');
$co = isset($_GET['co']) ? $_GET['co'] : array();

$ns = isset($_GET['ns']) ? $_GET['ns'] : 0;
if( $ns ){
	$in[$ns] = 'snmpversion';
	$op[$ns] = '>';
	$st[$ns] = 0;
	$co[$ns-1] = 'AND';
}

$fmt = isset($_GET['fmt']) ? $_GET['fmt'] : '';
$dim = isset($_GET['dim']) ? $_GET['dim'] : "1024x768";
list($xm,$ym) = explode("x",$dim);

$fsz = isset($_GET['fsz']) ? $_GET['fsz'] : 80;
$len = isset($_GET['len']) ? $_GET['len'] : intval($xm/100)*10;

$tit = isset($_GET['tit']) ? $_GET['tit'] : "$netlbl";
$mde = isset($_GET['mde']) ? $_GET['mde'] : "b";
$lev = isset($_GET['lev']) ? $_GET['lev'] : 1;
if( ($mde == 'f' or $mde == 'l' ) and $lev < 4) $lev = 4;
if( $mde == 'b' and $fmt == 'json' ) $mde = 'r';

$ly = isset($_GET['ly']) ? $_GET['ly'] : "$corlbl,$dislbl,$acslbl,${acslbl}2";
$uy = ($mde=='l')?'&ly='.urlencode($ly):'';

$xo  = isset($_GET['xo']) ? $_GET['xo'] : 0;
$yo  = isset($_GET['yo']) ? $_GET['yo'] : 0;
$rot = isset($_GET['rot']) ? $_GET['rot'] : 0;
$cro = isset($_GET['cro']) ? $_GET['cro'] : 0;
$bro = isset($_GET['bro']) ? $_GET['bro'] : 0;

$ifi = ($_GET['ifi']) ? 'checked' : '';
$ifa = ($_GET['ifa']) ? 'checked' : '';
$ipi = ($_GET['ipi']) ? 'checked' : '';
$ipd = ($_GET['ipd']) ? 'checked' : '';
$loo = ($_GET['loo']) ? 'checked' : '';
$loa = ($_GET['loa']) ? 'checked' : '';
$dco = ($_GET['dco']) ? 'checked' : '';
$dmo = ($_GET['dmo']) ? 'checked' : '';
$nds = ($_GET['nds']) ? 'checked' : '';
$loi = (($loo)?1:0) + (($loa)?2:0);
$dvi = (($dco)?1:0) + (($dmo)?2:0);

$lis = isset($_GET['lis']) ? $_GET['lis'] : '';
$lit = isset($_GET['lit']) ? $_GET['lit'] : '';
$lil = isset($_GET['lil']) ? $_GET['lil'] : 0;
$lal = isset($_GET['lal']) ? $_GET['lal'] : 50;
$pos = isset($_GET['pos']) ? $_GET['pos'] : '';
$pwt = isset($_GET['pwt']) ? $_GET['pwt'] : 10;
$lsf = isset($_GET['lsf']) ? $_GET['lsf'] : 5;
$fco = isset($_GET['fco']) ? $_GET['fco'] : 8;

$imas= ($pos == "d" or $pos == "a")?4:18;

$oc = '';
$oi = '';
$dyn= '';
if( isset($_GET['dyn']) ){
	$oi = $oc = 'onchange="this.form.submit();"';
	$dyn = "checked";
}
if( $lit == 'S' or $pos == 'S' ) include_once ("inc/libsnmp.php");
$dvlnk = $pos=='S'?'Topology-Spanningtree.php?dev=':'Devices-Status.php?dev=';

$cols = array(	"device"=>$devlbl,
		"devip"=>"$manlbl $adrlbl",
		"origip"=>"$orilbl $adrlbl",
		"serial"=>$serlbl,
		"vendor"=>$venlbl,
		"type"=>"$devlb $typlbl",
		"firstdis"=>$fislbl,
		"lastdis"=>$laslbl,
		"services"=>$srvlbl,
		"description"=>$deslbl,
		"devos"=>$osylbl,
		"bootimage"=>$boolbl,
		"contact"=>$conlbl,
		"location"=>$loclbl,
		"devgroup"=>$grplbl,
		"snmpversion"=>"SNMP $verlbl",
		"login"=>$usrlbl,
		"cpu"=>"% CPU",
		"temp"=>$tmplbl,
		"test"=>$tstlbl,
		"vlanid"=>"Vlan ID",
		"vlanname"=>"Vlan $namlbl",
		"vrfname"=>"VRF",
		"ifip"=>$netlbl,
		"neighbor"=>$neblbl,
		"linktype"=>"$cnclbl $typlbl",
		"range"=>$rnglbl,
		"mac"=>"$nodlbl MAC",
		"nodip"=>"$nodlbl $adrlbl",
		"aname"=>"$nodlbl $namlbl",
		"oui"=>"$nodlbl $venlbl"
		);

$link	= DbConnect($dbhost,$dbuser,$dbpass,$dbname);

?>

<h1 onclick="document.dynfrm.style.display = (document.dynfrm.style.display == 'none')?'':'none';"><?= $tpolbl ?> <?= $maplbl ?></h1>

<?php

if( !isset($_GET['print']) ){ ?>
<form method="get" name="dynfrm" action="<?= $self ?>.php">
<table class="content"><tr class="bgmain">
<td class="ctr s">
	<a href="<?= $self ?>.php"><img src="img/32/<?= $selfi ?>.png" title="<?= $self ?>"></a>
</td>
<td class="top">
	<h3><?= $fltlbl ?></h3>
<?php
$i   = 0;
$flt = "in[]=$in[0]&op[]=$op[0]&st[]=".urlencode($st[0]);
while( $co[$i] and $i < 4 ){
	$i++;
	$flt .= "&co[]=".$co[$i-1]."&in[]=$in[$i]&op[]=$op[$i]&st[]=".urlencode($st[$i]);
}
if( $in[1] == 'range' ){
	$uri1 = "?in[]=$in[0]&op[]=$op[0]&st[]=".urlencode($st[0])."&co[]=$co[0]&in[]=range&op[]==&st[]=";
	$uri2 = "&co[]=$co[1]&in[]=$in[2]&op[]=$op[2]&st[]=".urlencode($st[2])."&co[]=$co[2]&in[]=$in[3]&op[]=$op[3]&st[]=".urlencode($st[3])."&tit=".urlencode($tit)."&dim=$dim&fmt=$fmt&lev=$lev&mde=$mde&xo=$xo&yo=$yo&rot=$rot&lsf=$lsf&lal=$lal&len=$len&lis=$lis&lil=$lil&lit=$lit&pwt=$pwt&pos=$pos&ly=$uy";
	echo "<a href=\"$uri1".($st[1]+1)."$uri2\" title=\"$rnglbl + 1\"><img src=\"img/16/bup.png\"></a>";
	echo "<a href=\"$uri1".($st[1]?$st[1]-1:0)."$uri2\" title=\"$rnglbl - 1\"><img src=\"img/16/bdwn.png\"></a>";
}
if( $i < 4 ){
	echo "<a href=\"?$_SERVER[QUERY_STRING]&ns=".($i+1)."\" title=\"SNMP $devlbl\"><img src=\"img/16/dev.png\"></a>";
}

if($mde == "l"){
?>
	<input type="text" <?= $oc ?> name="ly" value="<?= $ly ?>" class="l" title="<?= $levlbl ?> <?= $titlbl ?>"><br>
<?php
}
Filters();
?>
</td>
<td class="top">
	<h3><?= $manlbl ?></h3>
	<img src="img/16/say.png" title="<?= $maplbl ?> <?= $namlbl ?>">
	<input type="text" <?= $oc ?> name="tit" value="<?= $tit ?>" class="m"><br>
	<img src="img/16/fimg.png" title="<?= $sizlbl ?> & <?= $frmlbl ?>">
	<select size="1" <?= $oc ?> name="dim">
<?= ($dim)?"\t\t<option value=\"$dim\">$dim</option>":"" ?>

		<option value="320x240">320x240
		<option value="640x480">640x480
		<option value="1024x768">1024x768
		<option value="1280x1024">1280x1024
		<option value="1600x900">1600x900
		<option value="1920x1200">1920x1200
		<option value="2560x1600">2560x1600
		<option value="4096x2160">4096x2160
	</select>
	<select size="1" <?= $oc ?> name="fmt">
		<option value="png">png
		<option value="png4" <?= ($fmt == "png4")?" selected":"" ?>>4bit
		<option value="png6" <?= ($fmt == "png6")?" selected":"" ?>>6bit
		<option value="png8" <?= ($fmt == "png8")?" selected":"" ?>>8bit
		<option value="svg" <?= ($fmt == "svg")?" selected":"" ?>>svg
		<option value="json" <?= ($fmt == "json")?" selected":"" ?>>D3js
	</select><br>

	<img src="img/16/abc.png" title="Map <?= $typlbl ?>">
	<select size="1" <?= $oc ?> name="lev" title="<?= $levlbl ?>">
		<option value="1"><?= $place['r'] ?>

		<option value="2" <?= ($lev == "2")?" selected":"" ?>><?= $place['c'] ?>

		<option value="3" <?= ($lev == "3")?" selected":"" ?>><?= $place['b'] ?>

		<option value="4" <?= ($lev == "4")?" selected":"" ?>>Devices
		<option value="6" <?= ($lev == "6")?" selected":"" ?>>Nodes
	</select>
	<select size="1" <?= $oc ?> name="mde" title="Map <?= $typlbl ?>">
		<option value="b">bld
		<option value="r" <?= ($mde == "r")?" selected":"" ?>>ring
		<option value="f" <?= ($mde == "f")?" selected":"" ?>>flat
		<option value="l" <?= ($mde == "l")?" selected":"" ?>>layer
		<option value="g" <?= ($mde == "g")?" selected":"" ?>>bgmap
	</select>
	<br>

	<img src="img/16/geom.png" title="Map <?= $loclbl ?>">
	<input type="number" min="-1000" max="1000" step="10" <?= $oi ?> name="xo" value="<?= $xo ?>" class="xs" title="X <?= $loclbl ?>">
	<input type="number" min="-1000" max="1000" step="10" <?= $oi ?> name="yo" value="<?= $yo ?>" class="xs" title="Y <?= $loclbl ?>"><br>

	<img src="img/16/brld.png" title="Map <?= $rotlbl ?>">
	<input type="number" min="-180" max="180" <?= $oi ?> name="rot" value="<?= $rot ?>" class="xs" title="<?= $place['r'] ?>">
	<input type="number" min="-180" max="180" <?= $oi ?> name="cro" <?= ($mde == "f" or $lev < 2 and $dyn)?"disabled":"" ?> value="<?= $cro ?>" class="xs" title="<?= $place['c'] ?>">
	<input type="number" min="-180" max="180" <?= $oi ?> name="bro" <?= ($mde == "f" or $lev < 3 and $dyn)?"disabled":"" ?> value="<?= $bro ?>" class="xs" title="<?= $place['b'] ?>">
</td>
<td class="top">
	<h3><?= $dislbl ?></h3>
	<img src="img/16/lngo.png" title="<?= $cnclbl ?> <?= $endlbl ?>">
	<input type="number" min="1" max="100" <?= $oi ?> name="lsf" <?= ($mde == "f" and $lev < 6 and $dyn and $fmt != "json")?"disabled":"" ?> value="<?= $lsf ?>" class="xs" title="<?= ($fmt == 'json')?$cnclbl:"$lenlbl/$levlbl" ?>">
	<input type="number" min="0" <?= $oi ?> step="5" name="lal" <?= (!$ifi and !$ifa and !$ipi and $dyn and $fmt != "json")?"disabled":"" ?> value="<?= $lal ?>" class="xs" title="<?= "IF/IP $loclbl" ?>"><br>

	<img src="img/16/link.png" title="<?= $cnclbl ?> <?= $frmlbl ?>">
	<input type="number" min="0" max="1000" <?= $oi ?> name="len" value="<?= $len ?>" class="xs" title="<?= $lenlbl ?>">
	<select size="1" <?= $oc ?> name="lis">
		<option value=""><?= $strlbl ?>

		<option value="a1" <?= ($lis == "a1")?" selected":"" ?>><?= $arclbl ?>

		<option value="a2" <?= ($lis == "a2")?" selected":"" ?>><?= $arclbl ?> 2
		<option value="a3" <?= ($lis == "a3")?" selected":"" ?>><?= $arclbl ?> 3
		<option value="a4" <?= ($lis == "a4")?" selected":"" ?>><?= $arclbl ?> 4
	</select><br>
	<img src="img/16/lned.png" title="<?= $cnclbl ?> <?= $inflbl ?>">
	<input type="number" min="-100" max="100" <?= $oi ?> name="lil" <?= ($fmt == "json" or !$lit and $dyn)?"disabled":"" ?> value="<?= $lil ?>" class="xs" title="<?= $inflbl ?> <?= $loclbl ?>">
	<select size="1" <?= $oc ?> name="lit">
		<option value="">- <?= $inflbl ?> -

		<option value="t" <?= ($lit == "t")?" selected":"" ?>><?= $typlbl ?>

		<option value="l" <?= ($lit == "l")?" selected":"" ?>><?= $lodlbl ?>

		<option value="s" <?= ($lit == "s")?" selected":"" ?>><?= $stalbl ?>

		<option value="w" <?= ($lit == "w")?" selected":"" ?>><?= $bwdlbl ?>

		<option value="W" <?= ($lit == "W")?" selected":"" ?>><?= $bwdlbl ?> 2

		<option value="S" <?= ($lit == "S")?" selected":"" ?>><?= $sptlbl ?>

		<option value="n" <?= ($lit == "n")?" selected":"" ?>><?= $neg1?"$nonlbl $cnclbl":"$cnclbl $nonlbl" ?>

<?php if($rrdcmd){ ?>
		<option value="">- <?= $gralbl ?> -

		<option value="f1" <?= ($lit == "f1")?" selected":"" ?>><?= $trflbl ?> <?= $siz['t'] ?>

		<option value="f2" <?= ($lit == "f2")?" selected":"" ?>><?= $trflbl ?> <?= $siz['s'] ?>

		<option value="f3" <?= ($lit == "f3")?" selected":"" ?>><?= $trflbl ?> <?= $siz['m'] ?>

		<option value="f4" <?= ($lit == "f4")?" selected":"" ?>><?= $trflbl ?> <?= $siz['l'] ?>


		<option value="e1" <?= ($lit == "e1")?" selected":"" ?>><?= $errlbl ?> <?= $siz['t'] ?>

		<option value="e2" <?= ($lit == "e2")?" selected":"" ?>><?= $errlbl ?> <?= $siz['s'] ?>

		<option value="e3" <?= ($lit == "e3")?" selected":"" ?>><?= $errlbl ?> <?= $siz['m'] ?>

		<option value="e4" <?= ($lit == "e4")?" selected":"" ?>><?= $errlbl ?> <?= $siz['l'] ?>

		<option value="b1" <?= ($lit == "b1")?" selected":"" ?>>Bcast <?= $siz['t'] ?>

		<option value="b2" <?= ($lit == "b2")?" selected":"" ?>>Bcast <?= $siz['s'] ?>

		<option value="b3" <?= ($lit == "b3")?" selected":"" ?>>Bcast <?= $siz['m'] ?>

		<option value="b4" <?= ($lit == "b4")?" selected":"" ?>>Bcast <?= $siz['l'] ?>

		<option value="d1" <?= ($lit == "d1")?" selected":"" ?>><?= $dcalbl ?> <?= $siz['t'] ?>

		<option value="d2" <?= ($lit == "d2")?" selected":"" ?>><?= $dcalbl ?> <?= $siz['s'] ?>

		<option value="d3" <?= ($lit == "d3")?" selected":"" ?>><?= $dcalbl ?> <?= $siz['m'] ?>

		<option value="d4" <?= ($lit == "d4")?" selected":"" ?>><?= $dcalbl ?> <?= $siz['l'] ?>

<?php } ?>
	</select><br>
	<img src="img/16/cog.png" title="<?= $nodlbl ?> <?= $cfglbl ?>">
	<input type="number" min="<?= $fmt=="json"?4:-10 ?>" max="100" <?= $oi ?> name="pwt" value="<?= $pwt ?>" class="xs" title="<?= ($fmt == "json")?"$imglbl $sizlbl":"$nodlbl $rnglbl" ?>">
	<select size="1" <?= $oc ?> name="pos" title="<?= $nodlbl ?> <?= $typlbl ?>">
		<option value=""><?= $icolbl ?> <?= $typlbl ?>

		<option value="i" <?= ($pos == "i")?" selected":"" ?>><?= $icolbl ?> <?= $siz['s'] ?>

		<option value="I" <?= ($pos == "I")?" selected":"" ?>><?= $icolbl ?> <?= $siz['m'] ?>

		<option value="d" <?= ($pos == "d")?" selected":"" ?>><?= $shplbl ?> <?= $siz['t'] ?>

		<option value="s" <?= ($pos == "s")?" selected":"" ?>><?= $shplbl ?> <?= $siz['s'] ?>

		<option value="D" <?= ($pos == "D")?" selected":"" ?>><?= $imglbl ?> <?= $siz['s'] ?>

		<option value="p" <?= ($pos == "p")?" selected":"" ?>><?= $imglbl ?> <?= $siz['m'] ?>

		<option value="P" <?= ($pos == "P")?" selected":"" ?>><?= $imglbl ?> <?= $siz['l'] ?>

		<option value="a" <?= ($pos == "a")?" selected":"" ?>><?= $stalbl ?> <?= $siz['t'] ?>

		<option value="A" <?= ($pos == "A")?" selected":"" ?>><?= $stalbl ?> <?= $siz['m'] ?>

		<option value="l" <?= ($pos == "l")?" selected":"" ?>><?= $latlbl ?> <?= $siz['t'] ?>

		<option value="L" <?= ($pos == "L")?" selected":"" ?>><?= $latlbl ?> <?= $siz['m'] ?>

		<option value="S" <?= ($pos == "S")?" selected":"" ?>><?= $sptlbl ?>

		<option value="c" <?= ($pos == "c")?" selected":"" ?>>CPU <?= $lodlbl ?>

		<option value="h" <?= ($pos == "h")?" selected":"" ?>><?= $tmplbl ?>

	</select><br>
	<img src="img/16/home.png" title="<?= $place['b'] ?> <?= $cfglbl ?>">
	<input type="number" min="1" max="50" <?= $oi ?> name="fco" <?= ($fmt == "json" or $lev < 4 and $dyn)?"disabled":"" ?> value="<?= $fco ?>" class="xs" title="<?= $collbl ?>">
	<input type="number" min="6" max="1000" <?= $oi ?> name="fsz" <?= ($mde == "f" or $fmt == "json" or $lev < 4 and $dyn)?"disabled":"" ?> value="<?= $fsz ?>" class="xs" title="<?= $place['f'] ?> <?= $sizlbl ?>">
</td>
<td class="top">
	<h3><?= $inflbl ?></h3>
	<img src="img/16/port.png" title="<?= $intlbl ?> <?= $inflbl ?>">
	<input type="checkbox" title="<?= $namlbl ?>" <?= $oc ?> name="ifi" <?= $ifi ?>> <input type="checkbox" title="<?= $alilbl ?>" <?= $oc ?> name="ifa" <?= $ifa ?>><br>
	<img src="img/16/ip.png" title="IP <?= $adrlbl ?>">
	<input type="checkbox" title="<?= $devlbl ?>" <?= $oc ?> name="ipd" <?= $ipd ?>> <input type="checkbox" title="<?= $intlbl ?>" <?= $oc ?> name="ipi" <?= $ipi ?>><br>
	<img src="img/16/fort.png" title="<?= $loclbl ?>"> <input type="checkbox" <?= $oc ?> name="loo" title="<?= $place['o'] ?>" <?= $loo ?>> <input type="checkbox" <?= $oc ?> name="loa" title="<?= $place['a'] ?>" <?= $loa ?>><br>
	<img src="img/16/find.png" title="<?= $mlvl['30'] ?>"> <input type="checkbox" <?= $oc ?> name="dco" title="<?= $conlbl ?>" <?= $dco ?>> <input type="checkbox" <?= $oc ?> name="dmo" title="<?= $modlbl ?>" <?= $dmo ?>><br>
	<img src="img/16/walk.png" title="<?= $actlbl ?>"> <input type="checkbox" onchange="this.form.submit();" name="dyn" title="<?= $rltlbl ?>" <?= $dyn ?>> <input type="checkbox" name="nds" title="<?= $neg1?"$nonlbl $devlbl-$stalbl":"$devlbl-$stalbl $nonlbl" ?>" <?= $nds ?>>
</td>
<td class="ctr s">
<?php if( $refresh ){ ?>
	<h3>
		<img src="img/16/exit.png" title="Stop" onClick="stop_countdown(interval);">
		<span id="counter"><?= $refresh ?></span>
	</h3>
	<input type="hidden" name="vid" value="<?= $vid ?>">
	<input type="submit" class="button" name="end" value="<?= $endlbl ?>">
<?php }else{ ?>
	<input type="submit" class="button" name="sho" value="<?= $sholbl ?>">
<?php	if( $_SERVER['QUERY_STRING'] and strstr($fmt,'png') ){ ?>
	<input type="submit" class="button" name="vid" value="<?= $vidlbl ?>">
	<input type="hidden" name="id" value="<?= $id ?>">
	<input type="submit" class="button" name="mon" value="<?= $id?$updlbl:$monlbl ?>">
<?php	} ?>
<?php } ?>
</td>
</tr>
</table>
</form>
<?= $hidefrm ?>
<p>
<?php

	if( isset($_GET['mon']) ){
		if( $id ){
			if( !DbQuery($link,'monimap','u','','','',
				array('id'),
				array($id),
				array('title','filter','args'),
				array($tit,$flt,"dim=$dim&lev=$lev&mde=$mde&xo=$xo&yo=$yo&rot=$rot&cro=$cro&bro=$bro&lsf=$lsf&lal=$lal&len=$len&lis=$lis&lil=$lil&lit=$lit&pwt=$pwt&pos=$pos&fco=$fco&fsz=$fsz&ifi=$ifi&ifa=$ifa&ipd=$ipd&ipi=$ipi&loo=$loo&loa=$loa&dco=$dco&dmo=$dmo&fmt=$fmt$uy")
			) ){echo "<h4>".DbError($link)."</h4>";}else{echo "<h5>$updlbl Id $id OK</h5>";}
		}else{
			if( !DbQuery($link,'monimap','i','','','',
				array('title','filter','args','mapopts','usrname'),
				array(),
				array($tit,$flt,"dim=$dim&lev=$lev&mde=$mde&xo=$xo&yo=$yo&rot=$rot&cro=$cro&bro=$bro&lsf=$lsf&lal=$lal&len=$len&lis=$lis&lil=$lil&lit=$lit&pwt=$pwt&pos=$pos&fco=$fco&fsz=$fsz&ifi=$ifi&ifa=$ifa&ipd=$ipd&ipi=$ipi&loo=$loo&loa=$loa&dco=$dco&dmo=$dmo&fmt=$fmt$uy",'A140',$_SESSION[user])
			) ){echo "<h4>".DbError($link)."</h4>";}else{echo "<h5>$addlbl Monitoring-Map OK</h5>";}
		}
	}
}

if($fmt == 'json'){
	if( !isset($_GET['print']) ){
		echo "<h2><img src=\"img/16/flop.png\" onclick=\"saveSvgAsPng(document.getElementById('dchart'),'$tit',)\"><a href=\"map/map_$_SESSION[user].json\" title=\"$lenlbl: $len $metlbl: $lal $cnclbl: $lsf, $srclbl\"><img src=\"img/16/form.png\"></a> D3js Map</h2>\n";
	}
	if( $pwt<4 ) $pwt = 4;										# powt scales nodes and labels, which works best with 4 - 10
	$lnum = 1;
	Map();
	WriteJson();
?>

<style>
.chart {
	display:block;
	margin: 0 auto;
}
.node {
	stroke-width: 0.2px;
	cursor: move;
	fill: #888;
}
.nodelabel {
	font: 13px "Trebuchet MS", Helvetica, sans-serif;
	font-size:<?= round($pwt/3,1) ?>pt;
	font-weight: bold;
}

.node.fixed {
	fill: #000;
}
.nodeinfo {
	font: 11px "Trebuchet MS", Helvetica, sans-serif;
	font-size:<?= round($pwt/4,1) ?>pt;
	fill: #555;
}

.linklabel {
	font: 11px "Trebuchet MS", Helvetica, sans-serif;
	font-size: <?= round($pwt/4,1) ?>pt;
	stroke-opacity: 0;
	fill: #88a;
}
.iflbl{
	font: 11px "Trebuchet MS", Helvetica, sans-serif;
	font: 11px "Trebuchet MS", Helvetica, sans-serif;
	font-size: <?= round($pwt/4,1) ?>pt;
}

.lnk {
	fill-opacity: 0;
	stroke-opacity: 0;
}
</style>

<script src="inc/d3.v3.lic-min.js" charset="utf-8"></script>
<script src="inc/saveSvgAsPng.js" charset="utf-8"></script>
<script charset="utf-8">

var	dvurl  = <?= $pos=='S'?'"Topology-Spanningtree.php?dev="':'"Devices-Status.php?dev="' ?>

var	ifipos = <?= intval($lal/2) ?>

var	width = <?= $xm ?>,
	height = <?= $ym ?>;

var color = d3.scale.category20();

var force = d3.layout.force()
	.charge(<?= -150 ?>)
	.linkDistance(<?= intval($len/4) ?>)
	.size([width, height]);

var svg = d3.select("body")
	.append("svg")
	.attr("id", "dchart")
	.attr("class", "chart genpad")
	.attr("width", width)
	.attr("height", height)
	.attr("viewBox", "0 0 " + width + " " + height )
	.attr("preserveAspectRatio", "xMidYMid meet")
	.attr("pointer-events", "all")
	.call(d3.behavior.zoom().on("zoom", redraw))
	.append("g");

function pwtchg() {											// TODO add onchange="pwtchg();" to $pwt input for realtime interaction?
	var node = svg.selectAll(".node")
	.attr("width", function(d) { return document.dynfrm.pwt.value; })
	.attr("height", function(d) { return document.dynfrm.pwt.value; });
	alert(document.dynfrm.pwt.value);
}

function redraw() {
	svg.attr("transform",
	  "translate(" + d3.event.translate + ")"
	  + " scale(" + d3.event.scale + ")");
}

function drag(){
	return force.drag()
	.on("dragstart", dragstarted)
	.on("drag", dragged)
	.on("dragend", dragended);
}

function dragged(d) {
	d3.select(this).attr("x", d.x = d3.event.x).attr("y", d.y = d3.event.y);
}

function dragstarted(d) {
	d3.event.sourceEvent.stopPropagation();
	d3.select(this).classed("fixed", d.fixed = true);
}

function dragended(d) {
	d3.select(this).classed("dragging", false);
}

function rgtclick(d) {
	d3.select(this).classed("fixed", d.fixed = false);
}

d3.json("map/map_<?= $_SESSION['user'] ?>.json", function(error, graph){
	force
	.nodes(graph.nodes)
	.links(graph.links)
	.start();

	var link = svg.selectAll(".link")
		.data(graph.links)
		.enter()
		//.append("line")
		.append("path")
		.attr("class", "link")
		.style("stroke-width", function(d) { return d.w; })
		.style("stroke", function(d) { return d.c; })

		.attr("d", linkArc)
		.style("fill","none")
		.style("pointer-events", "none");

	var node = svg.selectAll(".node")
		.data(graph.nodes)
		.enter().append("g")
		.attr("class", "node")
		.attr("r", 12)
		.on("contextmenu", rgtclick)
		.call(force.drag()
		.on("drag", function(d) { drag() }))
<?php if( !$nds ){ ?>
		.append("a")
		.attr("xlink:href", function(d) {return dvurl + d.na})
		.attr("target", "_blank")
<?php } ?>;

	node.on('mouseover', function(d) {
		link.style('stroke-dasharray', function(l) {
		if (d === l.source || d === l.target)
			return 2;
		else
			return 0;
		});
/*
		var g = d3.select(this); // Show mouseover info?
		var info = g.append('text')
		 .classed('info', true)
		 .attr('x', -10)
		 .attr('y', 20)
		 .text(d.ty);
*/
	});

// draw node
	node.on('mouseout', function() {
		link.style('stroke-dasharray', 0);
//		d3.select(this).select('text.info').remove();
	});

<?php if( preg_match('/^[iIS]?$/',$pos) ){									# Only sending necessary JS to browser
?>
	node
	.filter(function(d) { return d.it == "i"; })
	.append("image")
	.attr("xlink:href", function(d) { return "img/"+d.is+".png"; })
	.attr("x", function(d) { return -d.w/2; })
	.attr("y", function(d) { return -d.h/2; })
	.attr("width", function(d) { return d.w; })
	.attr("height", function(d) { return d.h; });
<?php }elseif($pos == "p" or $pos == "P"){ ?>
	node
	.filter(function(d) { return d.it == "p"; })
	.append("image")
	.attr("xlink:href", function(d) { return d.is; })
	.attr("x", function(d) { return -d.w/2; })
	.attr("y", function(d) { return -d.h/2; })
	.attr("width", function(d) { return d.w; })
	.attr("height", function(d) { return d.h; });
<?php }else{ ?>
	node
	.filter(function(d) { return d.it == "c"; })
	.append("circle")
	.attr("r", function(d) { return d.w; })
	.style("fill", function(d) { return d.is; });

	node
	.filter(function(d) { return d.it == "r"; })
	.append("rect")
	.attr("x", function(d) { return -d.w/2; })
	.attr("y", function(d) { return -d.h/2; })
	.attr("width", function(d) { return d.w; })
	.attr("height", function(d) { return d.h; })
	.style("fill", function(d) { return d.is; });
<?php } ?>

<?php if($pos == "d" or $pos == "a" or $pos == "l"){ ?>
	node.append("title")
		.text(function(d) { return d.na + ', ' + d.ty });
<?php }else{ ?>
	node.append("text")
	.attr("text-anchor", "middle")
	.attr("dy", function(d) { return (d.h/2+<?= round($pwt/3,1) ?>); })
	.attr("class", "nodelabel")
	.text(function(d) { return d.na });
<?php $lnum++;} ?>

<?php  if( $ipd ){ ?>
// show device ip address
	node
	.append("text")
	.attr("text-anchor", "middle")
	.attr("dy", function(d) { return Math.floor(d.h/2+<?= round($pwt*$lnum/2.5,1) ?>); })
	.attr("class","nodeinfo")
	.style("fill", "blue")
	.text(function(d,i) { return d.ip; });
<?php $lnum++;} ?>

<?php if( $loi ){ ?>
// show  location
	node
	.append("text")
	.attr("dy", function(d) { return Math.floor(d.h/2+<?= round($pwt*$lnum/2.5,1) ?>); })
	.attr("class","nodeinfo")
	.style("fill", "cornflowerblue")
	.attr("text-anchor", "middle")
	.text(function(d,i) { return d.lo; });
<?php $lnum++;} ?>

<?php if( $dco ){ ?>
// show contact
	node
	.append("text")
	.attr("dy", function(d) { return Math.floor(d.h/2+<?= round($pwt*$lnum/2.5,1) ?>); })
	.attr("class","nodeinfo")
	.attr("text-anchor", "middle")
	.text(function(d,i) { return d.co; });
<?php $lnum++;} ?>

<?php if( $dmo ){ ?>
// show device mode
	node
	.append("text")
	.attr("dy", function(d) { return Math.floor(d.h/2+<?= round($pwt*$lnum/2.5,1) ?>); })
	.attr("class","nodeinfo")
	.attr("text-anchor", "middle")
	.text(function(d,i) { return d.mo; });
<?php $lnum++;} ?>

<?php if( $ifi ){ ?>
// show interface label
    var lnk = svg.selectAll(".lnk")							// Path for the LINKS and after to link LABELS
        .data(graph.links)
        .enter()
        .append('path')
        .attr({'d': function(d) {return 'M '+d.source.x+' '+d.source.y+' L '+ d.target.x +' '+d.target.y},
               'class':'lnk',									// give id to your path
               'id':function(d,i) {return 'lnk'+i}})
	.style("pointer-events", "none");

	var lnksta = svg.selectAll(".linklabel")							// LINK label device interface
		.data(graph.links)
		.enter()
		.append('text')
		.attr('class', 'iflbl')
		.attr('text-anchor', 'start')
		.attr({'id':function(d,i){return 'linklabel'+i},
		});

	lnksta.append('textPath')									// use the svg textPath element for associating labels with above links by specifying xlink:href attribute to point to its respective link/path
			.attr('xlink:href',function(d,i) {return '#lnk'+i})
			.style("pointer-events", "none")
			.attr('startOffset',ifipos + '%')
			.text(function(d){return d.di});

	var lnkend = svg.selectAll(".linklabel")							// LINK label neighbor interface
		.data(graph.links)
		.enter()
		.append('text')
		.attr('class', 'iflbl')
		.attr('text-anchor', 'end')
		.attr({'id':function(d,i){return 'linklabel'+i},
		});

	lnkend.append('textPath')									// use the svg textPath element for associating labels with above links by specifying xlink:href attribute to point to its respective link/path
			.attr('xlink:href',function(d,i) {return '#lnk'+i})
			.style("pointer-events", "none")
			.attr('startOffset',(100 - ifipos) + '%')
			.text(function(d){return d.ni});

<?php } ?>

	force.on("tick", function() {
		/*link.attr("x1", function(d) { return d.source.x; })
		.attr("y1", function(d) { return d.source.y; })
		.attr("x2", function(d) { return d.target.x; })
		.attr("y2", function(d) { return d.target.y; });*/
		link.attr("d", linkArc);

		node.attr("transform", function(d) { return "translate(" + d.x + "," + d.y + ")"; });

<?php  if( isset($_GET['ifi']) ){ ?>
		lnk.attr("d", linkArc);
		lnksta.attr('transform',function(d,i){
			if (d.target.x<d.source.x){
				bbox = this.getBBox();
				rx = bbox.x+bbox.width/2;
				ry = bbox.y+bbox.height/2;
				return 'rotate(180 '+rx+' '+ry+')';
			}else {
				return 'rotate(0)';
			}
		});
		lnkend.attr('transform',function(d,i){
			if (d.target.x<d.source.x){
				bbox = this.getBBox();
				rx = bbox.x+bbox.width/2;
				ry = bbox.y+bbox.height/2;
				return 'rotate(180 '+rx+' '+ry+')';
			}else {
				return 'rotate(0)';
			}
		});
<?php } ?>
	});
});

function linkArc(d) {
	var	ro = 0
		dx = d.target.x - d.source.x,
		dy = d.target.y - d.source.y,
		dl = Math.sqrt(dx * dx + dy * dy);

	if( d.n > 1 ){
		if( d.n % 2 ){										// Even links don't get bigger arc, but mirrored
			ro = 1
			dr = dl*(d.n -1)/2
		}else {
			dr = dl*d.n/2
		}
	}else {
		dr = 0;
	}
	return "M" + d.source.x + "," + d.source.y + "A" + dr + "," + dr + " 0 0," + ro + " " + d.target.x + "," + d.target.y;
}

</script>
<?php

}elseif($fmt == 'svg'){
	if( !isset($_GET['print']) ){echo "<h2>SVG Map</h2>";}
	Map();
	WriteSVG( Condition($in,$op,$st,$co,1) );
?>
	<embed width="<?= $xm ?>" height="<?= $ym ?>" src="map/map_<?= $_SESSION[user] ?>.svg" name="SVG Map" type="image/svg+xml" class="genpad bctr">
<?php
}elseif( isset($_GET['end']) ){
	system($convcmd);
	array_map('unlink', glob("/tmp/map_$_SESSION[user]-*"));
?>
	<h3><?= $maplbl ?> <?= $hislbl ?></h3>

	<video class="tqrt bctr" controls>
		<source src="map/map_<?= $_SESSION[user] ?>-<?= $timst ?>.mp4" type="video/mp4">
		HTML5 <?= $vidlbl ?> <?= $stco['200'] ?>!
	</video><p>
<?php
}else{
	$fname = $refresh?"/tmp/map_$_SESSION[user]-".sprintf('%06d', $vid):"/tmp/map_$_SESSION[user]";
	if($fmt){
		if( !isset($_GET['print']) ){
			$us = urlencode($st[0]);
			echo "<h2>\n\n";
			echo ModLink('Reports','Combination',"in[]=$in[0]&op[]=$op[0]&st[]=$us&map=1");
			echo ModLink('Reports','Devices',"in[]=$in[0]&op[]=$op[0]&st[]=$us&map=1");
			echo ModLink('Reports','Nodes',"in[]=$in[0]&op[]=$op[0]&st[]=$us&map=1");
			echo "\tPNG  $maplbl\n</h2>\n";
		}
		Map();
		WritePNG( Condition($in,$op,$st,$co,1), $fname );
	}else{
		if( !isset($_GET['print']) ){echo "<h3>PNG $maplbl ($laslbl)</h3>";}
	}
	if (file_exists("$fname.png")) {
?>
<img class="genpad bctr" usemap="#net" src="drawmap.php?id=<?= $vid ?>">
<map name="net">
<?= $imgmap ?>
</map>
<?php
	}
}

include_once ("inc/footer.php");

?>
