=pod

=head1 LIBRARY
libmisc.pm

Miscellaneous functions

=head2 AUTHORS

Remo Rickli & NeDi Community

=cut

package misc;
use warnings;

# Don't import duplicate routines from either Socket or Socket6 to avoid errors in GWOS log4perl:
use IO::Socket qw(:DEFAULT !pack_sockaddr_in6 !sockaddr_in6 !unpack_sockaddr_in6);
use Socket6    qw(:DEFAULT !pack_sockaddr_in6 !sockaddr_in6 !unpack_sockaddr_in6);

use RRDs;
use Net::FTP;

use vars qw($netfilter $webdev $nosnmpdev $border $ignorename $ignoreconf $getfwd $timeout $retry $ncmd);
use vars qw($nedipath $backend $dbname $dbuser $dbpass $dbhost $uselogin $usessh $sms $pol $nsok);
use vars qw($rrdcmd $rrdstep $rrdsize $nfdpath $snmpwrite $redbuild $guiauth $locsep $asset);
use vars qw($arpwatch $ignoredvlans $ignoredmacs $useivl $arppoison $macflood $seedlist);
use vars qw($notify $norep $latw $trfa $brca $pause $smtpserver $mailfrom $mailfoot);
use vars qw(%comm3 %login %map %usepoe %skippol %doip %seedini %sysobj %ifmac %ifip %useip %dlc %nfport);
use vars qw(%oui %arp %arp6 %arpc %arpn %portprop %portdes %vlid %pol %act %eventpipe %ifcontext %dom %domal);
use vars qw(@todo @comms @seeds @dbseeds @users @curcfg @retire);

our @donenam = @doneid = @doneip = @failid = @failip = ();
our $ipchg   = $ifchg = $mq = 0;
our $ouidev  = '';

our @month   = qw(Jan Feb Mar Apr May Jun Jul Aug Sep Oct Nov Dec);

$misc::nsok  = 0;
eval 'use Net::Nslookup;';
if( $@ ){
	misc::Prt("DNS :Net::Nslookup not available\n");
}else{
	$nsok = 1;
	misc::Prt("DNS :Net::Nslookup loaded\n");
}

=head2 FUNCTION ReadConf()

Searches for nedi.conf in nedi folder first then fall back to /etc. Parse
it if found or die if not.

locsep is set to a space if commented.

B<Options> -

B<Globals> various  varables

B<Returns> dies on missing nedi.conf

=cut
sub ReadConf{

	my $nconf = $_[0]?$_[0]:"$main::p/nedi.conf";

	$ignoredvlans = $ignoredmacs = $useivl = $border = $nosnmpdev = $ignorename = $ignoreconf = $usessh = $asset = "isch nid gsetzt!";
	$retry    = 1;
	$locsep   = " ";
	$rrdsize  = 1000;
	$macflood = 1000;
	$arppoison = 1;

	my @conf = ();
	my @nfar = ();
	if($nconf eq '-'){
		@conf = <STDIN>
	}else{
		if(-e "$nconf"){
			open  ("CONF", $nconf);
		}elsif(-e "/etc/nedi.conf"){
			open  ("CONF", "/etc/nedi.conf");
		}else{
			die "Can't find $nconf: $!\n";
		}
		@conf = <CONF>;
		close("CONF");
	}

	foreach my $l (@conf){
		if($l !~ /^[#;]|^(\s)*$/){
			$l =~ s/[\r\n]//g;
			my @v  = split(/\s+/,$l);
			if( $v[0] eq "comm" ){
				push (@comms,$v[1]);
				if( $v[2] ){
					$comm3{$v[1]}{aprot} = $v[2];
					$comm3{$v[1]}{apass} = $v[3];
					$comm3{$v[1]}{pprot} = $v[4];
					$comm3{$v[1]}{ppass} = $v[5];
				}
			}
			elsif( $v[0] eq "commsec" and $v[2] ){
				push (@comms,$v[1]);
				$comm3{$v[1]}{aprot} = $v[2];
				$comm3{$v[1]}{apass} = XORpass( pack "H*",$v[3] );
				$comm3{$v[1]}{pprot} = $v[4];
				$comm3{$v[1]}{ppass} = XORpass( pack "H*",$v[5] ) if $v[5];
			}
			elsif( $v[0] eq "usr" and $v[1] ){
				push (@users,$v[1]);
				$login{$v[1]}{pw} = $v[2];
				$login{$v[1]}{en} = $v[3] if $v[3];
			}
			elsif( $v[0] eq "usrsec" ){
				push (@users,$v[1]);
				$login{$v[1]}{pw} = XORpass( pack "H*",$v[2] );
				$login{$v[1]}{en} = XORpass( pack "H*",$v[3] ) if $v[3];
			}
			elsif($v[0] eq "useip"){$useip{$v[1]} = $v[2];}
			elsif($v[0] eq "uselogin"){$uselogin = $v[1]}
			elsif($v[0] eq "ignoreconf"){$ignoreconf = join ' ', splice @v,1}
			elsif($v[0] eq "snmpwrite"){$snmpwrite = $v[1]}
			elsif($v[0] eq "usessh"){$usessh = $v[1]}
			elsif($v[0] eq "skippol"){$skippol{$v[1]} = (defined $v[2])?$v[2]:''}		# Avoid undef...
			elsif($v[0] eq "usepoe"){$usepoe{$v[1]} = $v[2];}

			elsif($v[0] eq "mapns"){$map{$v[1]}{ns} = $v[2]}				# Map nameserver
			elsif($v[0] eq "mapip"){$map{$v[1]}{ip} = $v[2]}
			elsif($v[0] eq "maptp"){$map{$v[1]}{cp} = $v[2]}
			elsif($v[0] eq "mapsn"){$map{$v[1]}{sn} = $v[2]}
			elsif($v[0] eq "maplo"){$map{$v[1]}{lo} = join ' ', splice @v,2}
			elsif($v[0] eq "mapco"){$map{$v[1]}{co} = join ' ', splice @v,2}
			elsif($v[0] eq "mapgr"){$map{$v[1]}{gr} = join ' ', splice @v,2}
			elsif($v[0] eq "mapvrf"){$map{$v[1]}{vrf} = join ' ', splice @v,2}
			elsif($v[0] eq "mapna"){
				$map{$v[1]}{na} = $v[2];
				if( $v[3] ){
					$map{$v[1]}{nar} = $v[3];
				}
			}
			elsif($v[0] eq "mapn2l"){
				$map{$v[1]}{nlm} = $v[2];
				$map{$v[1]}{nlr} = $v[3];
			}
			elsif($v[0] eq "mapl2l"){
				$map{$v[1]}{llm} = $v[2];
				$map{$v[1]}{llr} = $v[3];
			}
			elsif($v[0] eq "nosnmpdev"){$nosnmpdev = $v[1]}
			elsif($v[0] eq "webdev"){$webdev = $v[1]}
			elsif($v[0] eq "netfilter"){push (@nfar,$v[1]);}
			elsif($v[0] eq "border"){$border = join ' ', splice @v,1}
			elsif($v[0] eq "ouidev"){$ouidev = join ' ', splice @v,1}
			elsif($v[0] eq "ignorename"){$ignorename = $v[1]}
			elsif($v[0] eq "asset"){$asset = $v[1]}

			elsif($v[0] eq "backend"){$backend = $v[1]}
			elsif($v[0] eq "dbname"){$dbname = $v[1]}
			elsif($v[0] eq "dbuser"){$dbuser = $v[1]}
			elsif($v[0] eq "dbpass"){$dbpass = (defined $v[1])?$v[1]:''}			# based on dirtyal's suggestion
			elsif($v[0] eq "dbhost"){$dbhost = $v[1]}

			elsif($v[0] eq "ignoredvlans"){$ignoredvlans = $v[1]}
			elsif($v[0] eq "ignoredmacs"){$ignoredmacs = $v[1]}
			elsif($v[0] eq "useivl"){$useivl = $v[1]}
			elsif($v[0] eq "getfwd"){$getfwd = $v[1]}
			elsif($v[0] eq "retire"){
				$v[2] = $v[1] unless $v[2];
				$v[3] = $v[2] unless $v[3];
				$retire[0] = $main::now - $v[1] * 86400;
				$revive[0] = $main::now - $v[1] * 43200;
				$retire[1] = $main::now - $v[2] * 86400;
				$revive[1] = $main::now - $v[2] * 43200;
				$retire[2] = $main::now - $v[3] * 86400;
				$revive[2] = $main::now - $v[3] * 43200;
			}
			elsif($v[0] eq "timeout"){$timeout = $v[1];$retry = (defined $v[2])?$v[2]:1}
			elsif($v[0] eq "arpwatch"){$arpwatch = $v[1]}
			elsif($v[0] eq "arppoison"){$arppoison = $v[1]}
			elsif($v[0] eq "macflood"){$macflood = $v[1]}

			elsif($v[0] eq "rrdstep"){$rrdstep = $v[1]}
			elsif($v[0] eq "rrdsize"){$rrdsize = $v[1]}
			elsif($v[0] eq "rrdcmd"){$rrdcmd = $v[1]}
			elsif($v[0] eq "eventpipe"){$evpipe{'dst'} = $v[1];$evpipe{'opt'} = $v[2];}

			elsif($v[0] eq "nfdpath"){$nfdpath = $v[1]}
			elsif($v[0] eq "nfport"){$nfport{$v[1]} = $v[2]}

			elsif($v[0] eq "notify"){$notify = $v[1]}
			elsif($v[0] eq "noreply"){$norep = $v[1]}
			elsif($v[0] eq "latency-warn"){$latw = $v[1]}
			elsif($v[0] eq "traf-alert"){$trfa = $v[1]}
			elsif($v[0] eq "bcast-alert"){$brca = $v[1]}
			elsif($v[0] eq "dom-alert"){
				$domal{$v[1]}{TH} = $v[2];
				$domal{$v[1]}{TL} = $v[3];
				$domal{$v[1]}{RH} = $v[4];
				$domal{$v[1]}{RL} = $v[5];
				$domal{$v[1]}{de} = join ' ', splice @v,5;
			}

			elsif($v[0] eq "pause"){$pause = $v[1]}
			elsif($v[0] eq "smtpserver"){$smtpserver = $v[1]}
			elsif($v[0] eq "mailfrom"){$mailfrom = $v[1]}
			elsif($v[0] eq "mailfooter"){$mailfoot = join ' ', splice @v,1}
			elsif($v[0] eq "sms"){$sms{$v[1]} = $v[2]}
			elsif($v[0] eq "guiauth"){$guiauth = $v[1]}
			elsif($v[0] eq "locsep"){$locsep = $v[1]}
			elsif($v[0] eq "redbuild"){$redbuild = $v[1]}

			elsif($v[0] eq "nedipath"){
				$nedipath = $v[1];
				if($main::p !~ /^\//){
					Prt("RCFG:$0 path is relative\n");
					$nedipath = $main::p;
				}else{
					if($nedipath ne $main::p){die "Please configure nedipath!\n";}
				}
			}
		}
	}
	$netfilter = join('|',@nfar);
}

=head2 FUNCTION XORpass()

XOR cleartext passwords with passphrase

B<Options> -

B<Globals> -

B<Returns> -

=cut
sub XORpass {

	my $k = 'change for more security';
	my $r = '';
	for my $ch (split //, $_[0]){
		my $i = chop $k;
		$r .= chr(ord($ch) ^ ord($i));
		$k = $i . $k;
	}
	return $r;
}

=head2 FUNCTION ReadSysobj()

Reads Sysobj definition file

B<Options> -

B<Globals> sysobj

B<Returns> -

=cut
sub ReadSysobj{

	my ($so) = @_;

	unless( exists $sysobj{$so} ){									# Load .def if not done already
		if(-e "$main::p/sysobj/$so.def"){
			open  ("DEF", "$main::p/sysobj/$so.def");
			Prt("SOBJ:Reading $so.def ");
		}else{
			open  ("DEF","$main::p/sysobj/other.def");
			Prt("SOBJ:$so.def not found, using other.def ");
		}
		my @def = <DEF>;
		chomp @def;
		close("DEF");
		$sysobj{$so}{ty} = $so;
		$sysobj{$so}{hc} = $sysobj{$so}{mv} = $sysobj{$so}{ib} = 0;
		$sysobj{$so}{pm} = '-';
		$sysobj{$so}{st} = '';
		$sysobj{$so}{en} = '';
		$sysobj{$so}{px} = '';
		$sysobj{$so}{ma} = '';
		$sysobj{$so}{mk} = '';
		$sysobj{$so}{ml} = '';
		$sysobj{$so}{fc} = '';
		$sysobj{$so}{vo} = '';
		$sysobj{$so}{cul}= '';
		$sysobj{$so}{cuv}= '';
		$sysobj{$so}{upt}= 'U';
		$sysobj{$so}{vrf}= '';
		$sysobj{$so}{dom}= '';

		foreach my $l (@def){
			if($l !~ /^[#;]|^\s*$/){
				$l =~ s/[\r\n]|\s+$//g;							# Chomp doesn't remove \r and trailing spaces
				my @v  = split(/\t/,$l);
				if(!defined $v[1]){$v[1] = ""}
				if($v[0] eq "Type")		{$sysobj{$so}{ty} = $v[1]}
				elsif($v[0] eq "OS")		{$sysobj{$so}{os} = $v[1]}
				elsif($v[0] eq "Icon")		{$sysobj{$so}{ic} = $v[1]}
				elsif($v[0] eq "Size")		{$sysobj{$so}{sz} = $v[1]}
				elsif($v[0] eq "SNMPv"){
					$sysobj{$so}{rv} = substr($v[1],0,1);
					if(substr($v[1],1,2) eq 'HC'){
						$sysobj{$so}{hc} = 128;					# Pure Highspeed 64bit counters
					}elsif(substr($v[1],1,2) eq 'HS'){
						$sysobj{$so}{hc} = 160;					# 64bit counters with ifSpeed
					}elsif(substr($v[1],1,2) eq 'MC'){
						$sysobj{$so}{hc} = 192;					# Merge Counters
					}else{
						$sysobj{$so}{hc} = 64;					# 32bit counters only
					}
				}
				elsif($v[0] eq "Serial")	{$sysobj{$so}{sn} = $v[1]}
				elsif($v[0] eq "Bimage")	{$sysobj{$so}{bi} = $v[1]}
				elsif($v[0] eq "Sysdes")	{$sysobj{$so}{de} = $v[1]}
				elsif($v[0] eq "Bridge")	{$sysobj{$so}{bf} = $v[1]}
				elsif($v[0] eq "ArpND")		{$sysobj{$so}{ar} = $v[1]}
				elsif($v[0] eq "Dispro")	{$sysobj{$so}{dp} = $v[1]}
				elsif($v[0] eq "Typoid")	{$sysobj{$so}{to} = $v[1]}		# tx vtur
				elsif($v[0] eq "Uptime")	{$sysobj{$so}{upt} = $v[1]}

				elsif($v[0] eq "VLnams")	{$sysobj{$so}{vn} = $v[1]}
				elsif($v[0] eq "VLnamx")	{$sysobj{$so}{vl} = $v[1]}
				elsif($v[0] eq "Group")		{$sysobj{$so}{dg} = $v[1]}
				elsif($v[0] eq "Mode")		{$sysobj{$so}{dm} = $v[1]}
				elsif($v[0] eq "CfgChg")	{$sysobj{$so}{cc} = $v[1]}
				elsif($v[0] eq "CfgWrt")	{$sysobj{$so}{cw} = $v[1]}
				elsif($v[0] eq "FTPConf")	{$sysobj{$so}{fc} = $v[1]}
				elsif($v[0] eq "Fanstat")	{
					$sysobj{$so}{fas} = $v[1];
					$sysobj{$so}{fav} = $v[2];
				}

				elsif($v[0] eq "StartX")	{$sysobj{$so}{st} = $v[1]}
				elsif($v[0] eq "EndX")		{$sysobj{$so}{en} = $v[1]}
				elsif($v[0] eq "IFname")	{$sysobj{$so}{in} = $v[1]}
				elsif($v[0] eq "IFaddr")	{
					$sysobj{$so}{ia} = $v[1];
					$sysobj{$so}{vrf}= $v[2] if $v[2];
				}
				elsif($v[0] eq "IFalia")	{$sysobj{$so}{al} = $v[1]}
				elsif($v[0] eq "IFalix")	{$sysobj{$so}{ax} = $v[1]}
				elsif($v[0] eq "IFdupl")	{$sysobj{$so}{du} = $v[1]}
				elsif($v[0] eq "IFduix")	{$sysobj{$so}{dx} = $v[1]}
				elsif($v[0] eq "Halfdp")	{$sysobj{$so}{hd} = $v[1]}
				elsif($v[0] eq "Fulldp")	{$sysobj{$so}{fd} = $v[1]}
				elsif($v[0] eq "InBcast")	{$sysobj{$so}{ib} = $v[1]}
				elsif($v[0] eq "InDisc")	{$sysobj{$so}{id} = $v[1]}
				elsif($v[0] eq "OutDisc")	{$sysobj{$so}{od} = $v[1]}
				elsif($v[0] eq "IFvlan")	{
					$sysobj{$so}{vi} = $v[1];
					$sysobj{$so}{vo} = $v[2] if $v[2];
				}
				elsif($v[0] eq "IFvlix")	{$sysobj{$so}{vx} = $v[1]}
				elsif($v[0] eq "IFpowr")	{
					$sysobj{$so}{pw} = $v[1];
					$sysobj{$so}{pm} = $v[2] if $v[2];
				}
				elsif($v[0] eq "IFpwix")	{$sysobj{$so}{px} = $v[1]}
				elsif($v[0] eq "Moslot")	{$sysobj{$so}{mt} = $v[1]}
				elsif($v[0] eq "Modesc")	{$sysobj{$so}{md} = $v[1]}
				elsif($v[0] eq "Moclas")	{$sysobj{$so}{mc} = $v[1]}
				elsif($v[0] eq "Movalu")	{$sysobj{$so}{mv} = $v[1]}
				elsif($v[0] eq "Mostep")	{$sysobj{$so}{mp} = $v[1]}
				elsif($v[0] eq "Mostat")	{$sysobj{$so}{ma} = $v[1]}
				elsif($v[0] eq "Mostok")	{$sysobj{$so}{mk} = $v[1]}
				elsif($v[0] eq "Modhw")		{$sysobj{$so}{mh} = $v[1]}
				elsif($v[0] eq "Modsw")		{$sysobj{$so}{ms} = $v[1]}
				elsif($v[0] eq "Modfw")		{$sysobj{$so}{mf} = $v[1]}
				elsif($v[0] eq "Modser")	{$sysobj{$so}{mn} = $v[1]}
				elsif($v[0] eq "Momodl")	{$sysobj{$so}{mm} = $v[1]}
				elsif($v[0] eq "Modloc")	{$sysobj{$so}{ml} = $v[1]}
				elsif($v[0] eq "Modom"){
					$sysobj{$so}{dom} = $v[1];
					$sysobj{$so}{dou} = $v[2]?$v[2]:'';
				}

				elsif($v[0] eq "CPUutl")	{
					$sysobj{$so}{cpu} = $v[1];
					$sysobj{$so}{cmu} = $v[2]?$v[2]:1;
					$sysobj{$so}{ctr} = $v[3]?$v[3]:75;
				}
				elsif($v[0] eq "MemCPU")	{
					$sysobj{$so}{mem} = $v[1];
					$sysobj{$so}{mmu} = $v[2]?$v[2]:1;
					if( $v[3] ){
						$sysobj{$so}{mtr} = $v[3];
					}else{
						$sysobj{$so}{mtr} = ($sysobj{$so}{mmu} =~ /%/)?10:1024;
					}
				}
				elsif($v[0] eq "Temp")		{
					$sysobj{$so}{tmp} = $v[1];
					$sysobj{$so}{tmu} = $v[2]?$v[2]:1;
					$sysobj{$so}{ttr} = $v[3]?$v[3]:75;
				}
				elsif($v[0] eq "Custom" and $v[2]){
					$sysobj{$so}{cul} = $v[1];
					$sysobj{$so}{cuv} = $v[2];
					$sysobj{$so}{utr} = $v[3]?$v[3]:0;
				}
			}
		}
		Prt("($sysobj{$so}{ty})\n");
	}
}

=head2 FUNCTION ReadOUIs()

Reads IEEE NIC vendors from provided .csv files

L<http://regauth.standards.ieee.org/standards-ra-web/pub/view.html>

B<Options> -

B<Globals> oui

B<Returns> -

=cut
sub ReadOUIs{

	my @ouifiles = qw(cid.csv iab.csv mam.csv oui36.csv oui.csv);

	foreach my $f (@ouifiles){
		open  ("OUI", "$main::p/inc/$f" ) or die "no $f in $main::p/inc!";
		my @ouitxt = <OUI>;
		close("OUI");
		foreach my $l (@ouitxt){
			if( $l !~ /Registry,Assignment,Organization|IEEE Registration Authority/){	# Avoid header and MAC ranges used by IEEE
				#my @m = $l =~ m/("[^"]+"|[^,]+)(?:,\s*)?/g;				# Respects , in quotes (found on stackoverflow)
				my @m = split(',',$l);							# More compact result when text after , is cut
				$m[2] =~ s/"//g;
				$oui{lc($m[1])} = substr($m[2],0,32);
			}
		}
	}
	my $nnic = keys %oui;
	Prt("OUI :$nnic NIC vendor entries read\n");
}


=head2 FUNCTION GetOui()

Returns OUI vendor.

B<Options> MAC address

B<Globals> -

B<Returns> vendor

=cut
sub GetOui{

	if( exists $oui{substr($_[0],0,9)} ){
		return $oui{substr($_[0],0,9)};
	}elsif( exists $oui{substr($_[0],0,7)} ){
		return $oui{substr($_[0],0,7)};
	}elsif( exists $oui{substr($_[0],0,6)} ){
		return $oui{substr($_[0],0,6)};
	}else{
		return '?';
	}
}


=head2 FUNCTION Strip()

Strips unwanted characters from a string. Additionally the return value
for an empty string (e.g. 0) can be specified.

B<Options> string, return

B<Globals> oui

B<Returns> cleaned string

=cut
sub Strip{

	my ($str,$ret) = @_;

	$ret = (defined $ret)?$ret:'';
	if(defined $str and $str ne ''){								# only strip if it's worth it!
		$str =~ s/^\s*|\s*$//g;									# leading/trailing spaces
		$str =~ s/"//g;										# quotes
		$str =~ s/[\x00-\x1F]//g;								# below ASCII
		$str =~ s/[\x7F-\xff]//g;								# above ASCII
		$str =~ s/\s+/ /g;									# excess spaces
		$str = int($str + 0.5) if $str =~ /^\d+(\.\d+)?$/ and $ret =~ /^0$/;			# round to int, if it's float
		return $str;
	}else{
		return $ret;
	}
}


=head2 FUNCTION Shif()

Shorten interface names.

B<Options> IF name

B<Globals> -

B<Returns> shortened IF name

=cut
sub Shif{

	my ($n) = @_;

	if($n){
		$n =~ s/ten(-)?gigabitethernet/Te/i;
		$n =~ s/gigabit[\s]{0,1}ethernet/Gi/i;
		$n =~ s/fast[\s]{0,1}ethernet/Fa/i;
		$n =~ s/^eth(ernet)?/Et/i;								# NXOS uses Eth in CLI, but Ethernet in SNMP...tx sk95, Matthias
		$n =~ s/^Serial/Se/;
		$n =~ s/^Dot11Radio/Do/;
		$n =~ s/^Management/Mgmt/;
		$n =~ s/^Wireless port\s?/Wp/;								# Former Colubris controllers
		$n =~ s/^[F|G]EC-//;									# Doesn't match telnet CAM table!
		$n =~ s/^Alcatel-Lucent //;								# ALU specific
		$n =~ s/^BayStack (.*?)- //;								# Nortel specific
		$n =~ s/rtif|\(|\)//g;									# Extreme specific to avoid too long ifnames
		$n =~ s/^Vlan/Vl/;									# MSFC2 and Cat6k5 discrepancy!
		$n =~ s/^Vethernet/Veth/;								# Cisco UCS
		$n =~ s/port-channel/Po/i;								# N5K requires this, Tx Matthias
		$n =~ s/(Port\d): .*/$1/g;								# Ruby specific
		$n =~ s/PIX Firewall|pci|motorola|power|switch|network|interface//ig;			# Strip other garbage (removed management for asa)
		$n =~ s/\s+|['<>]//g;									# Strip unwanted characters
		return substr($n,0,32);									# Avoid DB error for too long ifname
	}else{
		return "-";
	}
}

=head2 FUNCTION ProCount()

Process counter with respect to overflow and delta

B<Options> Device, IF index, abs index, delta index, status, value

B<Globals> Interface abs and delta value

B<Returns> -

=cut
sub ProCount{

	my ($dv,$i,$abs,$dlt,$stat,$val) = @_;
	if( $stat ){
		$main::int{$dv}{$i}{$abs} = 0 unless $main::int{$dv}{$i}{$abs};
		$main::int{$dv}{$i}{$dlt} = 0 unless $main::int{$dv}{$i}{$dlt};
	}else{
		if($main::int{$dv}{$i}{old}){
			my $dval = $val - $main::int{$dv}{$i}{$abs};
			if( $val eq '1.84467440737096e+19' ){						# Some Cisco routers got inbrc counters stuck at > 64bit!
				$val = 1;
				Prt("ERR :$abs counter stuck > 64bit!\n",'');
			}elsif( $val < 18446744073709551615 and $dval == abs $dval ){			# Nexus can produce overflowing 64-bit counters causing NeDi to die at DB write!
				$main::int{$dv}{$i}{$dlt} = $dval;
			}else{
				Prt("ERR :$abs overflow, not updating\n",'');
			}
		}else{
			$main::int{$dv}{$i}{$dlt} = 0;
		}
		$main::int{$dv}{$i}{$abs} = $val;
	}
}

=head2 FUNCTION CheckIf()

Check interface against monitoring policy

B<Options> Device, IF name, Skipstring

B<Globals> -

B<Returns> -

=cut
sub CheckIF{

	my ($dv,$i,$skip) = @_;

	return unless $main::int{$dv}{$i}{old};

	my $ele = 0;
	my $lvl = 100;
	my $cla = "if";
	my $iftxt = $main::int{$dv}{$i}{ina};
	$iftxt .= " ($main::int{$dv}{$i}{ali})" if $main::int{$dv}{$i}{ali};
	if( $main::int{$dv}{$i}{'lty'} ){
		$iftxt .= ' is '.$main::int{$dv}{$i}{'lty'}.' link';
		$lvl = 150;
		$cla = "ln";
		$ele = mon::Elevate('L',0,$dv);
	}elsif( $main::int{$dv}{$i}{'plt'} ){
		$iftxt .= ' was '.$main::int{$dv}{$i}{'plt'}.' link';
		$lvl = 150;
		$cla = "ln";
		$ele = mon::Elevate('L',0,$dv);

	}
	CheckPolicy('cnb',\$main::int{$dv}{$i}{plt},$dv,$main::int{$dv}{$i}{vid},$main::int{$dv}{$i}{ina},'');
	CheckPolicy('cif',\$main::int{$dv}{$i}{lty},$dv,$main::int{$dv}{$i}{vid},$main::int{$dv}{$i}{ina},'');
	if( $main::dev{$dv}{'ls'} > $main::now - $rrdstep*1.5 and $main::int{$dv}{$i}{chg} != $main::now ){# Avoid > 100% events due to offline dev being rediscovered or IF status change
		my $trfele = mon::Elevate('T',$ele,$dv);
		my $errele = mon::Elevate('E',$ele,$dv);
		my $dicele = mon::Elevate('G',$ele,$dv);
		if($trfele and $main::int{$dv}{$i}{'spd'} and $skip !~ /t/){				# Ignore speed 0 and if traffic is skipped
			my $rioct = int( $main::int{$dv}{$i}{'dio'} / $main::int{$dv}{$i}{'spd'} / $rrdstep * 800 );
			my $rooct = int( $main::int{$dv}{$i}{'doo'} / $main::int{$dv}{$i}{'spd'} / $rrdstep * 800 );
			if( $rioct < 102 and $rioct > $main::int{$dv}{$i}{'tra'} ){			# Ignore ridiculous %, but leave some room for rounding error (thus 101%)
				$mq += mon::Event($trfele,200,$cla.'ti',$dv,$dv,"$iftxt (".DecFix($main::int{$dv}{$i}{'spd'}).") has had $rioct% inbound traffic in the last ${rrdstep}s, exceeds alert threshold of $main::int{$dv}{$i}{'tra'}%!");
			}
			if( $rooct < 102 and $rooct > $main::int{$dv}{$i}{'tra'} ){
				$mq += mon::Event($trfele,200,$cla.'to',$dv,$dv,"$iftxt (".DecFix($main::int{$dv}{$i}{'spd'}).") has had $rooct% outbound traffic in the last ${rrdstep}s, exceeds alert threshold of $main::int{$dv}{$i}{'tra'}%!");
			}
			my $bcps = int($main::int{$dv}{$i}{'dib'}/$rrdstep);
			my $bral = ($main::int{$dv}{$i}{'bra'})?$main::int{$dv}{$i}{'bra'}:$brca;
			if( $skip !~ /b/ and $bral < 65000 and $bcps > $bral){
				$mq += mon::Event($trfele,200,$cla.'bi',$dv,$dv,"$iftxt has had $bcps inbound broadcasts/s, exceeds alert threshold of ${bral}/s!");
			}
		}
		if($errele and $main::int{$dv}{$i}{typ} != 71 and $skip !~ /e/){			# Ignore Wlan IF
			if($main::int{$dv}{$i}{die} > $rrdstep){
				$mq += mon::Event($errele,$lvl,$cla.'ei',$dv,$dv,"$iftxt has had $main::int{$dv}{$i}{die} inbound errors in the last ${rrdstep}s!");
			}elsif($main::int{$dv}{$i}{die} > $rrdstep / 60){
				$mq += mon::Event( ($errele > 1)?1:0,$lvl,$cla.'ei',$dv,$dv,"$iftxt has had some ($main::int{$dv}{$i}{die}) inbound errors in the last ${rrdstep}s");
			}
			if($main::int{$dv}{$i}{doe} > $rrdstep){
				$mq += mon::Event($errele,$lvl,$cla.'eo',$dv,$dv,"$iftxt has had $main::int{$dv}{$i}{doe} outbound errors in the last ${rrdstep}s!");
			}elsif($main::int{$dv}{$i}{doe} > $rrdstep / 60){
				$mq += mon::Event( ($errele > 1)?1:0,$lvl,$cla.'eo',$dv,$dv,"$iftxt has had some ($main::int{$dv}{$i}{doe}) outbound errors in the last ${rrdstep}s");
			}
		}
		if($dicele and $main::int{$dv}{$i}{typ} != 71 and $skip !~ /d/){			# Ignore Wlan IF
			if($main::int{$dv}{$i}{did} > $rrdstep * 1000){
				$mq += mon::Event($errele,$lvl,$cla.'di',$dv,$dv,"$iftxt has had $main::int{$dv}{$i}{did} inbound discards in the last ${rrdstep}s!");
			}
			if($main::int{$dv}{$i}{dod} > $rrdstep * 1000){
				$mq += mon::Event($errele,$lvl,$cla.'do',$dv,$dv,"$iftxt has had $main::int{$dv}{$i}{dod} outbound discards in the last ${rrdstep}s!");
			}
		}
	}

	if($main::int{$dv}{$i}{sta} == 0 and $main::int{$dv}{$i}{pst} != 0 and $skip !~ /a/){
		$mq += mon::Event( mon::Elevate('A',$ele,$dv),$lvl,$cla.'ad',$dv,$dv,"$iftxt has been disabled, previous status change on ".localtime($main::int{$dv}{$i}{pcg}) );
	}elsif($main::int{$dv}{$i}{sta} == 1 and $main::int{$dv}{$i}{pst} > 1 and $skip !~ /o/){
		$mq += mon::Event( mon::Elevate('O',$ele,$dv),$lvl,$cla.'op',$dv,$dv,"$iftxt went down, previous status change on ".localtime($main::int{$dv}{$i}{pcg}) );
	}

	if($main::int{$dv}{$i}{sta} == 3 and $skip !~ /p/ and ($main::int{$dv}{$i}{lty} !~ /^$|[FW]$/ or $main::int{$dv}{$i}{plt}) !~ /^$|[FW]$/){
		my $typc = ($main::int{$dv}{$i}{lty} ne $main::int{$dv}{$i}{plt})?" type ".($main::int{$dv}{$i}{plt}?" from $main::int{$dv}{$i}{plt}":"").($main::int{$dv}{$i}{lty}?" to $main::int{$dv}{$i}{lty}":""):"";
		my $spdc = ($main::int{$dv}{$i}{spd} ne $main::int{$dv}{$i}{psp})?" speed from ".&DecFix($main::int{$dv}{$i}{psp})." to ".&DecFix($main::int{$dv}{$i}{spd}):"";
		my $dupc = ($main::int{$dv}{$i}{dpx} ne $main::int{$dv}{$i}{pdp})?" duplex from $main::int{$dv}{$i}{pdp} to $main::int{$dv}{$i}{dpx}":"";
		my $ndio = (!$main::int{$dv}{$i}{dio} and $main::int{$dv}{$i}{sta} & 3 and $main::int{$dv}{$i}{typ} != 161)?" did not receive any traffic":"";# ProCurve doesn't show traffic on trunks
		my $ndoo = (!$main::int{$dv}{$i}{doo} and $main::int{$dv}{$i}{sta} & 3 and $main::int{$dv}{$i}{typ} != 161)?" did not send any traffic":"";
		if( $typc or $spdc or $dupc or $ndio or $ndoo ){
			my $msg  = "$iftxt ".(($typc or $spdc or $dupc)?"changed":"")."$typc$spdc$dupc$ndio$ndoo";
			$mq += mon::Event($ele,$lvl,$cla.'c',$dv,$dv,$msg);
		}
	}
}

=head2 FUNCTION LinkType()

Return linktype based on neighbor, except DP, MAC, NOP or static was set before

B<Options> nbr, existing linktype

B<Globals> -

B<Returns> linktype

=cut
sub LinkType{

	my ($dv,$et) = @_;

	if( $et =~ /^[DFMS]$/ ){
		return $et;
	}elsif( !exists $main::dev{$dv} ){
		Prt("ERR :No device $dv, nbrtrack zombie?\n",'');
		return '';
	}elsif( $main::dev{$dv}{os} eq 'ESX' ){
		return 'H';
	}elsif( $main::dev{$dv}{os} eq 'Printer' ){
		return 'P';
	}elsif( $main::dev{$dv}{os} eq 'UPS' ){
		return 'U';
	}elsif( $main::dev{$dv}{dm} == 8 ){
		return 'C';
	}else{
		return 'M';
	}
}


=head2 FUNCTION PrepLink()

Prepare L2 link of untypical devices for calculation with MacLinks()

B<Options> -

B<Globals> -

B<Returns> -

=cut
sub PrepLink{

	my ($dv,$if,$imc, $st) = @_;

	if( $st == 2 ){
		my @nbr = keys %{$ifmac{$imc}};
		if( scalar @nbr == 1 ){
			$portprop{$dv}{$if}{lnk} = LinkType( $nbr[0],$portprop{$dv}{$if}{lnk} );
			if( $main::dev{$nbr[0]}{dm} =~ /^[1-6]$/ ){
				Prt("DBG :$imc belongs to a switch $nbr[0], no need to prepare\n") if $main::opt{'d'};
			}elsif( $main::dev{$nbr[0]}{dm} == 8 ){						# It's a controlled AP, create fake IF
				$portprop{$nbr[0]}{'eth'}{lnk} = 'B';
				$portprop{$nbr[0]}{'eth'}{ntrk}{$dv} = 1;
				Prt("DBG :Prepared '$portprop{$dv}{$if}{lnk}' link on controlled AP $nbr[0],eth\n") if $main::opt{'d'};
			}elsif( scalar @{$ifmac{$imc}{$nbr[0]}} == 1 ){					# TODO check for single Ethernet instead?
				push @{$portprop{$dv}{$if}{pop}},$ifmac{$imc}{$nbr[0]}[0];
				$portprop{$nbr[0]}{$ifmac{$imc}{$nbr[0]}[0]}{lnk} = 'B';		# B as in backlink for MacLinks()
				$portprop{$nbr[0]}{$ifmac{$imc}{$nbr[0]}[0]}{ntrk}{$dv} = 1;
				Prt("DBG :Prepared '$portprop{$dv}{$if}{lnk}' link on $main::dev{$nbr[0]}{os} device $nbr[0],$ifmac{$imc}{$nbr[0]}[0]\n") if $main::opt{'d'};
			}else{
				Prt("DBG :$imc belongs to multiple interfaces on $nbr[0]!\n") if $main::opt{'d'};
			}
		}else{
			Prt("DBG :$imc belongs to multiple devices!\n") if $main::opt{'d'};
		}
	}else{
		push @{$portprop{$dv}{$if}{pop}},$imc;
	}
}

=head2 FUNCTION MacLinks()

Calculate L2 links based on bridge-forwarding tables

B<Options> -

B<Globals> -

B<Returns> -

=cut
sub MacLinks{

	my $iter  = 0;
	my $mlcnt = 0;
	my $tlcnt = 0;

	Prt("\nMacLinks  ---------------------------------------------------------------------  ".localtime()."\n");

	my $start = time;
	do{
		$mlcnt = 0;
		my $curdv = 0;
		foreach my $dv ( sort keys %portprop ){						# Key order in Perl is random if not sorted...
			foreach my $if ( sort keys %{$portprop{$dv}} ){
				if( exists $portprop{$dv}{$if}{lnk} and $portprop{$dv}{$if}{lnk} !~ /[BX]/  ){# make sure lnk exists (avoid errors due to portprop created by weird LLDP neighbor info)
					if($portprop{$dv}{$if}{lnk} eq 'D'){
						if( exists $portprop{$dv}{$if}{nbr} and exists $portprop{$portprop{$dv}{$if}{nbr}} ){
							if( exists $portprop{$portprop{$dv}{$if}{nbr}}{$portprop{$dv}{$if}{nif}}{lnk} and
							    $portprop{$portprop{$dv}{$if}{nbr}}{$portprop{$dv}{$if}{nif}}{lnk} ne 'D'){#Check for half-link
								Prt("HLNK:$dv,$if to $portprop{$dv}{$if}{nbr},$portprop{$dv}{$if}{nif} adding reverse link\n");
								db::WriteLink(	$portprop{$dv}{$if}{nbr},
										$portprop{$dv}{$if}{nif},
										$dv,
										$if,
										'MAC',
										$portprop{$portprop{$dv}{$if}{nbr}}{$portprop{$dv}{$if}{nif}}{spd},
										$portprop{$portprop{$dv}{$if}{nbr}}{$portprop{$dv}{$if}{nif}}{dpx},
										$portprop{$portprop{$dv}{$if}{nbr}}{$portprop{$dv}{$if}{nif}}{vid},
										"Constructed from halflink") unless $main::opt{'t'};
								$portprop{$portprop{$dv}{$if}{nbr}}{$portprop{$dv}{$if}{nif}}{lnk} = 'D';
							}
							my @nbr = keys %{$portprop{$dv}{$if}{ntrk}};# DP links need pruning as well
							PruNeb($dv,$nbr[0]) if scalar @nbr == 1;
						}
					}elsif( $portprop{$dv}{$if}{lnk} =~ /^[CHMPU]$/ and $portprop{$dv}{$if}{typ} =~ /^(6|7|117)$/ ){
						my @nbr = keys %{$portprop{$dv}{$if}{ntrk}};
						Prt("DEV :$dv\t$if\t".@nbr." MAC neighbors\t#$curdv\n");
						if( scalar @nbr == 1 ){					# A single nbr can be linked
							my $nlnk = 0;
							my $nif  = '';
							my $enif = '';
							foreach my $cnif ( sort keys %{$portprop{$nbr[0]}} ){
								if( exists $portprop{$nbr[0]}{$cnif}{lnk} and $portprop{$nbr[0]}{$cnif}{lnk} eq 'B'){
									if( $main::dev{$nbr[0]}{dm} == 8 ){
										$enif = $cnif;
										Prt("NEB :$nbr[0],$cnif\tusing controlled AP backlink\n");
									}else{
										$enif = $portprop{$dv}{$if}{pop}[0];
										if( defined $enif ){
											Prt("NEB :$nbr[0],$enif\tusing prepared backlink\n");
										}else{
											Prt("NEB :$nbr[0],$cnif\tno backlink found\n");
										}
									}
								}elsif( exists $portprop{$nbr[0]}{$cnif}{lnk} and $portprop{$nbr[0]}{$cnif}{lnk} eq 'M'){
									my @bnbr = sort keys %{$portprop{$nbr[0]}{$cnif}{ntrk}};
									if(scalar @bnbr){		# Got a backlink
										Prt("NEB :$nbr[0],$cnif\t".@bnbr." neighbors backlinked\n") if $main::opt{'d'};
										$nif = $cnif;
										$nlnk++;
										foreach my $blnb ( @bnbr ){# Try to find exact backlink in case we end up with more than one
											if($blnb eq $dv){
												Prt("NEB :$nbr[0],$cnif\tfound exact backlink to $blnb\n");
												$enif = $cnif;
											}
										}
									}
								}
							}
							if($nlnk == 1 or $enif){			# We got one or even exact backlink
								$nif = $enif if $enif;
								db::WriteLink(	$dv,
										$if,
										$nbr[0],
										$nif,
										'MAC',
										$portprop{$nbr[0]}{$nif}{spd},
										$portprop{$nbr[0]}{$nif}{dpx},
										$portprop{$nbr[0]}{$nif}{vid},
										"Constructed (Hub)") unless $main::opt{'t'};
								db::WriteLink(	$nbr[0],
										$nif,
										$dv,
										$if,
										'MAC',
										$portprop{$dv}{$if}{spd},
										$portprop{$dv}{$if}{dpx},
										$portprop{$dv}{$if}{vid},
										"Constructed from $nlnk backlinks".($enif?" and exact interface $enif":"") ) unless $main::opt{'t'};
								PruNeb($dv,$nbr[0]);
								Prt("MLNK:$dv,$if <=====> $nbr[0],$nif\n");
								$portprop{$dv}{$if}{lnk} = 'X';		# Processed MAC-link...
								$portprop{$nbr[0]}{$nif}{lnk} = 'X';	# TODO remove? if exists $portprop{$nbr[0]};
								$mlcnt++;
							}else{
								Prt("NEB :$nbr[0] got $nlnk backlinks!\n");
							}
						}
					}
				}
			}
			#sleep 3 unless $curdv % 500;							# wait 3s after each 500 devices to prevent other discoveries from stalling
			$curdv++;
		}
		$iter++;
		Prt("ITER:$iter found $mlcnt MAC links\n\n");
		$tlcnt += $mlcnt;
	}while($mlcnt);

	my $mldur = time - $start;
	Prt("MLNK:found $tlcnt MAC links in $iter iterations, $mldur seconds\n","$tlcnt MAC links in $iter iterations, $mldur seconds\n");
}

=head2 FUNCTION PruNeb()

Prune linked neighbor from all links where it appears along with linked device

B<Options> device,neighbor

B<Globals> portprop

B<Returns> -

=cut
sub PruNeb{
	foreach my $d ( keys %portprop ){
		foreach my $i ( keys %{$portprop{$d}} ){
			if( exists $portprop{$d}{$i}{ntrk}{$_[0]} and exists $portprop{$d}{$i}{ntrk}{$_[1]} ){
				delete $portprop{$d}{$i}{ntrk}{$_[1]};
			}
		}
	}
}

=head2 FUNCTION MapIp()

Map values according to map settings in nedi.conf or input value, if no match exists
If typ is 'ip', it'll always return the IP address (value is ignored).

B<Options> IP address, mode, value

B<Globals> -

B<Returns> mapped value

=cut
sub MapIp{
	my ($ip,$typ,$val) = @_;
	my @i = split('\.', $ip);
	if( exists $map{$ip} and exists $map{$ip}{$typ} ){
		return ProMap($ip,$ip,$typ,$val);
	}elsif( exists $map{"$i[0].$i[1].$i[2]"} and exists $map{"$i[0].$i[1].$i[2]"}{$typ} ){
		return ProMap($ip,"$i[0].$i[1].$i[2]",$typ,$val);
	}elsif( exists $map{"$i[0].$i[1]"} and exists $map{"$i[0].$i[1]"}{$typ} ){
		return ProMap($ip,"$i[0].$i[1]",$typ,$val);
	}elsif( exists $map{$i[0]} and exists $map{$i[0]}{$typ} ){
		return ProMap($ip,$i[0],$typ,$val);
	}elsif( exists $map{'default'} and exists $map{'default'}{$typ} ){
		return ProMap($ip,'default',$typ,$val);
	}else{
		$val = $ip if $typ eq 'ip';
		return ($val,0);
	}
}

=head2 FUNCTION ProMap()

Process actual map operation
The mapped value is returned with status=1

B<Options>IP, mapkey, maptype, input value

B<Globals> -

B<Returns> mapresult, ismapped

=cut
sub ProMap{

	my ($ip,$k,$typ,$val) = @_;

	if($typ eq 'na' and $map{$k}{$typ} eq 'map2DNS'){
		my $na = misc::IP2Name($ip);
		if( $na ){
			$na =~ s/^(.*?)\.(.*)/$1/ unless $main::opt{'F'};
			Prt("MAP :Mapped name for $ip to DNS $na\n");
			return ($na,'d');
		}else{
			Prt("MAP :Error mapping name to DNS, mapped to IP $ip instead\n");
			return ($ip,'i');
		}
	}elsif($typ eq 'na' and $map{$k}{$typ} eq 'map2IP' ){
		Prt("MAP :Mapped name to IP $ip\n");
		return ($ip,'i');
	}elsif($typ eq 'na' and defined $map{$k}{nar} ){
		Prt("MAP :Mapped name $val to name regex\n");
		$val =~ s/$map{$k}{na}/$map{$k}{nar}/ee;
		return ($val,'r');
	}elsif($typ eq 'nlm'){
		Prt("MAP :Mapped $val to location\n");
		$val =~ s/$map{$k}{nlm}/$map{$k}{nlr}/ee;
		return ($val,'m');
	}elsif($typ eq 'llm'){
		Prt("MAP :Mapped $val to location\n");
		{
			no warnings 'uninitialized';							# suppress warnings on input with less elements than replacement
			$val =~ s/$map{$k}{llm}/$map{$k}{llr}/ee;
		}
		return ($val,'m');
	}else{
		Prt("MAP :Mapped $typ of $k to $map{$k}{$typ}\n");
		return ($map{$k}{$typ},'m');
	}
}

=head2 FUNCTION MSM2I()

Converts HP MSM (former Colubris) IF type to IEEE types

B<Options>IF type

B<Globals> -

B<Returns> IEEE type

=cut
sub MSM2I{

	my ($t) = @_;

	if($t == 2){
		return 6;
	}elsif($t == 3){
		return 53;
	}elsif($t == 4){
		return 209;
	}elsif($t == 5){
		return 71;
	}else{
		return $t;
	}
}

=head2 FUNCTION Ip2Dec()

Converts IP addresses to dec for efficiency in DB.

B<Options> IP address

B<Globals> -

B<Returns> dec IP

=cut
sub Ip2Dec{
	if(!$_[0]){$_[0] = 0}
	return unpack N => pack CCCC => split /\./ => shift;
}

=head2 FUNCTION Dec2Ip()

Of course we need to convert them back.

B<Options> dec IP

B<Globals> -

B<Returns> IP address

=cut
sub Dec2Ip{
	if(!$_[0]){$_[0] = 0}
	return join '.' => map { ($_[0] >> 8*(3-$_)) % 256 } 0 .. 3;
}

=head2 FUNCTION IP6toDB()

Convert IPv6 for writing to DB (e.g. mysql-binary).
It'll return undef, if ip6 is not true, thus can easily be
used in functions like db::WriteNet()

B<Options> dbhandle

B<Globals> -

B<Returns> -

=cut
sub IP6toDB{

	my ($addr,$ip6) = @_;

	if($backend eq 'Pg'){
		if($addr and $ip6){
			return  $addr;
		}else{
			return  undef;									# Pg accepts NULL but not empty :-/
		}
	}elsif($addr and $ip6){
		return inet_pton(AF_INET6, $addr);
	}
}

=head2 FUNCTION IP6Text()

Returns binary IPv6 as text

B<Options> binary IPv6

B<Globals> -

B<Returns> IPv6 as text

=cut
sub IP6Text{
	return inet_ntop(AF_INET6, $_[0]) if defined $_[0];
}

=head2 FUNCTION IP2Name()

Returns DNS name

B<Options> IP Address

B<Globals> -

B<Returns> DNS Name

=cut
sub IP2Name{

	my $name = '';
	(my $ns, my $mapped) = misc::MapIp($_[0],'ns','');
	if( $ns eq '0.0.0.0' ){
		return '';
	}elsif( $nsok and $mapped ){
		my @a = nslookup(host => $_[0], server => $ns,type => "PTR",debug => $main::opt{d}?1:0 );
		$name = $a[0] if $a[0];
		misc::Prt( sprintf("DBG :DNS %-30.30s  %s-12.12  NS:%s-12.12\n",$name,$ip,$ns) ) if $main::opt{'d'};
	}else{
		my($family, $socktype, $proto, $saddr, $canonname) = getaddrinfo( $_[0], 0 );
		($name, my $port) = getnameinfo($saddr);
		misc::Prt("DBG :DNS $_[0]\t$name\n") if $main::opt{'d'};
	}
	return substr($name,0,64) if $name ne $_[0] and $name !~ /:/;

#use Socket qw(AF_INET6 inet_ntop inet_pton getaddrinfo getnameinfo); TODO use when  getaddrinfo is exported in most Socket version (Perl > 5.10)?
#	my ( $err, @addrs ) = getaddrinfo( $_[0], 0 );
#	if($err){
#		Prt("IP2N:$_[0] -> $err\n");
#	}else{
#		( $err, $name ) = getnameinfo( $addrs[0]->{addr},0 );
#		if($err){
#			Prt("IP2N:$_[0] -> $err\n");
#		}elsif( $name ne $_[0] and $name !~ /:/ ){
#			return $name;
#		}
#	}
}

=head2 FUNCTION Mask2Bit()

Converts IP mask to # of bits.

B<Options> IP address

B<Globals> -

B<Returns> bitcount

=cut
sub Mask2Bit{
	$_[0] = 0 if !$_[0];
	my $bit = sprintf("%b", unpack N => pack CCCC => split /\./ => shift);
	$bit =~ s/0//g;
	return length($bit);
}


=head2 FUNCTION DecFix()

Return big numbers in a more readable way

B<Options> number

B<Globals> -

B<Returns> readable number

=cut
sub DecFix{

	if($_[0] >= 1000000000){
		return int($_[0]/1000000000)."G";
	}elsif($_[0] >= 1000000){
		return int($_[0]/1000000)."M";
	}elsif($_[0] >= 1000){
		return int($_[0]/1000)."k";
	}else{
		return $_[0];
	}
}

=head2 FUNCTION Val2Char()

 Return letter based on value:
 A-F	100G - <10M speed on FD nodes
 G-L	100G - <10M speed on HD nodes
 M-Z	SNR of wlan nodes (3db steps)

 A-Z	send or receive dBm of transceivers

B<Options> SNR, or speed & duplex

B<Globals> -

B<Returns> letter

=cut
sub Val2Char{

	my ($s,$d) = @_;

	if( $d eq 'SNR' ){
		$s = 0 if $s < 0;									# Negative SNR even exist (DD-WRT)? Just make it 0
		return  $s<52?chr( 90 - int($s/4) ):'M';						# SNR >= 50 (if ever found) is the Max
	}elsif( $d eq 'dBm' ){
		$s = 1 if $s > 0;
		$s = -24 if $s < -24;
		return  chr(66-$s);
	}else{
		my $off = ($d eq 'FD')?76:82;
		$s = 1000000 if($s < 10000000);
		return chr( $off - log($s)/log(10) );
	}
}


=head2 FUNCTION EventPipe()

Pipe NeDi events into Nagios or spool file

B<Options> string of values

B<Globals> -

B<Returns> -

=cut
sub EventPipe{

	my $valstr = $_[0];

        if( $evpipe{'dst'} eq 'syslog' ){
                system("logger -t NeDi $valstr");
	}elsif( $evpipe{'opt'} eq 'cmdarg' ){
                system("$evpipe{'dst'} $valstr");
	}elsif( $evpipe{'opt'} eq 'nedi' ){
		open (OUT, ">>$evpipe{'dst'}");
		print OUT "$valstr\n";
		close OUT;
	}elsif( $evpipe{'opt'} eq 'nagios' and -p $evpipe{'dst'} ){					# Nagios Handler by S.Neuser
		$valstr =~ s/["'\n]//g;
		my @vals   = split /,/, $valstr;
		my $level  = shift @vals;
		my $time   = shift @vals;
		my $source = lc shift @vals;
		my $class  = shift @vals;
		my $dev    = shift @vals;
		my $msg    = join(',', @vals);

		my $status = 3;
		if($level < 11)     { $status = 3; }							# UNKNOWN
		elsif($level < 100) { $status = 0; }							# OK
		elsif($level < 200) { $status = 1; }							# WARN
		else { $status = 2; }									# CRIT

		open (OUT, ">>$evpipe{'dst'}");
		print OUT "[$time] PROCESS_SERVICE_CHECK_RESULT;$source;Events;$status;NeDi:$msg\n";
		close OUT;
	}
}

=head2 FUNCTION Diff()

Find differences in to arrays.

B<Options> pointer to config arrays

B<Globals> -

B<Returns> differences as string

=cut
sub Diff{# investigate Text::Diff::Unified for more lines around change?

	use Algorithm::Diff qw(diff);

	my $chg = '';
	my $row = 1000;
	my $accts_split_a = SplitArray(0,$row,@{$_[0]});						# tx dcec
	my $accts_split_b = SplitArray(0,$row,@{$_[1]});
	my $i = 0;
	foreach (@$accts_split_a){
		if (!defined(@$accts_split_a[$i])){ @$accts_split_a[$i] = [];}
		if (!defined(@$accts_split_b[$i])){ @$accts_split_b[$i] = [];}
		my $diffs = diff(@$accts_split_a[$i], @$accts_split_b[$i]);
		if( !@$diffs ){
			$i++;
			next;
		}
		foreach my $chunk (@$diffs) {
			foreach my $line (@$chunk) {
				my ($sign, $lineno, $l) = @$line;
				if( $l !~ /\#time:|ntp clock-period/){					# Ignore ever changing lines
					$chg .= sprintf "%4d$sign %s\n", $lineno+1+($row*$i), $l;
				}
			}
		}
		$i++
	}
	return $chg;
}

=head2 FUNCTION SplitArray()

Split Array in more SubArrays (tx dcec)

B<Options> pointer to use large arrays

B<Globals> -

B<Returns> pointer arrayjunks

=cut
sub SplitArray {

	my ($start, $length, @array) = @_;
	my @array_split;
	my $count =  @array / $length;
	for (my $i=0; $i <= $count; $i++){
		my $end = ($i == 9) ? $#array : $start + $length - 1;
		@{$array_split[$i]} = grep defined,@array[$start .. $end];
		$start += $length;
	}
	return \@array_split;
}

=head2 FUNCTION GetGw()

Get the default gateway of your system (should work on *nix and win).

B<Options> -

B<Globals> -

B<Returns> default gw IP

=cut
sub GetGw{

	my @routes = `netstat -rn`;
	my @l = grep(/^\s*(0\.0\.0\.0|default)/,@routes);
	return "" unless $l[0];

	my @gw = split(/\s+/,$l[0]);

	if($gw[1] eq "0.0.0.0"){
		return $gw[3] ;
	}else{
		return $gw[1] ;
	}
}


=head2 FUNCTION CheckTodo()

Add/remove entry to/from todolist

B<Options> -

B<Globals> seedini, doip, todo

B<Returns> # of seeds queued

=cut
sub CheckTodo{

	my ($id,$tgt,$rc,$na,$lo,$co,$opt) = @_;

	$tgt = $id if !defined $tgt;
	$opt = '' if !defined $opt;									# Forces adding, if true
	if($tgt =~ /^!/){
		my $del = substr($tgt,1);
		Prt("TODO:".sprintf("%-15.15s %-15.15s ",$del,$id) );
		my ($i) = grep { $todo[$_] eq $del } (0 .. @todo-1);
		$map{$del}{ip} = '0.0.0.0';								# Prevent discovering deleted IPs alltogether
		if( defined $i ){
			splice(@todo, $i, 1);
			delete $seedini{$del} if !exists $seedini{$del}{'dn'};				# Only delete seedini if not in DB or firstdis is lost!
			delete $doip{$del};
			Prt("removed\n");
			return -1 * scalar @dto;
		}else{
			Prt("not in todo list\n");
			return 0;
		}
	}elsif( grep {$_ eq $id} (@doneid,@donenam,@failid,@todo) ){						# Don't add if done or already queued
		Prt("TODO:".sprintf("%-15.15s %-15.15s already processed\n",$tgt,$id) );
		return 0;
	}else{
		my $hexip = ($tgt)?gethostbyname($tgt):gethostbyname($id);				# Resolve $tgt (fallback to $id). If IP is given this should not create DNS query...
		if(defined $hexip){
			my $ip = join('.',unpack('C4',$hexip) );
			if( IPType($ip) != 4 or grep {$_ eq $ip} (@doneip,@failip) ){
				Prt("TODO:".sprintf("%-15.15s %-15.15s unusable or already processed\n",$ip,$id) );
				return 0;
			}elsif(  $opt or !($main::opt{'S'} =~ /X/ and exists $seedini{$ip}) ){
				$seedini{$ip}{rc} = ($rc and $rc ne '-')?$rc:'';
				$map{$ip}{na} = $na if $na and $na ne '-';
				$map{$ip}{lo} = $lo if $lo and $lo ne '-';
				$map{$ip}{co} = $co if $co and $co ne '-';
				$doip{$id} = $ip;
				push(@todo,$id);
				Prt("TODO:".sprintf("%-15.15s %-15.15s %8s added\n",$ip,$id,$seedini{$ip}{rc}) );
				return 1;
			}else{
				Prt("TODO:Not adding existing device $id, $ip with -SX\n" );
				return 0;
			}
		}else{
			Prt("ERR :Resolving $id!\n");
			return 0;
		}
	}
}

=head2 FUNCTION InitSeeds()

Queue devices to discover based on the seedlist.

B<Options> mode: 0=nedi 1=master 2=cusdi

B<Globals> doip, todo

B<Returns> # of seeds queued

=cut
sub InitSeeds{

	my $s = 0;

	$seedlist = $_[0]==1?"$nedipath/agentlist":"$nedipath/seedlist";

	@todo = ();
	%doip = ();

	if( $main::opt{'u'} ){
		$seedlist = "$main::opt{'u'}";
	}
	my $src = substr($seedlist, rindex($seedlist, '/')+1,5 );

	if($main::opt{'a'}){
		$seedlist = "-a $main::opt{'a'}";
		if( $main::opt{'a'} =~ /[a-zA-Z]+/ ){
			$s += CheckTodo( $main::opt{'a'} );
		}else{
			my @r = split(/\./,$main::opt{'a'});
			foreach my $ipa ( ExpandRange($r[0]) ){
				foreach my $ipb ( ExpandRange($r[1]) ){
					foreach my $ipc ( ExpandRange($r[2]) ){
						foreach my $ipd ( ExpandRange($r[3]) ){
							$s += CheckTodo( "$ipa.$ipb.$ipc.$ipd" );
						}
					}
				}
			}
		}
	}elsif($main::opt{'A'}){
		$seedlist = "-A $main::opt{'A'}";
		my $query = ($main::opt{'A'} ne 'all')?$main::opt{'A'}:'';				# WHERE is empty, if all devices are chosen
		$query    = $query?"snmpversion > 0 AND $query":"snmpversion > 0" unless $_[0] == 2;	# Custom discovery has no SNMP only limit
		my $devs  = db::Select('devices','','device,inet_ntoa(devip),readcomm,snmpversion & 3', $query,'LEFT JOIN configs USING (device)' );
		foreach my $dv ( @$devs ){
			$s += CheckTodo( $dv->[0], $dv->[1], $dv->[2], '-', '-', '-', 1 );
		}
	}elsif($main::opt{'O'}){
		$seedlist = "-O $main::opt{'O'}";
		my $mtch = ($main::opt{'O'} eq 'all')?'':$main::opt{'O'};
		my $nods = db::Select('nodarp','nodip','mac,nodip',$mtch,'LEFT JOIN nodes USING (mac)');
		for my $nip (keys %{$nods}){
			my $ip = Dec2Ip($nip);
			if( IPType( $ip ) == 4 ){
				if( $main::opt{'s'} ){
					ScanIP($ip,$main::opt{'s'});
				}else{
					$s += CheckTodo( $nods->{$nip}{'mac'},$ip );
				}
			}
		}
		exit if $main::opt{'s'};
	}elsif( $arpwatch and $main::opt{'o'} ){
		$seedlist .= " arpwatch";
		$s += ArpWatch(1);
	}else{
		my $te = 0;
		if(-e "$seedlist"){
			Prt("SEED:Using $seedlist\n");
			open  (LIST, "$seedlist");
			my @list = <LIST>;
			close(LIST);
			foreach my $l (@list){
				if($l !~ /^[#;]|^\s/){
					$l =~ s/[\r\n]//g;
					my @f = split(/\s+/,$l);
					if( $f[0] =~ /[a-zA-Z]+/ ){
						$s += CheckTodo( $f[0],$f[0],$f[1],$f[2], $f[3], $f[4] );
					}else{
						my @r = split(/\./,$f[0]);
						foreach my $ipa ( ExpandRange($r[0]) ){
							foreach my $ipb ( ExpandRange($r[1]) ){
								foreach my $ipc ( ExpandRange($r[2]) ){
									foreach my $ipd ( ExpandRange($r[3]) ){
										$s += CheckTodo( "$ipa.$ipb.$ipc.$ipd", "$ipa.$ipb.$ipc.$ipd", $f[1], $f[2], $f[3], $f[4] );
									}
								}
							}
						}
					}
					$te++;
				}
			}
		}else{
			Prt("SEED:$seedlist not found!\n","$seedlist not found!\n");
		}
		$s += CheckTodo( 'Default GW', GetGw() ) unless $te or $main::opt{'u'};			# Resort to default GW, unless we have seeds or -u was used
	}

	return $s;
}

sub ExpandRange{

	my @ip = ();

	if(!defined $_[0]){
		@ip = (1..254);
	}elsif($_[0] =~ /,/){
		foreach my $d (split(/,/,$_[0])){
			push @ip, ExpandRange($d);							# Recursion allows for multiple ranges separated by ,
		}
	}elsif($_[0] =~ /-/){
		my @r = split(/-/,$_[0]);
		for my $d ($r[0]..$r[1]){
			push @ip,$d;
		}
	}else{
		push @ip,$_[0];
	}

	return @ip;
}

=head2 FUNCTION Discover()

Discover a single device.

B<Options> device ID

B<Globals> curcfg

B<Returns> -

=cut
sub Discover{

	my ($id)    = @_;
	my $start   = time;
	my $clistat = 'init';										# CLI access status
	my $dv	    = '';
	my $skip    = $main::opt{'S'};
	my $doid    = 1;

	Prt("DISC:$doip{$id} ID $id\n",sprintf("%-15.15s ",$doip{$id}));
	if( $doip{$id} !~ /$netfilter/ ){
		#mon::Event('d',50,'nedn',$id,'',"IP $doip{$id} not matching netfilter $netfilter");
		Prt("DISC:Not matching netfilter $netfilter\n","$id, netfilter $netfilter\t");
		$doid = 0;
	}elsif( grep {$_ eq $doip{$id}} (@doneip,@failip) ){
		Prt("DISC:IP discovered already\n","IP discovered already\t\t\t");
		$doid = 0;
	}elsif( $main::opt{'P'} ){									# Ping requested
		my $latency = mon::PingService($doip{$id},'icmp',1,$main::opt{'P'});
		if( $main::opt{'t'} eq 'p' ){
			Prt('',"$doip{$id} Ping:".(($latency eq -1)?"---   \t":"${latency}ms   \t") );
			$doid = 0;
		}elsif( $latency eq -1 ){								# No response, not ok to indentify
			$doid = 0;
			Prt('',"-\t");
		}elsif( $skip =~ /s/ and $seedini{$doip{$id}}{dv} ){					# Skip system, create dv from DB if available...
			$dv = $seedini{$doip{$id}}{dn};
			ReadSysobj($main::dev{$dv}{so});
			$doid = 0;
			Prt('',"Sys-skipped\t$dv\t");
		}else{
			Prt('','+');
		}
	}
	$dv  = snmp::Identify($id,$skip) if $doid;							# ...identify device otherwise
	if( $dv and $main::dev{$dv}{fs} == $main::now and $main::opt{'T'} ){				# Install new device
		my $entst = snmp::Enterprise($dv,$skip);						# Get enterprise info
		my $inst  = db::Select('install','','*',"'$main::dev{$dv}{ty}' ~ type AND '$main::dev{$dv}{ip}' ~ target AND  status = 10 order by name");
		if( scalar @$inst ){
			foreach my $ie ( @$inst ){
				my $newst = 10;
				Prt("DISC:$ie->[0] and $ie->[1] match install entry $ie->[2]\n");
				if( mon::PingService($ie->[3],'icmp',1) ne -1 ){
					$newst = 170;
					Prt("DISC:IP $ie->[3] already in use, install entry disposed\n");
				}elsif( -e "$main::p/conf/$ie->[10].tmpl" ){
					open  ("TMPL", "$main::p/conf/$ie->[10].tmpl");
					my @tmpl = <TMPL>;
					close("TMPL");

					my @i = grep $tmpl[$_] =~ /^===$/, 0 .. $#tmpl;
					my @conf = splice(@tmpl,$i[0]);
					shift @conf;
					if( scalar @conf ){
						if( open (CFG, ">/var/tftpboot/$ie->[2].cfg" ) ){
							foreach my $l (@conf){
								$l =~ s/%NAME%/$ie->[2]/g;
								$l =~ s/%IPADDR%/$ie->[3]/g;
								$l =~ s/%MASK%/$ie->[4]/g;
								$l =~ s/%GATEWAY%/$ie->[5]/g;
								$l =~ s/%VLANID%/$ie->[6]/g;
								$l =~ s/%LOCATION%/$ie->[7]/g;
								$l =~ s/%CONTACT%/$ie->[8]/g;
								$l =~ s/%LOGIN%/$ie->[9]/g;
								$l =~ s/%PASSWORD%/$login{$ie->[9]}{pw}/g;
								$l =~ s/%ENABLEPW%/$login{$ie->[9]}{en}/g;
								print CFG $l;
							}
							close (CFG);
							Prt("DISC:TFTP config file $ie->[2].cfg created\n");
						}else{
							Prt("DISC:Can't create config \n");
							$newst = 200;
						}
					}
					if( scalar @tmpl and $newst != 200 ){
						if( open (CMD, ">$main::p/cli/cmd_$ie->[2]" ) ){
							foreach my $l (@tmpl){
								$l =~ s/%NAME%/$ie->[2]/g;
								$l =~ s/%IPADDR%/$ie->[3]/g;
								print CMD $l unless $l =~ /^#/;
							}
							close (CMD);
							$clistat = &cli::PrepDev($dv,'cmd');
							Prt("DISC:Clistatus = $clistat\n");
							if($clistat =~ /^OK/){
								$clistat = cli::Commands($dv, $main::dev{$dv}{ip}, $main::dev{$dv}{cp}, $main::dev{$dv}{us}, $pw, $main::dev{$dv}{os}, "cmd_$ie->[2]");
							}
							if($clistat =~ /^OK-/){
								$newst = 100;
							}else{
								$mq += mon::Event('C',150,'nede',$dv,$dv,"Cli cmd error: $clistat");
								$newst = 200;
							}
						}else{
							Prt("DISC:Can't create command file $main::p/cli/cmd_$ie->[2]\n");
						}
					}else{
						Prt("DISC:No commands in template or creating config failed\n");
					}
				}else{
					Prt("DISC:Can't find template $main::p/conf/$ie->[10].tmpl\n");
				}
				db::Update('install',"status=$newst",'name='.$db::dbh->quote($ie->[2]) ) unless $newst == 10;
				last if $newst == 100 or $newst == 200;
			}
		}else{
			Prt("DISC:No matching install entry for $main::dev{$dv}{ip} ($main::dev{$dv}{ty})\n");
		}
	}elsif( $dv ){											# Success?
		if(exists $skippol{$main::dev{$dv}{ty}}){
			$skip .= $skippol{$main::dev{$dv}{ty}};
			Prt("DISC:skippol  for $main::dev{$dv}{ty}=$skippol{$main::dev{$dv}{ty}}\n");
		}elsif(exists $skippol{'default'}){
			$skip .= $skippol{'default'};
			Prt("DISC:default skippol=$skip\n");
		}elsif($skip){
			Prt("DISC:no skippol, -S $skip\n");
		}
		my $entst = snmp::Enterprise($dv,$skip);						# Get enterprise info
		my $iferr = snmp::Interfaces($dv,$skip);						# Get interface info

		if( $sysobj{$main::dev{$dv}{so}}{ia} and $skip !~ /j/ ){
			snmp::IfAddresses($dv);								# Get IP addresses
			if($main::dev{$dv}{pip} and $main::dev{$dv}{pip} ne $main::dev{$dv}{ip}){	# Previous IP was different...
				$mq += mon::Event('I',150,'nedj',$dv,$dv,"IP changed from $main::dev{$dv}{pip} to $main::dev{$dv}{ip} (update monitoring)");
			}
		}

		if($sysobj{$main::dev{$dv}{so}}{dp} and $skip !~ /p/){
			snmp::DisProtocol($dv,$id,$sysobj{$main::dev{$dv}{so}}{dp},$skip);		# Get neighbours via LLDP, CDP or FDP
		}

		my $moderr = 0;
		if( $skip =~ /m/ ){
			Prt('',' ');
		}else{
			$moderr = snmp::Modules($dv) if $sysobj{$main::dev{$dv}{so}}{md};		# Get modules if a module description OID exists
			snmp::Optics($dv) if $sysobj{$main::dev{$dv}{so}}{dom};				# Get optics
		}

		KeyScan($main::dev{$dv}{ip}) if $main::opt{'k'} or $main::opt{'K'};
		if( $sysobj{$main::dev{$dv}{so}}{ar} and $skip !~ /A/ ){				# Map IP to MAC addresses, if ARP/ND is in .def
			$clistat = cli::PrepDev($dv,'arp');						# Prepare device for cli access
			Prt("DISC:Clistatus = $clistat\n");
			if($clistat =~ /^OK/){
				$clistat = cli::ArpND($dv);
			}elsif( $sysobj{$main::dev{$dv}{so}}{ar} ne 'cli'){
				snmp::ArpND($dv);
			}
		}else{
			Prt('','      ');								# Spacer instead of L3 info.
		}

		if( $main::opt{'r'} ){									# User route discovery on L3 devs, if -r
			if( $main::dev{$dv}{sv} & 4 or $main::dev{$dv}{os} =~ /NetScreen/ ){
				snmp::Routes($dv);
			}else{
				Prt('','r-');
			}
		}else{
			Prt('',' ');
		}

		if( $sysobj{$main::dev{$dv}{so}}{bf} eq 'Aruba' ){					# Discover Wlan APs on controllers
			snmp::ArubaAP($dv,$skip);
		}elsif( $sysobj{$main::dev{$dv}{so}}{bf} eq 'CW' ){
			snmp::CWAP($dv,$skip);
		}elsif( $sysobj{$main::dev{$dv}{so}}{bf} eq 'MSM' ){
			snmp::MSMAP($dv,$skip);
		}elsif( $sysobj{$main::dev{$dv}{so}}{bf} eq 'ZD' ){
			snmp::ZDAP($dv,$skip);
		}elsif( $sysobj{$main::dev{$dv}{so}}{bf} eq 'SZ' ){
			snmp::SZAP($dv,$skip);
		}elsif( $sysobj{$main::dev{$dv}{so}}{bf} =~ /WLC/ ){					# Cisco switches with integrated WLC as detected by SNMP::Interfaces()
			snmp::WLCAP($dv,$skip);
		}
		if( $skip !~ /F/ ){
			if( $sysobj{$main::dev{$dv}{so}}{bf} eq 'CAP' ){
				snmp::CAPFwd($dv);
			}elsif( $sysobj{$main::dev{$dv}{so}}{bf} eq 'Aero' ){
				snmp::AeroFwd($dv);
			}elsif( $sysobj{$main::dev{$dv}{so}}{bf} eq 'DDWRT' ){
				snmp::DDWRTFwd($dv);
			}elsif( $sysobj{$main::dev{$dv}{so}}{bf} =~ /^(normal|qbri|VLX|VXP|cli)/ ){	# Get mac address table, if  bridging is set in .def
				db::ReadNbr('device = '.$db::dbh->quote($dv) );				# Read nbrtrack entries
				if( $getfwd =~ /dyn|sec/ ){						# Using CLI to fetch forwarding table is configured?
					$clistat = cli::PrepDev($dv,'fwd');				# Prepare device for cli access
					Prt("DISC:Clistatus = $clistat\n");
					if($clistat =~ /^OK/){
						$clistat = cli::BridgeFwd($dv);
					}
				}
				if( $clistat ne 'OK-Bridge' ){
					$mq += mon::Event('C',150,'nede',$dv,$dv,"CLI Bridge Fwd error: $clistat") unless $clistat =~ /^(init|unsupported)/;
					if( $sysobj{$main::dev{$dv}{so}}{bf} =~ /^V(LX|XP)$/ and  $skip =~ /v/ ){
						Prt("ERR :Cannot get Vlan indexed forwarding entries with skipping v!\n");
					}elsif( $sysobj{$main::dev{$dv}{so}}{bf} ne 'cli' ){		# Do SNMP if CLI failed and not forced
						snmp::BridgeFwd($dv);
					}
				}
				FloodFind($dv);
			}
		}

		if( $main::opt{'c'} ){									# Run CLI commands
			if($clistat =~ /^OK-/){
				Prt("DISC:Cli waiting $cli::clipause seconds before reconnecting\n");
				select(undef, undef, undef, $cli::clipause);
			}else{
				$clistat = cli::PrepDev($dv,'cmd');
			}
			Prt("DISC:Clistatus = $clistat\n");
			if($clistat =~ /^OK/){
				$clistat = cli::Commands($dv, $main::dev{$dv}{ip}, $main::dev{$dv}{cp}, $main::dev{$dv}{us}, $pw, $main::dev{$dv}{os}, $main::opt{'c'});
			}
			if($clistat !~ /^OK-/){
				$mq += mon::Event('C',150,'nede',$dv,$dv,"Command error: $clistat");
			}
		}

		if($main::opt{'b'} or defined $main::opt{'B'}){						# Backup configurations
			if($skip =~ /s/ or $main::dev{$dv}{fs} == $main::now or $main::dev{$dv}{bup} ne 'A'){# Skip sysinfo or new devs force backup (or non-active are updated)
				if( $sysobj{$main::dev{$dv}{so}}{fc} and $skip !~ /f/){			# Use FTP for backup (more efficient) if not skipped
					my $ftperr = FTPConf( $dv );
					if( $ftperr ){
						Prt("ERR :$ftperr\n",'Bf');
						$mq += mon::Event('B',150,'cfge',$dv,$dv,"Config backup error: $ftperr");
					}else{
						open("CFG","/tmp/ftpconf-$main::now");
						@curcfg = <CFG>;# TODO add ignoreconf
						chomp @curcfg;
						close("CFG");
						unlink("/tmp/ftpconf-$main::now");
						db::WriteCfg($dv);
					}
				}else{
					if($clistat =~ /^OK-/){						# Wait if we just got BridgeFWD or ARP via CLI to avoid hang
						Prt("DISC:Cli waiting $cli::clipause seconds before reconnecting\n");
						select(undef, undef, undef, $cli::clipause);
					}else{
						$clistat = cli::PrepDev($dv,'cfg');
					}

					if($clistat =~ /^OK/){
						@curcfg = ();						# Empty config (global due to efficiency)
						$clistat = cli::Config($dv);
						if($clistat =~ /^OK-/){
							Prt("\nConfigbackup  -----------------------------------------------------------------  ".localtime()."\n");
							db::WriteCfg($dv);
						}
					}elsif($clistat =~ /^unsupported/){
						$main::dev{$dv}{bup} = '-';
						Prt("DBG :$clistat\n") if $main::opt{'d'} =~ /c/;
					}else{
						$mq += mon::Event('B',150,'cfge',$dv,$dv,"Config backup error: $clistat");
						$main::dev{$dv}{bup} = 'E';
					}
				}
			}else{
				Prt("DISC:Config hasn't been changed. Not backing up.\n");
			}
		}
		DevRRD($dv,$skip) if !$iferr and $rrdcmd and $skip !~ /g/;

		push (@doneid,$id);
		push (@doneip,$doip{$id});
		push (@donenam, $dv);
		unless($main::opt{'t'}){
			Prt("\nWrite Device Info -------------------------------------------------------------  ".localtime()."\n");
			db::WriteDev($dv);
			db::WriteInt($dv,$skip)	unless $iferr;
			db::WriteMod($dv)		unless $skip =~ /m/ or $moderr;
			db::WriteVlan($dv,$skip)	unless $skip =~ /v/;
			db::WriteNet($dv)  		unless $skip =~ /j/;
			db::Update('install',"status=150","name=".$db::dbh->quote($dv) );
			db::Commit();
		}

		my $pof = ProPolicy($dv,$skip);
		if( $pof and !$main::opt{'t'} ){							# Send policy file to device, if we're not testing
			if($clistat =~ /^OK-/){
				Prt("DISC:Cli waiting $cli::clipause seconds before reconnecting\n");
				select(undef, undef, undef, $cli::clipause);
			}else{
				$clistat = cli::PrepDev($dv,'cmd');
			}
			Prt("DISC:Clistatus = $clistat\n");
			if($clistat =~ /^OK/){
				$clistat = 'safety on! Remove only, if you know what you are doing!!!!';
				#$clistat = cli::Commands($dv, $main::dev{$dv}{ip}, $main::dev{$dv}{cp}, $main::dev{$dv}{us}, $pw, $main::dev{$dv}{os}, $pof);
			}
			if($clistat !~ /^OK-/){
				$mq += mon::Event('C',150,'nede',$dv,$dv,"Policy error: $clistat");
			}
		}

		if($main::opt{'x'}){
		Prt("\nCallout  ----------------------------------------------------------------------  ".localtime()."\n");
			my $xst = system($main::opt{'x'},
						($main::dev{$dv}{fs} == $main::now)?'new':'existing',
						$dv,
						$main::dev{$dv}{ip},
						$main::dev{$dv}{rv},
						$main::dev{$dv}{rc},
						$main::dev{$dv}{wc},
						$main::dev{$dv}{so},
						$main::dev{$dv}{de}
					);
			Prt("DISC:Executed $main::opt{'x'}, which returned $xst\n"," x$xst");
		}

		delete $main::mod{$dv};
		delete $main::vlan{$dv};
		delete $main::vlid{$dv};
		delete $main::int{$dv};
		delete $main::net{$dv};
		delete $act{$dv};
	}else{
		push (@failid,$id);
		push (@failip,$doip{$id});
	}

	my @t = localtime;
	my $s = sprintf ("%4d/%d-%ds",scalar(@todo),scalar(@donenam),(time - $start) );
	$s .= sprintf ("\t%02d:%02d:%02d",$t[2],$t[1],$t[0] ) if $notify =~ /x/;
	Prt("DISC:ToDo/Done-Time\t\t\t\t\t$s\n\n"," $s\n");
}

=head2 FUNCTION UseThisPoE()

Returns whether PoE should be tracked with given method

B<Options> disprot,ifmib

B<Globals> -

B<Returns> true/false

=cut

sub UseThisPoE{

	if( exists $usepoe{$_[0]} ){
		return ($usepoe{$_[0]} eq $_[1])?1:0;
	}elsif( exists $usepoe{'default'} and $usepoe{'default'} eq $_[1] ){
		return 1;
	}else{
		return 0;
	}

}

=head2 FUNCTION ArpWatch()

Build arp table from Arpwatch files (if set in nedi.conf).
First loop picks latest entry, second builds proper arp hash.

B<Options> seedmode

B<Globals> arp, arpn, arpc

B<Returns> -

=cut
sub ArpWatch{

	my $nad = 0;
	my %amc = ();
	my %arp = ();
	my @awf = glob($arpwatch);
	chomp @awf;

	Prt("\nArpWatch  ---------------------------------------------------------------------  ".localtime()."\n");
	foreach my $f (@awf){
		Prt("ARPW:Reading $f\n");
		open  ("ARPDAT", $f ) or die "ARP:$f not found!";					# read arp.dat
		my @adat = <ARPDAT>;
		close("ARPDAT");
		foreach my $l (@adat){
			$l =~ s/[\r\n]//g;
			my @ad = split(/\s/,$l);
			my $mc = sprintf "%02s%02s%02s%02s%02s%02s",split(/:/,$ad[0]);
			if(!exists $amc{$mc} or $ad[2] > $amc{$mc}{'time'}){
				Prt("ARPW:$mc $ad[1]");
				if( $_[0] ){
					my $oui = GetOui($mc);
					Prt(" $oui ");
					if($mc =~ /$border/ or $oui =~ /$border/){
						Prt(" matches border /$border/\n");
						$bd++;
					}elsif($oui =~ /$ouidev/i or $mc =~ /$ouidev/){
						Prt(" matches ouidev /$ouidev/\n");
						$nad += CheckTodo($mc,$ad[1]);
					}else{
						Prt(" no match\n");
					}
				}else{
					my $ipt = IPType($ad[1]);
					if(  $ipt == 4 or $ipt == 6 ){
						$amc{$mc}{'ty'}   = $ipt;
						$amc{$mc}{'ip'}   = $ad[1];
						$amc{$mc}{'time'} = $ad[2];
						$amc{$mc}{'name'} = ($ad[3] and $main::opt{'N'} !~ /-iponly$/)?$ad[3]:'';
						Prt("Address $amc{$mc}{'ip'}\t$amc{$mc}{'name'}\tOK\n");
					}else{
						Prt("$ad[1] doesn't look like an address\n");
					}
				}
			}
		}
	}
	if($_[0]){
		Prt('',"$nad arpwatch entries added as seeds\n");
		return $nad;
	}else{
		foreach my $mc( keys %amc ){
			if( $amc{$mc}{'time'} > $revive[0] ){						# Ignore older entries
				$arp{$amc{$mc}{'ty'}}{$mc}{''}{$amc{$mc}{'ip'}} = $amc{$mc}{'time'};
				if($amc{$mc}{'name'} and $main::opt{'N'} !~ /-iponly$/){ db::WriteDNS($amc{$mc}{'ip'},'',0,$amc{$mc}{'name'}) }
				$nad++;
			}
		}
		Prt("ARPW:$nad arpwatch entries used\n","$nad arpwatch entries used, ");
		db::WriteArpND('',\%arp);
		Prt(''," written to DB\n");
	}
}

=head2 FUNCTION FloodFind()

Detect potential Switch flooders, based on population.

B<Options> device

B<Globals> -

B<Returns> - (generates events)

=cut
sub FloodFind{

	my ($dv) = @_;
	my $nfld = 0;

	Prt("\nFloodFind  --------------------------------------------------------------------  ".localtime()."\n");
	foreach my $if( keys %{$portprop{$dv}} ){
		my $mf = ($main::int{$dv}{$portprop{$dv}{$if}{idx}}{mcf})?$main::int{$dv}{$portprop{$dv}{$if}{idx}}{mcf}:$macflood;
		if( !$portprop{$dv}{$if}{lnk} and $#{$portprop{$dv}{$if}{pop}} > $mf and $mf ){
			$mq += mon::Event('N',150,'secf',$dv,$dv,"$#{$portprop{$dv}{$if}{pop}} MAC entries exceed threshold of $mf on $dv,$if");
			$nfld++;
		}
	}
	Prt("FLOD:$nfld IFs triggered a MACflood alert\n");
}

=head2 FUNCTION DevRRD()

Creates system and IF RRDs if necessary and then updates them.

B<Options> device name

B<Globals> -

B<Returns> -

=cut
sub DevRRD{

	my ($na,$skip) = @_;
	my $err  = 0;
	my $dok  = 1;
	my $rra  = '-';
	my $typ  = 'GAUGE';

	Prt("\nDevRRD  -----------------------------------------------------------------------  ".localtime()."\n");
	if( $main::dev{$na}{cul} ){
		($rra, $typ) = split(/;/, $main::dev{$na}{cul});
		$rra =~ s/[^a-zA-Z0-9]//g;
		$typ = ($typ eq "C")?"COUNTER":"GAUGE";
	}
	my $ddir = DevDir('rrd',$na);
	if( $ddir ){
		unless($main::opt{'t'}){
			unless(-e "$nedipath/rrd/$ddir/system.rrd"){
				my $ds = 2 * $rrdstep;
				RRDs::create("$nedipath/rrd/$ddir/system.rrd","-s","$rrdstep",
						"DS:cpu:GAUGE:$ds:0:255",
						"DS:memcpu:GAUGE:$ds:0:U",
						"DS:".lc($rra).":$typ:$ds:0:U",
						"DS:temp:GAUGE:$ds:-255:255",
						"RRA:AVERAGE:0.5:1:$rrdsize",
						"RRA:AVERAGE:0.5:10:$rrdsize"
						);
				$err = RRDs::error;
			}
			if( $err ){
				Prt("DRRD:Can't create $nedipath/rrd/$ddir/system.rrd\n","Rs");
			}else{
				RRDs::update "$nedipath/rrd/$ddir/system.rrd","N:$main::dev{$na}{cpu}:$main::dev{$na}{mcp}:$main::dev{$na}{cuv}:$main::dev{$na}{tmp}";
				$err = RRDs::error;
				if($err){
					Prt("ERR :RRD $nedipath/rrd/$ddir/system.rrd $err\n","Ru");
				}else{
					Prt("DRRD:Updated $nedipath/rrd/$ddir/system.rrd\n");
				}
			}
		}
		Prt("DRRD:CPU=$main::dev{$na}{cpu} MEM=$main::dev{$na}{mcp} TEMP=$main::dev{$na}{tmp} CUS=$main::dev{$na}{cuv}\n");

		return if $skip =~ /t/ and $skip =~ /e/ and $skip =~ /d/ and $skip =~ /b/;
		$err = '';

		Prt("DRRD:IFName        Inoct     Outoct  Inerr Outerr   Indis  Outdis Inbcst Stat\n");
		foreach my $i ( keys %{$main::int{$na}} ){
			if(exists $main::int{$na}{$i}{ina}){						# Avoid errors due empty ifnames
				$irf =  $main::int{$na}{$i}{ina};
				$irf =~ s/([^a-zA-Z0-9_.-])/"%" . uc(sprintf("%2.2x",ord($1)))/eg;
				unless($main::opt{'t'}){
					unless(-e "$nedipath/rrd/$ddir/$irf.rrd"){
						my $ds = 2 * $rrdstep;
						RRDs::create("$nedipath/rrd/$ddir/$irf.rrd","-s","$rrdstep",
								"DS:inoct:COUNTER:$ds:0:1E12",
								"DS:outoct:COUNTER:$ds:0:1E12",
								"DS:inerr:COUNTER:$ds:0:1E9",
								"DS:outerr:COUNTER:$ds:0:1E9",
								"DS:indisc:COUNTER:$ds:0:1E9",
								"DS:outdisc:COUNTER:$ds:0:1E9",
								"DS:inbcast:COUNTER:$ds:0:1E9",
								"DS:status:GAUGE:$ds:0:3",
								"RRA:AVERAGE:0.5:1:$rrdsize",
								"RRA:AVERAGE:0.5:10:$rrdsize"
								);
						$err = RRDs::error;
					}
					if($err){
						Prt("ERR :RRD $nedipath/rrd/$ddir/$irf.rrd $err\n","Ri($irf)");
					}else{
						RRDs::update "$nedipath/rrd/$ddir/$irf.rrd","N:$main::int{$na}{$i}{ioc}:$main::int{$na}{$i}{ooc}:$main::int{$na}{$i}{ier}:$main::int{$na}{$i}{oer}:$main::int{$na}{$i}{idi}:$main::int{$na}{$i}{odi}:$main::int{$na}{$i}{ibr}:".($main::int{$na}{$i}{sta} & 3);
						$err = RRDs::error;
						if($err){
							Prt("ERR :$irf.rrd $err\n","Ru($irf)");
						}
					}
				}
				Prt(sprintf ("DRRD:%-8.8s %10.10s %10.10s %6.6s %6.6s %7.7s %7.7s %6.6s %4.4s\n", $irf,$main::int{$na}{$i}{ioc},$main::int{$na}{$i}{ooc},$main::int{$na}{$i}{ier},$main::int{$na}{$i}{oer},$main::int{$na}{$i}{idi},$main::int{$na}{$i}{odi},$main::int{$na}{$i}{ibr},$main::int{$na}{$i}{sta}) );
			}else{
				Prt("DRRD:No IF name for IF-index $i\n","Rn($i)");
			}
		}
	}else{
		Prt("DRRD:Can't create $na directory in $nedipath/rrd\n","Rd");
	}
}

=head2 FUNCTION TopRRD()

Update Top traffic, error, power & monitoring RRDs.

B<Options> -

B<Globals> -

B<Returns> -

=cut
sub TopRRD{

	my (%ec, %ifs);
	my $err = "";
	my $mok = my $msl = my $mal = 0;
	$ec{'50'} = $ec{'100'} = $ec{'150'} = $ec{'200'} = $ec{'250'} = 0;
	$ifs{'0'} = $ifs{'1'} = $ifs{'3'} = 0;
	my $tinoct = my $toutoct = my $tinerr = my $touterr = my $tindis = my $toutdis = 0;
	# Access traffic using delta octets to avoid error from missing or rebooted switches. Needs to be divided by 1G*rrdstep to get GB/s
	my $tat = db::Select('interfaces','',"round(sum(dinoct)/1000000000/$rrdstep,6),round(sum(doutoct)/1000000000/$rrdstep,6)","linktype = '' AND lastdis > ".($main::now - $rrdstep),'LEFT JOIN devices USING (device)');
	if( defined $tat->[0][1] ){
		$tinoct  = $tat->[0][0];
		$toutoct = $tat->[0][1];
	}
	# Wired interface (type not 71) errors/s
	my $twe = db::Select('interfaces','',"round(sum(dinerr)/$rrdstep,3),round(sum(douterr)/$rrdstep,3),round(sum(dindis)/$rrdstep,3),round(sum(doutdis)/$rrdstep,3)","iftype != 71 AND lastdis > ".($main::now - $rrdstep),'LEFT JOIN devices USING (device)');
	if( defined $twe->[0][3] ){
		$tinerr  = $twe->[0][0];
		$touterr = $twe->[0][1];
		$tindis  = $twe->[0][2];
		$toutdis = $twe->[0][3];
	}

	# Total nodes lastseen
	my $nodl = db::Select('nodes','',"count(lastseen)","lastseen > $main::now - $rrdstep");

	# Total nodes firstseen
	my $nodf = db::Select('nodes','',"count(firstseen)","firstseen > $main::now - $rrdstep");

	# Total power in Watts
	my $pwr = db::Select('devices','',"sum(totpoe)","lastdis > $main::now - $rrdstep");

	# Count IF ifstat up=3, down=1 and admin down=0
	my $ifdb = db::Select('interfaces','ifstat','ifstat,count(ifstat) as c',"lastdis > $main::now - $rrdstep group by ifstat",'LEFT JOIN devices USING (device)');
	foreach my $k (keys %$ifdb ){
		$ifs{$k} = $ifdb->{$k}{'c'} if $ifdb->{$k}{'c'};
	}

	# Number of monitored targets / check if moni's running...
	my $lck = db::Select('monitoring','',"max(lastok)");
	if($lck and $lck > (time - 2 * $pause) ){
		$mok = db::Select('monitoring','',"count(status)","test != 'none' AND latency <= latwarn AND status = 0");
		$msl = db::Select('monitoring','',"count(status)","test != 'none' AND latency > latwarn AND status = 0");
		$mal = db::Select('monitoring','',"count(status)","test != 'none' AND status > 0");
	}else{
		my $msg = "No successful check at all, is moni running?";
		$msg = "Last successful check on ".localtime($lck).", is moni running?" if $lck;
		$mq += mon::Event('Y',150,'mons','NeDi','NeDi',$msg);
		Prt("TRRD:$msg\n");
	}

	# Number of cathegorized events during discovery cycle
	my $dbec = db::Select('events','level',"level,count(*) as c","time > ".(time - $rrdstep)." GROUP BY level");
	foreach my $k (keys %$dbec ) {
		$ec{$k} = $dbec->{$k}{'c'} if $dbec->{$k}{'c'};
	}

	Prt("TRRD:Trf=$tinoct/$toutoct Err=$tinerr/$touterr Dis=$tindis/$toutdis\n");
	Prt("TRRD:Up/Dn/Dis=$ifs{'3'}/$ifs{'1'}/$ifs{'0'} Pwr=${pwr}W Nod=$nodl/$nodf Mon=$mok/$msl/$mal Event=$ec{'50'}/$ec{'100'}/$ec{'150'}/$ec{'200'}/$ec{'250'}\n");
	if( $main::opt{'t'} ){
		Prt("TRRD:Not writing when testing\n");
	}else{
		unless(-e "$nedipath/rrd/top.rrd"){
			my $ds = 2 * $rrdstep;
			RRDs::create(	"$nedipath/rrd/top.rrd",
					"-s","$rrdstep",
					"DS:tinoct:GAUGE:$ds:0:U",
					"DS:totoct:GAUGE:$ds:0:U",
					"DS:tinerr:GAUGE:$ds:0:U",
					"DS:toterr:GAUGE:$ds:0:U",
					"DS:tindis:GAUGE:$ds:0:U",
					"DS:totdis:GAUGE:$ds:0:U",
					"DS:nodls:GAUGE:$ds:0:U",
					"DS:nodfs:GAUGE:$ds:0:U",
					"DS:tpoe:GAUGE:$ds:0:U",
					"DS:upif:GAUGE:$ds:0:U",
					"DS:downif:GAUGE:$ds:0:U",
					"DS:disif:GAUGE:$ds:0:U",
					"DS:monok:GAUGE:$ds:0:U",
					"DS:monsl:GAUGE:$ds:0:U",
					"DS:monal:GAUGE:$ds:0:U",
					"DS:msg50:GAUGE:$ds:0:U",
					"DS:msg100:GAUGE:$ds:0:U",
					"DS:msg150:GAUGE:$ds:0:U",
					"DS:msg200:GAUGE:$ds:0:U",
					"DS:msg250:GAUGE:$ds:0:U",
					"RRA:AVERAGE:0.5:1:$rrdsize",
					"RRA:AVERAGE:0.5:10:$rrdsize");
			$err = RRDs::error;
		}
		if($err){
			Prt("ERR :$err\n");
		}else{
			RRDs::update "$nedipath/rrd/top.rrd","N:$tinoct:$toutoct:$tinerr:$touterr:$tindis:$toutdis:$nodl:$nodf:$pwr:$ifs{'3'}:$ifs{'1'}:$ifs{'0'}:$mok:$msl:$mal:$ec{'50'}:$ec{'100'}:$ec{'150'}:$ec{'200'}:$ec{'250'}";
			$err = RRDs::error;
			if($err){
				Prt("ERR :$err\n");
			}else{
				Prt("TRRD:$nedipath/rrd/top.rrd update OK\n");
			}
		}
	}
}

=head2 FUNCTION WriteCfgFile()

Creates a directory with device name, if necessary and writes its
configuration to a file (with a timestamp as name).

B<Options> device name

B<Globals> -

B<Returns> -

=cut
sub WriteCfgFile{

	use POSIX qw(strftime);

	my ($dv) = @_;
	$dv      =~ s/([^a-zA-Z0-9_.-])/"%" . uc(sprintf("%2.2x",ord($1)))/eg;
	my $ok   = 1;
	unless(-e "$nedipath/conf/$dv"){
		Prt("WCFF:Creating $nedipath/conf/$dv\n");
		$ok = mkdir ("$nedipath/conf/$dv", 0755);
	}
	my $wcf = "$nedipath/conf/$dv/".strftime ("%Y-%m%d-%H%M.cfg", localtime($main::now) );
	if($ok and open (CF, ">$wcf" ) ){
		foreach ( @curcfg ){ print CF "$_\n" }
		close (CF);
		Prt("WCFF:Config written to $wcf\n");

		if( $main::opt{'B'} =~ /^[1-9][0-9]+$/ ){						# if >0 only keep that many, based on raider82's idea
			my @cfiles = sort {$b cmp $a} glob("$nedipath/conf/$dv/*.cfg");
			my $cur = 0;
			foreach my $cf (@cfiles) {
				$cur++;
				if($cur > $main::opt{'B'}){
					$dres = unlink ("$cf");
					if($dres){
						Prt("WCFF:Deleted $cf\n");
					}else{
						Prt("ERR :Deleting config $cf\n","Bd");
					}
				}
			}
		}
	}else{
		Prt("ERR :Writing config $wcf","Bw");
	}
}


=head2 FUNCTION CheckPolicy()

Check given policy class for match and execute or queue (interface related) actions
A reference to the target is used is it may contain a very long config
The $err argument skips all processing to avoid erratic actions (e.g. if walking Discovery Protocol had major errors)

B<Options> class,\target,device,vlan,interface

B<Globals> -

B<Returns> -

=cut
sub CheckPolicy{

	my ($cl,$tgtref,$dv,$vl,$if,$err) = @_;

	foreach my $r ( keys %{$pol->{$cl}} ){

		my $m = 0;
		my ($o,$ic,$lt,$ex) = split //, $pol->{$cl}{$r}{'polopts'};
		if( $err ){
			$ex = 'S';
			$o  = "skipped due to '$err' error";
		}

		if( $cl eq 'mdv' or $cl eq 'cif' ){							# Monitor and IF-Context policies always match
			$m = 1;
		}elsif( $o eq 'I' and ${$tgtref} =~ /$pol->{$cl}{$r}{'target'}/ ){
			$o = 'matches';
			$m = 1;
		}elsif( $o eq 'E' and ${$tgtref} !~ /$pol->{$cl}{$r}{'target'}/ ){
			$o = 'is missing';
			$m = 1;
		}elsif( $o eq '>' and ${$tgtref} > $pol->{$cl}{$r}{'target'} ){
			$o = "${$tgtref} exceeds target of ".$pol->{$cl}{$r}{'target'};
			$m = 1;
		}elsif( $o eq '<' and ${$tgtref} < $pol->{$cl}{$r}{'target'} ){
			$o = "${$tgtref} is below target of ".$pol->{$cl}{$r}{'target'};
			$m = 1;
		}

		if( $m ){
			if( !$pol->{$cl}{$r}{'device'} or $dv =~ $pol->{$cl}{$r}{'device'} ){
				if( !$pol->{$cl}{$r}{'type'} or $main::dev{$dv}{'ty'} =~ $pol->{$cl}{$r}{'type'} ){
					if( !$pol->{$cl}{$r}{'location'} or $main::dev{$dv}{'lo'} =~ $pol->{$cl}{$r}{'location'} ){
						if( !$pol->{$cl}{$r}{'contact'} or $main::dev{$dv}{'co'} =~ $pol->{$cl}{$r}{'devgroup'} ){
							if( !$pol->{$cl}{$r}{'devgroup'} or $main::dev{$dv}{'dg'} =~ $pol->{$cl}{$r}{'devgroup'} ){
								if( $cl eq 'cfg' ){
									$mq += mon::Event( $pol->{$cl}{$r}{'alert'},200,'spcf',$dv,$dv,"Policy $r: Config $o $pol->{$cl}{$r}{'target'} $pol->{$cl}{$r}{'info'}","Policy $r:Config $o" );
								}elsif( $cl eq 'rds' ){
									$mq += mon::Event( $pol->{$cl}{$r}{'alert'},200,'sprd',$dv,$dv,"Policy $r: Route Destination $o $pol->{$cl}{$r}{'target'} $pol->{$cl}{$r}{'info'}","Policy $r:Route $o $pol->{$cl}{$r}{'target'}" );
								}elsif( $cl eq 'tmc' ){
									$mq += mon::Event( $pol->{$cl}{$r}{'alert'},200,'sptm',$dv,$dv,"Policy $r: Total #MACs $o $pol->{$cl}{$r}{'info'}","Policy $r:Total #MACs = $o" );
								}elsif( $cl eq 'mdv' ){
									my $test = ($pol->{$cl}{$r}{'target'} =~ /-|no|none/i)?'none':${$tgtref}?'uptime':'icmp';
									db::Insert('monitoring','name,monip,test,alert,device,latwarn',
										$db::dbh->quote($dv).",".Ip2Dec($main::dev{$dv}{'ip'}).",'$test',$pol->{$cl}{$r}{'alert'},".$db::dbh->quote($dv).",$latw" );
								}else{
									if( !$pol->{$cl}{$r}{'ifname'} or $if =~ $pol->{$cl}{$r}{'ifname'} ){
										if( !$pol->{$cl}{$r}{'vlan'} or $vl =~ $pol->{$cl}{$r}{'vlan'} ){
											if( $ic eq '-' or $if and exists $portprop{$dv}{$if}{cnd} and $ic eq $portprop{$dv}{$if}{cnd} ){
												$lt = '' if $lt eq 'O';
												if( $lt eq '-' or $if and $lt eq $portprop{$dv}{$if}{lnk} ){
													my $msg = "$cl policy $r: ${$tgtref} $o ".($if?" on interface $if":"").($vl?" Vl$vl":"");
													if( $cl eq 'cif' ){
														Prt("DBG :Portconfig $r on $if $o:$pol->{$cl}{$r}{'target'}\n") if $main::opt{'d'};
														if ( exists $ifcontext{$if} ){
															if( $o eq 'I' and $ifcontext{$if} =~ /$pol->{$cl}{$r}{'target'}/ ){
																$mq += mon::Event( $pol->{$cl}{$r}{'alert'},200,'spci',$dv,$dv,"Policy $r: Portconfig matches $pol->{$cl}{$r}{'target'} on $if $pol->{$cl}{$r}{'info'}","Policy $r:Portcfg matches" );
															}elsif( $o eq 'E' and $ifcontext{$if} !~ /$pol->{$cl}{$r}{'target'}/ ){
																$mq += mon::Event( $pol->{$cl}{$r}{'alert'},200,'spci',$dv,$dv,"Policy $r: Portconfig is missing $pol->{$cl}{$r}{'target'} on $if $pol->{$cl}{$r}{'info'}","Policy $r:Portcfg missing" );
															}
														}elsif( $o eq 'I' ){
															$mq += mon::Event( $pol->{$cl}{$r}{'alert'},200,'spci',$dv,$dv,"Policy $r:No context found for port $if $pol->{$cl}{$r}{'info'}","Policy $r:No context for port $if" );
														}
													}else{
														Prt("DBG :$msg, '$ex' action".($act{$dv}{$if}{'rp'}?", reset policy in $act{$dv}{$if}{'rp'}min":"")."\n") if $main::opt{'d'};
														if( !defined $act{$dv}{$if}{'ex'} or $ex eq 'S' ){
															if( $ex eq 'A'){
																if( $cl eq 'nbr' and ${$tgtref} ne $portprop{$dv}{$if}{ali} ){
																	$act{$dv}{$if}{'ar'} = ${$tgtref};
																}elsif( $cl eq 'mac' and @{$portprop{$dv}{$if}{pop}} == 1 ){
																	my $dns = db::Select('nodarp','','nodip,aname',"mac='${$portprop{$dv}{$if}{pop}}[0]'",'LEFT JOIN dns USING (nodip)');
																	if( $dns->[0][1] and $dns->[0][1] ne $portprop{$dv}{$if}{ali} ){
																		$act{$dv}{$if}{'ar'} = $dns->[0][1];
																	}
																}
															}else{
																$act{$dv}{$if}{'rp'} = $pol->{$cl}{$r}{'respolicy'};
															}
															$act{$dv}{$if}{'ex'} = $ex;
															$act{$dv}{$if}{'al'} = $pol->{$cl}{$r}{'alert'};
															$act{$dv}{$if}{'cl'} = 'sp'.substr($cl,0,2);
															$act{$dv}{$if}{'em'} = $msg.' '.$pol->{$cl}{$r}{'info'};
															$act{$dv}{$if}{'sm'} = "$o $cl policy $r";
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}

}

=head2 FUNCTION ProPolicy()

Process policy actions for interfaces

B<Options> device

B<Globals> -

B<Returns> -

=cut
sub ProPolicy{

	my ($dv,$skip) = @_;

	my @aq = ();
	my $rpol = '';
	my $os = $main::dev{$dv}{'os'};
	Prt("\nProPolicy  --------------------------------------------------------------------  ".localtime()."\n");
	if( $skip =~ /P/ ){
		Prt("PROP:Skipping policy actions due to skip /$skip/\n");
		return '';
	}elsif( defined $main::mon{$dv}{up} and $main::mon{$dv}{up} < $rrdstep ){
		Prt("PROP:Skipping policy actions due to uptime < rrdstep\n");
		return '';
	}else{												# No action whith DP or FWD-table skipped
		$rpol = db::Select('policies','ifname','*',"status=10 AND device=".$db::dbh->quote($dv)." AND time < $main::now");
		foreach my $if ( keys %{$rpol} ){
			my $rev = ($rpol->{$if}{'alert'} & 128)?1:0;
			my ($o,$ic,$lt,$ex) = split //, $rpol->{$if}{'polopts'};
			if( $ex eq 'D' and exists $cli::cmd{$os}{'ifes'} ){
				$mq += mon::Event( $rev,50,'spr',$dv,$dv,"Reset policy $rpol->{$if}{'id'} enabling $if",'' );
				push @aq, "$cli::cmd{$os}{'ifct'} $if";
				push @aq, " $cli::cmd{$os}{'ifes'}";
			}elsif( $ex eq 'P' and exists $cli::cmd{$os}{'ifep'} ){
				$mq += mon::Event( $rev,50,'spr',$dv,$dv,"Reset policy $rpol->{$if}{'id'} restoring PoE on $if",'' );
				push @aq, "$cli::cmd{$os}{'ifct'} $if";
				push @aq, " $cli::cmd{$os}{'ifep'}";
			}
			my $dr = db::Delete('policies',"id=$rpol->{$if}{'id'}" );
			Prt("PROP:$dr reset policies processed\n");
		}
	}

	foreach my $if ( sort keys %{$act{$dv}} ){
		if( $act{$dv}{$if}{'ex'} eq 'S' ){
			$mq += mon::Event( $act{$dv}{$if}{'al'},100,$act{$dv}{$if}{'cl'},$dv,$dv,$act{$dv}{$if}{'em'},$act{$dv}{$if}{'sm'} );
			Prt("PROP:$act{$dv}{$if}{'em'} skip action\n");
		}elsif( $skip =~ /[pF]/ ){								# No action whith DP or FWD-table skipped
			Prt("PROP:$act{$dv}{$if}{'em'} ignored due to skip /$skip/\n");
		}else{
			if( exists $rpol->{$if} ){							# Process action unless reset policy is active
				Prt("PROP:Ignoring $act{$dv}{$if}{'em'} due to pending reset policy\n");
			}else{
				$mq += mon::Event( $act{$dv}{$if}{'al'},200,$act{$dv}{$if}{'cl'},$dv,$dv,$act{$dv}{$if}{'em'},$act{$dv}{$if}{'sm'} );
				if( $act{$dv}{$if}{'ex'} eq 'D' and exists $cli::cmd{$os}{'ifds'} ){
					push @aq, "$cli::cmd{$os}{'ifct'} $if";
					push @aq, " $cli::cmd{$os}{'ifds'}";
				}elsif( $act{$dv}{$if}{'ex'} eq 'P' and exists $cli::cmd{$os}{'ifdp'} ){
					push @aq, "$cli::cmd{$os}{'ifct'} $if";
					push @aq, " $cli::cmd{$os}{'ifdp'}";
				}elsif( $act{$dv}{$if}{'ex'} eq 'A' and exists $cli::cmd{$os}{'ifal'} and defined $act{$dv}{$if}{'ar'}){
					push @aq, "$cli::cmd{$os}{'ifct'} $if";
					push @aq, " $cli::cmd{$os}{'ifal'} \"$act{$dv}{$if}{'ar'}\"";
				}
				if( $#aq and $act{$dv}{$if}{'rp'} ){					# Create a reset policy only if action was set
					db::Insert('policies','status,class,polopts,device,ifname,alert,info,time',"10,'res','---$act{$dv}{$if}{'ex'}',".$db::dbh->quote($dv).",'$if',$act{$dv}{$if}{'al'},'$act{$dv}{$if}{'em'}',".($main::now+$act{$dv}{$if}{'rp'}*60) );
				}
			}
		}
	}

	if( scalar @aq ){
		$dv =~ s/([^a-zA-Z0-9_.-])/"%" . uc(sprintf("%2.2x",ord($1)))/eg;
		my $aqf = "$nedipath/cli/pol_$dv";
		if( open (CF, ">$aqf" ) ){
			print CF "$cli::cmd{$os}{'conf'}\n";
			foreach ( @aq ){ print CF "$_\n" }
			print CF "$cli::cmd{$os}{'end'}\n";
			close (CF);
			Prt("PROP:$#aq actions written to $aqf\n");
		}else{
			Prt("ERR :Writing actions $aqf","Pw");
		}

		return "pol_$dv";
	}else{
		Prt("PROP:No actions triggered\n");
		return '';
	}
}

=head2 FUNCTION DevDir()

Create device dir, if it doesn't exist

B<Options> parentdir,device

B<Globals> -

B<Returns> dirname

=cut
sub DevDir{

	my $ddir = $_[1];

	$ddir =~ s/([^a-zA-Z0-9_.-])/"%" . uc(sprintf("%2.2x",ord($1)))/eg;

	my $ok = 1;
	unless(-e "$nedipath/$_[0]/$ddir"){
		Prt("CMD :Creating $nedipath/$_[0]/$ddir\n");
		$ok = mkdir( "$nedipath/$_[0]/$ddir", 0755 );
	}

	return $ddir if $ok;
}

=head2 FUNCTION Daemonize()

Fork current programm and detatch from cli.

B<Options> -

B<Globals> -

B<Returns> -

=cut
sub Daemonize{

	use POSIX qw(setsid);

	Prt(" daemonizing");
	defined(my $pid = fork)   or die "Can't fork: $!";
	exit if $pid;
	setsid                    or die "Can't start a new session: $!";
	umask 0;
}


=head2 FUNCTION RetrVar()

Retrieve variables previousely stored in .db files for debugging.

B<Options> -

B<Globals> all important globals (see code)

B<Returns> -

=cut
sub RetrVar{

	use Storable;

	my $seedini = retrieve("$main::p/seedini.db");
	%seedini = %$seedini;
	my $sysobj = retrieve("$main::p/sysobj.db");
	%sysobj = %$sysobj;
	my $portprop = retrieve("$main::p/portprop.db");
	%portprop = %$portprop;
	my $doip = retrieve("$main::p/doip.db");
	%doip = %$doip;
	my $arp = retrieve("$main::p/arp.db");
	%arp = %$arp;
	my $ifmac = retrieve("$main::p/ifmac.db");
	%ifmac = %$ifmac;
	my $ifip = retrieve("$main::p/ifip.db");
	%ifip = %$ifip;

	my $donenam = retrieve("$main::p/donenam.db");
	@donenam = @$donenam;
	my $doneid = retrieve("$main::p/doneid.db");
	@doneid = @$doneid;
	my $doneip = retrieve("$main::p/doneip.db");
	@doneip = @$doneip;


	my $dev = retrieve("$main::p/dev.db");
	%main::dev = %$dev;
	my $net = retrieve("$main::p/net.db");
	%main::net = %$net;
	my $int = retrieve("$main::p/int.db");
	%main::int = %$int;
	my $vlan = retrieve("$main::p/vlan.db");
	%main::vlan = %$vlan;
}


=head2 FUNCTION StorVar()
Write important variables in .db files for debugging.

B<Options> -

B<Globals> -

B<Returns> -

=cut
sub StorVar{

	use Storable;

	store \%seedini, "$main::p/seedini.db";
	store \%sysobj, "$main::p/sysobj.db";
	store \%portprop, "$main::p/portprop.db";
	store \%doip, "$main::p/doip.db";
	store \%arp, "$main::p/arp.db";
	store \%ifmac, "$main::p/ifmac.db";
	store \%ifip, "$main::p/ifip.db";

	store \@donenam, "$main::p/donenam.db";
	store \@doneid, "$main::p/doneid.db";
	store \@doneip, "$main::p/doneip.db";

	store \%main::dev, "$main::p/dev.db";
	store \%main::int, "$main::p/int.db";
	store \%main::net, "$main::p/net.db";
	store \%main::vlan, "$main::p/vlan.db";
}


=head2 FUNCTION Prt()

Print output based on verbosity or buffer into variable in case
of multiple threads.

B<Options> Short output, verbose output

B<Globals> -

B<Returns> -

=cut
sub Prt{
	if( $main::opt{'v'} ){
		print "$_[0]" if $_[0];
	}elsif( $_[1] ){
		print "$_[1]";
	}
}

=head2 FUNCTION DevIcon()

Assign icon based on services or use existing one

B<Options> icon, services

B<Globals> -

B<Returns> icon

=cut
sub DevIcon{
	if($_[1]){
		return $_[1];
	}else{
		if( $_[0] > 8 ){
			return 'csan';
		}elsif( $_[0] > 4 ){
			return 'w3an';
		}elsif( $_[0] > 1 ){
			return 'w2an';
		}else{
			return 'w1an';
		}
	}
}

=head2 FUNCTION DevVendor()

Return vendor based on enterprise#
Switch/Case or using the official vendor listing was considered:
1.Switch/Case is a perl core module and adds overhead
2.Vendorlisting contains some way-too-long-vendor-names

B<Options> sysobjid

B<Globals> -

B<Returns> vendor

=cut
sub DevVendor{

	if( $_[0] =~ /^1.3.6.1.4.1.(9|5596|14179|15497|29671)\./ ){					# Not matching all literal dots, but easier to read!
		return'Cisco';
	}elsif( $_[0] =~ /^1.3.6.1.4.1.(202)\./ ){
		return'SMC Net';
	}elsif( $_[0] =~ /^1.3.6.1.4.1.(207)\./ ){							# tx n0n0
		return'Allied Telesis';
	}elsif( $_[0] =~ /^1.3.6.1.4.1.(259)\./ ){
		return'Accton';
	}elsif( $_[0] =~ /^1.3.6.1.4.1.(297)\./ ){
		return'Xerox';
	}elsif( $_[0] =~ /^1.3.6.1.4.1.(641)\./ ){
		return'Lexmark';
	}elsif( $_[0] =~ /^1.3.6.1.4.1.(2435)\./ ){
		return'Brother';
	}elsif( $_[0] =~ /^1.3.6.1.4.1.(26928)\./ ){
		return'Aerohive';
	}elsif( $_[0] =~ /^1.3.6.1.4.1.(6486|637|6527)\./ ){
		return'Alcatel-Lucent';
	}elsif( $_[0] =~ /^1.3.6.1.4.1.(318)\./ ){
		return'APC';
	}elsif( $_[0] =~ /^1.3.6.1.4.1.(30065)\./ ){
		return'Arista';
	}elsif( $_[0] =~ /^1.3.6.1.4.1.(14823)\./ ){
		return'Aruba';
	}elsif( $_[0] =~ /^1.3.6.1.4.1.(45|2272)\./ ){
		return'Avaya';
	}elsif( $_[0] =~ /^1.3.6.1.4.1.(10704)\./ ){
		return'Barracuda';
	}elsif( $_[0] =~ /^1.3.6.1.4.1.(3417)\./ ){
		return'Blue Coat';
	}elsif( $_[0] =~ /^1.3.6.1.4.1.(289|1588|1991|30803)\./ ){
		return'Brocade';
	}elsif( $_[0] =~ /^1.3.6.1.4.1.(674|6027)\./ ){
		return'Dell';
	}elsif( $_[0] =~ /^1.3.6.1.4.1.(476)\./ ){
		return'Emerson';
	}elsif( $_[0] =~ /^1.3.6.1.4.1.(1916|5624)\./ ){
		return'Extreme Networks';
	}elsif( $_[0] =~ /^1.3.6.1.4.1.(3375)\./ ){
		return'F5';
	}elsif( $_[0] =~ /^1.3.6.1.4.1.(12356)\./ ){
		return'Fortinet';
	}elsif( $_[0] =~ /^1.3.6.1.4.1.(11|43|8744|25506)\./ ){
		return'Hewlett-Packard';
	}elsif( $_[0] =~ /^1.3.6.1.4.1.(2011)\./ ){
		return'Huawei';
	}elsif( $_[0] =~ /^1.3.6.1.4.1.(2636|3224|12532)\./ ){
		return'Juniper';
	}elsif( $_[0] =~ /^1.3.6.1.4.1.(2356)\./ ){
		return'Lancom';
	}elsif( $_[0] =~ /^1.3.6.1.4.1.(13742)\./ ){
		return'Raritan';
	}elsif( $_[0] =~ /^1.3.6.1.4.1.(5651)\./ ){
		return'Maipu';
	}elsif( $_[0] =~ /^1.3.6.1.4.1.(5206|33049)\./ ){
		return'Mellanox';
	}elsif( $_[0] =~ /^1.3.6.1.4.1.(1573|3181|3401)\./ ){
		return'Microsens';
	}elsif( $_[0] =~ /^1.3.6.1.4.1.(14988)\./ ){
		return'Mikrotik';
	}elsif( $_[0] =~ /^1.3.6.1.4.1.(789)\./ ){
		return'Netapp';
	}elsif( $_[0] =~ /^1.3.6.1.4.1.(4526)\./ ){
		return'Netgear';
	}elsif( $_[0] =~ /^1.3.6.1.4.1.(266)\./ ){
		return'Nexans';
	}elsif( $_[0] =~ /^1.3.6.1.4.1.(94)\./ ){
		return'Nokia';
	}elsif( $_[0] =~ /^1.3.6.1.4.1.(24681)\./ ){
		return'Qnap';
	}elsif( $_[0] =~ /^1.3.6.1.4.1.(25461)\./ ){
		return'Palo Alto';
	}elsif( $_[0] =~ /^1.3.6.1.4.1.(8059)\./ ){
		return'Paradyne';
	}elsif( $_[0] =~ /^1.3.6.1.4.1.(10456)\./ ){
		return'Planet';
	}elsif( $_[0] =~ /^1.3.6.1.4.1.(17163)\./ ){
		return'Riverbed';
	}elsif( $_[0] =~ /^1.3.6.1.4.1.(25053)\./ ){
		return'Ruckus';
	}elsif( $_[0] =~ /^1.3.6.1.4.1.(8741)\./ ){
		return'Sonicwall';
	}elsif( $_[0] =~ /^1.3.6.1.4.1.(1369)\./ ){
		return'Stonesoft';
	}elsif( $_[0] =~ /^1.3.6.1.4.1.(10002)\./ ){
		return'Ubiquiti';
	}elsif( $_[0] =~ /^1.3.6.1.4.1.(6876)\./ ){
		return'VMware';
	}elsif( $_[0] =~ /^1.3.6.1.4.1.(890)\./ ){
		return'Zyxel';
	}else{
		return'Other';
	}
}

=head2 FUNCTION KeyScan()

Useful with strict host key checking enabled. Invoked with -k the ssh
keys will be stored in the users .ssh directory. Should only be used at
the first discovery.

B<Options> device IP

B<Globals> -

B<Returns> -

=cut
sub KeyScan{

	Prt("\nKeyScan  ----------------------------------------------------------------------  ".localtime()."\n");

	if($main::opt{'K'}){										# Delete stored key, based on raider82's idea
		my $res = `ssh-keygen -R $_[0] -f ~/.ssh/known_hosts`;
		Prt("DISC:Cli: key removed for $_[0]\n","Kr");
	}

	if($main::opt{'k'}){										# Scan key (tx jug)
		my $res = `ssh-keyscan $_[0] 2>&1 >> ~/.ssh/known_hosts`;
		if( $res =~ m/^$|no hostkey alg/ ){
			Prt("ERR :ssh-keyscan rsa failed, trying dsa\n");
			$res = `ssh-keyscan -t dsa $_[0] 2>&1 >> ~/.ssh/known_hosts`;
			if( $res =~ m/^$|no hostkey alg/ ){
				Prt("ERR :ssh-keyscan dsa failed, trying rsa1 as last resort\n");
				$res = `ssh-keyscan -t rsa1 $_[0] 2>&1 >> ~/.ssh/known_hosts`;
				if( $res =~ m/^$|no hostkey alg/ ){
					Prt("ERR :ssh-keyscan for $_[0] failed\n","Ke");
				} else {
					chomp($res);
					Prt("KEY :$res (RSA1) added to ~/.ssh/known_hosts\n","Ks");
				}
			} else {
				chomp($res);
				Prt("KEY :$res (DSA) added to ~/.ssh/known_hosts\n","Ks");
			}
		}else{
			chomp($res);
			Prt("KEY :$res (RSA) added to ~/.ssh/known_hosts\n","Ks");
		}
	}
}

=head2 FUNCTION ResolveName()

Resolves IP via DNS or find in DB

B<Options> DNS Name

B<Globals> -

B<Returns> IP/0

=cut
sub ResolveName{
	my $hip = gethostbyname($_[0]);
	if(defined $hip){
		return join('.',unpack( 'C4',$hip ) );
	}elsif(exists $main::dev{$_[0]}){
		return $main::dev{$_[0]}{ip};
	}else{
		return 0;
	}
}

=head2 FUNCTION IPType()

Return type of IP addres:

 0 invalid
 1 IPv4 loopback or broadcast
 4 IPv4 address
 5 IPv6 special (rudimentary check of loopback, multicast etc.)
 6 IPv6 address

B<Options> IP address

B<Globals> -

B<Returns> IP type

=cut
sub IPType{
	if( defined $_[0] and $_[0] ne '' ){
		if( $_[0] =~ /^0$|^127\.0\.0\.|^0\.0\.0\.0$|^255\.255\.255\.255$/ ){
			return 1;
		}elsif( $_[0] =~ /^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$/ ){
			return 4;
		}elsif( $_[0] =~ /^(::|ff.*)$/ ){
			return 5;
		}elsif( $_[0] =~ /[:0-9a-fA-F]+/ ){
			return 6;
		}else{
			return 0;
		}
	}
	return 0;
}

=head2 FUNCTION ValidMAC()

Check whether MAC is usable and belongs to a device:

 0 = invalid MAC
 1 = valid node MAC
 2 = device MAC

B<Options> MAC address

B<Globals> -

B<Returns> MAC status

=cut
sub ValidMAC{
	if( defined $_[0] and $_[0] =~ /^[0-9a-f]{12}$/ ){
		if( exists $ifmac{$_[0]} ){
			return 2;
		}elsif(  $_[0] !~ /$ignoredmacs/ ){
			return 1;
		}
	}
}

=head2 FUNCTION CheckProduct()

Tries to find a device type in a vendor specific EoL listing.

 E.g. Cisco products are read from ciscoeol.csv (in the nedi directory):
 Migration Product ID			added to comment
 End of Routine Failure Analysis Date	mapped to endsupport
 End of Service Contract Renewal	mapped to endwarranty
 Last Date of Support			mapped to endlife

B<Options> vendor, type

B<Globals> -

B<Returns> endwarranty,endlife,endsupport,migration info

=cut
sub CheckProduct{

	if($_[0] eq 'Cisco' and -e "$main::p/ciscoeol.csv"){
		my @l = `egrep -hi '^$_[1](\/K9)?;' $main::p/ciscoeol.csv`;
		if( @l and scalar @l < 4 ){								# Tolerating up to 3 duplicates and picking the 1st
			my @v = split(';',$l[0]);
			Prt("CHKP:$_[0] $_[1] is EoL, check PDID $v[5]\n");
			return( $v[1],$v[2],$v[3],", can be migrated to $v[4]" );
		}else{
			Prt("CHKP:".scalar @l." matches found with $_[1] in ciscoeol.csv\n");
			return( 0,0,0,'' );
		}
	}else{
		return( 0,0,0,'' );
	}
}

=head2 FUNCTION CheckOptic()

1. Check signal levels and set module status (and description, if set in nedi.conf)
2. Create events based on alert and warning thresholds if corresponding IF status is up

B<Options> device name, modidx, power, unit, direction (T or R), IF status

 Unit can be:
 - (empty) dBm
 - d dezi  dBm
 - m milli dBm
 - u micro Watt

B<Globals> main::mod

B<Returns> -

=cut
sub CheckOptic{

	my ($na,$x,$p,$u,$d,$i) = @_;

	#substr(misc::Val2Char($rxl{"1.3.6.1.4.1.9.9.91.1.1.1.1.4.$x"},'dBm').$main::mod{$na}{$prl{$key}}{fw},0,9);
	my $f = $d eq 'R'?'fw':'sw';
	$p = '' unless defined $p;
	if( $p =~ /^-?\d+/ ){
		$p =~ s/ dBm normal//;									# Edgecore add ' dBm normal'
		my $th = 'default';
		if( exists $domal{$main::mod{$na}{$x}{mo}} ){
			$th = $main::mod{$na}{$x}{mo};
			$main::mod{$na}{$x}{de} = $domal{$main::mod{$na}{$x}{mo}}{de} if $domal{$main::mod{$na}{$x}{mo}}{de};
		}
		if( $u eq 'd'){
			$p /= 10;
		}elsif( $u eq 'm'){
			$p /= 1000;
		}elsif( $u eq 'u'){
			$p = $p==0?-100:10*log($p/1000000)/2.302585093;
		}
		$main::mod{$na}{$x}{$f} = int($p-0.5);
		if( $main::mod{$na}{$x}{$f} > $domal{$th}{$d.'H'} or $main::mod{$na}{$x}{$f} < $domal{$th}{$d.'L'} ){
			$main::mod{$na}{$x}{st} = 132;
			$main::dev{$na}{sta} = $main::dev{$na}{sta} | 32;				# Set DOM alert, no matter the IF status
			mon::Event('M',200,'nedo',$na,$na,"Transceiver $main::mod{$na}{$x}{sl} ${d}X power is $main::mod{$na}{$x}{$f} dBm") if $i == 3;
		}elsif( $main::mod{$na}{$x}{$f} >= $domal{$th}{$d.'H'}-3 or $main::mod{$na}{$x}{$f} <= $domal{$th}{$d.'L'}+3 ){
			$main::mod{$na}{$x}{st} = 131;
			mon::Event('M',150,'nedo',$na,$na,"Transceiver $main::mod{$na}{$x}{sl} ${d}X power is $main::mod{$na}{$x}{$f} dBm") if $i == 3;
		}elsif(  $d eq 'R' and $i < 3 ){							# Receiving signal, but IF is not up
			mon::Event('M',100,'nedo',$na,$na,"No link on $main::mod{$na}{$x}{sl}, but transceiver RX power is $main::mod{$na}{$x}{$f} dBm") if $i == 3;
		}elsif( !$main::mod{$na}{$x}{st} or $main::mod{$na}{$x}{st} < 129 ){			# Keep inactive/alert/warning status from other direction
			$main::mod{$na}{$x}{st} = 130;
		}
	}else{
		$main::mod{$na}{$x}{$f} = '?';
		$main::mod{$na}{$x}{st} = 128;
	}
	$main::mod{$na}{$x}{de} = '' unless defined $main::mod{$na}{$x}{de};				# Avoid uninit
}

=head2 FUNCTION ScanIP()

Scans IP for open ports and identifies HTTP and SSH servers

B<Options> IP address

B<Globals> -

B<Returns> -

=cut
sub ScanIP{

	my ($ip,$opt) = @_;

	my $res = my $srv = my $os = '';
	my $svtcp = my $svudp = my $svtyp = my $svos = '';

	Prt("\nSCAN:$ip:\n");

	my $latency = 0;
	if( $main::opt{'P'} ){
		$latency = mon::PingService($ip,'icmp',1,$main::opt{'P'});
	}
	return if $latency eq -1;

	my @i = split /,/, $opt;
	foreach my $p (@i){
		if( $p eq 'id' ){
			( $res, $srv, $os ) = mon::CliStat($ip,22);
			if( $res ){
				$svtcp .= '22,';
				$svtyp .= "$srv,";
				$svos  = $os;
			}

			( $res, $srv, $os ) = mon::CliStat($ip,25);
			if( $res ){
				$svtcp .= '25,';
				$svtyp .= "$srv,";
				$svos  = $os;
			}

			if( $web::lwpok ){
				( $res, $srv, $os ) = web::GetHTTP($ip,'http','/');
				if( $res ){
					$svtcp .= '80,';
					$svtyp .= "$srv,";
					$svos  = $os unless $svos;
				}
				($res, $srv, $os ) = web::GetHTTP($ip,'https','/');
				if( $res ){
					$svtcp .= '443,';
					$svtyp .= "$srv," unless $svtyp;
					$svos  = $os unless $svos;
				}
			}

			($res, $srv, $err) = mon::NbtStat($ip,137);
			if( !$err ){
				$svudp .= '137,';
				$svtyp .= "$res/$srv,";
			}
		}
		if( $p =~ /^[0-9]+$/ ){
			if( $p == 5357 ){								# WDSAPI scan...
				( $res, $srv, $os ) = web::GetHTTP($ip,'http','',5357);
				if( $res ){
					$svtcp .= '5357,';
					$svtyp .= "$srv,";
					$svos  = $os unless $svos;
				}
			}else{
				$latency = mon::PingService($ip,'tcp',$p);
				$svtcp .= "$p," unless $latency == -1;
			}
		}
		if( $p =~ /^U[0-9]+$/ ){								# Just testing UDP, only seems to work with port 7 (echo)
			$latency = mon::PingService($ip,'udp',substr($p,1));
			$svudp .= "$p," unless $latency == -1;
		}
	}

	if( $svtcp or $svudp ){
		my $dip   = Ip2Dec($ip);
		my $dbnam = db::Select('nodarp','nodip','*',"nodip=$dip");
		my $nodex = (exists $dbnam->{$dip})?'existing':'new';
		if( $nodex ){
			db::Update('nodarp',"tcpports='$svtcp',udpports='$svudp',srvtype='$svtyp',srvos='$svos',srvupdate=$main::now","nodip=$dip");
		}else{
			Prt("SCAN:$ip with $svtyp was not found in nodarp!\n");
		}
		if( $main::opt{'x'} ){
			Prt("\nCallout  ----------------------------------------------------------------------  ".localtime()."\n");
			my $xst = system($main::opt{'x'},$nodex,$ip,$svtcp,$svudp,$svtyp,$svos );
			Prt("DISC:Executed $main::opt{'x'}, which returned $xst\n"," $xst");
		}
	}
}

=head2 FUNCTION FTPConf()

Fetch config via ftp

B<Options> device

B<Globals> -

B<Returns> -

=cut
sub FTPConf{

	my ($dv) = @_;

	Prt("FTP :Config backup\n");
	$ftp = Net::FTP->new($main::dev{$dv}{ip}, Passive => 0)
	or return "Cannot connect $@";
	if( $main::dev{$dv}{us} ){
		unless( $ftp->login($main::dev{$dv}{us},$login{$main::dev{$dv}{us}}{pw}) ){
			$ftp->quit;
			return "Cannot login ", $ftp->message;
		}
	}else{
		foreach my $us (@users){
			Prt("FTP :Trying user $us\n");
			if( $ftp->login($us,$login{$us}{pw}) ){
				$main::dev{$dv}{us} = $us;
				last;
			}
		}
		unless( $main::dev{$dv}{us} ){
			$ftp->quit;
			return "No login found"
		}
	}
	unless( $ftp->get($sysobj{$main::dev{$dv}{so}}{fc},"/tmp/ftpconf-$main::now") ){
		$ftp->quit;
		return "get failed ", $ftp->message;
	}
	$ftp->quit;

	return 0;
}

=head2 FUNCTION FTPConf()

Fetch config via ftp

B<Options> device

B<Globals> -

B<Returns> -

=cut
sub SetSize{

	my ($dv) = @_;

	my @locs = split($misc::locsep,$main::dev{$dv}{lo});
	if( exists $locs[7] ){
		if( $locs[7]=~/^\d+$/ ){
			$main::dev{$dv}{siz} = $locs[7];
			misc::Prt("SetS:Using 8th location element ($locs[7]) as size\n");
		}else{
			$main::dev{$dv}{siz} = 0;
			misc::Prt("SetS:Cannot use 8th location element ($locs[7]) as size!\n");
		}
	}
}

1;
