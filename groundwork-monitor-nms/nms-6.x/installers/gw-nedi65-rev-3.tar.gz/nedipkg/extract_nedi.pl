#!/usr/local/groundwork/perl/bin/perl -w --
#
# Copyright 2007, 2011 GroundWork Open Source, Inc.
# All rights reserved. Use is subject to GroundWork commercial license terms.
#

use strict;
use DBI;

my $nedi_conf = "/usr/local/groundwork/nedi/nedi.conf";

my $nedi_dbhost = undef;
my $nedi_dbname = undef;
my $nedi_dbuser = undef;
my $nedi_dbpass = undef;

if ( not open( CONF, '<', $nedi_conf ) ) {
    print "ERROR:  Cannot open $nedi_conf ($!).\n";
    exit 2;
}
while (<CONF>) {
    next if /^\s*#/;
    next if /^\s*;/;
    ## FIX LATER:  There's some question as to whether the value should include any
    ## trailing whitespace before the end of the line.  For now, we exclude it, but
    ## we do include any whitespace within the value.
    if (/^\s*(\S+)\t+(\S+(?:\s+\S+)*)\s*$/) {
	my $name  = $1;
	my $value = $2;
	## The last value in the file for each of these settings will prevail.
	$nedi_dbhost = $value if $name eq 'dbhost';
	$nedi_dbname = $value if $name eq 'dbname';
	$nedi_dbuser = $value if $name eq 'dbuser';
	$nedi_dbpass = $value if $name eq 'dbpass';
    }
}
close CONF;

if ( not defined($nedi_dbhost) or not defined($nedi_dbname) or not defined($nedi_dbuser) or not defined($nedi_dbpass) ) {
    print "ERROR:  The full set of database access credentials is not present\n";
    print "        in the $nedi_conf file.\n";
    exit 2;
}

my $data_file = "/usr/local/groundwork/core/monarch/automation/data/nedi_data.txt";
## my $data_file = "/usr/local/groundwork/core/monarch/automation/data/auto-discovery-nedi.txt";

my $dbh     = undef;
my $sqlstmt = '';
my $sth     = undef;

# We turn RaiseError on so the presence of any problem causes the script not to continue as though
# no problem occurred.  But then it will be our responsibility to catch all such exceptions.  We
# turn PrintError off because RaiseError is on and we don't want duplicate messages printed, as we
# will normally be formatting and printing error messages.  But again, it will be our responsibility
# to catch all possible exceptions, or else the script might die without any error output.
eval { $dbh = DBI->connect( "DBI:mysql:$nedi_dbname:$nedi_dbhost", $nedi_dbuser, $nedi_dbpass, { RaiseError => 1, PrintError => 0 } ); };
if ($@) {
    chomp $@;
    print "ERROR:  Cannot connect to the $nedi_dbname database ($@).\n";
    exit 2;
}

my $output = "# name;;ip;;type;;description;;os;;location;;parent;;contact";
$sqlstmt = "select name, ip, type, description, os, location, contact from devices";
eval {
    $sth = $dbh->prepare($sqlstmt);
    $sth->execute;
    while ( my @values = $sth->fetchrow_array() ) {
	if ( $values[1] ) {
	    $output .= "\n$values[0];;$values[1];;$values[3];;$values[4];;$values[5];;$values[2];;$values[6]";
	}
    }
    $sth->finish;
};
if ($@) {
    chomp $@;
    print "ERROR:  Cannot access the $nedi_dbname database ($@).\n";
    exit 2;
}

my %hosts = ();
$sqlstmt = "select name, ip, oui, device from nodes where ip not in (select ip from devices)";
eval {
    $sth = $dbh->prepare($sqlstmt);
    $sth->execute;
    while ( my @values = $sth->fetchrow_array() ) {
	if ( $values[1] ) {
	    $output .= "\n$values[0];;$values[1];;;;$values[2];;;;;;;;$values[3];;";
	}
    }
    $sth->finish;
};
if ($@) {
    chomp $@;
    print "ERROR:  Cannot access the $nedi_dbname database ($@).\n";
    exit 2;
}

$dbh->disconnect();

if ( not open( FILE, '>', $data_file ) ) {
    print "ERROR:  Cannot open $data_file ($!).\n";
    exit 2;
}
print FILE $output;
close(FILE);

__END__

# nedi table info


# nodes

'name', 'varchar(64)', 'YES', 'MUL', '', ''
'ip', 'int(10) unsigned', 'YES', 'MUL', '', ''
'mac', 'varchar(12)', 'YES', 'MUL', '', ''
'oui', 'varchar(32)', 'YES', '', '', ''
'firstseen', 'int(10) unsigned', 'YES', '', '', ''
'lastseen', 'int(10) unsigned', 'YES', '', '', ''
'device', 'varchar(64)', 'YES', '', '', ''
'ifname', 'varchar(32)', 'YES', '', '', ''
'vlanid', 'smallint(5) unsigned', 'YES', 'MUL', '', ''
'ifmetric', 'tinyint(3) unsigned', 'YES', '', '', ''
'ifupdate', 'int(10) unsigned', 'YES', '', '', ''
'ifchanges', 'int(10) unsigned', 'YES', '', '', ''
'ipupdate', 'int(10) unsigned', 'YES', '', '', ''
'ipchanges', 'int(10) unsigned', 'YES', '', '', ''
'iplost', 'int(10) unsigned', 'YES', '', '', ''


# devices

'name', 'varchar(64)', 'YES', 'MUL', '', ''
'ip', 'int(10) unsigned', 'YES', '', '', ''
'serial', 'varchar(32)', 'YES', '', '', ''
'type', 'varchar(32)', 'YES', '', '', ''
'firstseen', 'int(10) unsigned', 'YES', '', '', ''
'lastseen', 'int(10) unsigned', 'YES', '', '', ''
'services', 'tinyint(3) unsigned', 'YES', '', '', ''
'description', 'varchar(255)', 'YES', '', '', ''
'os', 'varchar(8)', 'YES', '', '', ''
'bootimage', 'varchar(64)', 'YES', '', '', ''
'location', 'varchar(255)', 'YES', '', '', ''
'contact', 'varchar(255)', 'YES', '', '', ''
'vtpdomain', 'varchar(32)', 'YES', '', '', ''
'vtpmode', 'tinyint(3) unsigned', 'YES', '', '', ''
'snmpversion', 'tinyint(3) unsigned', 'YES', '', '', ''
'community', 'varchar(32)', 'YES', '', '', ''
'cliport', 'smallint(5) unsigned', 'YES', '', '', ''
'login', 'varchar(32)', 'YES', '', '', ''
'icon', 'varchar(16)', 'YES', '', '', ''
