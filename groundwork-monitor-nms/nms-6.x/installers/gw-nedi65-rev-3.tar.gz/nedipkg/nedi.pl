#!/usr/local/groundwork/perl/bin/perl
#============================================================================
# Program: nedi.pl
# Programmer: Remo Rickli
#
# DATE		COMMENT
#----------------------------------------------------------------------------
# 07/09/04	v1.0.a	initial merged (0.8 and 0.9) version
# 21/12/04	v1.0.e	first alpha^17 version.
# 22/02/05	v1.0.p	alpha^5 version.
# 27/04/05	v1.0.s	alpha^2 version (1 timestamp per discovery for coherence).
# 30/03/06	v1.0.w1	rrd integration, .def philosopy, monitoring
# 30/06/06	v1.0.w2	system rrd, modules, monitoring, discovery
# 3/11/06	v1.0.w3	1st SSH implementation, link mgmt, defgen
# 15/12/06	v1.0.w4	cleanup and bugfixes. RRDs based on 1h interval
# 21/03/07	v1.0.w	more cleanup, -I and -N, nodetrack, rel IF counters
# 16/04/07	v1.0rc1	device names now BINARY (is case sensitive), new  (route based) discovery, stock module management.
# 26/09/07	v1.0rc2	libcli-netssh rework, added -F to allow FQDN.
# 17/01/08	v1.0rc6	overhauled libcli-netssh and optimized discovery process
# 07/04/08	v1.0	minor bugfixes and improvements, major nedi.conf change and final release!
# 29/12/08	v1.0.1	Moving DB writing for devices to misc::discover(). Including many user contributions...
# 15/02/09	v1.0.2	Rewrite of Discovery Protocol handling (FDP todo) and minor fixes/enhancements (e.g. Nodes-Toolbox supporting nmap now). SNMPv3 todo!
# 08/03/09	v1.0.3	Custom Device graph, Top Graphs, Many GUI enhancements, Print supply support, PHP Session rework to cather for per-user settings!
# 08/04/09	v1.0.4	Minor enhancements and new theme. Cleaned up for public release.
# 28/11/09	v1.0.5	Refer to NeDi Forum for changes...

$VERSION = "1.0.5";

#============================================================================
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
#============================================================================
# Visit http://www.nedi.ch for more information.
#============================================================================

use strict;
use Getopt::Std;
use File::Path;

#use threads;
#use threads::shared;
#my $threads = 5;

use vars qw($p $now $nediconf $cdp $lldp $oui);
use vars qw(%nod %dev %int %mod %link %vlan %opt %net %usr);

select(STDOUT);
$| = 1;

getopts('a:AbBdDFiINnoprs:t:u:U:vw:y',\%opt) || &HELP_MESSAGE;

$p = $0;
$p =~ s/(.*)\/(.*)/$1/;
if($0 eq $p){$p = "."};

$now = time;

require "$p/inc/libmisc.pl";								# Use the miscellaneous nedi library
&misc::ReadConf();
require "$p/inc/libsnmp.pl";								# Use the SNMP function library
require "$p/inc/libmon.pl";								# Use the Monitoring lib for notifications
require "$p/inc/libweb.pl";								# Use the WEB functions for webdevs
require "$p/inc/libdb-" . lc($misc::backend) . ".pl" || die "Backend error ($misc::backend)!";
require "$p/inc/libcli-" . lc($misc::clilib) . ".pl" || die "Clilib error ($misc::clilib)!";

# START: GroundWork patch to support seedlist
if($opt{u}){
         $misc::seedlist = "$opt{u}";
 }else{
         $misc::seedlist = "seedlist";
}  
# END: GroundWork patch to support seedlist

# Disable buffering so we can see what's going on right away.
select(STDOUT); $| = 1;

# -------------------------------------------------------------------
# This is the debug mode, using previousely saved vars instead of discovering...
# -------------------------------------------------------------------
if ($opt{D}){
	&misc::ReadOUIs();
	&db::ReadDev();
#	&misc::RetrVar();
# Functions to be debugged go here
#	&db::UnStock();
	&misc::BuildArp() if(defined $misc::arpwatch);

#	&db::ReadNod();
#	&misc::BuildNod();
#	&misc::RetireNod();
#	&misc::FloodFind() if $misc::notify =~ /n/;

#	&db::WriteNod();

	die "\n=== Debugging ended! ===\n";
}
# -------------------------------------------------------------------
if ($opt{'w'}) {
	&db::WlanUp();
}elsif($opt{'i'}) {
	my $adminuser;
	my $adminpass;
	my $nedihost = 'localhost';
	if ($#ARGV eq 1){								# 2 arguments for -i?
		$adminuser = @ARGV [0];
		$adminpass = @ARGV [1];
	}else{										# interactive credentials then...
		print "\nDB, RRDs and configs files will be cleared, bail out if don't want this!\n";
		print "--------------------------------------------------------------------------\n";
		print "MySQL admin user: ";
		$adminuser = <STDIN>;
		print "MySQL admin pass: ";
		$adminpass = <STDIN>;
		if($misc::dbhost ne 'localhost'){
			print "NeDi host (where the discovery runs on: ";
			$nedihost = <STDIN>;
		}
	}
	chomp($adminuser,$adminpass,$nedihost);
	&db::InitDB($adminuser, $adminpass, $nedihost);

	my $nrrd = rmtree( "$misc::nedipath/rrd", {keep_root => 1} );
	my $ncfg = rmtree( "$misc::nedipath/conf", {keep_root => 1} );
	mkpath("$misc::nedipath/rrd");
	mkpath("$misc::nedipath/conf");
	print "$nrrd RRDs and $ncfg configurations (with dirs) deleted!\n\n";
}elsif($opt{'y'}) {
	print "Supported Devices (NeDi $main::VERSION) --------------------------------------------\n";
	chdir("$p/sysobj");
	my $nd = 0;
	my @defs = glob("*.def");
	foreach my $df (sort @defs){
		$nd++;
		open F, $df or print "couldn't open $df\n" && return;
		while (<F>) {
			chomp;
			next unless /^Type/o;
			$_ =~ s/^Type\s*//;
			printf ("%-40s%s\n",$_,$df );
		}
	}
	print "$nd Definitions and counting -------------------------------------------------------\n\n";
}elsif($opt{'s'}) {
	print "Scanning Nodes (NeDi $main::VERSION) -----------------------------------------\n";
	#if($opt{'f'} eq "all") {&db::ReadNod()}
	if($opt{'s'} eq "old100") {&db::ReadNod("WHERE lastseen > $now-$misc::rrdstep order by osupdate limit 100")}
	elsif($opt{'s'} eq "update") {&db::ReadNod("WHERE lastseen > $now-$misc::rrdstep and osupdate < $misc::retire")}
	elsif($opt{'s'} =~ s/^ip=//) {
		&db::ReadNod("WHERE ip = \"".&misc::Ip2Dec($opt{'s'})."\"");
	}
	foreach my $mc (keys %main::nod){
		if ($main::nod{$mc}{ip} ne "0.0.0.0"){
			my %setos = ();
			my $alive = 1;
			$setos{'osupdate'} = $now;
			$setos{'tcpports'} = "";
			$setos{'udpports'} = "";
			$setos{'os'} = "?";
			$setos{'type'} = "?";
			print "$main::nod{$mc}{ip} ($main::nod{$mc}{na}):" if$opt{'v'};
			my @res = split(/\n/,`$misc::scancmd $main::nod{$mc}{ip} 2> /dev/null`);
			foreach my $l (@res){
				if($l =~ /Host seems down/){$alive = 0;}
				elsif($l =~ /^([0-9]+)\/tcp/){$setos{'tcpports'} .= "$1 ";}
				elsif($l =~ /^([0-9]+)\/udp/){$setos{'udpports'} .= "$1 ";}
				elsif($l =~ /^Running.*?:\s*(.*)/){$setos{'os'} = "$1";}
				elsif($l =~ /^Device type:\s*(.*)/){$setos{'type'} = "$1";}
				elsif($setos{'type'} =~ /general purpose|\?/ and $l =~ /Device:\s*(.*)/){$setos{'type'} = "$1";}
			}
			if($alive){
				if(!$opt{t} and $misc::notify =~ /p/ and $main::nod{$mc}{ou}){		# Log port changes if desired and nodes was scanned before
					if($main::nod{$mc}{tp} ne $setos{'tcpports'}){
						if( ! &db::Insert('messages','level,time,source,info',"\"10\",\"$main::now\",\"$main::nod{$mc}{ip}\",\"TCP Port change from '$main::nod{$mc}{tp}' to '$setos{tcpports}' detected\"") ){
							die "DB error messages!\n";
						}
					}
					if($main::nod{$mc}{up} ne $setos{'udpports'}){
						if( ! &db::Insert('messages','level,time,source,info',"\"10\",\"$main::now\",\"$main::nod{$mc}{ip}\",\"UDP Port change from '$main::nod{$mc}{up}' to '$setos{udpports}' detected\"") ){
							die "DB error messages!\n";
						}
					}
				}
				print "$setos{'type'} TCP:$setos{'tcpports'} UDP:$setos{'udpports'}\n" if $opt{'v'};
				&db::Update('nodes',\%setos,"mac = \"$mc\"") if(!$opt{t});
				print "*" if$opt{'d'};
			}else{
				print "is down\n" if$opt{'v'};
				print "." if$opt{'d'};
			}
		}
		if(time - $misc::rrdstep > $now){
			print "Running longer than $misc::rrdstep s, ending now." if$opt{'v'};
			print "T" if $opt{'d'};
			last;
		}
	}
	print "\n";
}else{
	&misc::ReadOUIs();
	&db::ReadDev();
	&db::ReadLink('type','STAT');							# Static links will override DP

	my $nseed = &misc::InitSeeds();

	&db::SetSystem('threads','value+1');					# Register new thread

	print "\n";
	print "DP-"   if($opt{p});
	print "OUI-"   if($opt{o});
	print "Route-" if($opt{r});
	print "Manual-" if($opt{a});
	print "Discovery ($main::VERSION) with $nseed seed".(($nseed > 1)?"s":"")." on ". localtime($now)."\n";
	print "================================================================================\n";
	print "Device				Status				 Todo/Done-Time\n";
	print "--------------------------------------------------------------------------------\n";
	while ($#misc::todo ne "-1"){
		my $id = shift(@misc::todo);
		&misc::Discover($id);
	}
	print "--------------------------------------------------------------------------------\n";
	print "Took " . int((time - $now)/60) . " minutes\n\n";
	my $ndev = scalar @misc::donenam;
	if ($ndev){
		print "Devs:	$ndev devices discovered\n";
		&misc::StorVar() if ($opt{d});
		&misc::BuildArp() if(defined $misc::arpwatch);
		if ($opt{t}){							# we're only testing
			&db::ReadNod();
			&misc::BuildNod();
			&misc::RetireNod();
		}else{
			&db::DelDev();
			while( &db::GetSystem('nodlock') ){			# wait until nodes are unlocked of a parallel run;
				print " NOD:Waiting for unlock...\n" if$opt{'v'};
				print "t" if $opt{'d'};
				sleep 5;
			}
			&db::SetSystem('nodlock','1');				# set lock in system table...
			print " NOD:table locked!\n" if$opt{'v'};
			&db::ReadNod();
			&misc::BuildNod();
			&misc::RetireNod();
			&db::WriteNod() if !$opt{t};
			&db::SetSystem('nodlock','0');				# ...unlock them again
			print " NOD:unlocked & done!\n" if$opt{'v'};
		}
		&misc::FloodFind() if $misc::notify =~ /n/i;
		&db::SetSystem('threads','value-1');					# Deregister thread
		&db::TopRRD() if !&db::GetSystem('threads');
	}else{
		print "Nothing discovered, nothing written...\n";
	}
	print "\n";
}

#===================================================================
# Display some help
# Parameters:		-
# Global:		-
# Return:		-
#===================================================================
sub HELP_MESSAGE{
	print "\n";
	print "usage: nedi.pl [-i|-D|-t|-w|-y|-s|] <more option(s)>\n";
	print "Discovery Options (can be combined, default is static) --------------------\n";
	print "-a ip	add device manually\n";
	print "-A 	use current SNMP devices as seeds\n";
	print "-p 	use LLDP,CDP or FDP discovery protocol\n";
	print "-o	OUI discovery (based on ARP chache entries of the above)\n";
	print "-r	route table discovery (on L3 devices)\n";
	print "-u f	use specified seedlist\n";
	print "-U f	use specified configuration\n";
	print "-b|B	backup running configs (and write files too)\n";
	print "-F 	use FQDNs for devices. Allows \".\" in device names (can mess up links)\n";
	print "-I 	don't try to find best suited IP addresses for devices\n";
	print "-n 	don't resolve node names via DNS\n";
	print "-N 	don't exclude devices from nodes\n\n";
	print "Other Options -------------------------------------------------------------\n";
	print "-i u pw	initialize database and start all over\n";
	print "-s opt	scan nodes, opt can be: update, old100 or ip=(ip)\n";
	print "-w d	add Kismet csv files in directory to WLAN database\n";
	print "-t ip	test IP only, but don't write anything\n";
	print "-d|D	store internal variables and print debug info/debug mode\n";
	print "-v	verbose output\n";
	print "-y	show supported devices based on .def files (in sysobj)\n\n";
	print "Output Legend -------------------------------------------------------------\n";
	print "Statistics (lower case letters):\n";
	print "i#	Interfaces\n";
	print "j#	IF IP addresses\n";
	print "a#	ARP entries\n";
	print "f#	Forwarding entries\n";
	print "m#	Modules\n";
	print "v#	Vlans\n";
	print "p|r|o	Discovery protocol, route or OUI queueing (# added/# done already)\n";
	print "b#	border hits\n\n";
	print "Warnings (upper case letters) -------------------------------------------\n";
	print "Jx	Addresses (i=IF IP, m=IF mask, a=arptable, n=no IF), v=vrf\n";
	print "Bx	Backup configs (f=fetched, n=new, u=update, w=write e=empty)\n";
	print "Fx(#)	Forwarding table (i=IF, p=Port, #=vlan, w=wlan)\n";
	print "Ix	Interface (d=desc, n=name, t=type, s=speed, m=mac, a=admin status,\n";
	print "	h(in)/H(out)=HC octet,o/O=octet,e/E=error, l=alias, x=duplex, v=vlan)\n";
	print "Hx	SSH (s=no ssh libs or port mapped, e=enable, o=other\n";
	print "M#..	Mapping IP or telnet port according to config\n";
	print "Mx	Modules (t=slot, d=desc, c=class, h=hw, f=fw, s=sw, n=SN, m=model)\n";
	print "Qx	Queueing (w=poe, a=IP address, p=proto, r=route, o=127|0 IP, l=loop,\n";
	print "Px	CLI preparing (u=no user, c=no credentials\n";
	print "Rx	RRD (d=mkdir, u=update, s=make sys, i=make IF,t=make top,n=IF name)\n";
	print "Sx	SNMP (c=connect, n=SN, B=Bootimg,u=CPU util, m=CPUmem,i=IOmem,t=Tmp)\n";
	print "Tx	Telnet (c=connect,e=enable, p=password, u=no user\n";
	print "Vx	VTP or Vlan (d=VTP domain, m=VTP mode, n=Vl name,i=ID not #)\n";
	print "---------------------------------------------------------------------------\n";
	print "NeDi $main::VERSION (C) 2001-2009 Remo Rickli (and contributors)\n\n";
	die;
}
