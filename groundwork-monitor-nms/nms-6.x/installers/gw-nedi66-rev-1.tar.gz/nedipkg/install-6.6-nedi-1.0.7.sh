#!/bin/bash

# Copyright 2012 GroundWork Open Source, Inc.  All rights reserved.

# FIX LATER:  With each new release, make this a string such as "6.6",
# reflecting the base GWMEE release to which this install file applies.
gwmee_release="6.6"

# FIX LATER:  With each new release, make this a string such as "1.0.7",
# reflecting the NeDi release which is installed by this script.
nedi_release="1.0.7"

# This script applies ONLY to installing NeDi $nedi_release on the
# GWMEE $gwmee_release.X release.

# Note:  We do our best to ensure that this script can be executed
# idempotently (i.e., won't fail if it is executed a second time).
# That allows it to be used again on a system that already has some
# previous version installed.  If you find a failure in that regard,
# please pass that information to GroundWork Support.

VERSION="${gwmee_release}_nedi_${nedi_release}"

echo "
This is the NeDi integration install script, version $VERSION.
WARNING:  This installer restarts the GroundWork portal!
"
read -p "Press Enter to install, Control-C to exit."

# Extract just the "6.W" portion of the "6.W.X" version number, so
# we can support possible "6.W.1" or similar releases, not just "6.W".
if [ ! -f /usr/local/groundwork/Info.txt -o \
	"`awk '/version/{print gensub(/^([0-9]+\.[0-9]+)\.[0-9]+$/, "'"\\\\\\\\1"'", 1, $2)}' /usr/local/groundwork/Info.txt`" != "$gwmee_release" ]; then
    echo
    echo "Error:  You must have a GWMEE $gwmee_release.X release installed"
    echo "        before you can install this NeDi package."
    echo
    exit 1;
fi

if [ "`id -u`" != "0" ]; then
    echo
    echo "Error:  You must be root to run this script."
    echo
    exit 1;
fi

nedi_parent_dir=/usr/local/groundwork
nedi_base=/usr/local/groundwork/nedi
old_nedi_base=/usr/local/groundwork/nedi.pre_nedipkg_$VERSION
if [ -e $old_nedi_base ]; then
    echo "
Error:
    The backup directory for saving the current nedi release:
        $old_nedi_base
    already exists.  Installation of the new package cannot
    proceed with this directory in place.
"
    exit 1;
fi
if mv $nedi_base $old_nedi_base ; then
    echo "
Notice:
    Your existing configuration in:
        $nedi_base/nedi.conf
    has been moved to:
	$old_nedi_base/nedi.conf
    You may need to access the old version to copy credentials it
    contains to the new copy of this file that is being installed.
"
else
    echo "
Error:
    Could not move the current NeDi release to the backup directory:
        $old_nedi_base
    Installation of the new package has failed.
"
    exit 1;
fi
if mkdir $nedi_base; then
    :
else
    echo "
Error:
    Could not make the NeDi base directory:
        $nedi_base
    Installation of the new package has failed.
"
    exit 1;
fi

(cd $nedi_parent_dir; tar xfz -) < nedi-1.0.7-gw.tar.gz
if [ $? -ne 0 ]; then
    echo "
Error:
    Could not install the software into the NeDi base directory:
        $nedi_base
    Installation of the new package has failed.
"
    exit 1;
fi

chown -R nagios:nagios    $nedi_base
chmod 600                 $nedi_base/nedi.conf

rm -f             /usr/local/groundwork/foundation/container/webapps/nedi.war
ln -s $nedi_base/ /usr/local/groundwork/foundation/container/webapps/nedi.war

# There's a literal tab character in the next string,
# because egrep won't recognize a \t escape sequence.
tab="	"
expr="^[ $tab]*Include[ $tab]+/usr/local/groundwork/apache2/conf/groundwork/[*].conf[ $tab]*\$"
line="Include /usr/local/groundwork/apache2/conf/groundwork/*.conf"
httpd_conf="/usr/local/groundwork/apache2/conf/httpd.conf"

# Don't append to the file if the line is already uncommented,
# so we don't have two active includes for the same files.
if egrep -q "$expr" $httpd_conf; then
    # The line is already in the file.  There is nothing to do here.
    :
else
    # The line is either commented out or missing.  Add it to the end.
    echo "$line" >> $httpd_conf
fi

gw_conf_dir=/usr/local/groundwork/apache2/conf/groundwork
if [ ! -d $gw_conf_dir ]; then
    mkdir               $gw_conf_dir
    chown nagios:nagios $gw_conf_dir
    chmod 755           $gw_conf_dir
fi

line="ProxyPass /nedi/    http://localhost:8080/nedi/"
nedi_httpd_conf=/usr/local/groundwork/apache2/conf/groundwork/nedi_httpd.conf
echo $line        > $nedi_httpd_conf
chown nagios:nagios $nedi_httpd_conf
chmod 644           $nedi_httpd_conf

nedi_properties=/usr/local/groundwork/config/nedi.properties
cp -p nedi.properties $nedi_properties
chown nagios:nagios   $nedi_properties
chmod 600             $nedi_properties

gw_home=/usr/local/groundwork
$gw_home/perl/bin/perl << 'EOF'
#!/usr/local/groundwork/perl/bin/perl -w --

my $disabled = 0;
my $insert   = 1;
if (! open (CRON, '-|', '/usr/bin/crontab -u nagios -l')) { 
    print "ERROR:  Cannot run crontab for the nagios user to read the existing content!\n";
    exit 1; 
}
my @crontab = <CRON>; 
close CRON;
for (@crontab) {
    next if /^\s*#/;
    # First test if the setup exists but is commented out.  If it's commented out,
    # we assume it was for good reason, and we don't override it.
    if (/^\s*#.*nedi.pl/) {
	$disabled = 1;
	$insert   = 0;
    }
    elsif (/nedi.pl/) {
	# Some version of the NeDi cron jobs appear to be already installed.
	# FIX MAJOR:  Should we comment those out, and install the new jobs?
	$insert = 0;
    }
}
if ($insert) {
    push @crontab, "0 4,8,12,16,20 * * * (/usr/local/groundwork/perl/bin/perl /usr/local/groundwork/nedi/nedi.pl -po ; /usr/local/groundwork/nedi/extract_nedi.pl ) > /dev/null 2>&1\n";
    push @crontab, "0 0 * * * /usr/local/groundwork/perl/bin/perl /usr/local/groundwork/nedi/nedi.pl -pob > /dev/null 2>&1\n";
    if (! open (CRON, '|-', '/usr/bin/crontab -u nagios -')) {
	print "ERROR:  Cannot run crontab for the nagios user to add the nedi.pl lines!\n";
	exit 1;
    }
    print CRON @crontab;
    close CRON;
}
else {
    print "WARNING:  NeDi crontab jobs for the nagios user are NOT being installed!\n";
    if ($disabled) {
	# Perhaps we should instead add the up-to-date NeDi cron jobs commented-out,
	# along with a big warning that these lines might duplicate similar lines
	# earlier in the nagios crontab file.
	print "NOTICE:   The nagios user crontab file already contained some commented-out\n";
	print "          NeDi crontab jobs.  These have been left in place.\n";
    }
}
EOF

# We protect against strange failure messages due to having no backup
# directories on the system, by setting the nullglob option and also by
# including a purposely empty directory to search (so find doesn't complain
# about having no directories passed to it on the command line).
shopt -s nullglob
res=`find empty_directory /usr/local/groundwork/backup* -name nedi.conf`
lres=${#res}
if [ "$lres" -gt 0 ]; then
    echo "
WARNING: At least one backup nedi.conf file was found.  You may need to
merge the database credentials into $nedi_base/nedi.conf .
"
    read -p "Press Enter to continue ..."; 
fi

echo "
NOTICE:  Following this install of NeDi, you will need to initialize
the database with \"$nedi_base/nedi.pl -i\".
"
# Since NeDi 1.0.7 tables are not commensurate with the NeDi 1.0.5 schema,
# we cannot recommend trying to just copy data between releases.
# echo "
# If this is an upgrade, you should consider first saving some tables that
# contain historical information and then replaying them back into the
# database after the initialization step.
# "
# FIX LATER:  The "6.6" string in this text must be edited by hand with
# each new release, because the correct text might be "6.6 and 6.6.1", not
# just "6.6", so we cannot just use $gwmee_release for this substitution.
echo "
Refer to the upgrade instructions in the \"NeDi integration add-on for
6.6 and 6.6.1\" page in the GroundWork Knowledge Base for more information.
"

read -p "Press Enter to continue.  GroundWork components will be restarted.";
/etc/init.d/groundwork stop gwservices
/etc/init.d/groundwork restart apache
/etc/init.d/groundwork start gwservices

echo "
Except for initializing the database, you are now done with the NeDi
integration install.  After you take other install or upgrade steps
such as saving, initializing, and restoring the database, you should
be able to access NeDi from the Advanced > Network Discovery tab in
GroundWork Monitor.
"
