#!/bin/bash
echo "This is the Ntop integration install script. WARNING: this installer restarts the GroundWork portal!"
read -p "Press Enter to install. Control-C to exit."
cp -rp ./nms-ntop /etc/init.d/nms-ntop
chown nagios.nagios /etc/init.d/nms-ntop
chmod +x /etc/init.d/nms-ntop
hname=`hostname -s`
ntopprops=/usr/local/groundwork/config/ntop.properties
echo "# ntop.properties" > $ntopprops
echo "# Properties file with ntop-related settings." >> $ntopprops
echo "#" >> $ntopprops
echo "# Copyright 2010 GroundWork Open Source, Inc. ("GroundWork")  " >> $ntopprops
echo "# All rights reserved. Use is subject to GroundWork commercial license terms." >> $ntopprops
echo "#" >> $ntopprops
echo "ntop.host=$hname" >> $ntopprops
echo "ntop.port=82" >> $ntopprops
echo "ntop.uri=/trafficStats.html" >> $ntopprops
echo "ntop.protocol=http" >> $ntopprops
chown nagios.nagios $ntopprops
if [ ! -d /usr/local/groundwork/common/var/ntop/db ]; then mkdir /usr/local/groundwork/common/var/ntop/db; chown nagios.nagios /usr/local/groundwork/common/var/ntop/db; fi
if [  -d /usr/local/groundwork/nms/applications/ntop/db ]; then cp -rp /usr/local/groundwork/nms/applications/ntop/db/* /usr/local/groundwork/common/var/ntop/db ; fi
rm /usr/local/groundwork/common/var/ntop/db/ntop_pw.db
/usr/local/groundwork/common/bin/ntop --user nagios --db-file-path /usr/local/groundwork/common/var/ntop/db --http-server 82  --set-admin-password=admin
chkconfig nms-ntop on
service nms-ntop stop
service nms-ntop start
/etc/init.d/groundwork stop gwservices
/etc/init.d/groundwork restart apache
/etc/init.d/groundwork start gwservices
echo "Done with ntop integration install. You should be able to access Protocol Analyzer from the Advanced tab in GroundWork now."
