#!/bin/bash
echo "This is the Weathermap integration install script. WARNING: this installer restarts the GroundWork portal!"
read -p "Press Enter to start install. Control-c to exit."
cp -p ./weathermap.properties /usr/local/groundwork/config/weathermap.properties
chown nagios.nagios /usr/local/groundwork/config/weathermap.properties
tar zxvfp ./gw-weathermap-6.3.tar.gz -C /
/etc/init.d/groundwork stop gwservices
/etc/init.d/groundwork restart apache
/etc/init.d/groundwork start gwservices
echo "Done with weathermap integration install. You should be able to install the Weathermap Plugin in the GroundWork Cacti, and use the Weathermap editor now."
