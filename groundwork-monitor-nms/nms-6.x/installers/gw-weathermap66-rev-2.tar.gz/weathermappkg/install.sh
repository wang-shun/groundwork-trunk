#!/bin/bash

# Script to install the Cacti Weathermap plugin
# on a GroundWork Monitor Enterprise system.
# www.groundworkopensource.com

echo "This is the Weathermap integration install script."
echo
echo "WARNING:  This installer restarts the GroundWork portal!"
echo "You should run this only during a maintenance period."
echo
read -p "Press Enter to start install, Control-c to exit."

cp -p ./weathermap.properties /usr/local/groundwork/config/weathermap.properties
chown nagios:nagios /usr/local/groundwork/config/weathermap.properties
tar xzvfp ./gw-weathermap-6.6-rev-2.tar.gz -C /
/etc/init.d/groundwork stop gwservices
/etc/init.d/groundwork restart apache
/etc/init.d/groundwork start gwservices

echo "Done with the Weathermap Integration install."
echo
echo "You should be able to install the Weathermap Plugin within the"
echo "GroundWork Cacti pages.  Then you can use the Weathermap editor"
echo "to define your Weathermap maps."
echo
echo "Weathermap maps will be available for viewing once they have been"
echo "defined and the Cacti poller runs and produces them according to"
echo "their respective definitions."
