--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET client_encoding = 'LATIN1';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

SET search_path = public, pg_catalog;

ALTER TABLE ONLY public.servicestatusproperty DROP CONSTRAINT servicestatusproperty_ibfk_2;
ALTER TABLE ONLY public.servicestatusproperty DROP CONSTRAINT servicestatusproperty_ibfk_1;
ALTER TABLE ONLY public.servicestatus DROP CONSTRAINT servicestatus_ibfk_6;
ALTER TABLE ONLY public.servicestatus DROP CONSTRAINT servicestatus_ibfk_5;
ALTER TABLE ONLY public.servicestatus DROP CONSTRAINT servicestatus_ibfk_4;
ALTER TABLE ONLY public.servicestatus DROP CONSTRAINT servicestatus_ibfk_3;
ALTER TABLE ONLY public.servicestatus DROP CONSTRAINT servicestatus_ibfk_2;
ALTER TABLE ONLY public.servicestatus DROP CONSTRAINT servicestatus_ibfk_1;
ALTER TABLE ONLY public.plugin DROP CONSTRAINT plugin_ibfk_1;
ALTER TABLE ONLY public.monitorlist DROP CONSTRAINT monitorlist_ibfk_2;
ALTER TABLE ONLY public.monitorlist DROP CONSTRAINT monitorlist_ibfk_1;
ALTER TABLE ONLY public.logperformancedata DROP CONSTRAINT logperformancedata_ibfk_2;
ALTER TABLE ONLY public.logperformancedata DROP CONSTRAINT logperformancedata_ibfk_1;
ALTER TABLE ONLY public.logmessageproperty DROP CONSTRAINT logmessageproperty_ibfk_2;
ALTER TABLE ONLY public.logmessageproperty DROP CONSTRAINT logmessageproperty_ibfk_1;
ALTER TABLE ONLY public.logmessage DROP CONSTRAINT logmessage_ibfk_9;
ALTER TABLE ONLY public.logmessage DROP CONSTRAINT logmessage_ibfk_8;
ALTER TABLE ONLY public.logmessage DROP CONSTRAINT logmessage_ibfk_7;
ALTER TABLE ONLY public.logmessage DROP CONSTRAINT logmessage_ibfk_6;
ALTER TABLE ONLY public.logmessage DROP CONSTRAINT logmessage_ibfk_5;
ALTER TABLE ONLY public.logmessage DROP CONSTRAINT logmessage_ibfk_4;
ALTER TABLE ONLY public.logmessage DROP CONSTRAINT logmessage_ibfk_3;
ALTER TABLE ONLY public.logmessage DROP CONSTRAINT logmessage_ibfk_2;
ALTER TABLE ONLY public.logmessage DROP CONSTRAINT logmessage_ibfk_1;
ALTER TABLE ONLY public.hoststatusproperty DROP CONSTRAINT hoststatusproperty_ibfk_2;
ALTER TABLE ONLY public.hoststatusproperty DROP CONSTRAINT hoststatusproperty_ibfk_1;
ALTER TABLE ONLY public.hoststatus DROP CONSTRAINT hoststatus_ibfk_4;
ALTER TABLE ONLY public.hoststatus DROP CONSTRAINT hoststatus_ibfk_3;
ALTER TABLE ONLY public.hoststatus DROP CONSTRAINT hoststatus_ibfk_2;
ALTER TABLE ONLY public.hoststatus DROP CONSTRAINT hoststatus_ibfk_1;
ALTER TABLE ONLY public.hostgroupcollection DROP CONSTRAINT hostgroupcollection_ibfk_2;
ALTER TABLE ONLY public.hostgroupcollection DROP CONSTRAINT hostgroupcollection_ibfk_1;
ALTER TABLE ONLY public.hostgroup DROP CONSTRAINT hostgroup_ibfk_1;
ALTER TABLE ONLY public.host DROP CONSTRAINT host_ibfk_2;
ALTER TABLE ONLY public.host DROP CONSTRAINT host_ibfk_1;
ALTER TABLE ONLY public.logmessage DROP CONSTRAINT fk_logmessage_servicestatusid;
ALTER TABLE ONLY public.logmessage DROP CONSTRAINT fk_logmessage_hoststatusid;
ALTER TABLE ONLY public.category DROP CONSTRAINT entitytypeid_ibfk1_1;
ALTER TABLE ONLY public.entityproperty DROP CONSTRAINT entityproperty_ibfk_2;
ALTER TABLE ONLY public.entityproperty DROP CONSTRAINT entityproperty_ibfk_1;
ALTER TABLE ONLY public.deviceparent DROP CONSTRAINT deviceparent_ibfk_2;
ALTER TABLE ONLY public.deviceparent DROP CONSTRAINT deviceparent_ibfk_1;
ALTER TABLE ONLY public.categoryhierarchy DROP CONSTRAINT categoryhierarchy_ibfk_2;
ALTER TABLE ONLY public.categoryhierarchy DROP CONSTRAINT categoryhierarchy_ibfk_1;
ALTER TABLE ONLY public.categoryentity DROP CONSTRAINT categoryentity_ibfk_2;
ALTER TABLE ONLY public.categoryentity DROP CONSTRAINT categoryentity_ibfk_1;
ALTER TABLE ONLY public.entity DROP CONSTRAINT applicationtypeid_ibfk1_1;
ALTER TABLE ONLY public.applicationentityproperty DROP CONSTRAINT applicationentityproperty_ibfk_3;
ALTER TABLE ONLY public.applicationentityproperty DROP CONSTRAINT applicationentityproperty_ibfk_2;
ALTER TABLE ONLY public.applicationentityproperty DROP CONSTRAINT applicationentityproperty_ibfk_1;
ALTER TABLE ONLY public.applicationaction DROP CONSTRAINT applicationaction_ibfk_2;
ALTER TABLE ONLY public.applicationaction DROP CONSTRAINT applicationaction_ibfk_1;
ALTER TABLE ONLY public.actionproperty DROP CONSTRAINT actionproperty_ibfk_1;
ALTER TABLE ONLY public.actionparameter DROP CONSTRAINT actionparameter_ibfk_1;
ALTER TABLE ONLY public.action DROP CONSTRAINT action_ibfk_1;
DROP INDEX public.servicestatusproperty_propertytypeid;
DROP INDEX public.servicestatus_statetypeid;
DROP INDEX public.servicestatus_monitorstatusid;
DROP INDEX public.servicestatus_lasthardstateid;
DROP INDEX public.servicestatus_checktypeid;
DROP INDEX public.servicestatus_applicationtypeid;
DROP INDEX public.monitorlist_deviceid;
DROP INDEX public.logperformancedata_servicestatusid;
DROP INDEX public.logperformancedata_performancedatalabelid;
DROP INDEX public.logmessageproperty_propertytypeid;
DROP INDEX public.logmessage_typeruleid;
DROP INDEX public.logmessage_severityid;
DROP INDEX public.logmessage_priorityid;
DROP INDEX public.logmessage_operationstatusid;
DROP INDEX public.logmessage_monitorstatusid;
DROP INDEX public.logmessage_idx_logmessage_statetransitionhash;
DROP INDEX public.logmessage_idx_logmessage_statelesshash;
DROP INDEX public.logmessage_idx_logmessage_reportdate;
DROP INDEX public.logmessage_idx_logmessage_lastinsertdate;
DROP INDEX public.logmessage_idx_logmessage_firstinsertdate;
DROP INDEX public.logmessage_idx_logmessage_consolidationhash;
DROP INDEX public.logmessage_fk_logmessage_servicestatusid;
DROP INDEX public.logmessage_fk_logmessage_hoststatusid;
DROP INDEX public.logmessage_deviceid;
DROP INDEX public.logmessage_componentid;
DROP INDEX public.logmessage_applicationtypeid;
DROP INDEX public.logmessage_applicationseverityid;
DROP INDEX public.hoststatusproperty_propertytypeid;
DROP INDEX public.hoststatus_statetypeid;
DROP INDEX public.hoststatus_monitorstatusid;
DROP INDEX public.hoststatus_checktypeid;
DROP INDEX public.hostgroupcollection_hostgroupid;
DROP INDEX public.hostgroup_applicationtypeid;
DROP INDEX public.host_deviceid;
DROP INDEX public.host_applicationtypeid;
DROP INDEX public.entityproperty_propertytypeid;
DROP INDEX public.entity_applicationtypeid_ibfk1_1;
DROP INDEX public.deviceparent_parentid;
DROP INDEX public.categoryhierarchy_parentid;
DROP INDEX public.categoryentity_entitytypeid;
DROP INDEX public.categoryentity_categoryid;
DROP INDEX public.category_entitytypeid_ibfk1_1;
DROP INDEX public.applicationentityproperty_propertytypeid;
DROP INDEX public.applicationentityproperty_entitytypeid;
DROP INDEX public.applicationaction_actionid;
DROP INDEX public.action_idx_action_name;
DROP INDEX public.action_actiontypeid;
ALTER TABLE ONLY public.typerule DROP CONSTRAINT typerule_pkey;
ALTER TABLE ONLY public.typerule DROP CONSTRAINT typerule_name_key;
ALTER TABLE ONLY public.statetype DROP CONSTRAINT statetype_pkey;
ALTER TABLE ONLY public.statetype DROP CONSTRAINT statetype_name_key;
ALTER TABLE ONLY public.severity DROP CONSTRAINT severity_pkey;
ALTER TABLE ONLY public.severity DROP CONSTRAINT severity_name_key;
ALTER TABLE ONLY public.servicestatusproperty DROP CONSTRAINT servicestatusproperty_pkey;
ALTER TABLE ONLY public.servicestatus DROP CONSTRAINT servicestatus_pkey;
ALTER TABLE ONLY public.servicestatus DROP CONSTRAINT servicestatus_hostid_servicedescription_key;
ALTER TABLE ONLY public.propertytype DROP CONSTRAINT propertytype_pkey;
ALTER TABLE ONLY public.propertytype DROP CONSTRAINT propertytype_name_key;
ALTER TABLE ONLY public.priority DROP CONSTRAINT priority_pkey;
ALTER TABLE ONLY public.priority DROP CONSTRAINT priority_name_key;
ALTER TABLE ONLY public.pluginplatform DROP CONSTRAINT pluginplatform_pkey;
ALTER TABLE ONLY public.pluginplatform DROP CONSTRAINT pluginplatform_name_arch_key;
ALTER TABLE ONLY public.plugin DROP CONSTRAINT plugin_platformid_name_key;
ALTER TABLE ONLY public.plugin DROP CONSTRAINT plugin_pkey;
ALTER TABLE ONLY public.performancedatalabel DROP CONSTRAINT performancedatalabel_pkey;
ALTER TABLE ONLY public.performancedatalabel DROP CONSTRAINT performancedatalabel_performancename_key;
ALTER TABLE ONLY public.operationstatus DROP CONSTRAINT operationstatus_pkey;
ALTER TABLE ONLY public.operationstatus DROP CONSTRAINT operationstatus_name_key;
ALTER TABLE ONLY public.network_service_status DROP CONSTRAINT network_service_status_pkey;
ALTER TABLE ONLY public.network_service_short_news DROP CONSTRAINT network_service_short_news_pkey;
ALTER TABLE ONLY public.network_service_notifications DROP CONSTRAINT network_service_notifications_pkey;
ALTER TABLE ONLY public.monitorstatus DROP CONSTRAINT monitorstatus_pkey;
ALTER TABLE ONLY public.monitorstatus DROP CONSTRAINT monitorstatus_name_key;
ALTER TABLE ONLY public.monitorserver DROP CONSTRAINT monitorserver_pkey;
ALTER TABLE ONLY public.monitorlist DROP CONSTRAINT monitorlist_pkey;
ALTER TABLE ONLY public.messagefilter DROP CONSTRAINT messagefilter_pkey;
ALTER TABLE ONLY public.messagefilter DROP CONSTRAINT messagefilter_name_key;
ALTER TABLE ONLY public.logperformancedata DROP CONSTRAINT logperformancedata_pkey;
ALTER TABLE ONLY public.logmessageproperty DROP CONSTRAINT logmessageproperty_pkey;
ALTER TABLE ONLY public.logmessage DROP CONSTRAINT logmessage_pkey;
ALTER TABLE ONLY public.hoststatusproperty DROP CONSTRAINT hoststatusproperty_pkey;
ALTER TABLE ONLY public.hoststatus DROP CONSTRAINT hoststatus_pkey;
ALTER TABLE ONLY public.hostgroupcollection DROP CONSTRAINT hostgroupcollection_pkey;
ALTER TABLE ONLY public.hostgroup DROP CONSTRAINT hostgroup_pkey;
ALTER TABLE ONLY public.hostgroup DROP CONSTRAINT hostgroup_name_key;
ALTER TABLE ONLY public.host DROP CONSTRAINT host_pkey;
ALTER TABLE ONLY public.host DROP CONSTRAINT host_hostname_key;
ALTER TABLE ONLY public.entitytype DROP CONSTRAINT entitytype_pkey;
ALTER TABLE ONLY public.entitytype DROP CONSTRAINT entitytype_name_key;
ALTER TABLE ONLY public.entityproperty DROP CONSTRAINT entityproperty_pkey;
ALTER TABLE ONLY public.entity DROP CONSTRAINT entity_pkey;
ALTER TABLE ONLY public.deviceparent DROP CONSTRAINT deviceparent_pkey;
ALTER TABLE ONLY public.device DROP CONSTRAINT device_pkey;
ALTER TABLE ONLY public.device DROP CONSTRAINT device_identification_key;
ALTER TABLE ONLY public.consolidationcriteria DROP CONSTRAINT consolidationcriteria_pkey;
ALTER TABLE ONLY public.consolidationcriteria DROP CONSTRAINT consolidationcriteria_name_key;
ALTER TABLE ONLY public.component DROP CONSTRAINT component_pkey;
ALTER TABLE ONLY public.component DROP CONSTRAINT component_name_key;
ALTER TABLE ONLY public.checktype DROP CONSTRAINT checktype_pkey;
ALTER TABLE ONLY public.checktype DROP CONSTRAINT checktype_name_key;
ALTER TABLE ONLY public.categoryhierarchy DROP CONSTRAINT categoryhierarchy_pkey;
ALTER TABLE ONLY public.categoryentity DROP CONSTRAINT categoryentity_pkey;
ALTER TABLE ONLY public.category DROP CONSTRAINT category_pkey;
ALTER TABLE ONLY public.category DROP CONSTRAINT category_name_key;
ALTER TABLE ONLY public.applicationtype DROP CONSTRAINT applicationtype_pkey;
ALTER TABLE ONLY public.applicationtype DROP CONSTRAINT applicationtype_name_key;
ALTER TABLE ONLY public.applicationentityproperty DROP CONSTRAINT applicationentityproperty_pkey;
ALTER TABLE ONLY public.applicationentityproperty DROP CONSTRAINT applicationentityproperty_applicationtypeid_entitytypeid_pr_key;
ALTER TABLE ONLY public.applicationaction DROP CONSTRAINT applicationaction_pkey;
ALTER TABLE ONLY public.actiontype DROP CONSTRAINT actiontype_pkey;
ALTER TABLE ONLY public.actiontype DROP CONSTRAINT actiontype_name_key;
ALTER TABLE ONLY public.actionproperty DROP CONSTRAINT actionproperty_pkey;
ALTER TABLE ONLY public.actionproperty DROP CONSTRAINT actionproperty_actionid_name_key;
ALTER TABLE ONLY public.actionparameter DROP CONSTRAINT actionparameter_pkey;
ALTER TABLE ONLY public.actionparameter DROP CONSTRAINT actionparameter_actionid_name_key;
ALTER TABLE ONLY public.action DROP CONSTRAINT action_pkey;
ALTER TABLE ONLY public.action DROP CONSTRAINT action_name_key;
ALTER TABLE public.typerule ALTER COLUMN typeruleid DROP DEFAULT;
ALTER TABLE public.statetype ALTER COLUMN statetypeid DROP DEFAULT;
ALTER TABLE public.severity ALTER COLUMN severityid DROP DEFAULT;
ALTER TABLE public.servicestatus ALTER COLUMN servicestatusid DROP DEFAULT;
ALTER TABLE public.propertytype ALTER COLUMN propertytypeid DROP DEFAULT;
ALTER TABLE public.priority ALTER COLUMN priorityid DROP DEFAULT;
ALTER TABLE public.pluginplatform ALTER COLUMN platformid DROP DEFAULT;
ALTER TABLE public.plugin ALTER COLUMN pluginid DROP DEFAULT;
ALTER TABLE public.performancedatalabel ALTER COLUMN performancedatalabelid DROP DEFAULT;
ALTER TABLE public.operationstatus ALTER COLUMN operationstatusid DROP DEFAULT;
ALTER TABLE public.network_service_status ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.network_service_short_news ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.network_service_notifications ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.monitorstatus ALTER COLUMN monitorstatusid DROP DEFAULT;
ALTER TABLE public.monitorserver ALTER COLUMN monitorserverid DROP DEFAULT;
ALTER TABLE public.messagefilter ALTER COLUMN messagefilterid DROP DEFAULT;
ALTER TABLE public.logperformancedata ALTER COLUMN logperformancedataid DROP DEFAULT;
ALTER TABLE public.logmessage ALTER COLUMN logmessageid DROP DEFAULT;
ALTER TABLE public.hostgroup ALTER COLUMN hostgroupid DROP DEFAULT;
ALTER TABLE public.host ALTER COLUMN hostid DROP DEFAULT;
ALTER TABLE public.entitytype ALTER COLUMN entitytypeid DROP DEFAULT;
ALTER TABLE public.entity ALTER COLUMN entityid DROP DEFAULT;
ALTER TABLE public.device ALTER COLUMN deviceid DROP DEFAULT;
ALTER TABLE public.consolidationcriteria ALTER COLUMN consolidationcriteriaid DROP DEFAULT;
ALTER TABLE public.component ALTER COLUMN componentid DROP DEFAULT;
ALTER TABLE public.checktype ALTER COLUMN checktypeid DROP DEFAULT;
ALTER TABLE public.categoryentity ALTER COLUMN categoryentityid DROP DEFAULT;
ALTER TABLE public.category ALTER COLUMN categoryid DROP DEFAULT;
ALTER TABLE public.applicationtype ALTER COLUMN applicationtypeid DROP DEFAULT;
ALTER TABLE public.applicationentityproperty ALTER COLUMN applicationentitypropertyid DROP DEFAULT;
ALTER TABLE public.actiontype ALTER COLUMN actiontypeid DROP DEFAULT;
ALTER TABLE public.actionproperty ALTER COLUMN actionpropertyid DROP DEFAULT;
ALTER TABLE public.actionparameter ALTER COLUMN actionparameterid DROP DEFAULT;
ALTER TABLE public.action ALTER COLUMN actionid DROP DEFAULT;
DROP SEQUENCE public.typerule_typeruleid_seq;
DROP TABLE public.typerule;
DROP SEQUENCE public.statetype_statetypeid_seq;
DROP TABLE public.statetype;
DROP SEQUENCE public.severity_severityid_seq;
DROP TABLE public.severity;
DROP TABLE public.servicestatusproperty;
DROP SEQUENCE public.servicestatus_servicestatusid_seq;
DROP TABLE public.servicestatus;
DROP TABLE public.schemainfo;
DROP SEQUENCE public.propertytype_propertytypeid_seq;
DROP TABLE public.propertytype;
DROP SEQUENCE public.priority_priorityid_seq;
DROP TABLE public.priority;
DROP SEQUENCE public.pluginplatform_platformid_seq;
DROP TABLE public.pluginplatform;
DROP SEQUENCE public.plugin_pluginid_seq;
DROP TABLE public.plugin;
DROP SEQUENCE public.performancedatalabel_performancedatalabelid_seq;
DROP TABLE public.performancedatalabel;
DROP SEQUENCE public.operationstatus_operationstatusid_seq;
DROP TABLE public.operationstatus;
DROP SEQUENCE public.network_service_status_id_seq;
DROP TABLE public.network_service_status;
DROP SEQUENCE public.network_service_short_news_id_seq;
DROP TABLE public.network_service_short_news;
DROP SEQUENCE public.network_service_notifications_id_seq;
DROP TABLE public.network_service_notifications;
DROP SEQUENCE public.monitorstatus_monitorstatusid_seq;
DROP TABLE public.monitorstatus;
DROP SEQUENCE public.monitorserver_monitorserverid_seq;
DROP TABLE public.monitorserver;
DROP TABLE public.monitorlist;
DROP SEQUENCE public.messagefilter_messagefilterid_seq;
DROP TABLE public.messagefilter;
DROP SEQUENCE public.logperformancedata_logperformancedataid_seq;
DROP TABLE public.logperformancedata;
DROP TABLE public.logmessageproperty;
DROP SEQUENCE public.logmessage_logmessageid_seq;
DROP TABLE public.logmessage;
DROP TABLE public.hoststatusproperty;
DROP TABLE public.hoststatus;
DROP TABLE public.hostgroupcollection;
DROP SEQUENCE public.hostgroup_hostgroupid_seq;
DROP TABLE public.hostgroup;
DROP SEQUENCE public.host_hostid_seq;
DROP TABLE public.host;
DROP SEQUENCE public.hibernate_sequence;
DROP SEQUENCE public.entitytype_entitytypeid_seq;
DROP TABLE public.entitytype;
DROP TABLE public.entityproperty;
DROP SEQUENCE public.entity_entityid_seq;
DROP TABLE public.entity;
DROP TABLE public.deviceparent;
DROP SEQUENCE public.device_deviceid_seq;
DROP TABLE public.device;
DROP SEQUENCE public.consolidationcriteria_consolidationcriteriaid_seq;
DROP TABLE public.consolidationcriteria;
DROP SEQUENCE public.component_componentid_seq;
DROP TABLE public.component;
DROP SEQUENCE public.checktype_checktypeid_seq;
DROP TABLE public.checktype;
DROP TABLE public.categoryhierarchy;
DROP SEQUENCE public.categoryentity_categoryentityid_seq;
DROP TABLE public.categoryentity;
DROP SEQUENCE public.category_categoryid_seq;
DROP TABLE public.category;
DROP SEQUENCE public.applicationtype_applicationtypeid_seq;
DROP TABLE public.applicationtype;
DROP SEQUENCE public.applicationentityproperty_applicationentitypropertyid_seq;
DROP TABLE public.applicationentityproperty;
DROP TABLE public.applicationaction;
DROP SEQUENCE public.actiontype_actiontypeid_seq;
DROP TABLE public.actiontype;
DROP SEQUENCE public.actionproperty_actionpropertyid_seq;
DROP TABLE public.actionproperty;
DROP SEQUENCE public.actionparameter_actionparameterid_seq;
DROP TABLE public.actionparameter;
DROP SEQUENCE public.action_actionid_seq;
DROP TABLE public.action;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: action; Type: TABLE; Schema: public; Owner: collage; Tablespace: 
--

CREATE TABLE action (
    actionid integer NOT NULL,
    actiontypeid integer NOT NULL,
    name character varying(256) NOT NULL,
    description character varying(512)
);


ALTER TABLE public.action OWNER TO collage;

--
-- Name: action_actionid_seq; Type: SEQUENCE; Schema: public; Owner: collage
--

CREATE SEQUENCE action_actionid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.action_actionid_seq OWNER TO collage;

--
-- Name: action_actionid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: collage
--

ALTER SEQUENCE action_actionid_seq OWNED BY action.actionid;


--
-- Name: actionparameter; Type: TABLE; Schema: public; Owner: collage; Tablespace: 
--

CREATE TABLE actionparameter (
    actionparameterid integer NOT NULL,
    actionid integer NOT NULL,
    name character varying(128) NOT NULL,
    value text
);


ALTER TABLE public.actionparameter OWNER TO collage;

--
-- Name: actionparameter_actionparameterid_seq; Type: SEQUENCE; Schema: public; Owner: collage
--

CREATE SEQUENCE actionparameter_actionparameterid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.actionparameter_actionparameterid_seq OWNER TO collage;

--
-- Name: actionparameter_actionparameterid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: collage
--

ALTER SEQUENCE actionparameter_actionparameterid_seq OWNED BY actionparameter.actionparameterid;


--
-- Name: actionproperty; Type: TABLE; Schema: public; Owner: collage; Tablespace: 
--

CREATE TABLE actionproperty (
    actionpropertyid integer NOT NULL,
    actionid integer NOT NULL,
    name character varying(128) NOT NULL,
    value text
);


ALTER TABLE public.actionproperty OWNER TO collage;

--
-- Name: actionproperty_actionpropertyid_seq; Type: SEQUENCE; Schema: public; Owner: collage
--

CREATE SEQUENCE actionproperty_actionpropertyid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.actionproperty_actionpropertyid_seq OWNER TO collage;

--
-- Name: actionproperty_actionpropertyid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: collage
--

ALTER SEQUENCE actionproperty_actionpropertyid_seq OWNED BY actionproperty.actionpropertyid;


--
-- Name: actiontype; Type: TABLE; Schema: public; Owner: collage; Tablespace: 
--

CREATE TABLE actiontype (
    actiontypeid integer NOT NULL,
    name character varying(256) NOT NULL,
    classname character varying(256) NOT NULL
);


ALTER TABLE public.actiontype OWNER TO collage;

--
-- Name: actiontype_actiontypeid_seq; Type: SEQUENCE; Schema: public; Owner: collage
--

CREATE SEQUENCE actiontype_actiontypeid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.actiontype_actiontypeid_seq OWNER TO collage;

--
-- Name: actiontype_actiontypeid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: collage
--

ALTER SEQUENCE actiontype_actiontypeid_seq OWNED BY actiontype.actiontypeid;


--
-- Name: applicationaction; Type: TABLE; Schema: public; Owner: collage; Tablespace: 
--

CREATE TABLE applicationaction (
    applicationtypeid integer NOT NULL,
    actionid integer NOT NULL
);


ALTER TABLE public.applicationaction OWNER TO collage;

--
-- Name: applicationentityproperty; Type: TABLE; Schema: public; Owner: collage; Tablespace: 
--

CREATE TABLE applicationentityproperty (
    applicationentitypropertyid integer NOT NULL,
    applicationtypeid integer NOT NULL,
    entitytypeid integer NOT NULL,
    propertytypeid integer NOT NULL,
    sortorder integer DEFAULT (999)::numeric NOT NULL
);


ALTER TABLE public.applicationentityproperty OWNER TO collage;

--
-- Name: applicationentityproperty_applicationentitypropertyid_seq; Type: SEQUENCE; Schema: public; Owner: collage
--

CREATE SEQUENCE applicationentityproperty_applicationentitypropertyid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.applicationentityproperty_applicationentitypropertyid_seq OWNER TO collage;

--
-- Name: applicationentityproperty_applicationentitypropertyid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: collage
--

ALTER SEQUENCE applicationentityproperty_applicationentitypropertyid_seq OWNED BY applicationentityproperty.applicationentitypropertyid;


--
-- Name: applicationtype; Type: TABLE; Schema: public; Owner: collage; Tablespace: 
--

CREATE TABLE applicationtype (
    applicationtypeid integer NOT NULL,
    name character varying(128) NOT NULL,
    description character varying(254),
    statetransitioncriteria character varying(512)
);


ALTER TABLE public.applicationtype OWNER TO collage;

--
-- Name: applicationtype_applicationtypeid_seq; Type: SEQUENCE; Schema: public; Owner: collage
--

CREATE SEQUENCE applicationtype_applicationtypeid_seq
    START WITH 101
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.applicationtype_applicationtypeid_seq OWNER TO collage;

--
-- Name: applicationtype_applicationtypeid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: collage
--

ALTER SEQUENCE applicationtype_applicationtypeid_seq OWNED BY applicationtype.applicationtypeid;


--
-- Name: category; Type: TABLE; Schema: public; Owner: collage; Tablespace: 
--

CREATE TABLE category (
    categoryid integer NOT NULL,
    name character varying(254) NOT NULL,
    description character varying(4096),
    entitytypeid integer NOT NULL
);


ALTER TABLE public.category OWNER TO collage;

--
-- Name: category_categoryid_seq; Type: SEQUENCE; Schema: public; Owner: collage
--

CREATE SEQUENCE category_categoryid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.category_categoryid_seq OWNER TO collage;

--
-- Name: category_categoryid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: collage
--

ALTER SEQUENCE category_categoryid_seq OWNED BY category.categoryid;


--
-- Name: categoryentity; Type: TABLE; Schema: public; Owner: collage; Tablespace: 
--

CREATE TABLE categoryentity (
    categoryentityid integer NOT NULL,
    objectid integer DEFAULT 0 NOT NULL,
    categoryid integer DEFAULT 0 NOT NULL,
    entitytypeid integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.categoryentity OWNER TO collage;

--
-- Name: categoryentity_categoryentityid_seq; Type: SEQUENCE; Schema: public; Owner: collage
--

CREATE SEQUENCE categoryentity_categoryentityid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.categoryentity_categoryentityid_seq OWNER TO collage;

--
-- Name: categoryentity_categoryentityid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: collage
--

ALTER SEQUENCE categoryentity_categoryentityid_seq OWNED BY categoryentity.categoryentityid;


--
-- Name: categoryhierarchy; Type: TABLE; Schema: public; Owner: collage; Tablespace: 
--

CREATE TABLE categoryhierarchy (
    categoryid integer DEFAULT 0 NOT NULL,
    parentid integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.categoryhierarchy OWNER TO collage;

--
-- Name: checktype; Type: TABLE; Schema: public; Owner: collage; Tablespace: 
--

CREATE TABLE checktype (
    checktypeid integer NOT NULL,
    name character varying(254) NOT NULL,
    description character varying(254)
);


ALTER TABLE public.checktype OWNER TO collage;

--
-- Name: checktype_checktypeid_seq; Type: SEQUENCE; Schema: public; Owner: collage
--

CREATE SEQUENCE checktype_checktypeid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.checktype_checktypeid_seq OWNER TO collage;

--
-- Name: checktype_checktypeid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: collage
--

ALTER SEQUENCE checktype_checktypeid_seq OWNED BY checktype.checktypeid;


--
-- Name: component; Type: TABLE; Schema: public; Owner: collage; Tablespace: 
--

CREATE TABLE component (
    componentid integer NOT NULL,
    name character varying(128) NOT NULL,
    description character varying(254)
);


ALTER TABLE public.component OWNER TO collage;

--
-- Name: component_componentid_seq; Type: SEQUENCE; Schema: public; Owner: collage
--

CREATE SEQUENCE component_componentid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.component_componentid_seq OWNER TO collage;

--
-- Name: component_componentid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: collage
--

ALTER SEQUENCE component_componentid_seq OWNED BY component.componentid;


--
-- Name: consolidationcriteria; Type: TABLE; Schema: public; Owner: collage; Tablespace: 
--

CREATE TABLE consolidationcriteria (
    consolidationcriteriaid integer NOT NULL,
    name character varying(254) NOT NULL,
    criteria character varying(512) NOT NULL
);


ALTER TABLE public.consolidationcriteria OWNER TO collage;

--
-- Name: consolidationcriteria_consolidationcriteriaid_seq; Type: SEQUENCE; Schema: public; Owner: collage
--

CREATE SEQUENCE consolidationcriteria_consolidationcriteriaid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.consolidationcriteria_consolidationcriteriaid_seq OWNER TO collage;

--
-- Name: consolidationcriteria_consolidationcriteriaid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: collage
--

ALTER SEQUENCE consolidationcriteria_consolidationcriteriaid_seq OWNED BY consolidationcriteria.consolidationcriteriaid;


--
-- Name: device; Type: TABLE; Schema: public; Owner: collage; Tablespace: 
--

CREATE TABLE device (
    deviceid integer NOT NULL,
    displayname character varying(254),
    identification character varying(128) NOT NULL,
    description character varying(254)
);


ALTER TABLE public.device OWNER TO collage;

--
-- Name: device_deviceid_seq; Type: SEQUENCE; Schema: public; Owner: collage
--

CREATE SEQUENCE device_deviceid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.device_deviceid_seq OWNER TO collage;

--
-- Name: device_deviceid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: collage
--

ALTER SEQUENCE device_deviceid_seq OWNED BY device.deviceid;


--
-- Name: deviceparent; Type: TABLE; Schema: public; Owner: collage; Tablespace: 
--

CREATE TABLE deviceparent (
    deviceid integer NOT NULL,
    parentid integer NOT NULL
);


ALTER TABLE public.deviceparent OWNER TO collage;

--
-- Name: entity; Type: TABLE; Schema: public; Owner: collage; Tablespace: 
--

CREATE TABLE entity (
    entityid integer NOT NULL,
    name character varying(254) NOT NULL,
    description character varying(254) NOT NULL,
    class character varying(254) NOT NULL,
    applicationtypeid integer NOT NULL
);


ALTER TABLE public.entity OWNER TO collage;

--
-- Name: entity_entityid_seq; Type: SEQUENCE; Schema: public; Owner: collage
--

CREATE SEQUENCE entity_entityid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.entity_entityid_seq OWNER TO collage;

--
-- Name: entity_entityid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: collage
--

ALTER SEQUENCE entity_entityid_seq OWNED BY entity.entityid;


--
-- Name: entityproperty; Type: TABLE; Schema: public; Owner: collage; Tablespace: 
--

CREATE TABLE entityproperty (
    entitytypeid integer NOT NULL,
    objectid integer NOT NULL,
    propertytypeid integer NOT NULL,
    valuestring character varying(4096),
    valuedate timestamp without time zone,
    valueboolean boolean,
    valueinteger integer,
    valuelong bigint,
    valuedouble double precision,
    lasteditedon timestamp without time zone DEFAULT now() NOT NULL,
    createdon timestamp without time zone NOT NULL
);


ALTER TABLE public.entityproperty OWNER TO collage;

--
-- Name: entitytype; Type: TABLE; Schema: public; Owner: collage; Tablespace: 
--

CREATE TABLE entitytype (
    entitytypeid integer NOT NULL,
    name character varying(128) NOT NULL,
    description character varying(254),
    islogicalentity boolean DEFAULT false NOT NULL,
    isapplicationtypesupported boolean DEFAULT false NOT NULL
);


ALTER TABLE public.entitytype OWNER TO collage;

--
-- Name: entitytype_entitytypeid_seq; Type: SEQUENCE; Schema: public; Owner: collage
--

CREATE SEQUENCE entitytype_entitytypeid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.entitytype_entitytypeid_seq OWNER TO collage;

--
-- Name: entitytype_entitytypeid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: collage
--

ALTER SEQUENCE entitytype_entitytypeid_seq OWNED BY entitytype.entitytypeid;


--
-- Name: hibernate_sequence; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE hibernate_sequence
    START WITH 1000
    INCREMENT BY 1
    MINVALUE 1000
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.hibernate_sequence OWNER TO postgres;

--
-- Name: host; Type: TABLE; Schema: public; Owner: collage; Tablespace: 
--

CREATE TABLE host (
    hostid integer NOT NULL,
    deviceid integer NOT NULL,
    hostname character varying(254) NOT NULL,
    description character varying(4096),
    applicationtypeid integer,
    agentid character varying(128)
);


ALTER TABLE public.host OWNER TO collage;

--
-- Name: host_hostid_seq; Type: SEQUENCE; Schema: public; Owner: collage
--

CREATE SEQUENCE host_hostid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.host_hostid_seq OWNER TO collage;

--
-- Name: host_hostid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: collage
--

ALTER SEQUENCE host_hostid_seq OWNED BY host.hostid;


--
-- Name: hostgroup; Type: TABLE; Schema: public; Owner: collage; Tablespace: 
--

CREATE TABLE hostgroup (
    hostgroupid integer NOT NULL,
    name character varying(254) NOT NULL,
    description character varying(4096),
    applicationtypeid integer,
    alias character varying(254),
    agentid character varying(128)
);


ALTER TABLE public.hostgroup OWNER TO collage;

--
-- Name: hostgroup_hostgroupid_seq; Type: SEQUENCE; Schema: public; Owner: collage
--

CREATE SEQUENCE hostgroup_hostgroupid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.hostgroup_hostgroupid_seq OWNER TO collage;

--
-- Name: hostgroup_hostgroupid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: collage
--

ALTER SEQUENCE hostgroup_hostgroupid_seq OWNED BY hostgroup.hostgroupid;


--
-- Name: hostgroupcollection; Type: TABLE; Schema: public; Owner: collage; Tablespace: 
--

CREATE TABLE hostgroupcollection (
    hostid integer NOT NULL,
    hostgroupid integer NOT NULL
);


ALTER TABLE public.hostgroupcollection OWNER TO collage;

--
-- Name: hoststatus; Type: TABLE; Schema: public; Owner: collage; Tablespace: 
--

CREATE TABLE hoststatus (
    hoststatusid integer NOT NULL,
    applicationtypeid integer NOT NULL,
    monitorstatusid integer NOT NULL,
    lastchecktime timestamp without time zone,
    checktypeid integer,
    statetypeid integer,
    nextchecktime timestamp without time zone
);


ALTER TABLE public.hoststatus OWNER TO collage;

--
-- Name: hoststatusproperty; Type: TABLE; Schema: public; Owner: collage; Tablespace: 
--

CREATE TABLE hoststatusproperty (
    hoststatusid integer NOT NULL,
    propertytypeid integer NOT NULL,
    valuestring character varying(32768),
    valuedate timestamp without time zone,
    valueboolean boolean,
    valueinteger integer,
    valuelong bigint,
    valuedouble double precision,
    lasteditedon timestamp without time zone DEFAULT now() NOT NULL,
    createdon timestamp without time zone NOT NULL
);


ALTER TABLE public.hoststatusproperty OWNER TO collage;

--
-- Name: logmessage; Type: TABLE; Schema: public; Owner: collage; Tablespace: 
--

CREATE TABLE logmessage (
    logmessageid integer NOT NULL,
    applicationtypeid integer NOT NULL,
    deviceid integer NOT NULL,
    hoststatusid integer,
    servicestatusid integer,
    textmessage character varying(4096) NOT NULL,
    msgcount integer DEFAULT (1)::numeric NOT NULL,
    firstinsertdate timestamp without time zone NOT NULL,
    lastinsertdate timestamp without time zone NOT NULL,
    reportdate timestamp without time zone NOT NULL,
    monitorstatusid integer,
    severityid integer NOT NULL,
    applicationseverityid integer NOT NULL,
    priorityid integer NOT NULL,
    typeruleid integer NOT NULL,
    componentid integer NOT NULL,
    operationstatusid integer NOT NULL,
    isstatechanged boolean DEFAULT false NOT NULL,
    consolidationhash integer DEFAULT 0 NOT NULL,
    statelesshash integer DEFAULT 0 NOT NULL,
    statetransitionhash integer
);


ALTER TABLE public.logmessage OWNER TO collage;

--
-- Name: logmessage_logmessageid_seq; Type: SEQUENCE; Schema: public; Owner: collage
--

CREATE SEQUENCE logmessage_logmessageid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.logmessage_logmessageid_seq OWNER TO collage;

--
-- Name: logmessage_logmessageid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: collage
--

ALTER SEQUENCE logmessage_logmessageid_seq OWNED BY logmessage.logmessageid;


--
-- Name: logmessageproperty; Type: TABLE; Schema: public; Owner: collage; Tablespace: 
--

CREATE TABLE logmessageproperty (
    logmessageid integer NOT NULL,
    propertytypeid integer NOT NULL,
    valuestring character varying(4096),
    valuedate timestamp without time zone,
    valueboolean boolean,
    valueinteger integer,
    valuelong bigint,
    valuedouble double precision,
    lasteditedon timestamp without time zone DEFAULT now() NOT NULL,
    createdon timestamp without time zone NOT NULL
);


ALTER TABLE public.logmessageproperty OWNER TO collage;

--
-- Name: logperformancedata; Type: TABLE; Schema: public; Owner: collage; Tablespace: 
--

CREATE TABLE logperformancedata (
    logperformancedataid integer NOT NULL,
    servicestatusid integer NOT NULL,
    lastchecktime timestamp without time zone NOT NULL,
    maximum double precision DEFAULT 0,
    minimum double precision DEFAULT 0,
    average double precision DEFAULT 0,
    measurementpoints integer DEFAULT 0,
    performancedatalabelid integer
);


ALTER TABLE public.logperformancedata OWNER TO collage;

--
-- Name: logperformancedata_logperformancedataid_seq; Type: SEQUENCE; Schema: public; Owner: collage
--

CREATE SEQUENCE logperformancedata_logperformancedataid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.logperformancedata_logperformancedataid_seq OWNER TO collage;

--
-- Name: logperformancedata_logperformancedataid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: collage
--

ALTER SEQUENCE logperformancedata_logperformancedataid_seq OWNED BY logperformancedata.logperformancedataid;


--
-- Name: messagefilter; Type: TABLE; Schema: public; Owner: collage; Tablespace: 
--

CREATE TABLE messagefilter (
    messagefilterid integer NOT NULL,
    name character varying(254) NOT NULL,
    regexpresion character varying(512) NOT NULL,
    ischangeseveritytostatistic boolean DEFAULT false
);


ALTER TABLE public.messagefilter OWNER TO collage;

--
-- Name: messagefilter_messagefilterid_seq; Type: SEQUENCE; Schema: public; Owner: collage
--

CREATE SEQUENCE messagefilter_messagefilterid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.messagefilter_messagefilterid_seq OWNER TO collage;

--
-- Name: messagefilter_messagefilterid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: collage
--

ALTER SEQUENCE messagefilter_messagefilterid_seq OWNED BY messagefilter.messagefilterid;


--
-- Name: monitorlist; Type: TABLE; Schema: public; Owner: collage; Tablespace: 
--

CREATE TABLE monitorlist (
    monitorserverid integer NOT NULL,
    deviceid integer NOT NULL
);


ALTER TABLE public.monitorlist OWNER TO collage;

--
-- Name: monitorserver; Type: TABLE; Schema: public; Owner: collage; Tablespace: 
--

CREATE TABLE monitorserver (
    monitorserverid integer NOT NULL,
    monitorservername character varying(254) NOT NULL,
    ip character varying(128) NOT NULL,
    description character varying(254)
);


ALTER TABLE public.monitorserver OWNER TO collage;

--
-- Name: monitorserver_monitorserverid_seq; Type: SEQUENCE; Schema: public; Owner: collage
--

CREATE SEQUENCE monitorserver_monitorserverid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.monitorserver_monitorserverid_seq OWNER TO collage;

--
-- Name: monitorserver_monitorserverid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: collage
--

ALTER SEQUENCE monitorserver_monitorserverid_seq OWNED BY monitorserver.monitorserverid;


--
-- Name: monitorstatus; Type: TABLE; Schema: public; Owner: collage; Tablespace: 
--

CREATE TABLE monitorstatus (
    monitorstatusid integer NOT NULL,
    name character varying(254) NOT NULL,
    description character varying(254)
);


ALTER TABLE public.monitorstatus OWNER TO collage;

--
-- Name: monitorstatus_monitorstatusid_seq; Type: SEQUENCE; Schema: public; Owner: collage
--

CREATE SEQUENCE monitorstatus_monitorstatusid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.monitorstatus_monitorstatusid_seq OWNER TO collage;

--
-- Name: monitorstatus_monitorstatusid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: collage
--

ALTER SEQUENCE monitorstatus_monitorstatusid_seq OWNED BY monitorstatus.monitorstatusid;


--
-- Name: network_service_notifications; Type: TABLE; Schema: public; Owner: collage; Tablespace: 
--

CREATE TABLE network_service_notifications (
    id integer NOT NULL,
    created_at timestamp without time zone DEFAULT ('now'::text)::timestamp(0) with time zone,
    guid integer,
    type character varying(20),
    title character varying(255) DEFAULT ''::character varying,
    critical integer,
    description text DEFAULT ''::text,
    webpage_url text DEFAULT ''::text,
    webpage_url_description text DEFAULT ''::text,
    update_md5 character varying(255) DEFAULT ''::character varying,
    update_url character varying(255) DEFAULT ''::character varying,
    update_cmd_switch character varying(255) DEFAULT ''::character varying,
    update_instruction text DEFAULT ''::text,
    update_size integer,
    update_type character varying(255) DEFAULT ''::character varying,
    update_os character varying(255) DEFAULT ''::character varying,
    is_read integer DEFAULT 0,
    is_archived integer DEFAULT 0
);


ALTER TABLE public.network_service_notifications OWNER TO collage;

--
-- Name: network_service_notifications_id_seq; Type: SEQUENCE; Schema: public; Owner: collage
--

CREATE SEQUENCE network_service_notifications_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.network_service_notifications_id_seq OWNER TO collage;

--
-- Name: network_service_notifications_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: collage
--

ALTER SEQUENCE network_service_notifications_id_seq OWNED BY network_service_notifications.id;


--
-- Name: network_service_short_news; Type: TABLE; Schema: public; Owner: collage; Tablespace: 
--

CREATE TABLE network_service_short_news (
    id integer NOT NULL,
    status integer,
    title character varying(255) DEFAULT ''::character varying,
    message text DEFAULT ''::text,
    url character varying(255) DEFAULT ''::character varying,
    url_description text DEFAULT ''::text,
    is_archived integer DEFAULT 0
);


ALTER TABLE public.network_service_short_news OWNER TO collage;

--
-- Name: network_service_short_news_id_seq; Type: SEQUENCE; Schema: public; Owner: collage
--

CREATE SEQUENCE network_service_short_news_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.network_service_short_news_id_seq OWNER TO collage;

--
-- Name: network_service_short_news_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: collage
--

ALTER SEQUENCE network_service_short_news_id_seq OWNED BY network_service_short_news.id;


--
-- Name: network_service_status; Type: TABLE; Schema: public; Owner: collage; Tablespace: 
--

CREATE TABLE network_service_status (
    id integer NOT NULL,
    last_checked timestamp without time zone
);


ALTER TABLE public.network_service_status OWNER TO collage;

--
-- Name: network_service_status_id_seq; Type: SEQUENCE; Schema: public; Owner: collage
--

CREATE SEQUENCE network_service_status_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.network_service_status_id_seq OWNER TO collage;

--
-- Name: network_service_status_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: collage
--

ALTER SEQUENCE network_service_status_id_seq OWNED BY network_service_status.id;


--
-- Name: operationstatus; Type: TABLE; Schema: public; Owner: collage; Tablespace: 
--

CREATE TABLE operationstatus (
    operationstatusid integer NOT NULL,
    name character varying(128) NOT NULL,
    description character varying(254)
);


ALTER TABLE public.operationstatus OWNER TO collage;

--
-- Name: operationstatus_operationstatusid_seq; Type: SEQUENCE; Schema: public; Owner: collage
--

CREATE SEQUENCE operationstatus_operationstatusid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.operationstatus_operationstatusid_seq OWNER TO collage;

--
-- Name: operationstatus_operationstatusid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: collage
--

ALTER SEQUENCE operationstatus_operationstatusid_seq OWNED BY operationstatus.operationstatusid;


--
-- Name: performancedatalabel; Type: TABLE; Schema: public; Owner: collage; Tablespace: 
--

CREATE TABLE performancedatalabel (
    performancedatalabelid integer NOT NULL,
    performancename character varying(254),
    servicedisplayname character varying(128),
    metriclabel character varying(128),
    unit character varying(64)
);


ALTER TABLE public.performancedatalabel OWNER TO collage;

--
-- Name: performancedatalabel_performancedatalabelid_seq; Type: SEQUENCE; Schema: public; Owner: collage
--

CREATE SEQUENCE performancedatalabel_performancedatalabelid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.performancedatalabel_performancedatalabelid_seq OWNER TO collage;

--
-- Name: performancedatalabel_performancedatalabelid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: collage
--

ALTER SEQUENCE performancedatalabel_performancedatalabelid_seq OWNED BY performancedatalabel.performancedatalabelid;


--
-- Name: plugin; Type: TABLE; Schema: public; Owner: collage; Tablespace: 
--

CREATE TABLE plugin (
    pluginid integer NOT NULL,
    name character varying(128) NOT NULL,
    url character varying(254),
    platformid integer NOT NULL,
    dependencies character varying(254),
    lastupdatetimestamp timestamp without time zone DEFAULT now() NOT NULL,
    checksum character varying(254) NOT NULL,
    lastupdatedby character varying(254)
);


ALTER TABLE public.plugin OWNER TO collage;

--
-- Name: plugin_pluginid_seq; Type: SEQUENCE; Schema: public; Owner: collage
--

CREATE SEQUENCE plugin_pluginid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.plugin_pluginid_seq OWNER TO collage;

--
-- Name: plugin_pluginid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: collage
--

ALTER SEQUENCE plugin_pluginid_seq OWNED BY plugin.pluginid;


--
-- Name: pluginplatform; Type: TABLE; Schema: public; Owner: collage; Tablespace: 
--

CREATE TABLE pluginplatform (
    platformid integer NOT NULL,
    name character varying(128) NOT NULL,
    arch integer NOT NULL,
    description character varying(254)
);


ALTER TABLE public.pluginplatform OWNER TO collage;

--
-- Name: pluginplatform_platformid_seq; Type: SEQUENCE; Schema: public; Owner: collage
--

CREATE SEQUENCE pluginplatform_platformid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.pluginplatform_platformid_seq OWNER TO collage;

--
-- Name: pluginplatform_platformid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: collage
--

ALTER SEQUENCE pluginplatform_platformid_seq OWNED BY pluginplatform.platformid;


--
-- Name: priority; Type: TABLE; Schema: public; Owner: collage; Tablespace: 
--

CREATE TABLE priority (
    priorityid integer NOT NULL,
    name character varying(128) NOT NULL,
    description character varying(254)
);


ALTER TABLE public.priority OWNER TO collage;

--
-- Name: priority_priorityid_seq; Type: SEQUENCE; Schema: public; Owner: collage
--

CREATE SEQUENCE priority_priorityid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.priority_priorityid_seq OWNER TO collage;

--
-- Name: priority_priorityid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: collage
--

ALTER SEQUENCE priority_priorityid_seq OWNED BY priority.priorityid;


--
-- Name: propertytype; Type: TABLE; Schema: public; Owner: collage; Tablespace: 
--

CREATE TABLE propertytype (
    propertytypeid integer NOT NULL,
    name character varying(128) NOT NULL,
    description character varying(254),
    isdate boolean DEFAULT false,
    isboolean boolean DEFAULT false,
    isstring boolean DEFAULT false,
    isinteger boolean DEFAULT false,
    islong boolean DEFAULT false,
    isdouble boolean DEFAULT false,
    isvisible boolean DEFAULT true
);


ALTER TABLE public.propertytype OWNER TO collage;

--
-- Name: propertytype_propertytypeid_seq; Type: SEQUENCE; Schema: public; Owner: collage
--

CREATE SEQUENCE propertytype_propertytypeid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.propertytype_propertytypeid_seq OWNER TO collage;

--
-- Name: propertytype_propertytypeid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: collage
--

ALTER SEQUENCE propertytype_propertytypeid_seq OWNED BY propertytype.propertytypeid;


--
-- Name: schemainfo; Type: TABLE; Schema: public; Owner: collage; Tablespace: 
--

CREATE TABLE schemainfo (
    name character varying(254),
    value character varying(254)
);


ALTER TABLE public.schemainfo OWNER TO collage;

--
-- Name: servicestatus; Type: TABLE; Schema: public; Owner: collage; Tablespace: 
--

CREATE TABLE servicestatus (
    servicestatusid integer NOT NULL,
    applicationtypeid integer NOT NULL,
    servicedescription character varying(254) NOT NULL,
    hostid integer NOT NULL,
    monitorstatusid integer NOT NULL,
    lastchecktime timestamp without time zone,
    nextchecktime timestamp without time zone,
    laststatechange timestamp without time zone,
    lasthardstateid integer NOT NULL,
    statetypeid integer NOT NULL,
    checktypeid integer NOT NULL,
    metrictype character varying(254),
    domain character varying(254),
    agentid character varying(128)
);


ALTER TABLE public.servicestatus OWNER TO collage;

--
-- Name: servicestatus_servicestatusid_seq; Type: SEQUENCE; Schema: public; Owner: collage
--

CREATE SEQUENCE servicestatus_servicestatusid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.servicestatus_servicestatusid_seq OWNER TO collage;

--
-- Name: servicestatus_servicestatusid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: collage
--

ALTER SEQUENCE servicestatus_servicestatusid_seq OWNED BY servicestatus.servicestatusid;


--
-- Name: servicestatusproperty; Type: TABLE; Schema: public; Owner: collage; Tablespace: 
--

CREATE TABLE servicestatusproperty (
    servicestatusid integer NOT NULL,
    propertytypeid integer NOT NULL,
    valuestring character varying(16384),
    valuedate timestamp without time zone,
    valueboolean boolean,
    valueinteger integer,
    valuelong bigint,
    valuedouble double precision,
    lasteditedon timestamp without time zone DEFAULT now() NOT NULL,
    createdon timestamp without time zone NOT NULL
);


ALTER TABLE public.servicestatusproperty OWNER TO collage;

--
-- Name: severity; Type: TABLE; Schema: public; Owner: collage; Tablespace: 
--

CREATE TABLE severity (
    severityid integer NOT NULL,
    name character varying(128) NOT NULL,
    description character varying(254)
);


ALTER TABLE public.severity OWNER TO collage;

--
-- Name: severity_severityid_seq; Type: SEQUENCE; Schema: public; Owner: collage
--

CREATE SEQUENCE severity_severityid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.severity_severityid_seq OWNER TO collage;

--
-- Name: severity_severityid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: collage
--

ALTER SEQUENCE severity_severityid_seq OWNED BY severity.severityid;


--
-- Name: statetype; Type: TABLE; Schema: public; Owner: collage; Tablespace: 
--

CREATE TABLE statetype (
    statetypeid integer NOT NULL,
    name character varying(254) NOT NULL,
    description character varying(254)
);


ALTER TABLE public.statetype OWNER TO collage;

--
-- Name: statetype_statetypeid_seq; Type: SEQUENCE; Schema: public; Owner: collage
--

CREATE SEQUENCE statetype_statetypeid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.statetype_statetypeid_seq OWNER TO collage;

--
-- Name: statetype_statetypeid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: collage
--

ALTER SEQUENCE statetype_statetypeid_seq OWNED BY statetype.statetypeid;


--
-- Name: typerule; Type: TABLE; Schema: public; Owner: collage; Tablespace: 
--

CREATE TABLE typerule (
    typeruleid integer NOT NULL,
    name character varying(128) NOT NULL,
    description character varying(254)
);


ALTER TABLE public.typerule OWNER TO collage;

--
-- Name: typerule_typeruleid_seq; Type: SEQUENCE; Schema: public; Owner: collage
--

CREATE SEQUENCE typerule_typeruleid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.typerule_typeruleid_seq OWNER TO collage;

--
-- Name: typerule_typeruleid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: collage
--

ALTER SEQUENCE typerule_typeruleid_seq OWNED BY typerule.typeruleid;


--
-- Name: actionid; Type: DEFAULT; Schema: public; Owner: collage
--

ALTER TABLE ONLY action ALTER COLUMN actionid SET DEFAULT nextval('action_actionid_seq'::regclass);


--
-- Name: actionparameterid; Type: DEFAULT; Schema: public; Owner: collage
--

ALTER TABLE ONLY actionparameter ALTER COLUMN actionparameterid SET DEFAULT nextval('actionparameter_actionparameterid_seq'::regclass);


--
-- Name: actionpropertyid; Type: DEFAULT; Schema: public; Owner: collage
--

ALTER TABLE ONLY actionproperty ALTER COLUMN actionpropertyid SET DEFAULT nextval('actionproperty_actionpropertyid_seq'::regclass);


--
-- Name: actiontypeid; Type: DEFAULT; Schema: public; Owner: collage
--

ALTER TABLE ONLY actiontype ALTER COLUMN actiontypeid SET DEFAULT nextval('actiontype_actiontypeid_seq'::regclass);


--
-- Name: applicationentitypropertyid; Type: DEFAULT; Schema: public; Owner: collage
--

ALTER TABLE ONLY applicationentityproperty ALTER COLUMN applicationentitypropertyid SET DEFAULT nextval('applicationentityproperty_applicationentitypropertyid_seq'::regclass);


--
-- Name: applicationtypeid; Type: DEFAULT; Schema: public; Owner: collage
--

ALTER TABLE ONLY applicationtype ALTER COLUMN applicationtypeid SET DEFAULT nextval('applicationtype_applicationtypeid_seq'::regclass);


--
-- Name: categoryid; Type: DEFAULT; Schema: public; Owner: collage
--

ALTER TABLE ONLY category ALTER COLUMN categoryid SET DEFAULT nextval('category_categoryid_seq'::regclass);


--
-- Name: categoryentityid; Type: DEFAULT; Schema: public; Owner: collage
--

ALTER TABLE ONLY categoryentity ALTER COLUMN categoryentityid SET DEFAULT nextval('categoryentity_categoryentityid_seq'::regclass);


--
-- Name: checktypeid; Type: DEFAULT; Schema: public; Owner: collage
--

ALTER TABLE ONLY checktype ALTER COLUMN checktypeid SET DEFAULT nextval('checktype_checktypeid_seq'::regclass);


--
-- Name: componentid; Type: DEFAULT; Schema: public; Owner: collage
--

ALTER TABLE ONLY component ALTER COLUMN componentid SET DEFAULT nextval('component_componentid_seq'::regclass);


--
-- Name: consolidationcriteriaid; Type: DEFAULT; Schema: public; Owner: collage
--

ALTER TABLE ONLY consolidationcriteria ALTER COLUMN consolidationcriteriaid SET DEFAULT nextval('consolidationcriteria_consolidationcriteriaid_seq'::regclass);


--
-- Name: deviceid; Type: DEFAULT; Schema: public; Owner: collage
--

ALTER TABLE ONLY device ALTER COLUMN deviceid SET DEFAULT nextval('device_deviceid_seq'::regclass);


--
-- Name: entityid; Type: DEFAULT; Schema: public; Owner: collage
--

ALTER TABLE ONLY entity ALTER COLUMN entityid SET DEFAULT nextval('entity_entityid_seq'::regclass);


--
-- Name: entitytypeid; Type: DEFAULT; Schema: public; Owner: collage
--

ALTER TABLE ONLY entitytype ALTER COLUMN entitytypeid SET DEFAULT nextval('entitytype_entitytypeid_seq'::regclass);


--
-- Name: hostid; Type: DEFAULT; Schema: public; Owner: collage
--

ALTER TABLE ONLY host ALTER COLUMN hostid SET DEFAULT nextval('host_hostid_seq'::regclass);


--
-- Name: hostgroupid; Type: DEFAULT; Schema: public; Owner: collage
--

ALTER TABLE ONLY hostgroup ALTER COLUMN hostgroupid SET DEFAULT nextval('hostgroup_hostgroupid_seq'::regclass);


--
-- Name: logmessageid; Type: DEFAULT; Schema: public; Owner: collage
--

ALTER TABLE ONLY logmessage ALTER COLUMN logmessageid SET DEFAULT nextval('logmessage_logmessageid_seq'::regclass);


--
-- Name: logperformancedataid; Type: DEFAULT; Schema: public; Owner: collage
--

ALTER TABLE ONLY logperformancedata ALTER COLUMN logperformancedataid SET DEFAULT nextval('logperformancedata_logperformancedataid_seq'::regclass);


--
-- Name: messagefilterid; Type: DEFAULT; Schema: public; Owner: collage
--

ALTER TABLE ONLY messagefilter ALTER COLUMN messagefilterid SET DEFAULT nextval('messagefilter_messagefilterid_seq'::regclass);


--
-- Name: monitorserverid; Type: DEFAULT; Schema: public; Owner: collage
--

ALTER TABLE ONLY monitorserver ALTER COLUMN monitorserverid SET DEFAULT nextval('monitorserver_monitorserverid_seq'::regclass);


--
-- Name: monitorstatusid; Type: DEFAULT; Schema: public; Owner: collage
--

ALTER TABLE ONLY monitorstatus ALTER COLUMN monitorstatusid SET DEFAULT nextval('monitorstatus_monitorstatusid_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: collage
--

ALTER TABLE ONLY network_service_notifications ALTER COLUMN id SET DEFAULT nextval('network_service_notifications_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: collage
--

ALTER TABLE ONLY network_service_short_news ALTER COLUMN id SET DEFAULT nextval('network_service_short_news_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: collage
--

ALTER TABLE ONLY network_service_status ALTER COLUMN id SET DEFAULT nextval('network_service_status_id_seq'::regclass);


--
-- Name: operationstatusid; Type: DEFAULT; Schema: public; Owner: collage
--

ALTER TABLE ONLY operationstatus ALTER COLUMN operationstatusid SET DEFAULT nextval('operationstatus_operationstatusid_seq'::regclass);


--
-- Name: performancedatalabelid; Type: DEFAULT; Schema: public; Owner: collage
--

ALTER TABLE ONLY performancedatalabel ALTER COLUMN performancedatalabelid SET DEFAULT nextval('performancedatalabel_performancedatalabelid_seq'::regclass);


--
-- Name: pluginid; Type: DEFAULT; Schema: public; Owner: collage
--

ALTER TABLE ONLY plugin ALTER COLUMN pluginid SET DEFAULT nextval('plugin_pluginid_seq'::regclass);


--
-- Name: platformid; Type: DEFAULT; Schema: public; Owner: collage
--

ALTER TABLE ONLY pluginplatform ALTER COLUMN platformid SET DEFAULT nextval('pluginplatform_platformid_seq'::regclass);


--
-- Name: priorityid; Type: DEFAULT; Schema: public; Owner: collage
--

ALTER TABLE ONLY priority ALTER COLUMN priorityid SET DEFAULT nextval('priority_priorityid_seq'::regclass);


--
-- Name: propertytypeid; Type: DEFAULT; Schema: public; Owner: collage
--

ALTER TABLE ONLY propertytype ALTER COLUMN propertytypeid SET DEFAULT nextval('propertytype_propertytypeid_seq'::regclass);


--
-- Name: servicestatusid; Type: DEFAULT; Schema: public; Owner: collage
--

ALTER TABLE ONLY servicestatus ALTER COLUMN servicestatusid SET DEFAULT nextval('servicestatus_servicestatusid_seq'::regclass);


--
-- Name: severityid; Type: DEFAULT; Schema: public; Owner: collage
--

ALTER TABLE ONLY severity ALTER COLUMN severityid SET DEFAULT nextval('severity_severityid_seq'::regclass);


--
-- Name: statetypeid; Type: DEFAULT; Schema: public; Owner: collage
--

ALTER TABLE ONLY statetype ALTER COLUMN statetypeid SET DEFAULT nextval('statetype_statetypeid_seq'::regclass);


--
-- Name: typeruleid; Type: DEFAULT; Schema: public; Owner: collage
--

ALTER TABLE ONLY typerule ALTER COLUMN typeruleid SET DEFAULT nextval('typerule_typeruleid_seq'::regclass);


--
-- Data for Name: action; Type: TABLE DATA; Schema: public; Owner: collage
--

COPY action (actionid, actiontypeid, name, description) FROM stdin;
\.
COPY action (actionid, actiontypeid, name, description) FROM '$$PATH$$/2466.dat';

--
-- Name: action_actionid_seq; Type: SEQUENCE SET; Schema: public; Owner: collage
--

SELECT pg_catalog.setval('action_actionid_seq', 11, true);


--
-- Data for Name: actionparameter; Type: TABLE DATA; Schema: public; Owner: collage
--

COPY actionparameter (actionparameterid, actionid, name, value) FROM stdin;
\.
COPY actionparameter (actionparameterid, actionid, name, value) FROM '$$PATH$$/2468.dat';

--
-- Name: actionparameter_actionparameterid_seq; Type: SEQUENCE SET; Schema: public; Owner: collage
--

SELECT pg_catalog.setval('actionparameter_actionparameterid_seq', 73, true);


--
-- Data for Name: actionproperty; Type: TABLE DATA; Schema: public; Owner: collage
--

COPY actionproperty (actionpropertyid, actionid, name, value) FROM stdin;
\.
COPY actionproperty (actionpropertyid, actionid, name, value) FROM '$$PATH$$/2470.dat';

--
-- Name: actionproperty_actionpropertyid_seq; Type: SEQUENCE SET; Schema: public; Owner: collage
--

SELECT pg_catalog.setval('actionproperty_actionpropertyid_seq', 11, true);


--
-- Data for Name: actiontype; Type: TABLE DATA; Schema: public; Owner: collage
--

COPY actiontype (actiontypeid, name, classname) FROM stdin;
\.
COPY actiontype (actiontypeid, name, classname) FROM '$$PATH$$/2472.dat';

--
-- Name: actiontype_actiontypeid_seq; Type: SEQUENCE SET; Schema: public; Owner: collage
--

SELECT pg_catalog.setval('actiontype_actiontypeid_seq', 5, true);


--
-- Data for Name: applicationaction; Type: TABLE DATA; Schema: public; Owner: collage
--

COPY applicationaction (applicationtypeid, actionid) FROM stdin;
\.
COPY applicationaction (applicationtypeid, actionid) FROM '$$PATH$$/2474.dat';

--
-- Data for Name: applicationentityproperty; Type: TABLE DATA; Schema: public; Owner: collage
--

COPY applicationentityproperty (applicationentitypropertyid, applicationtypeid, entitytypeid, propertytypeid, sortorder) FROM stdin;
\.
COPY applicationentityproperty (applicationentitypropertyid, applicationtypeid, entitytypeid, propertytypeid, sortorder) FROM '$$PATH$$/2475.dat';

--
-- Name: applicationentityproperty_applicationentitypropertyid_seq; Type: SEQUENCE SET; Schema: public; Owner: collage
--

SELECT pg_catalog.setval('applicationentityproperty_applicationentitypropertyid_seq', 149, true);


--
-- Data for Name: applicationtype; Type: TABLE DATA; Schema: public; Owner: collage
--

COPY applicationtype (applicationtypeid, name, description, statetransitioncriteria) FROM stdin;
\.
COPY applicationtype (applicationtypeid, name, description, statetransitioncriteria) FROM '$$PATH$$/2477.dat';

--
-- Name: applicationtype_applicationtypeid_seq; Type: SEQUENCE SET; Schema: public; Owner: collage
--

SELECT pg_catalog.setval('applicationtype_applicationtypeid_seq', 111, true);


--
-- Data for Name: category; Type: TABLE DATA; Schema: public; Owner: collage
--

COPY category (categoryid, name, description, entitytypeid) FROM stdin;
\.
COPY category (categoryid, name, description, entitytypeid) FROM '$$PATH$$/2479.dat';

--
-- Name: category_categoryid_seq; Type: SEQUENCE SET; Schema: public; Owner: collage
--

SELECT pg_catalog.setval('category_categoryid_seq', 1, false);


--
-- Data for Name: categoryentity; Type: TABLE DATA; Schema: public; Owner: collage
--

COPY categoryentity (categoryentityid, objectid, categoryid, entitytypeid) FROM stdin;
\.
COPY categoryentity (categoryentityid, objectid, categoryid, entitytypeid) FROM '$$PATH$$/2481.dat';

--
-- Name: categoryentity_categoryentityid_seq; Type: SEQUENCE SET; Schema: public; Owner: collage
--

SELECT pg_catalog.setval('categoryentity_categoryentityid_seq', 1, false);


--
-- Data for Name: categoryhierarchy; Type: TABLE DATA; Schema: public; Owner: collage
--

COPY categoryhierarchy (categoryid, parentid) FROM stdin;
\.
COPY categoryhierarchy (categoryid, parentid) FROM '$$PATH$$/2483.dat';

--
-- Data for Name: checktype; Type: TABLE DATA; Schema: public; Owner: collage
--

COPY checktype (checktypeid, name, description) FROM stdin;
\.
COPY checktype (checktypeid, name, description) FROM '$$PATH$$/2484.dat';

--
-- Name: checktype_checktypeid_seq; Type: SEQUENCE SET; Schema: public; Owner: collage
--

SELECT pg_catalog.setval('checktype_checktypeid_seq', 2, true);


--
-- Data for Name: component; Type: TABLE DATA; Schema: public; Owner: collage
--

COPY component (componentid, name, description) FROM stdin;
\.
COPY component (componentid, name, description) FROM '$$PATH$$/2486.dat';

--
-- Name: component_componentid_seq; Type: SEQUENCE SET; Schema: public; Owner: collage
--

SELECT pg_catalog.setval('component_componentid_seq', 4, true);


--
-- Data for Name: consolidationcriteria; Type: TABLE DATA; Schema: public; Owner: collage
--

COPY consolidationcriteria (consolidationcriteriaid, name, criteria) FROM stdin;
\.
COPY consolidationcriteria (consolidationcriteriaid, name, criteria) FROM '$$PATH$$/2488.dat';

--
-- Name: consolidationcriteria_consolidationcriteriaid_seq; Type: SEQUENCE SET; Schema: public; Owner: collage
--

SELECT pg_catalog.setval('consolidationcriteria_consolidationcriteriaid_seq', 4, true);


--
-- Data for Name: device; Type: TABLE DATA; Schema: public; Owner: collage
--

COPY device (deviceid, displayname, identification, description) FROM stdin;
\.
COPY device (deviceid, displayname, identification, description) FROM '$$PATH$$/2490.dat';

--
-- Name: device_deviceid_seq; Type: SEQUENCE SET; Schema: public; Owner: collage
--

SELECT pg_catalog.setval('device_deviceid_seq', 3, true);


--
-- Data for Name: deviceparent; Type: TABLE DATA; Schema: public; Owner: collage
--

COPY deviceparent (deviceid, parentid) FROM stdin;
\.
COPY deviceparent (deviceid, parentid) FROM '$$PATH$$/2492.dat';

--
-- Data for Name: entity; Type: TABLE DATA; Schema: public; Owner: collage
--

COPY entity (entityid, name, description, class, applicationtypeid) FROM stdin;
\.
COPY entity (entityid, name, description, class, applicationtypeid) FROM '$$PATH$$/2493.dat';

--
-- Name: entity_entityid_seq; Type: SEQUENCE SET; Schema: public; Owner: collage
--

SELECT pg_catalog.setval('entity_entityid_seq', 1, false);


--
-- Data for Name: entityproperty; Type: TABLE DATA; Schema: public; Owner: collage
--

COPY entityproperty (entitytypeid, objectid, propertytypeid, valuestring, valuedate, valueboolean, valueinteger, valuelong, valuedouble, lasteditedon, createdon) FROM stdin;
\.
COPY entityproperty (entitytypeid, objectid, propertytypeid, valuestring, valuedate, valueboolean, valueinteger, valuelong, valuedouble, lasteditedon, createdon) FROM '$$PATH$$/2495.dat';

--
-- Data for Name: entitytype; Type: TABLE DATA; Schema: public; Owner: collage
--

COPY entitytype (entitytypeid, name, description, islogicalentity, isapplicationtypesupported) FROM stdin;
\.
COPY entitytype (entitytypeid, name, description, islogicalentity, isapplicationtypesupported) FROM '$$PATH$$/2496.dat';

--
-- Name: entitytype_entitytypeid_seq; Type: SEQUENCE SET; Schema: public; Owner: collage
--

SELECT pg_catalog.setval('entitytype_entitytypeid_seq', 1, false);


--
-- Name: hibernate_sequence; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('hibernate_sequence', 1000, false);


--
-- Data for Name: host; Type: TABLE DATA; Schema: public; Owner: collage
--

COPY host (hostid, deviceid, hostname, description, applicationtypeid, agentid) FROM stdin;
\.
COPY host (hostid, deviceid, hostname, description, applicationtypeid, agentid) FROM '$$PATH$$/2498.dat';

--
-- Name: host_hostid_seq; Type: SEQUENCE SET; Schema: public; Owner: collage
--

SELECT pg_catalog.setval('host_hostid_seq', 3, true);


--
-- Data for Name: hostgroup; Type: TABLE DATA; Schema: public; Owner: collage
--

COPY hostgroup (hostgroupid, name, description, applicationtypeid, alias, agentid) FROM stdin;
\.
COPY hostgroup (hostgroupid, name, description, applicationtypeid, alias, agentid) FROM '$$PATH$$/2500.dat';

--
-- Name: hostgroup_hostgroupid_seq; Type: SEQUENCE SET; Schema: public; Owner: collage
--

SELECT pg_catalog.setval('hostgroup_hostgroupid_seq', 3, true);


--
-- Data for Name: hostgroupcollection; Type: TABLE DATA; Schema: public; Owner: collage
--

COPY hostgroupcollection (hostid, hostgroupid) FROM stdin;
\.
COPY hostgroupcollection (hostid, hostgroupid) FROM '$$PATH$$/2502.dat';

--
-- Data for Name: hoststatus; Type: TABLE DATA; Schema: public; Owner: collage
--

COPY hoststatus (hoststatusid, applicationtypeid, monitorstatusid, lastchecktime, checktypeid, statetypeid, nextchecktime) FROM stdin;
\.
COPY hoststatus (hoststatusid, applicationtypeid, monitorstatusid, lastchecktime, checktypeid, statetypeid, nextchecktime) FROM '$$PATH$$/2503.dat';

--
-- Data for Name: hoststatusproperty; Type: TABLE DATA; Schema: public; Owner: collage
--

COPY hoststatusproperty (hoststatusid, propertytypeid, valuestring, valuedate, valueboolean, valueinteger, valuelong, valuedouble, lasteditedon, createdon) FROM stdin;
\.
COPY hoststatusproperty (hoststatusid, propertytypeid, valuestring, valuedate, valueboolean, valueinteger, valuelong, valuedouble, lasteditedon, createdon) FROM '$$PATH$$/2504.dat';

--
-- Data for Name: logmessage; Type: TABLE DATA; Schema: public; Owner: collage
--

COPY logmessage (logmessageid, applicationtypeid, deviceid, hoststatusid, servicestatusid, textmessage, msgcount, firstinsertdate, lastinsertdate, reportdate, monitorstatusid, severityid, applicationseverityid, priorityid, typeruleid, componentid, operationstatusid, isstatechanged, consolidationhash, statelesshash, statetransitionhash) FROM stdin;
\.
COPY logmessage (logmessageid, applicationtypeid, deviceid, hoststatusid, servicestatusid, textmessage, msgcount, firstinsertdate, lastinsertdate, reportdate, monitorstatusid, severityid, applicationseverityid, priorityid, typeruleid, componentid, operationstatusid, isstatechanged, consolidationhash, statelesshash, statetransitionhash) FROM '$$PATH$$/2505.dat';

--
-- Name: logmessage_logmessageid_seq; Type: SEQUENCE SET; Schema: public; Owner: collage
--

SELECT pg_catalog.setval('logmessage_logmessageid_seq', 65, true);


--
-- Data for Name: logmessageproperty; Type: TABLE DATA; Schema: public; Owner: collage
--

COPY logmessageproperty (logmessageid, propertytypeid, valuestring, valuedate, valueboolean, valueinteger, valuelong, valuedouble, lasteditedon, createdon) FROM stdin;
\.
COPY logmessageproperty (logmessageid, propertytypeid, valuestring, valuedate, valueboolean, valueinteger, valuelong, valuedouble, lasteditedon, createdon) FROM '$$PATH$$/2507.dat';

--
-- Data for Name: logperformancedata; Type: TABLE DATA; Schema: public; Owner: collage
--

COPY logperformancedata (logperformancedataid, servicestatusid, lastchecktime, maximum, minimum, average, measurementpoints, performancedatalabelid) FROM stdin;
\.
COPY logperformancedata (logperformancedataid, servicestatusid, lastchecktime, maximum, minimum, average, measurementpoints, performancedatalabelid) FROM '$$PATH$$/2508.dat';

--
-- Name: logperformancedata_logperformancedataid_seq; Type: SEQUENCE SET; Schema: public; Owner: collage
--

SELECT pg_catalog.setval('logperformancedata_logperformancedataid_seq', 1, false);


--
-- Data for Name: messagefilter; Type: TABLE DATA; Schema: public; Owner: collage
--

COPY messagefilter (messagefilterid, name, regexpresion, ischangeseveritytostatistic) FROM stdin;
\.
COPY messagefilter (messagefilterid, name, regexpresion, ischangeseveritytostatistic) FROM '$$PATH$$/2510.dat';

--
-- Name: messagefilter_messagefilterid_seq; Type: SEQUENCE SET; Schema: public; Owner: collage
--

SELECT pg_catalog.setval('messagefilter_messagefilterid_seq', 1, false);


--
-- Data for Name: monitorlist; Type: TABLE DATA; Schema: public; Owner: collage
--

COPY monitorlist (monitorserverid, deviceid) FROM stdin;
\.
COPY monitorlist (monitorserverid, deviceid) FROM '$$PATH$$/2512.dat';

--
-- Data for Name: monitorserver; Type: TABLE DATA; Schema: public; Owner: collage
--

COPY monitorserver (monitorserverid, monitorservername, ip, description) FROM stdin;
\.
COPY monitorserver (monitorserverid, monitorservername, ip, description) FROM '$$PATH$$/2513.dat';

--
-- Name: monitorserver_monitorserverid_seq; Type: SEQUENCE SET; Schema: public; Owner: collage
--

SELECT pg_catalog.setval('monitorserver_monitorserverid_seq', 1, true);


--
-- Data for Name: monitorstatus; Type: TABLE DATA; Schema: public; Owner: collage
--

COPY monitorstatus (monitorstatusid, name, description) FROM stdin;
\.
COPY monitorstatus (monitorstatusid, name, description) FROM '$$PATH$$/2515.dat';

--
-- Name: monitorstatus_monitorstatusid_seq; Type: SEQUENCE SET; Schema: public; Owner: collage
--

SELECT pg_catalog.setval('monitorstatus_monitorstatusid_seq', 23, true);


--
-- Data for Name: network_service_notifications; Type: TABLE DATA; Schema: public; Owner: collage
--

COPY network_service_notifications (id, created_at, guid, type, title, critical, description, webpage_url, webpage_url_description, update_md5, update_url, update_cmd_switch, update_instruction, update_size, update_type, update_os, is_read, is_archived) FROM stdin;
\.
COPY network_service_notifications (id, created_at, guid, type, title, critical, description, webpage_url, webpage_url_description, update_md5, update_url, update_cmd_switch, update_instruction, update_size, update_type, update_os, is_read, is_archived) FROM '$$PATH$$/2541.dat';

--
-- Name: network_service_notifications_id_seq; Type: SEQUENCE SET; Schema: public; Owner: collage
--

SELECT pg_catalog.setval('network_service_notifications_id_seq', 1, false);


--
-- Data for Name: network_service_short_news; Type: TABLE DATA; Schema: public; Owner: collage
--

COPY network_service_short_news (id, status, title, message, url, url_description, is_archived) FROM stdin;
\.
COPY network_service_short_news (id, status, title, message, url, url_description, is_archived) FROM '$$PATH$$/2543.dat';

--
-- Name: network_service_short_news_id_seq; Type: SEQUENCE SET; Schema: public; Owner: collage
--

SELECT pg_catalog.setval('network_service_short_news_id_seq', 1, false);


--
-- Data for Name: network_service_status; Type: TABLE DATA; Schema: public; Owner: collage
--

COPY network_service_status (id, last_checked) FROM stdin;
\.
COPY network_service_status (id, last_checked) FROM '$$PATH$$/2545.dat';

--
-- Name: network_service_status_id_seq; Type: SEQUENCE SET; Schema: public; Owner: collage
--

SELECT pg_catalog.setval('network_service_status_id_seq', 1, false);


--
-- Data for Name: operationstatus; Type: TABLE DATA; Schema: public; Owner: collage
--

COPY operationstatus (operationstatusid, name, description) FROM stdin;
\.
COPY operationstatus (operationstatusid, name, description) FROM '$$PATH$$/2517.dat';

--
-- Name: operationstatus_operationstatusid_seq; Type: SEQUENCE SET; Schema: public; Owner: collage
--

SELECT pg_catalog.setval('operationstatus_operationstatusid_seq', 5, true);


--
-- Data for Name: performancedatalabel; Type: TABLE DATA; Schema: public; Owner: collage
--

COPY performancedatalabel (performancedatalabelid, performancename, servicedisplayname, metriclabel, unit) FROM stdin;
\.
COPY performancedatalabel (performancedatalabelid, performancename, servicedisplayname, metriclabel, unit) FROM '$$PATH$$/2519.dat';

--
-- Name: performancedatalabel_performancedatalabelid_seq; Type: SEQUENCE SET; Schema: public; Owner: collage
--

SELECT pg_catalog.setval('performancedatalabel_performancedatalabelid_seq', 9, true);


--
-- Data for Name: plugin; Type: TABLE DATA; Schema: public; Owner: collage
--

COPY plugin (pluginid, name, url, platformid, dependencies, lastupdatetimestamp, checksum, lastupdatedby) FROM stdin;
\.
COPY plugin (pluginid, name, url, platformid, dependencies, lastupdatetimestamp, checksum, lastupdatedby) FROM '$$PATH$$/2521.dat';

--
-- Name: plugin_pluginid_seq; Type: SEQUENCE SET; Schema: public; Owner: collage
--

SELECT pg_catalog.setval('plugin_pluginid_seq', 1, false);


--
-- Data for Name: pluginplatform; Type: TABLE DATA; Schema: public; Owner: collage
--

COPY pluginplatform (platformid, name, arch, description) FROM stdin;
\.
COPY pluginplatform (platformid, name, arch, description) FROM '$$PATH$$/2523.dat';

--
-- Name: pluginplatform_platformid_seq; Type: SEQUENCE SET; Schema: public; Owner: collage
--

SELECT pg_catalog.setval('pluginplatform_platformid_seq', 12, true);


--
-- Data for Name: priority; Type: TABLE DATA; Schema: public; Owner: collage
--

COPY priority (priorityid, name, description) FROM stdin;
\.
COPY priority (priorityid, name, description) FROM '$$PATH$$/2525.dat';

--
-- Name: priority_priorityid_seq; Type: SEQUENCE SET; Schema: public; Owner: collage
--

SELECT pg_catalog.setval('priority_priorityid_seq', 10, true);


--
-- Data for Name: propertytype; Type: TABLE DATA; Schema: public; Owner: collage
--

COPY propertytype (propertytypeid, name, description, isdate, isboolean, isstring, isinteger, islong, isdouble, isvisible) FROM stdin;
\.
COPY propertytype (propertytypeid, name, description, isdate, isboolean, isstring, isinteger, islong, isdouble, isvisible) FROM '$$PATH$$/2527.dat';

--
-- Name: propertytype_propertytypeid_seq; Type: SEQUENCE SET; Schema: public; Owner: collage
--

SELECT pg_catalog.setval('propertytype_propertytypeid_seq', 63, true);


--
-- Data for Name: schemainfo; Type: TABLE DATA; Schema: public; Owner: collage
--

COPY schemainfo (name, value) FROM stdin;
\.
COPY schemainfo (name, value) FROM '$$PATH$$/2529.dat';

--
-- Data for Name: servicestatus; Type: TABLE DATA; Schema: public; Owner: collage
--

COPY servicestatus (servicestatusid, applicationtypeid, servicedescription, hostid, monitorstatusid, lastchecktime, nextchecktime, laststatechange, lasthardstateid, statetypeid, checktypeid, metrictype, domain, agentid) FROM stdin;
\.
COPY servicestatus (servicestatusid, applicationtypeid, servicedescription, hostid, monitorstatusid, lastchecktime, nextchecktime, laststatechange, lasthardstateid, statetypeid, checktypeid, metrictype, domain, agentid) FROM '$$PATH$$/2530.dat';

--
-- Name: servicestatus_servicestatusid_seq; Type: SEQUENCE SET; Schema: public; Owner: collage
--

SELECT pg_catalog.setval('servicestatus_servicestatusid_seq', 25, true);


--
-- Data for Name: servicestatusproperty; Type: TABLE DATA; Schema: public; Owner: collage
--

COPY servicestatusproperty (servicestatusid, propertytypeid, valuestring, valuedate, valueboolean, valueinteger, valuelong, valuedouble, lasteditedon, createdon) FROM stdin;
\.
COPY servicestatusproperty (servicestatusid, propertytypeid, valuestring, valuedate, valueboolean, valueinteger, valuelong, valuedouble, lasteditedon, createdon) FROM '$$PATH$$/2532.dat';

--
-- Data for Name: severity; Type: TABLE DATA; Schema: public; Owner: collage
--

COPY severity (severityid, name, description) FROM stdin;
\.
COPY severity (severityid, name, description) FROM '$$PATH$$/2533.dat';

--
-- Name: severity_severityid_seq; Type: SEQUENCE SET; Schema: public; Owner: collage
--

SELECT pg_catalog.setval('severity_severityid_seq', 26, true);


--
-- Data for Name: statetype; Type: TABLE DATA; Schema: public; Owner: collage
--

COPY statetype (statetypeid, name, description) FROM stdin;
\.
COPY statetype (statetypeid, name, description) FROM '$$PATH$$/2535.dat';

--
-- Name: statetype_statetypeid_seq; Type: SEQUENCE SET; Schema: public; Owner: collage
--

SELECT pg_catalog.setval('statetype_statetypeid_seq', 3, true);


--
-- Data for Name: typerule; Type: TABLE DATA; Schema: public; Owner: collage
--

COPY typerule (typeruleid, name, description) FROM stdin;
\.
COPY typerule (typeruleid, name, description) FROM '$$PATH$$/2537.dat';

--
-- Name: typerule_typeruleid_seq; Type: SEQUENCE SET; Schema: public; Owner: collage
--

SELECT pg_catalog.setval('typerule_typeruleid_seq', 9, true);


--
-- Name: action_name_key; Type: CONSTRAINT; Schema: public; Owner: collage; Tablespace: 
--

ALTER TABLE ONLY action
    ADD CONSTRAINT action_name_key UNIQUE (name);


--
-- Name: action_pkey; Type: CONSTRAINT; Schema: public; Owner: collage; Tablespace: 
--

ALTER TABLE ONLY action
    ADD CONSTRAINT action_pkey PRIMARY KEY (actionid);


--
-- Name: actionparameter_actionid_name_key; Type: CONSTRAINT; Schema: public; Owner: collage; Tablespace: 
--

ALTER TABLE ONLY actionparameter
    ADD CONSTRAINT actionparameter_actionid_name_key UNIQUE (actionid, name);


--
-- Name: actionparameter_pkey; Type: CONSTRAINT; Schema: public; Owner: collage; Tablespace: 
--

ALTER TABLE ONLY actionparameter
    ADD CONSTRAINT actionparameter_pkey PRIMARY KEY (actionparameterid);


--
-- Name: actionproperty_actionid_name_key; Type: CONSTRAINT; Schema: public; Owner: collage; Tablespace: 
--

ALTER TABLE ONLY actionproperty
    ADD CONSTRAINT actionproperty_actionid_name_key UNIQUE (actionid, name);


--
-- Name: actionproperty_pkey; Type: CONSTRAINT; Schema: public; Owner: collage; Tablespace: 
--

ALTER TABLE ONLY actionproperty
    ADD CONSTRAINT actionproperty_pkey PRIMARY KEY (actionpropertyid);


--
-- Name: actiontype_name_key; Type: CONSTRAINT; Schema: public; Owner: collage; Tablespace: 
--

ALTER TABLE ONLY actiontype
    ADD CONSTRAINT actiontype_name_key UNIQUE (name);


--
-- Name: actiontype_pkey; Type: CONSTRAINT; Schema: public; Owner: collage; Tablespace: 
--

ALTER TABLE ONLY actiontype
    ADD CONSTRAINT actiontype_pkey PRIMARY KEY (actiontypeid);


--
-- Name: applicationaction_pkey; Type: CONSTRAINT; Schema: public; Owner: collage; Tablespace: 
--

ALTER TABLE ONLY applicationaction
    ADD CONSTRAINT applicationaction_pkey PRIMARY KEY (applicationtypeid, actionid);


--
-- Name: applicationentityproperty_applicationtypeid_entitytypeid_pr_key; Type: CONSTRAINT; Schema: public; Owner: collage; Tablespace: 
--

ALTER TABLE ONLY applicationentityproperty
    ADD CONSTRAINT applicationentityproperty_applicationtypeid_entitytypeid_pr_key UNIQUE (applicationtypeid, entitytypeid, propertytypeid);


--
-- Name: applicationentityproperty_pkey; Type: CONSTRAINT; Schema: public; Owner: collage; Tablespace: 
--

ALTER TABLE ONLY applicationentityproperty
    ADD CONSTRAINT applicationentityproperty_pkey PRIMARY KEY (applicationentitypropertyid);


--
-- Name: applicationtype_name_key; Type: CONSTRAINT; Schema: public; Owner: collage; Tablespace: 
--

ALTER TABLE ONLY applicationtype
    ADD CONSTRAINT applicationtype_name_key UNIQUE (name);


--
-- Name: applicationtype_pkey; Type: CONSTRAINT; Schema: public; Owner: collage; Tablespace: 
--

ALTER TABLE ONLY applicationtype
    ADD CONSTRAINT applicationtype_pkey PRIMARY KEY (applicationtypeid);


--
-- Name: category_name_key; Type: CONSTRAINT; Schema: public; Owner: collage; Tablespace: 
--

ALTER TABLE ONLY category
    ADD CONSTRAINT category_name_key UNIQUE (name);


--
-- Name: category_pkey; Type: CONSTRAINT; Schema: public; Owner: collage; Tablespace: 
--

ALTER TABLE ONLY category
    ADD CONSTRAINT category_pkey PRIMARY KEY (categoryid);


--
-- Name: categoryentity_pkey; Type: CONSTRAINT; Schema: public; Owner: collage; Tablespace: 
--

ALTER TABLE ONLY categoryentity
    ADD CONSTRAINT categoryentity_pkey PRIMARY KEY (categoryentityid);


--
-- Name: categoryhierarchy_pkey; Type: CONSTRAINT; Schema: public; Owner: collage; Tablespace: 
--

ALTER TABLE ONLY categoryhierarchy
    ADD CONSTRAINT categoryhierarchy_pkey PRIMARY KEY (categoryid, parentid);


--
-- Name: checktype_name_key; Type: CONSTRAINT; Schema: public; Owner: collage; Tablespace: 
--

ALTER TABLE ONLY checktype
    ADD CONSTRAINT checktype_name_key UNIQUE (name);


--
-- Name: checktype_pkey; Type: CONSTRAINT; Schema: public; Owner: collage; Tablespace: 
--

ALTER TABLE ONLY checktype
    ADD CONSTRAINT checktype_pkey PRIMARY KEY (checktypeid);


--
-- Name: component_name_key; Type: CONSTRAINT; Schema: public; Owner: collage; Tablespace: 
--

ALTER TABLE ONLY component
    ADD CONSTRAINT component_name_key UNIQUE (name);


--
-- Name: component_pkey; Type: CONSTRAINT; Schema: public; Owner: collage; Tablespace: 
--

ALTER TABLE ONLY component
    ADD CONSTRAINT component_pkey PRIMARY KEY (componentid);


--
-- Name: consolidationcriteria_name_key; Type: CONSTRAINT; Schema: public; Owner: collage; Tablespace: 
--

ALTER TABLE ONLY consolidationcriteria
    ADD CONSTRAINT consolidationcriteria_name_key UNIQUE (name);


--
-- Name: consolidationcriteria_pkey; Type: CONSTRAINT; Schema: public; Owner: collage; Tablespace: 
--

ALTER TABLE ONLY consolidationcriteria
    ADD CONSTRAINT consolidationcriteria_pkey PRIMARY KEY (consolidationcriteriaid);


--
-- Name: device_identification_key; Type: CONSTRAINT; Schema: public; Owner: collage; Tablespace: 
--

ALTER TABLE ONLY device
    ADD CONSTRAINT device_identification_key UNIQUE (identification);


--
-- Name: device_pkey; Type: CONSTRAINT; Schema: public; Owner: collage; Tablespace: 
--

ALTER TABLE ONLY device
    ADD CONSTRAINT device_pkey PRIMARY KEY (deviceid);


--
-- Name: deviceparent_pkey; Type: CONSTRAINT; Schema: public; Owner: collage; Tablespace: 
--

ALTER TABLE ONLY deviceparent
    ADD CONSTRAINT deviceparent_pkey PRIMARY KEY (deviceid, parentid);


--
-- Name: entity_pkey; Type: CONSTRAINT; Schema: public; Owner: collage; Tablespace: 
--

ALTER TABLE ONLY entity
    ADD CONSTRAINT entity_pkey PRIMARY KEY (entityid);


--
-- Name: entityproperty_pkey; Type: CONSTRAINT; Schema: public; Owner: collage; Tablespace: 
--

ALTER TABLE ONLY entityproperty
    ADD CONSTRAINT entityproperty_pkey PRIMARY KEY (entitytypeid, objectid, propertytypeid);


--
-- Name: entitytype_name_key; Type: CONSTRAINT; Schema: public; Owner: collage; Tablespace: 
--

ALTER TABLE ONLY entitytype
    ADD CONSTRAINT entitytype_name_key UNIQUE (name);


--
-- Name: entitytype_pkey; Type: CONSTRAINT; Schema: public; Owner: collage; Tablespace: 
--

ALTER TABLE ONLY entitytype
    ADD CONSTRAINT entitytype_pkey PRIMARY KEY (entitytypeid);


--
-- Name: host_hostname_key; Type: CONSTRAINT; Schema: public; Owner: collage; Tablespace: 
--

ALTER TABLE ONLY host
    ADD CONSTRAINT host_hostname_key UNIQUE (hostname);


--
-- Name: host_pkey; Type: CONSTRAINT; Schema: public; Owner: collage; Tablespace: 
--

ALTER TABLE ONLY host
    ADD CONSTRAINT host_pkey PRIMARY KEY (hostid);


--
-- Name: hostgroup_name_key; Type: CONSTRAINT; Schema: public; Owner: collage; Tablespace: 
--

ALTER TABLE ONLY hostgroup
    ADD CONSTRAINT hostgroup_name_key UNIQUE (name);


--
-- Name: hostgroup_pkey; Type: CONSTRAINT; Schema: public; Owner: collage; Tablespace: 
--

ALTER TABLE ONLY hostgroup
    ADD CONSTRAINT hostgroup_pkey PRIMARY KEY (hostgroupid);


--
-- Name: hostgroupcollection_pkey; Type: CONSTRAINT; Schema: public; Owner: collage; Tablespace: 
--

ALTER TABLE ONLY hostgroupcollection
    ADD CONSTRAINT hostgroupcollection_pkey PRIMARY KEY (hostid, hostgroupid);


--
-- Name: hoststatus_pkey; Type: CONSTRAINT; Schema: public; Owner: collage; Tablespace: 
--

ALTER TABLE ONLY hoststatus
    ADD CONSTRAINT hoststatus_pkey PRIMARY KEY (hoststatusid);


--
-- Name: hoststatusproperty_pkey; Type: CONSTRAINT; Schema: public; Owner: collage; Tablespace: 
--

ALTER TABLE ONLY hoststatusproperty
    ADD CONSTRAINT hoststatusproperty_pkey PRIMARY KEY (hoststatusid, propertytypeid);


--
-- Name: logmessage_pkey; Type: CONSTRAINT; Schema: public; Owner: collage; Tablespace: 
--

ALTER TABLE ONLY logmessage
    ADD CONSTRAINT logmessage_pkey PRIMARY KEY (logmessageid);


--
-- Name: logmessageproperty_pkey; Type: CONSTRAINT; Schema: public; Owner: collage; Tablespace: 
--

ALTER TABLE ONLY logmessageproperty
    ADD CONSTRAINT logmessageproperty_pkey PRIMARY KEY (logmessageid, propertytypeid);


--
-- Name: logperformancedata_pkey; Type: CONSTRAINT; Schema: public; Owner: collage; Tablespace: 
--

ALTER TABLE ONLY logperformancedata
    ADD CONSTRAINT logperformancedata_pkey PRIMARY KEY (logperformancedataid);


--
-- Name: messagefilter_name_key; Type: CONSTRAINT; Schema: public; Owner: collage; Tablespace: 
--

ALTER TABLE ONLY messagefilter
    ADD CONSTRAINT messagefilter_name_key UNIQUE (name);


--
-- Name: messagefilter_pkey; Type: CONSTRAINT; Schema: public; Owner: collage; Tablespace: 
--

ALTER TABLE ONLY messagefilter
    ADD CONSTRAINT messagefilter_pkey PRIMARY KEY (messagefilterid);


--
-- Name: monitorlist_pkey; Type: CONSTRAINT; Schema: public; Owner: collage; Tablespace: 
--

ALTER TABLE ONLY monitorlist
    ADD CONSTRAINT monitorlist_pkey PRIMARY KEY (monitorserverid, deviceid);


--
-- Name: monitorserver_pkey; Type: CONSTRAINT; Schema: public; Owner: collage; Tablespace: 
--

ALTER TABLE ONLY monitorserver
    ADD CONSTRAINT monitorserver_pkey PRIMARY KEY (monitorserverid);


--
-- Name: monitorstatus_name_key; Type: CONSTRAINT; Schema: public; Owner: collage; Tablespace: 
--

ALTER TABLE ONLY monitorstatus
    ADD CONSTRAINT monitorstatus_name_key UNIQUE (name);


--
-- Name: monitorstatus_pkey; Type: CONSTRAINT; Schema: public; Owner: collage; Tablespace: 
--

ALTER TABLE ONLY monitorstatus
    ADD CONSTRAINT monitorstatus_pkey PRIMARY KEY (monitorstatusid);


--
-- Name: network_service_notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: collage; Tablespace: 
--

ALTER TABLE ONLY network_service_notifications
    ADD CONSTRAINT network_service_notifications_pkey PRIMARY KEY (id);


--
-- Name: network_service_short_news_pkey; Type: CONSTRAINT; Schema: public; Owner: collage; Tablespace: 
--

ALTER TABLE ONLY network_service_short_news
    ADD CONSTRAINT network_service_short_news_pkey PRIMARY KEY (id);


--
-- Name: network_service_status_pkey; Type: CONSTRAINT; Schema: public; Owner: collage; Tablespace: 
--

ALTER TABLE ONLY network_service_status
    ADD CONSTRAINT network_service_status_pkey PRIMARY KEY (id);


--
-- Name: operationstatus_name_key; Type: CONSTRAINT; Schema: public; Owner: collage; Tablespace: 
--

ALTER TABLE ONLY operationstatus
    ADD CONSTRAINT operationstatus_name_key UNIQUE (name);


--
-- Name: operationstatus_pkey; Type: CONSTRAINT; Schema: public; Owner: collage; Tablespace: 
--

ALTER TABLE ONLY operationstatus
    ADD CONSTRAINT operationstatus_pkey PRIMARY KEY (operationstatusid);


--
-- Name: performancedatalabel_performancename_key; Type: CONSTRAINT; Schema: public; Owner: collage; Tablespace: 
--

ALTER TABLE ONLY performancedatalabel
    ADD CONSTRAINT performancedatalabel_performancename_key UNIQUE (performancename);


--
-- Name: performancedatalabel_pkey; Type: CONSTRAINT; Schema: public; Owner: collage; Tablespace: 
--

ALTER TABLE ONLY performancedatalabel
    ADD CONSTRAINT performancedatalabel_pkey PRIMARY KEY (performancedatalabelid);


--
-- Name: plugin_pkey; Type: CONSTRAINT; Schema: public; Owner: collage; Tablespace: 
--

ALTER TABLE ONLY plugin
    ADD CONSTRAINT plugin_pkey PRIMARY KEY (pluginid);


--
-- Name: plugin_platformid_name_key; Type: CONSTRAINT; Schema: public; Owner: collage; Tablespace: 
--

ALTER TABLE ONLY plugin
    ADD CONSTRAINT plugin_platformid_name_key UNIQUE (platformid, name);


--
-- Name: pluginplatform_name_arch_key; Type: CONSTRAINT; Schema: public; Owner: collage; Tablespace: 
--

ALTER TABLE ONLY pluginplatform
    ADD CONSTRAINT pluginplatform_name_arch_key UNIQUE (name, arch);


--
-- Name: pluginplatform_pkey; Type: CONSTRAINT; Schema: public; Owner: collage; Tablespace: 
--

ALTER TABLE ONLY pluginplatform
    ADD CONSTRAINT pluginplatform_pkey PRIMARY KEY (platformid);


--
-- Name: priority_name_key; Type: CONSTRAINT; Schema: public; Owner: collage; Tablespace: 
--

ALTER TABLE ONLY priority
    ADD CONSTRAINT priority_name_key UNIQUE (name);


--
-- Name: priority_pkey; Type: CONSTRAINT; Schema: public; Owner: collage; Tablespace: 
--

ALTER TABLE ONLY priority
    ADD CONSTRAINT priority_pkey PRIMARY KEY (priorityid);


--
-- Name: propertytype_name_key; Type: CONSTRAINT; Schema: public; Owner: collage; Tablespace: 
--

ALTER TABLE ONLY propertytype
    ADD CONSTRAINT propertytype_name_key UNIQUE (name);


--
-- Name: propertytype_pkey; Type: CONSTRAINT; Schema: public; Owner: collage; Tablespace: 
--

ALTER TABLE ONLY propertytype
    ADD CONSTRAINT propertytype_pkey PRIMARY KEY (propertytypeid);


--
-- Name: servicestatus_hostid_servicedescription_key; Type: CONSTRAINT; Schema: public; Owner: collage; Tablespace: 
--

ALTER TABLE ONLY servicestatus
    ADD CONSTRAINT servicestatus_hostid_servicedescription_key UNIQUE (hostid, servicedescription);


--
-- Name: servicestatus_pkey; Type: CONSTRAINT; Schema: public; Owner: collage; Tablespace: 
--

ALTER TABLE ONLY servicestatus
    ADD CONSTRAINT servicestatus_pkey PRIMARY KEY (servicestatusid);


--
-- Name: servicestatusproperty_pkey; Type: CONSTRAINT; Schema: public; Owner: collage; Tablespace: 
--

ALTER TABLE ONLY servicestatusproperty
    ADD CONSTRAINT servicestatusproperty_pkey PRIMARY KEY (servicestatusid, propertytypeid);


--
-- Name: severity_name_key; Type: CONSTRAINT; Schema: public; Owner: collage; Tablespace: 
--

ALTER TABLE ONLY severity
    ADD CONSTRAINT severity_name_key UNIQUE (name);


--
-- Name: severity_pkey; Type: CONSTRAINT; Schema: public; Owner: collage; Tablespace: 
--

ALTER TABLE ONLY severity
    ADD CONSTRAINT severity_pkey PRIMARY KEY (severityid);


--
-- Name: statetype_name_key; Type: CONSTRAINT; Schema: public; Owner: collage; Tablespace: 
--

ALTER TABLE ONLY statetype
    ADD CONSTRAINT statetype_name_key UNIQUE (name);


--
-- Name: statetype_pkey; Type: CONSTRAINT; Schema: public; Owner: collage; Tablespace: 
--

ALTER TABLE ONLY statetype
    ADD CONSTRAINT statetype_pkey PRIMARY KEY (statetypeid);


--
-- Name: typerule_name_key; Type: CONSTRAINT; Schema: public; Owner: collage; Tablespace: 
--

ALTER TABLE ONLY typerule
    ADD CONSTRAINT typerule_name_key UNIQUE (name);


--
-- Name: typerule_pkey; Type: CONSTRAINT; Schema: public; Owner: collage; Tablespace: 
--

ALTER TABLE ONLY typerule
    ADD CONSTRAINT typerule_pkey PRIMARY KEY (typeruleid);


--
-- Name: action_actiontypeid; Type: INDEX; Schema: public; Owner: collage; Tablespace: 
--

CREATE INDEX action_actiontypeid ON action USING btree (actiontypeid);


--
-- Name: action_idx_action_name; Type: INDEX; Schema: public; Owner: collage; Tablespace: 
--

CREATE INDEX action_idx_action_name ON action USING btree (name);


--
-- Name: applicationaction_actionid; Type: INDEX; Schema: public; Owner: collage; Tablespace: 
--

CREATE INDEX applicationaction_actionid ON applicationaction USING btree (actionid);


--
-- Name: applicationentityproperty_entitytypeid; Type: INDEX; Schema: public; Owner: collage; Tablespace: 
--

CREATE INDEX applicationentityproperty_entitytypeid ON applicationentityproperty USING btree (entitytypeid);


--
-- Name: applicationentityproperty_propertytypeid; Type: INDEX; Schema: public; Owner: collage; Tablespace: 
--

CREATE INDEX applicationentityproperty_propertytypeid ON applicationentityproperty USING btree (propertytypeid);


--
-- Name: category_entitytypeid_ibfk1_1; Type: INDEX; Schema: public; Owner: collage; Tablespace: 
--

CREATE INDEX category_entitytypeid_ibfk1_1 ON category USING btree (entitytypeid);


--
-- Name: categoryentity_categoryid; Type: INDEX; Schema: public; Owner: collage; Tablespace: 
--

CREATE INDEX categoryentity_categoryid ON categoryentity USING btree (categoryid);


--
-- Name: categoryentity_entitytypeid; Type: INDEX; Schema: public; Owner: collage; Tablespace: 
--

CREATE INDEX categoryentity_entitytypeid ON categoryentity USING btree (entitytypeid);


--
-- Name: categoryhierarchy_parentid; Type: INDEX; Schema: public; Owner: collage; Tablespace: 
--

CREATE INDEX categoryhierarchy_parentid ON categoryhierarchy USING btree (parentid);


--
-- Name: deviceparent_parentid; Type: INDEX; Schema: public; Owner: collage; Tablespace: 
--

CREATE INDEX deviceparent_parentid ON deviceparent USING btree (parentid);


--
-- Name: entity_applicationtypeid_ibfk1_1; Type: INDEX; Schema: public; Owner: collage; Tablespace: 
--

CREATE INDEX entity_applicationtypeid_ibfk1_1 ON entity USING btree (applicationtypeid);


--
-- Name: entityproperty_propertytypeid; Type: INDEX; Schema: public; Owner: collage; Tablespace: 
--

CREATE INDEX entityproperty_propertytypeid ON entityproperty USING btree (propertytypeid);


--
-- Name: host_applicationtypeid; Type: INDEX; Schema: public; Owner: collage; Tablespace: 
--

CREATE INDEX host_applicationtypeid ON host USING btree (applicationtypeid);


--
-- Name: host_deviceid; Type: INDEX; Schema: public; Owner: collage; Tablespace: 
--

CREATE INDEX host_deviceid ON host USING btree (deviceid);


--
-- Name: hostgroup_applicationtypeid; Type: INDEX; Schema: public; Owner: collage; Tablespace: 
--

CREATE INDEX hostgroup_applicationtypeid ON hostgroup USING btree (applicationtypeid);


--
-- Name: hostgroupcollection_hostgroupid; Type: INDEX; Schema: public; Owner: collage; Tablespace: 
--

CREATE INDEX hostgroupcollection_hostgroupid ON hostgroupcollection USING btree (hostgroupid);


--
-- Name: hoststatus_checktypeid; Type: INDEX; Schema: public; Owner: collage; Tablespace: 
--

CREATE INDEX hoststatus_checktypeid ON hoststatus USING btree (checktypeid);


--
-- Name: hoststatus_monitorstatusid; Type: INDEX; Schema: public; Owner: collage; Tablespace: 
--

CREATE INDEX hoststatus_monitorstatusid ON hoststatus USING btree (monitorstatusid);


--
-- Name: hoststatus_statetypeid; Type: INDEX; Schema: public; Owner: collage; Tablespace: 
--

CREATE INDEX hoststatus_statetypeid ON hoststatus USING btree (statetypeid);


--
-- Name: hoststatusproperty_propertytypeid; Type: INDEX; Schema: public; Owner: collage; Tablespace: 
--

CREATE INDEX hoststatusproperty_propertytypeid ON hoststatusproperty USING btree (propertytypeid);


--
-- Name: logmessage_applicationseverityid; Type: INDEX; Schema: public; Owner: collage; Tablespace: 
--

CREATE INDEX logmessage_applicationseverityid ON logmessage USING btree (applicationseverityid);


--
-- Name: logmessage_applicationtypeid; Type: INDEX; Schema: public; Owner: collage; Tablespace: 
--

CREATE INDEX logmessage_applicationtypeid ON logmessage USING btree (applicationtypeid);


--
-- Name: logmessage_componentid; Type: INDEX; Schema: public; Owner: collage; Tablespace: 
--

CREATE INDEX logmessage_componentid ON logmessage USING btree (componentid);


--
-- Name: logmessage_deviceid; Type: INDEX; Schema: public; Owner: collage; Tablespace: 
--

CREATE INDEX logmessage_deviceid ON logmessage USING btree (deviceid);


--
-- Name: logmessage_fk_logmessage_hoststatusid; Type: INDEX; Schema: public; Owner: collage; Tablespace: 
--

CREATE INDEX logmessage_fk_logmessage_hoststatusid ON logmessage USING btree (hoststatusid);


--
-- Name: logmessage_fk_logmessage_servicestatusid; Type: INDEX; Schema: public; Owner: collage; Tablespace: 
--

CREATE INDEX logmessage_fk_logmessage_servicestatusid ON logmessage USING btree (servicestatusid);


--
-- Name: logmessage_idx_logmessage_consolidationhash; Type: INDEX; Schema: public; Owner: collage; Tablespace: 
--

CREATE INDEX logmessage_idx_logmessage_consolidationhash ON logmessage USING btree (consolidationhash);


--
-- Name: logmessage_idx_logmessage_firstinsertdate; Type: INDEX; Schema: public; Owner: collage; Tablespace: 
--

CREATE INDEX logmessage_idx_logmessage_firstinsertdate ON logmessage USING btree (firstinsertdate);


--
-- Name: logmessage_idx_logmessage_lastinsertdate; Type: INDEX; Schema: public; Owner: collage; Tablespace: 
--

CREATE INDEX logmessage_idx_logmessage_lastinsertdate ON logmessage USING btree (lastinsertdate);


--
-- Name: logmessage_idx_logmessage_reportdate; Type: INDEX; Schema: public; Owner: collage; Tablespace: 
--

CREATE INDEX logmessage_idx_logmessage_reportdate ON logmessage USING btree (reportdate);


--
-- Name: logmessage_idx_logmessage_statelesshash; Type: INDEX; Schema: public; Owner: collage; Tablespace: 
--

CREATE INDEX logmessage_idx_logmessage_statelesshash ON logmessage USING btree (statelesshash);


--
-- Name: logmessage_idx_logmessage_statetransitionhash; Type: INDEX; Schema: public; Owner: collage; Tablespace: 
--

CREATE INDEX logmessage_idx_logmessage_statetransitionhash ON logmessage USING btree (statetransitionhash);


--
-- Name: logmessage_monitorstatusid; Type: INDEX; Schema: public; Owner: collage; Tablespace: 
--

CREATE INDEX logmessage_monitorstatusid ON logmessage USING btree (monitorstatusid);


--
-- Name: logmessage_operationstatusid; Type: INDEX; Schema: public; Owner: collage; Tablespace: 
--

CREATE INDEX logmessage_operationstatusid ON logmessage USING btree (operationstatusid);


--
-- Name: logmessage_priorityid; Type: INDEX; Schema: public; Owner: collage; Tablespace: 
--

CREATE INDEX logmessage_priorityid ON logmessage USING btree (priorityid);


--
-- Name: logmessage_severityid; Type: INDEX; Schema: public; Owner: collage; Tablespace: 
--

CREATE INDEX logmessage_severityid ON logmessage USING btree (severityid);


--
-- Name: logmessage_typeruleid; Type: INDEX; Schema: public; Owner: collage; Tablespace: 
--

CREATE INDEX logmessage_typeruleid ON logmessage USING btree (typeruleid);


--
-- Name: logmessageproperty_propertytypeid; Type: INDEX; Schema: public; Owner: collage; Tablespace: 
--

CREATE INDEX logmessageproperty_propertytypeid ON logmessageproperty USING btree (propertytypeid);


--
-- Name: logperformancedata_performancedatalabelid; Type: INDEX; Schema: public; Owner: collage; Tablespace: 
--

CREATE INDEX logperformancedata_performancedatalabelid ON logperformancedata USING btree (performancedatalabelid);


--
-- Name: logperformancedata_servicestatusid; Type: INDEX; Schema: public; Owner: collage; Tablespace: 
--

CREATE INDEX logperformancedata_servicestatusid ON logperformancedata USING btree (servicestatusid);


--
-- Name: monitorlist_deviceid; Type: INDEX; Schema: public; Owner: collage; Tablespace: 
--

CREATE INDEX monitorlist_deviceid ON monitorlist USING btree (deviceid);


--
-- Name: servicestatus_applicationtypeid; Type: INDEX; Schema: public; Owner: collage; Tablespace: 
--

CREATE INDEX servicestatus_applicationtypeid ON servicestatus USING btree (applicationtypeid);


--
-- Name: servicestatus_checktypeid; Type: INDEX; Schema: public; Owner: collage; Tablespace: 
--

CREATE INDEX servicestatus_checktypeid ON servicestatus USING btree (checktypeid);


--
-- Name: servicestatus_lasthardstateid; Type: INDEX; Schema: public; Owner: collage; Tablespace: 
--

CREATE INDEX servicestatus_lasthardstateid ON servicestatus USING btree (lasthardstateid);


--
-- Name: servicestatus_monitorstatusid; Type: INDEX; Schema: public; Owner: collage; Tablespace: 
--

CREATE INDEX servicestatus_monitorstatusid ON servicestatus USING btree (monitorstatusid);


--
-- Name: servicestatus_statetypeid; Type: INDEX; Schema: public; Owner: collage; Tablespace: 
--

CREATE INDEX servicestatus_statetypeid ON servicestatus USING btree (statetypeid);


--
-- Name: servicestatusproperty_propertytypeid; Type: INDEX; Schema: public; Owner: collage; Tablespace: 
--

CREATE INDEX servicestatusproperty_propertytypeid ON servicestatusproperty USING btree (propertytypeid);


--
-- Name: action_ibfk_1; Type: FK CONSTRAINT; Schema: public; Owner: collage
--

ALTER TABLE ONLY action
    ADD CONSTRAINT action_ibfk_1 FOREIGN KEY (actiontypeid) REFERENCES actiontype(actiontypeid) ON UPDATE RESTRICT ON DELETE CASCADE;


--
-- Name: actionparameter_ibfk_1; Type: FK CONSTRAINT; Schema: public; Owner: collage
--

ALTER TABLE ONLY actionparameter
    ADD CONSTRAINT actionparameter_ibfk_1 FOREIGN KEY (actionid) REFERENCES action(actionid) ON UPDATE RESTRICT ON DELETE CASCADE;


--
-- Name: actionproperty_ibfk_1; Type: FK CONSTRAINT; Schema: public; Owner: collage
--

ALTER TABLE ONLY actionproperty
    ADD CONSTRAINT actionproperty_ibfk_1 FOREIGN KEY (actionid) REFERENCES action(actionid) ON UPDATE RESTRICT ON DELETE CASCADE;


--
-- Name: applicationaction_ibfk_1; Type: FK CONSTRAINT; Schema: public; Owner: collage
--

ALTER TABLE ONLY applicationaction
    ADD CONSTRAINT applicationaction_ibfk_1 FOREIGN KEY (applicationtypeid) REFERENCES applicationtype(applicationtypeid) ON UPDATE RESTRICT ON DELETE CASCADE;


--
-- Name: applicationaction_ibfk_2; Type: FK CONSTRAINT; Schema: public; Owner: collage
--

ALTER TABLE ONLY applicationaction
    ADD CONSTRAINT applicationaction_ibfk_2 FOREIGN KEY (actionid) REFERENCES action(actionid) ON UPDATE RESTRICT ON DELETE CASCADE;


--
-- Name: applicationentityproperty_ibfk_1; Type: FK CONSTRAINT; Schema: public; Owner: collage
--

ALTER TABLE ONLY applicationentityproperty
    ADD CONSTRAINT applicationentityproperty_ibfk_1 FOREIGN KEY (applicationtypeid) REFERENCES applicationtype(applicationtypeid) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: applicationentityproperty_ibfk_2; Type: FK CONSTRAINT; Schema: public; Owner: collage
--

ALTER TABLE ONLY applicationentityproperty
    ADD CONSTRAINT applicationentityproperty_ibfk_2 FOREIGN KEY (entitytypeid) REFERENCES entitytype(entitytypeid) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: applicationentityproperty_ibfk_3; Type: FK CONSTRAINT; Schema: public; Owner: collage
--

ALTER TABLE ONLY applicationentityproperty
    ADD CONSTRAINT applicationentityproperty_ibfk_3 FOREIGN KEY (propertytypeid) REFERENCES propertytype(propertytypeid) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: applicationtypeid_ibfk1_1; Type: FK CONSTRAINT; Schema: public; Owner: collage
--

ALTER TABLE ONLY entity
    ADD CONSTRAINT applicationtypeid_ibfk1_1 FOREIGN KEY (applicationtypeid) REFERENCES applicationtype(applicationtypeid) ON UPDATE RESTRICT ON DELETE CASCADE;


--
-- Name: categoryentity_ibfk_1; Type: FK CONSTRAINT; Schema: public; Owner: collage
--

ALTER TABLE ONLY categoryentity
    ADD CONSTRAINT categoryentity_ibfk_1 FOREIGN KEY (categoryid) REFERENCES category(categoryid) ON UPDATE RESTRICT ON DELETE CASCADE;


--
-- Name: categoryentity_ibfk_2; Type: FK CONSTRAINT; Schema: public; Owner: collage
--

ALTER TABLE ONLY categoryentity
    ADD CONSTRAINT categoryentity_ibfk_2 FOREIGN KEY (entitytypeid) REFERENCES entitytype(entitytypeid) ON UPDATE RESTRICT ON DELETE CASCADE;


--
-- Name: categoryhierarchy_ibfk_1; Type: FK CONSTRAINT; Schema: public; Owner: collage
--

ALTER TABLE ONLY categoryhierarchy
    ADD CONSTRAINT categoryhierarchy_ibfk_1 FOREIGN KEY (parentid) REFERENCES category(categoryid) ON UPDATE RESTRICT ON DELETE CASCADE;


--
-- Name: categoryhierarchy_ibfk_2; Type: FK CONSTRAINT; Schema: public; Owner: collage
--

ALTER TABLE ONLY categoryhierarchy
    ADD CONSTRAINT categoryhierarchy_ibfk_2 FOREIGN KEY (categoryid) REFERENCES category(categoryid) ON UPDATE RESTRICT ON DELETE CASCADE;


--
-- Name: deviceparent_ibfk_1; Type: FK CONSTRAINT; Schema: public; Owner: collage
--

ALTER TABLE ONLY deviceparent
    ADD CONSTRAINT deviceparent_ibfk_1 FOREIGN KEY (deviceid) REFERENCES device(deviceid) ON UPDATE RESTRICT ON DELETE CASCADE;


--
-- Name: deviceparent_ibfk_2; Type: FK CONSTRAINT; Schema: public; Owner: collage
--

ALTER TABLE ONLY deviceparent
    ADD CONSTRAINT deviceparent_ibfk_2 FOREIGN KEY (parentid) REFERENCES device(deviceid) ON UPDATE RESTRICT ON DELETE CASCADE;


--
-- Name: entityproperty_ibfk_1; Type: FK CONSTRAINT; Schema: public; Owner: collage
--

ALTER TABLE ONLY entityproperty
    ADD CONSTRAINT entityproperty_ibfk_1 FOREIGN KEY (entitytypeid) REFERENCES entitytype(entitytypeid) ON UPDATE RESTRICT ON DELETE CASCADE;


--
-- Name: entityproperty_ibfk_2; Type: FK CONSTRAINT; Schema: public; Owner: collage
--

ALTER TABLE ONLY entityproperty
    ADD CONSTRAINT entityproperty_ibfk_2 FOREIGN KEY (propertytypeid) REFERENCES propertytype(propertytypeid) ON UPDATE RESTRICT ON DELETE CASCADE;


--
-- Name: entitytypeid_ibfk1_1; Type: FK CONSTRAINT; Schema: public; Owner: collage
--

ALTER TABLE ONLY category
    ADD CONSTRAINT entitytypeid_ibfk1_1 FOREIGN KEY (entitytypeid) REFERENCES entitytype(entitytypeid) ON UPDATE RESTRICT ON DELETE CASCADE;


--
-- Name: fk_logmessage_hoststatusid; Type: FK CONSTRAINT; Schema: public; Owner: collage
--

ALTER TABLE ONLY logmessage
    ADD CONSTRAINT fk_logmessage_hoststatusid FOREIGN KEY (hoststatusid) REFERENCES hoststatus(hoststatusid) ON UPDATE RESTRICT ON DELETE SET NULL;


--
-- Name: fk_logmessage_servicestatusid; Type: FK CONSTRAINT; Schema: public; Owner: collage
--

ALTER TABLE ONLY logmessage
    ADD CONSTRAINT fk_logmessage_servicestatusid FOREIGN KEY (servicestatusid) REFERENCES servicestatus(servicestatusid) ON UPDATE RESTRICT ON DELETE SET NULL;


--
-- Name: host_ibfk_1; Type: FK CONSTRAINT; Schema: public; Owner: collage
--

ALTER TABLE ONLY host
    ADD CONSTRAINT host_ibfk_1 FOREIGN KEY (deviceid) REFERENCES device(deviceid) ON UPDATE RESTRICT ON DELETE CASCADE;


--
-- Name: host_ibfk_2; Type: FK CONSTRAINT; Schema: public; Owner: collage
--

ALTER TABLE ONLY host
    ADD CONSTRAINT host_ibfk_2 FOREIGN KEY (applicationtypeid) REFERENCES applicationtype(applicationtypeid) ON UPDATE RESTRICT ON DELETE CASCADE;


--
-- Name: hostgroup_ibfk_1; Type: FK CONSTRAINT; Schema: public; Owner: collage
--

ALTER TABLE ONLY hostgroup
    ADD CONSTRAINT hostgroup_ibfk_1 FOREIGN KEY (applicationtypeid) REFERENCES applicationtype(applicationtypeid) ON UPDATE RESTRICT ON DELETE CASCADE;


--
-- Name: hostgroupcollection_ibfk_1; Type: FK CONSTRAINT; Schema: public; Owner: collage
--

ALTER TABLE ONLY hostgroupcollection
    ADD CONSTRAINT hostgroupcollection_ibfk_1 FOREIGN KEY (hostid) REFERENCES host(hostid) ON UPDATE RESTRICT ON DELETE CASCADE;


--
-- Name: hostgroupcollection_ibfk_2; Type: FK CONSTRAINT; Schema: public; Owner: collage
--

ALTER TABLE ONLY hostgroupcollection
    ADD CONSTRAINT hostgroupcollection_ibfk_2 FOREIGN KEY (hostgroupid) REFERENCES hostgroup(hostgroupid) ON UPDATE RESTRICT ON DELETE CASCADE;


--
-- Name: hoststatus_ibfk_1; Type: FK CONSTRAINT; Schema: public; Owner: collage
--

ALTER TABLE ONLY hoststatus
    ADD CONSTRAINT hoststatus_ibfk_1 FOREIGN KEY (hoststatusid) REFERENCES host(hostid) ON UPDATE RESTRICT ON DELETE CASCADE;


--
-- Name: hoststatus_ibfk_2; Type: FK CONSTRAINT; Schema: public; Owner: collage
--

ALTER TABLE ONLY hoststatus
    ADD CONSTRAINT hoststatus_ibfk_2 FOREIGN KEY (monitorstatusid) REFERENCES monitorstatus(monitorstatusid) ON UPDATE RESTRICT ON DELETE CASCADE;


--
-- Name: hoststatus_ibfk_3; Type: FK CONSTRAINT; Schema: public; Owner: collage
--

ALTER TABLE ONLY hoststatus
    ADD CONSTRAINT hoststatus_ibfk_3 FOREIGN KEY (checktypeid) REFERENCES checktype(checktypeid) ON UPDATE RESTRICT ON DELETE CASCADE;


--
-- Name: hoststatus_ibfk_4; Type: FK CONSTRAINT; Schema: public; Owner: collage
--

ALTER TABLE ONLY hoststatus
    ADD CONSTRAINT hoststatus_ibfk_4 FOREIGN KEY (statetypeid) REFERENCES statetype(statetypeid) ON UPDATE RESTRICT ON DELETE CASCADE;


--
-- Name: hoststatusproperty_ibfk_1; Type: FK CONSTRAINT; Schema: public; Owner: collage
--

ALTER TABLE ONLY hoststatusproperty
    ADD CONSTRAINT hoststatusproperty_ibfk_1 FOREIGN KEY (hoststatusid) REFERENCES hoststatus(hoststatusid) ON UPDATE RESTRICT ON DELETE CASCADE;


--
-- Name: hoststatusproperty_ibfk_2; Type: FK CONSTRAINT; Schema: public; Owner: collage
--

ALTER TABLE ONLY hoststatusproperty
    ADD CONSTRAINT hoststatusproperty_ibfk_2 FOREIGN KEY (propertytypeid) REFERENCES propertytype(propertytypeid) ON UPDATE RESTRICT ON DELETE CASCADE;


--
-- Name: logmessage_ibfk_1; Type: FK CONSTRAINT; Schema: public; Owner: collage
--

ALTER TABLE ONLY logmessage
    ADD CONSTRAINT logmessage_ibfk_1 FOREIGN KEY (applicationtypeid) REFERENCES applicationtype(applicationtypeid) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: logmessage_ibfk_2; Type: FK CONSTRAINT; Schema: public; Owner: collage
--

ALTER TABLE ONLY logmessage
    ADD CONSTRAINT logmessage_ibfk_2 FOREIGN KEY (deviceid) REFERENCES device(deviceid) ON UPDATE RESTRICT ON DELETE CASCADE;


--
-- Name: logmessage_ibfk_3; Type: FK CONSTRAINT; Schema: public; Owner: collage
--

ALTER TABLE ONLY logmessage
    ADD CONSTRAINT logmessage_ibfk_3 FOREIGN KEY (monitorstatusid) REFERENCES monitorstatus(monitorstatusid) ON UPDATE RESTRICT ON DELETE CASCADE;


--
-- Name: logmessage_ibfk_4; Type: FK CONSTRAINT; Schema: public; Owner: collage
--

ALTER TABLE ONLY logmessage
    ADD CONSTRAINT logmessage_ibfk_4 FOREIGN KEY (severityid) REFERENCES severity(severityid) ON UPDATE RESTRICT ON DELETE CASCADE;


--
-- Name: logmessage_ibfk_5; Type: FK CONSTRAINT; Schema: public; Owner: collage
--

ALTER TABLE ONLY logmessage
    ADD CONSTRAINT logmessage_ibfk_5 FOREIGN KEY (applicationseverityid) REFERENCES severity(severityid) ON UPDATE RESTRICT ON DELETE CASCADE;


--
-- Name: logmessage_ibfk_6; Type: FK CONSTRAINT; Schema: public; Owner: collage
--

ALTER TABLE ONLY logmessage
    ADD CONSTRAINT logmessage_ibfk_6 FOREIGN KEY (priorityid) REFERENCES priority(priorityid) ON UPDATE RESTRICT ON DELETE CASCADE;


--
-- Name: logmessage_ibfk_7; Type: FK CONSTRAINT; Schema: public; Owner: collage
--

ALTER TABLE ONLY logmessage
    ADD CONSTRAINT logmessage_ibfk_7 FOREIGN KEY (typeruleid) REFERENCES typerule(typeruleid) ON UPDATE RESTRICT ON DELETE CASCADE;


--
-- Name: logmessage_ibfk_8; Type: FK CONSTRAINT; Schema: public; Owner: collage
--

ALTER TABLE ONLY logmessage
    ADD CONSTRAINT logmessage_ibfk_8 FOREIGN KEY (componentid) REFERENCES component(componentid) ON UPDATE RESTRICT ON DELETE CASCADE;


--
-- Name: logmessage_ibfk_9; Type: FK CONSTRAINT; Schema: public; Owner: collage
--

ALTER TABLE ONLY logmessage
    ADD CONSTRAINT logmessage_ibfk_9 FOREIGN KEY (operationstatusid) REFERENCES operationstatus(operationstatusid) ON UPDATE RESTRICT ON DELETE CASCADE;


--
-- Name: logmessageproperty_ibfk_1; Type: FK CONSTRAINT; Schema: public; Owner: collage
--

ALTER TABLE ONLY logmessageproperty
    ADD CONSTRAINT logmessageproperty_ibfk_1 FOREIGN KEY (logmessageid) REFERENCES logmessage(logmessageid) ON UPDATE RESTRICT ON DELETE CASCADE;


--
-- Name: logmessageproperty_ibfk_2; Type: FK CONSTRAINT; Schema: public; Owner: collage
--

ALTER TABLE ONLY logmessageproperty
    ADD CONSTRAINT logmessageproperty_ibfk_2 FOREIGN KEY (propertytypeid) REFERENCES propertytype(propertytypeid) ON UPDATE RESTRICT ON DELETE CASCADE;


--
-- Name: logperformancedata_ibfk_1; Type: FK CONSTRAINT; Schema: public; Owner: collage
--

ALTER TABLE ONLY logperformancedata
    ADD CONSTRAINT logperformancedata_ibfk_1 FOREIGN KEY (servicestatusid) REFERENCES servicestatus(servicestatusid) ON UPDATE RESTRICT ON DELETE CASCADE;


--
-- Name: logperformancedata_ibfk_2; Type: FK CONSTRAINT; Schema: public; Owner: collage
--

ALTER TABLE ONLY logperformancedata
    ADD CONSTRAINT logperformancedata_ibfk_2 FOREIGN KEY (performancedatalabelid) REFERENCES performancedatalabel(performancedatalabelid) ON UPDATE RESTRICT ON DELETE CASCADE;


--
-- Name: monitorlist_ibfk_1; Type: FK CONSTRAINT; Schema: public; Owner: collage
--

ALTER TABLE ONLY monitorlist
    ADD CONSTRAINT monitorlist_ibfk_1 FOREIGN KEY (monitorserverid) REFERENCES monitorserver(monitorserverid) ON UPDATE RESTRICT ON DELETE CASCADE;


--
-- Name: monitorlist_ibfk_2; Type: FK CONSTRAINT; Schema: public; Owner: collage
--

ALTER TABLE ONLY monitorlist
    ADD CONSTRAINT monitorlist_ibfk_2 FOREIGN KEY (deviceid) REFERENCES device(deviceid) ON UPDATE RESTRICT ON DELETE CASCADE;


--
-- Name: plugin_ibfk_1; Type: FK CONSTRAINT; Schema: public; Owner: collage
--

ALTER TABLE ONLY plugin
    ADD CONSTRAINT plugin_ibfk_1 FOREIGN KEY (platformid) REFERENCES pluginplatform(platformid) ON UPDATE RESTRICT ON DELETE CASCADE;


--
-- Name: servicestatus_ibfk_1; Type: FK CONSTRAINT; Schema: public; Owner: collage
--

ALTER TABLE ONLY servicestatus
    ADD CONSTRAINT servicestatus_ibfk_1 FOREIGN KEY (applicationtypeid) REFERENCES applicationtype(applicationtypeid) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: servicestatus_ibfk_2; Type: FK CONSTRAINT; Schema: public; Owner: collage
--

ALTER TABLE ONLY servicestatus
    ADD CONSTRAINT servicestatus_ibfk_2 FOREIGN KEY (hostid) REFERENCES host(hostid) ON UPDATE RESTRICT ON DELETE CASCADE;


--
-- Name: servicestatus_ibfk_3; Type: FK CONSTRAINT; Schema: public; Owner: collage
--

ALTER TABLE ONLY servicestatus
    ADD CONSTRAINT servicestatus_ibfk_3 FOREIGN KEY (statetypeid) REFERENCES statetype(statetypeid) ON UPDATE RESTRICT ON DELETE CASCADE;


--
-- Name: servicestatus_ibfk_4; Type: FK CONSTRAINT; Schema: public; Owner: collage
--

ALTER TABLE ONLY servicestatus
    ADD CONSTRAINT servicestatus_ibfk_4 FOREIGN KEY (checktypeid) REFERENCES checktype(checktypeid) ON UPDATE RESTRICT ON DELETE CASCADE;


--
-- Name: servicestatus_ibfk_5; Type: FK CONSTRAINT; Schema: public; Owner: collage
--

ALTER TABLE ONLY servicestatus
    ADD CONSTRAINT servicestatus_ibfk_5 FOREIGN KEY (lasthardstateid) REFERENCES monitorstatus(monitorstatusid) ON UPDATE RESTRICT ON DELETE CASCADE;


--
-- Name: servicestatus_ibfk_6; Type: FK CONSTRAINT; Schema: public; Owner: collage
--

ALTER TABLE ONLY servicestatus
    ADD CONSTRAINT servicestatus_ibfk_6 FOREIGN KEY (monitorstatusid) REFERENCES monitorstatus(monitorstatusid) ON UPDATE RESTRICT ON DELETE CASCADE;


--
-- Name: servicestatusproperty_ibfk_1; Type: FK CONSTRAINT; Schema: public; Owner: collage
--

ALTER TABLE ONLY servicestatusproperty
    ADD CONSTRAINT servicestatusproperty_ibfk_1 FOREIGN KEY (servicestatusid) REFERENCES servicestatus(servicestatusid) ON UPDATE RESTRICT ON DELETE CASCADE;


--
-- Name: servicestatusproperty_ibfk_2; Type: FK CONSTRAINT; Schema: public; Owner: collage
--

ALTER TABLE ONLY servicestatusproperty
    ADD CONSTRAINT servicestatusproperty_ibfk_2 FOREIGN KEY (propertytypeid) REFERENCES propertytype(propertytypeid) ON UPDATE RESTRICT ON DELETE CASCADE;


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO collage;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- Name: network_service_notifications; Type: ACL; Schema: public; Owner: collage
--

REVOKE ALL ON TABLE network_service_notifications FROM PUBLIC;
REVOKE ALL ON TABLE network_service_notifications FROM collage;
GRANT ALL ON TABLE network_service_notifications TO collage;


--
-- Name: network_service_short_news; Type: ACL; Schema: public; Owner: collage
--

REVOKE ALL ON TABLE network_service_short_news FROM PUBLIC;
REVOKE ALL ON TABLE network_service_short_news FROM collage;
GRANT ALL ON TABLE network_service_short_news TO collage;


--
-- Name: network_service_status; Type: ACL; Schema: public; Owner: collage
--

REVOKE ALL ON TABLE network_service_status FROM PUBLIC;
REVOKE ALL ON TABLE network_service_status FROM collage;
GRANT ALL ON TABLE network_service_status TO collage;


--
-- PostgreSQL database dump complete
--

