#!/bin/sh

prefix=/usr/local/noma
exec_prefix=${prefix}
datarootdir=${prefix}/share

/bin/sed \
    -e "s#\@prefix\@#/usr/local/noma#g" \
    -e "s#\@bindir\@#${exec_prefix}/bin#g" \
    -e "s#\@localstatedir\@#${prefix}/var#g" \
    -e "s#\@datadir\@#${datarootdir}#g" \
    -e "s#\@sysconfdir\@#${prefix}/etc#g" \
    -e "s#\@localstatedir\@#${prefix}/var#g" \
    -e "s#\@NOTIFIERDIR\@#/usr/local/noma/notifier#g" \
    -e "s#\@PERL\@#/usr/bin/perl#g" \
    -e "s#\@SENDMAIL\@#/usr/sbin/sendmail#g" \
    -e "s#\@NAGIOSLIBEXEC\@#/usr/local/icinga/libexec#g" \
    -e "s#\@NAGIOSPIPE\@#/usr/local/icinga/var/rw/icinga.cmd#g" \
    -e "s#\@RUNAS\@#icinga#g" \
    -e "s#\@RUNASGRP\@#icinga#g" \
    -e "s#\@WWWRUNASGRP\@#www-data#g" \
    -e "s#\@VERSION\@#2.0.3#g" \
    $1
chmod a+x $1
