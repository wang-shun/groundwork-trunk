#!/usr/bin/perl -w
#
# Copyright (c) 2010 GroundWork Open Source, Inc.  All rights reserved.
#

# TODO:
# 2.  update plugin to use --server and --host.  --server is optional but allows
#     a user to point the plugin at a VMware management host with it's credentials
#     rather than at a specific VMware host.  I suppose that if --server is
#     supplied then --host COULD be optional and the plugin could report metrics for
#     ALL VMware hosts that are visible to the management host.  This would give
#     a datacenter wide view.
# 4.  add standard usage instructions including reference to the use of credentials.
#     we might consider support of --user and --password but my guess is that
#     customers will want to use the credential store for user nagios.  We need
#     to research how users are set up on individual VMware hosts and management
#     servers such that Administrator or root user credentials are not required for
#     use of these plugins.
# 5.  when relocating this plugin to /usr/local/groundwork/nagios/libexec the
#     AppUtil::* modules will have to be included under that directory (this is
#     analagous to what we did with the check_oracle_by_jdbc plugin)
# 6.  when relocating this plugin we may want to ditch using VMWare Opts::*
#     modules.  Not sure.
# 7.  clean up the mathematical transformations in the get_cpu_info function.
# 8.  if we update thresholds or plugin output we must update any perfconfig
#     definitions.

use strict;
use warnings;

use FindBin;			# see note #5 above
use lib "$FindBin::Bin/../";

use AppUtil::VMUtil;
use VMware::VIRuntime;		# this is from the SDK after it is installed
use AppUtil::HostUtil;		# see note #5 above
use Getopt::Long;

use lib qw( /usr/local/groundwork/nagios/libexec );
require 'utils.pm';
use utils qw($TIMEOUT %ERRORS &print_revision &support &usage);


sub get_cpu_info;
sub print_help;
sub print_usage;
sub configure_thresholds;
sub calculation;

my $state = "OK";
my $worst;
my $prog_name;
my $lo_warn = undef;
my $hi_warn = undef;
my $lo_crit = undef;
my $hi_crit = undef;
my @vals = undef;


if ( $0 =~ /^(.*)\/(.*)$/ ) {
	$prog_name = $2;
}

#########################################
# obtain the remaining options related to GroundWork Thresholds
my %opts = (
   'warning' => {
      type => "=s",
      help => "Warning threshold",
      required => 0,
   },
   'critical' => {
      type => "=s",
      help => "Critical threshold",
      required => 0,
   },
   'gw_help' => {
      type => "",
      help => "GroundWork Usage",
      required => 0,
   },
);

Opts::add_options(%opts);
Opts::parse();			# see note #6 above
if (Opts::option_is_set('gw_help')) { print_help(); }
Opts::validate();		# see note #6 above

#########################################
# this is GroundWork plugin specific help

my $opt_w = Opts::get_option('warning');
my $opt_c = Opts::get_option('critical');
configure_thresholds ();

my $statusText = "";
my $perfData = "";

Util::connect();
my $plugin_status = get_cpu_info();

print $statusText;
print "| $perfData";

Util::disconnect();

exit $plugin_status;

sub get_cpu_info {
   my %filterHashHost;
   my $host_views = HostUtils::get_hosts('HostSystem', 
                                             , , %filterHashHost);
   my $hz = 0;
   my $numCpuCores = 0;
   my $overallCpuUsage = 0;
   my $totalCpu = 0;
   my $percentCpu = 0;
   my $exit_value;

   if ($host_views) {
      foreach (@$host_views) {
         my $host_view = $_;
         if (defined ($host_view->summary->hardware)){
	    $hz = $host_view->hardware->cpuInfo->hz;
            $numCpuCores = $host_view->hardware->cpuInfo->numCpuCores;
         }
         if (defined ($host_view->summary->quickStats->overallCpuUsage)) {
           $overallCpuUsage = $host_view->summary->quickStats->overallCpuUsage;
         }
      }
   }

   $totalCpu = $hz * $numCpuCores;
   $overallCpuUsage *= 1024 * 1024;

   if (!$totalCpu) {
      $exit_value = $ERRORS{'UNKNOWN'};
      $state = "UNKNOWN";
   } else {
     $percentCpu = int((100 * $overallCpuUsage / $totalCpu)+0.5);
     $totalCpu /= 1024 * 1024;
     $totalCpu = int($totalCpu+0.5);
     $overallCpuUsage /= 1024 * 1024;
     $overallCpuUsage = int($overallCpuUsage+0.5);
     if (($opt_w) || ($opt_c)) {
        $exit_value = calculation ($percentCpu);
     } else { 
        $state = "OK"; $exit_value = $ERRORS{'OK'}; 
     }
   }

   $statusText = $state . ": " . $overallCpuUsage . "/" . $totalCpu . " MHz (" . $percentCpu . "%) used.";
   my $warnMHz = undef;
   my $critMHz = undef;
   if (( $hi_warn || $hi_crit) && !( $lo_warn || $lo_crit)) {
     if ( $hi_warn) { $warnMHz = int (($hi_warn * $totalCpu / 100)+0.5); }
     if ( $hi_crit) { $critMHz = int (($hi_crit * $totalCpu / 100)+0.5); }
   }
   $perfData = "overallCpuUsage=$overallCpuUsage"."MHz;$warnMHz;$critMHz;0;$totalCpu totalCpu=$totalCpu"."MHz;;;0;";
   return ($exit_value);
}

sub print_usage () {
    print "Usage: $prog_name --server <esx server> [--credstore <credentials file>] --username <auth user> -w <warn> -c <critical>\n";
    print "Usage: $prog_name [ -v ]\n";
    print "Usage: $prog_name [ -h ]\n";
    print "Usage: $prog_name [ --help ]\n";
}

sub print_help () {
    print "\n";
    print $prog_name;
    print "\n";
    print "Use VMware API to obtain stats\n";
    print "\n";
    print_usage();
    print "\n";

    print '
        Usage:
        check_vsphere_<cpu,datastore,net,mem>.pl
                --warning <warning level>
                --critical <critical level>
                -gw_help (plugin help)

                --server <esx server | guest host>
		--username <authorized user in credential store>
		--help  (VMware API help)
                --version (VMware API version)

        Description:
        This script will access the VMware API to query the statistics on an ESX3 or 4 Server
        using the credentials stored securely for the specified username.
        The credentials must be administered for each serever/user/password combination.
        The returned values are compared to the thresholds which follow plugin standards.
        Performance data is provided.
        ';
    print "\n";
    exit 0;
}

sub configure_thresholds () {
# Options checking
# Warning
    if ($opt_w) {
            if ($opt_w =~ /:/){
                    @vals = split /:/, $opt_w;
                    ($vals[0]) || usage("Invalid value: low warning: $opt_w\n");
                    ($vals[1]) || usage("Invalid value: high warning: $opt_w\n");
                    $lo_warn = $vals[0] if ($vals[0] =~ /^[0-9]+$/);
                    $hi_warn = $vals[1] if ($vals[1] =~ /^[0-9]+$/);
                    ($lo_warn) || usage("Invalid value: low warning: $opt_w\n");
                    ($hi_warn) || usage("Invalid value: high warning: $opt_w\n");
            } else {
                    $lo_warn = undef;
                    $hi_warn = $opt_w if ($opt_w =~ /^[0-9]+$/);
            ($hi_warn) || usage("Invalid value: warning: $opt_w\n");
            }
    } else { $hi_warn = undef; $lo_warn = undef; } 

# Critical
    if ($opt_c) {
        if ($opt_c =~ /:/){
            @vals = split /:/, $opt_c;
            ($vals[0]) || usage("Invalid value: low critical: $opt_c\n");
            ($vals[1]) || usage("Invalid value: high critical: $opt_c\n");
            $lo_crit = $vals[0] if (($vals[0] =~ /^[0-9]+$/) && ($vals[0] < $lo_warn));
            $hi_crit = $vals[1] if (($vals[1] =~ /^[0-9]+$/) && ($vals[1] > $hi_warn));
            ($lo_crit) || usage("Invalid value: low critical: $opt_c\n");
            ($hi_crit) || usage("Invalid value: high critical: $opt_c\n");
        } else {
            $lo_crit = undef;
            $hi_crit = $opt_c if (($opt_c =~ /^[0-9]+$/)&& ($opt_c > $hi_warn));
            ($hi_crit) || usage("Invalid value: critical: $opt_c\n");
        }
    } else { $hi_crit = undef; $lo_crit = undef; } 
}

sub calculation () {
    my $value = $_[0];
    $worst =0;
    if ($lo_crit && $value < $lo_crit) {
            $worst = $ERRORS{'CRITICAL'};
            $state = "CRITICAL";
    }
    if ($hi_crit && $value > $hi_crit) {
        $worst = $ERRORS{'CRITICAL'};
        $state = "CRITICAL";
    }
    if ($lo_warn && $value < $lo_warn) {
        $worst = $ERRORS{'WARNING'} if $worst < $ERRORS{'CRITICAL'};
        $state = "WARNING" if $worst < $ERRORS{'CRITICAL'};
    }
    if ($hi_warn && $value > $hi_warn) {
        $worst = $ERRORS{'WARNING'} if $worst < $ERRORS{'CRITICAL'};
        $state = "WARNING" if $worst < $ERRORS{'CRITICAL'};
    }
    return ($worst);
}
