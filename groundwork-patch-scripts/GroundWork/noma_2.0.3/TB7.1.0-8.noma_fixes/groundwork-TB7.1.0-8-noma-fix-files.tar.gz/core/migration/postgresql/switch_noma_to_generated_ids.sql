--
-- switch_noma_to_generated_ids.sql
--

-- This is an SQL Script to convert the external-ID values in a "noma" database to reflect as much
-- as possible the values they would have had if the new notifier:generate_IDs config parameter had
-- been in effect since the beginning of time.  The conversion might not be perfect, but it's the
-- best we can do.

-- HOW TO RUN THIS SCRIPT
-- ----------------------
--
-- This script alters the "noma" database to convert existing alert unique-ID values to alternate
-- values that will either be consistent with new internally-generated unique-ID values when the
-- notifier:generate_IDs option is enabled, or moved aside to a safe range that is not likely to
-- conflict with future internally-generated values.  It is to be run from a terminal window while
-- logged in as the nagios user, with the following commands (assuming that a copy of this script has
-- been placed into the /tmp directory):
--
-- service groundwork stop noma
-- /usr/local/groundwork/postgresql/bin/psql -U noma -d noma -f /tmp/switch_noma_to_generated_ids.sql
--
-- Once the database is converted, the notifier:generate_IDs option must be set to a true value
-- (such as 1) in the noma/etc/NoMa.yaml configuration file, and then NoMa can be started up:
--
-- service groundwork start noma

-- ================================================================================================

-- Copyright (c) 2017 GroundWork Open Source, Inc.
-- www.groundworkopensource.com
--
-- This program is free software; you can redistribute it and/or modify
-- it under the terms of version 2 of the GNU General Public License
-- as published by the Free Software Foundation.
--
-- This program is distributed in the hope that it will be useful,
-- but WITHOUT ANY WARRANTY; without even the implied warranty of
-- MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
-- GNU General Public License for more details.
--
-- You should have received a copy of the GNU General Public License
-- along with this program; if not, write to the Free Software
-- Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

-- ================================================================================================

--
-- Be sure to keep this up-to-date!
--
\set version '1.0 of 2017-08-06'
\echo ''
\echo switch_noma_to_generated_ids.sql version :version
\echo ''

-- Make sure any error from this script gets reflected in the psql exit status.
\set ON_ERROR_STOP on

-- Suppress noise from "IF NOT EXISTS" clauses when the object does not exist.
\set QUIET on
SET client_min_messages=WARNING;
\set QUIET off

\set QUIET on
-- If this script was run before but errored out, we might still have this function lying around.
-- Drop it so we can ensure that we use the definition provided here.
DROP FUNCTION IF EXISTS convert_noma_external_id_values();
\set QUIET off

\set QUIET on
CREATE FUNCTION convert_noma_external_id_values() RETURNS VOID AS $$
BEGIN

    -- What we want to end up with is the notification_stati.id field generally serving as the unique ID
    -- for a given host or service, and the tmp_commands.external_id field matching up with that value.
    -- There are also a couple of other fields in other tables that need to be updated as well.
    --
    -- Ideally, it would suffice to simply shut down NoMa, change all the existing incident ID values
    -- in the database to instead be the corresponding notification_stati.id values, and start up NoMa
    -- again.  (That would be the ideal situation, but in practice we find that some rows in other
    -- tables might not correspond to any rows in the notification_stati table.  So any such ID values
    -- will need to be left as-is.)  No further adjustment would be needed to the notification_stati row
    -- sequencing to bump up its next value.
    --
    -- So the question is, in what tables and fields is the unique notification ID stored, that it would
    -- need to be adjusted during a switchover to internally-generated unique ID values?
    --
    -- We find the following fields that definitely contain the external ID (unique ID, notification ID)
    -- as originally provided by the alerting agent via the -u option:
    --
    --     tmp_commands.external_id
    --     notification_logs.incident_id   (with some exceptions not matching tmp_commands.external_id)
    --     escalation_stati.incident_id
    --
    -- Other fields in various tables contain similar-looking numbers, but they are not the same as
    -- these specific ID values.
    --
    -- The values we are likely to encounter in an existing database are of two forms:
    --
    -- * low-numbered values, probably originating as the Nagios $HOSTNOTIFICATIONID$ macro
    --   or $SERVICENOTIFICATIONID$ value (both very poor choices to begin with) or the Nagios
    --   $HOSTPROBLEMID$ or $SERVICEPROBLEMID$ values (reasonable and acceptable macro values
    --   to pass as the alert-script -u option).
    --
    -- * high-numbered values, representing a 10-digit UNIX epoch timestamp appended by 1 to 5 random
    --   digits.  (The number of appeneded digits should have been normalized to always be 5; we have
    --   done so in our corrected copy of NoMa.)
    --
    -- As part of our processing, we map certain unique-ID values (that we want to move out of the way
    -- to avoid possible future collisions) to a range of 10-digit numbers which should never collide
    -- with either these existing ranges or with any future internally-generated unique IDs.  This range
    -- starts with 1000000000 (that is, 1,000,000,000).  Being a 10-digit number representing a UNIX
    -- epoch timestamp back in 2001, before NoMa was even born, these remapped values cannot conflict
    -- with any previously generated random values, which would have at least one additional digit
    -- appended, and also cannot reasonably conflict with low-numbered values from Nagios.
    --
    -- Here is the update process:
    --
    -- (1) Move all tmp_commands.external_id values less than 10000000000 to their existing values
    --     plus 1000000000.  This will get them into a numbering range which will be less than any
    --     auto-generated unique-ID values, so as not to be confused with them, while being greater
    --     than any future generated ID values if they do not get renumbered in the rest of this
    --     process.  That will effectively block future conflicts from happening.
    --
    -- (2) Move all notification_logs.incident_id values according to the same rule.
    --
    -- (3) Move all escalation_stati.incident_id values according to the same rule.
    --
    -- (4) Take the tmp_commands.external_id value as the definitive unique-ID value that all others are
    --     to be matched to.
    --
    -- (5) If the notification_logs.incident_id has a matching tmp_commands.external_id, map the
    --     notification_logs.incident_id value to the corresponding notification_stati.id value (by
    --     matching host and service name).
    --
    -- (6) If the escalation_stati.incident_id has a matching tmp_commands.external_id, map the
    --     escalation_stati.incident_id value to the corresponding notification_stati.id value (by
    --     matching host and service name).
    --
    -- (7) Map the tmp_commands.external_id value to the corresponding notification_stati.id value (by
    --     matching host and service name).
    --
    -- (8) Leave everything else alone.

    -- ================================================================================================

    -- (-1):  In some of the updates below, we are joining to the tmp_commands table on the host and
    -- service fields, but the standard database has no index on those fields.  I am therefore somewhat
    -- concerned about the efficiency of these operations.  There is no definitive evidence that an
    -- index would help, but possibly a customer site might have a rather large historical database that
    -- could take a long time to convert.  To give PostgreSQL every possible opportunity to optimize
    -- these operations, we create a temporary index on the tmp_commands table for these fields.  This
    -- is the only table I'm concerned with; other sensible indexes should already be part of the "noma"
    -- database.  The index we create here is apparently not needed by the NoMa code itself, which is
    -- why we don't just create it on a permanent basis outide of this script.
    --
    -- Though this is to some extent a schema change, it does not seem to violate the sanctity of the
    -- transaction within which this function will be executed.  If the transaction fails, the index
    -- will be dropped automatically.  We do drop it explicitly at the end of this function.
    --
    -- PostgreSQL 9.4.X has no "CREATE INDEX IF NOT EXISTS" statement; that form is not available until
    -- PostgreSQL 9.5.x.  But the to_regclass() function for getting the OID of the named relation or
    -- NULL if it does not exist, used here to effectively test for the existence of an index without
    -- throwing an exception, is available as of PostgreSQL 9.4.X.
    --
    IF to_regclass('tmp_commands_host_service') IS NULL THEN
	CREATE INDEX tmp_commands_host_service ON tmp_commands USING btree (host, service);
    END IF;

    -- (0):  Check to see if this script has been run before, with a useful but non-definitive test.
    -- If you get a (non-fatal) INFO message here, that will be an indication that this script has been
    -- run before.  The logic here is slightly forgiving and allows this script to be run up to about
    -- nine times before this becomes problematic.  This is a convenience warning; if you convert too
    -- many times, it will silently stop raising any alarm.  So you shouldn't just repeatedly convert
    -- the same database with abandon.
    perform
	incident_id
    from
	notification_logs
    where
	incident_id >= 1000000000
    and incident_id < 10000000000
    ;
    IF FOUND THEN
	RAISE INFO 'Found some previously converted NoMa data:  some notification_logs rows have incident_id values in the reserved range.';
    END IF;

    -- (1), (2), (3):  Move low-numbered unique incident ID values out of the way of both high-numbered
    -- values originating in timestamp.random construction and low-numbered values probably originating
    -- from external sources.  This should leave the field clear for future auto-incremented values of
    -- the notification_stat.id field to be used as stable incident ID values for specific host/service
    -- pairs as long as they remain in non-UP/OK states.  This transform preserves matches of ID values
    -- across tables.  Further transforms will re-map values to notification_stati.id values when that
    -- is possible, possibly leaving some fraction of the original values still in this middle range.
    --
    update tmp_commands      set external_id = external_id + 1000000000 where external_id < 10000000000;
    update notification_logs set incident_id = incident_id + 1000000000 where incident_id < 10000000000;
    update escalation_stati  set incident_id = incident_id + 1000000000 where incident_id < 10000000000;

    -- (4):  There is nothing to do yet for tmp_commands.external_id; see step (7).  For the time being,
    -- we need to preserve the content of the tmp_commands table so it can be used as an intermediary
    -- while updating the notification_logs and escalation_stati tables.

    -- (5):  Update notification_logs.incident_id if possible, to its final value.

    -- The action is tricky here.  We need to join the notification_logs table to the notification_stati
    -- table, using the tmp_commands table as an intermediary.  But some rows in the notification_logs
    -- may have no corresponding row(s) in the tmp_commands table, and some rows in the tmp_commands
    -- table may have no corresponding row in the notification_stati table.  So the SQL statement used
    -- to perform this updating must take those possibilities into account.  Otherwise, we could end up
    -- setting the notification_logs.incident_id field in some rows to a NULL value.

    -- This query should yield 0 rows, thereby proving claim (a) below.
    perform
	external_id,
	count(*)
    from
	(
	select distinct
	    external_id,
	    host,
	    service
	from
	    tmp_commands tc
	) as distinct_triples
    group by external_id
    having count(*) > 1
    ;
    if FOUND THEN
	RAISE EXCEPTION 'Found bad NoMa data:  some tmp_command rows with identical external_id have different host and/or service.';
    END IF;

    -- This query should yield 0 rows, thereby proving claim (b) below.
    perform
	host,
	service,
	count(*)
    from
	notification_stati
    group by host, service
    having count(*) > 1
    ;
    if FOUND THEN
	RAISE EXCEPTION 'Found bad NoMa data:  have multiple notification_stati rows with identical host and service.';
    END IF;

    update notification_logs nl
	set incident_id = ns.id
    from
	tmp_commands tc
	left join notification_stati ns on ns.host = tc.host and ns.service = tc.service
    where
	-- Ensure that we have a proper match between the notification_logs and tmp_commands tables.
	-- It's true that there may be more than one tc row with the same external_id field, so this
	-- clause might match more than one row in the "tc left join ns" temporary table.  But it will
	-- turn out that (a) all such rows will have exactly the same tc host and service fields, and
	-- (b) there will be at most one matching ns row with those host and service fields, so (c)
	-- there will be no ambiguity as to what ns.id value to update the nl.incident_id field with,
	-- if a particular nl row can be updated at all.  If there were any question about the (a) and
	-- (b) assertions, we could programmatically check the results of the preceding queries to prove
	-- them (as we have now done, just above).  I don't know what kind of error would be thrown if
	-- there were some degree of ambiguity as to what value to use to update a given row in the
	-- notification_logs table.
	nl.incident_id = tc.external_id

	-- Also ensure that we have a proper match between the tmp_commands and notification_stati
	-- tables.  If we instead equated nl and tc table fields here, that would ignore the fact that
	-- if the tc table has no matching ns table row, the ns fields will be NULL, which would mean
	-- that the ns.id field would also be NULL.  We need to exclude such notification_logs rows from
	-- being updated.  The same things could have been done by comparing nl and tc host and service
	-- fields and then also adding any or all of "and ns.id IS NOT NULL", "and ns.host IS NOT NULL",
	-- or "and ns.service IS NOT NULL" clauses to further filter the results.  But we choose the
	-- simpler approach without those extra clauses, even if it does require this long comment to
	-- ensure accuracy.
    and nl.host    = ns.host
    and nl.service = ns.service
    ;

    -- (6):  Update escalation_stati.incident_id if possible, to its final value.

    -- The action is tricky here.  We need to join the escalation_stati table to the notification_stati
    -- table, using the tmp_commands table as an intermediary.  But some rows in the escalation_stati
    -- may have no corresponding row(s) in the tmp_commands table, and some rows in the tmp_commands
    -- table may have no corresponding row in the notification_stati table.  So the SQL statement used
    -- to perform this updating must take those possibilities into account.  Otherwise, we could end up
    -- setting the escalation_stati.incident_id field in some rows to a NULL value.

    -- This query should yield 0 rows, thereby proving claim (a) below.
    perform
	external_id,
	count(*)
    from
	(
	select distinct
	    external_id,
	    host,
	    service
	from
	    tmp_commands tc
	) as distinct_triples
    group by external_id
    having count(*) > 1
    ;
    if FOUND THEN
	RAISE EXCEPTION 'Found bad NoMa data:  some tmp_command rows with identical external_id have different host and/or service.';
    END IF;

    -- This query should yield 0 rows, thereby proving claim (b) below.
    perform
	host,
	service,
	count(*)
    from
	notification_stati
    group by host, service
    having count(*) > 1
    ;
    if FOUND THEN
	RAISE EXCEPTION 'Found bad NoMa data:  have multiple notification_stati rows with identical host and service.';
    END IF;

    update escalation_stati es
	set incident_id = ns.id
    from
	tmp_commands tc
	left join notification_stati ns on ns.host = tc.host and ns.service = tc.service
    where
	-- Ensure that we have a proper match between the escalation_stati and tmp_commands tables.
	-- It's true that there may be more than one tc row with the same external_id field, so this
	-- clause might match more than one row in the "tc left join ns" temporary table.  But it will
	-- turn out that (a) all such rows will have exactly the same tc host and service fields, and
	-- (b) there will be at most one matching ns row with those host and service fields, so (c)
	-- there will be no ambiguity as to what ns.id value to update the es.incident_id field with,
	-- if a particular es row can be updated at all.  If there were any question about the (a) and
	-- (b) assertions, we could programmatically check the results of the preceding queries to prove
	-- them (as we have now done, just above).  I don't know what kind of error would be thrown if
	-- there were some degree of ambiguity as to what value to use to update a given row in the
	-- escalation_stati table.
	es.incident_id = tc.external_id

	-- Also ensure that we have a proper match between the tmp_commands and notification_stati
	-- tables.  If we instead equated es and tc table fields here, that would ignore the fact that
	-- if the tc table has no matching ns table row, the ns fields will be NULL, which would mean
	-- that the ns.id field would also be NULL.  We need to exclude such escalation_stati rows from
	-- being updated.  The same things could have been done by comparing es and tc host and service
	-- fields and then also adding any or all of "and ns.id IS NOT NULL", "and ns.host IS NOT NULL",
	-- or "and ns.service IS NOT NULL" clauses to further filter the results.  But we choose the
	-- simpler approach without those extra clauses, even if it does require this long comment to
	-- ensure accuracy.
    and es.host    = ns.host
    and es.service = ns.service
    ;

    -- (7):  Update tmp_commands.external_id if possible, to its final value.

    update tmp_commands tc
	set external_id = ns.id
    from
	notification_stati ns
    where
	ns.host    = tc.host
    and ns.service = tc.service
    ;

    -- (8):  Leave everything else alone.

    -- (9):  Clean up the scaffolding we used.

    DROP INDEX IF EXISTS tmp_commands_host_service;

END;
$$ LANGUAGE plpgsql;
\set QUIET off

\set QUIET on
begin transaction;
\pset tuples_only on
-- There seems not to be any way to prevent this SELECT from printing two blank lines, despite our
-- having turned tuples-only mode on.  I suppose we could redirect the output to /dev/null, but that
-- seems excessive and we don't want to suppress messages that might appear upon failure.
SELECT convert_noma_external_id_values();
\pset tuples_only off
-- For script-debuggng purposes, uncomment the following line so we don't make any changes to the data.
-- rollback;
commit;
\set QUIET off

\set QUIET on
DROP FUNCTION IF EXISTS convert_noma_external_id_values();
\set QUIET off

-- That's all, folks!
\echo ''
\echo NoMa data has been converted.
\echo ''
\q

